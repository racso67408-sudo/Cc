# CC-shops · paquete de servidor V1.0003

Guía completa: `docs/DESPLIEGUE-SERVIDOR.md`.

Archivos de despliegue en `deploy/`:
- `cc-shops.env.example`: variables de producción (copiar a `/etc/cc-shops/cc-shops.env`).
- `cc-shops.service`: servicio de systemd.
- `Caddyfile`: HTTPS automático para la plataforma y los dominios propios.
- `cloudflared.yml.example`: alternativa con túnel de Cloudflare.
- `backup.sh`: copia de seguridad de la base de datos.

Arranque rápido (sin systemd, solo para probar):
    CC_ENV=production CC_SUPERADMIN_PASSWORD=... CC_ADMIN_PASSWORD=... CC_OPERADOR_PASSWORD=... python3 app.py
