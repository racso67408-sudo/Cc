#!/usr/bin/env bash
# Copia de seguridad de la base de datos.
#  - SQLite (por defecto): copia en caliente con la API de backup.
#  - PostgreSQL (si CC_DATABASE_URL está definida): pg_dump en formato comprimido.
# Uso: sudo -u ccshops /opt/cc-shops/deploy/backup.sh
# Programa en cron: 0 3 * * * /opt/cc-shops/deploy/backup.sh
set -euo pipefail
set -a; . /etc/cc-shops/cc-shops.env; set +a
DESTINO="${CC_BACKUP_DIR:-/var/backups/cc-shops}"
mkdir -p "$DESTINO"
MARCA="$(date +%Y%m%d-%H%M%S)"
cd /opt/cc-shops
if [[ "${CC_DATABASE_URL:-}" == postgres* ]]; then
    ARCHIVO="$DESTINO/cc_shops-$MARCA.dump"
    pg_dump --format=custom --no-owner --file "$ARCHIVO" "$CC_DATABASE_URL"
    echo "Copia creada: $ARCHIVO"
    ls -1t "$DESTINO"/*.dump 2>/dev/null | tail -n +31 | xargs -r rm -f
else
    python3 - "$DESTINO" "$MARCA" <<'PY'
import sys
from pathlib import Path
from server import db
ruta = db.backup(Path(sys.argv[1]) / f"cc_shops-{sys.argv[2]}.db")
print(f"Copia creada: {ruta}")
PY
    ls -1t "$DESTINO"/*.db 2>/dev/null | tail -n +31 | xargs -r rm -f
fi
