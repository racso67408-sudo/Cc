"""Alta de tiendas por el propio cliente: propietario, dirección única y configuración neutra."""
from __future__ import annotations

from server import api, ratelimit, tiendas

from .harness import BaseCase

DATOS = {
    "nombre_negocio": "Estética Luna",
    "nombre": "Marta Luna",
    "email": "marta@estetica-luna.test",
    "password": "MartaLuna2026",
}


class RegistroTienda(BaseCase):
    demo = True

    def setUp(self):
        super().setUp()
        ratelimit.reset_all()

    def registrar(self, **cambios):
        datos = {**DATOS, **cambios}
        return api.dispatch("POST", "/api/auth/registrar-tienda", {}, datos,
                            {"x-cc-request": "1", "x-cc-client-ip": "10.0.1.1"})

    def test_normaliza_la_direccion(self):
        self.assertEqual(tiendas.normalizar_slug("Estética Luna & Co."), "estetica-luna-co")
        self.assertEqual(tiendas.normalizar_slug("  Mi  Tienda 2 "), "mi-tienda-2")

    def test_alta_crea_tienda_propietario_y_sesion(self):
        r = self.registrar()
        self.assertEqual(r.status, 201, r.payload)
        self.assertEqual(r.payload["tienda"]["slug"], "estetica-luna")
        self.assertEqual(r.payload["usuario"]["rol"], "admin")
        self.assertIn("cc_shops_session=", r.headers["Set-Cookie"])
        self.assertNotIn("password", str(r.payload).lower())

    def test_el_propietario_ve_su_panel_vacio_y_sin_datos_de_la_demo(self):
        r = self.registrar()
        self.cookie = r.headers["Set-Cookie"].split(";", 1)[0]
        self.assertEqual(self.api("GET", "/api/admin/productos").payload["items"], [])
        ajustes = self.api("GET", "/api/admin/ajustes").payload["ajustes"]
        self.assertEqual(ajustes["tienda_nombre"], "Estética Luna")
        self.assertEqual(ajustes["tienda_email"], "marta@estetica-luna.test")
        self.assertEqual(ajustes["aviso_pago"], "")
        self.assertEqual(ajustes["tienda_telefono"], "")
        self.assertEqual(self.api("GET", "/api/admin/ajustes").payload["tienda_slug"], "estetica-luna")

    def test_la_tienda_publica_muestra_su_nombre_y_no_la_demo(self):
        self.registrar()
        config = api.dispatch("GET", "/api/public/config", {}, {}, {"x-cc-client-ip": "10.0.1.2", "x-tienda": "estetica-luna"}).payload
        self.assertEqual(config["tienda"]["nombre"], "Estética Luna")
        self.assertEqual(config["tienda"]["aviso_pago"], "")
        self.assertEqual(config["total_productos"], 0)

    def test_direccion_duplicada_reservada_o_no_valida(self):
        self.assertEqual(self.registrar().status, 201)
        self.assertEqual(self.registrar(email="otra@x.test", nombre_negocio="Estética Luna").status, 409)
        self.assertEqual(self.registrar(email="otra2@x.test", nombre_negocio="Admin").status, 400)
        r = self.registrar(email="otra3@x.test", nombre_negocio="Tienda", slug="ab")
        self.assertEqual(r.status, 400)
        self.assertEqual(r.payload["campo"], "slug")
        r = self.registrar(email="otra4@x.test", nombre_negocio="Tienda", slug="Mi_Tienda")
        self.assertEqual(r.status, 201)
        self.assertEqual(r.payload["tienda"]["slug"], "mi-tienda")

    def test_email_y_contrasena(self):
        self.assertEqual(self.registrar().status, 201)
        r = self.registrar(nombre_negocio="Otra Tienda")
        self.assertEqual(r.status, 409)
        self.assertEqual(r.payload["campo"], "email")
        r = self.registrar(email="corto@x.test", nombre_negocio="Otra Tienda 2", password="abc")
        self.assertEqual(r.status, 400)
        self.assertEqual(r.payload["campo"], "password")

    def test_limite_de_intentos(self):
        for i in range(5):
            self.assertEqual(self.registrar(email=f"u{i}@x.test", nombre_negocio=f"Tienda {i}").status, 201)
        self.assertEqual(self.registrar(email="u9@x.test", nombre_negocio="Tienda 9").status, 429)

    def test_el_propietario_puede_cambiar_ajustes_y_el_tema(self):
        r = self.registrar()
        self.cookie = r.headers["Set-Cookie"].split(";", 1)[0]
        self.assertEqual(self.api("PUT", "/api/admin/ajustes", {"tema_tienda": "tech"}).status, 200)
