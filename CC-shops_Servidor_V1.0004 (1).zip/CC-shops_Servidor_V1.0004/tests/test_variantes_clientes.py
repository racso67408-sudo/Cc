"""Variantes de producto y cuentas de cliente (compra como invitado, activación, ficha)."""
from __future__ import annotations

import re
from datetime import datetime, timedelta

from server import api, correo, db, ratelimit
from server.util import iso_now

from .harness import BaseCase


class Variantes(BaseCase):
    def setUp(self):
        super().setUp()
        self.padre = self.api("POST", "/api/admin/productos", {
            "nombre": "Camiseta lisa", "sku": "CAM-1", "precio": 12, "iva": 21, "stock_inicial": 0,
            "stock_minimo": 0, "unidad": "ud", "coste": 3}).payload["producto"]

    def variante(self, talla="M", color="Rojo", stock=5, **extra):
        r = self.api("POST", f"/api/admin/productos/{self.padre['id']}/variantes",
                     {"atributos": {"Talla": talla, "Color": color}, "stock_inicial": stock, "coste": 3, **extra})
        self.assertEqual(r.status, 201, r.payload)
        return r.payload["producto"]

    def stock(self, pid):
        return float(self.producto_db(pid)["stock"])

    def test_el_padre_suma_el_stock_de_sus_variantes(self):
        self.variante("M", "Rojo", 5)
        self.variante("L", "Azul", 3)
        self.assertEqual(self.stock(self.padre["id"]), 8)

    def test_las_variantes_no_aparecen_en_el_listado_pero_si_en_la_ficha(self):
        v = self.variante("M", "Rojo", 5)
        listado = self.api("GET", "/api/admin/productos").payload["items"]
        self.assertNotIn(v["id"], [p["id"] for p in listado])
        ficha = api.dispatch("GET", "/api/public/productos/camiseta-lisa", {}, {}, {"x-tienda": "demo", "x-cc-client-ip": "10.6.1.1"})
        self.assertEqual(ficha.status, 200, ficha.payload)
        self.assertEqual(ficha.payload["variantes"][0]["id"], v["id"])
        self.assertEqual(ficha.payload["variantes"][0]["atributos"], {"Talla": "M", "Color": "Rojo"})

    def test_combinacion_repetida_y_atributos_no_validos(self):
        self.variante("M", "Rojo", 1)
        self.assertEqual(self.api("POST", f"/api/admin/productos/{self.padre['id']}/variantes", {"atributos": {"Talla": "M", "Color": "Rojo"}}).status, 409)
        self.assertEqual(self.api("POST", f"/api/admin/productos/{self.padre['id']}/variantes", {"atributos": {}}).status, 400)
        self.assertEqual(self.api("POST", f"/api/admin/productos/{self.padre['id']}/variantes",
                                  {"atributos": {"a": "1", "b": "2", "c": "3", "d": "4"}}).status, 400)

    def test_no_se_puede_vender_el_padre_con_variantes(self):
        self.variante("M", "Rojo", 5)
        with db.session(write=True) as conn:
            from server import orders
            from server.util import ApiError
            with self.assertRaises(ApiError):
                orders.crear_pedido(conn, {"cliente": {"nombre": "Ana", "email": "ana@x.es"}, "items": [{"producto_id": self.padre["id"], "cantidad": 1}],
                                           "metodo_pago": "contrareembolso", "tipo_entrega": "recogida"}, tienda_id=self.user["tienda_id"])

    def test_vender_una_variante_descuenta_solo_esa_y_cancelar_la_devuelve(self):
        v = self.variante("M", "Rojo", 5)
        p = self.crear_pedido([{"producto_id": v["id"], "cantidad": 2}], metodo_pago="contrareembolso", tipo_entrega="envio_propio")
        self.assertEqual(self.stock(v["id"]), 3)
        self.assertEqual(self.stock(self.padre["id"]), 3)
        self.api("POST", f"/api/admin/pedidos/{p['id']}/cancelar", {"motivo": "prueba"})
        self.assertEqual(self.stock(v["id"]), 5)
        self.assertEqual(self.stock(self.padre["id"]), 5)

    def test_desactivar_una_variante_la_quita_de_la_ficha(self):
        v = self.variante("M", "Rojo", 5)
        self.api("PUT", f"/api/admin/productos/{self.padre['id']}/variantes/{v['id']}", {"activa": False})
        ficha = api.dispatch("GET", "/api/public/productos/camiseta-lisa", {}, {}, {"x-tienda": "demo", "x-cc-client-ip": "10.6.1.2"})
        self.assertEqual(ficha.payload["variantes"], [])

    def test_admin_ve_las_variantes_dentro_del_padre(self):
        self.variante("M", "Rojo", 5)
        self.variante("L", "Azul", 2)
        detalle = self.api("GET", f"/api/admin/productos/{self.padre['id']}").payload["producto"]
        self.assertEqual(len(detalle["variantes"]), 2)

    def crear_pedido(self, items, **extra):
        extra = {"tipo_entrega": "envio_propio", **extra}
        with db.session(write=True) as conn:
            from server import orders
            creado = orders.crear_pedido(conn, {"cliente": {"nombre": "Venta Test", "email": "venta@x.es", "telefono": "600000000",
                                                            "direccion": "Calle 1", "ciudad": "Terrassa", "cp": "08221", "provincia": "Barcelona"},
                                                "items": items, **extra}, tienda_id=self.user["tienda_id"])
        return creado


class Clientes(BaseCase):
    def setUp(self):
        super().setUp()
        correo.SIMULADOS.clear()
        ratelimit.reset_all()
        self.tid = self.user["tienda_id"]
        self.cookie_tienda = self.cookie
        self.producto = self.nuevo_producto(nombre="Pendiente cliente", sku="CLI-1", stock_inicial=20, coste=2, precio=10)

    def comprar_invitado(self, email="lucia@cliente.test", nombre="Lucía Compradora", ip="10.7.0.1"):
        datos = {"cliente": {"nombre": nombre, "email": email, "telefono": "611222333", "direccion": "Calle Sol 4",
                             "ciudad": "Terrassa", "cp": "08221", "provincia": "Barcelona"},
                 "items": [{"producto_id": self.producto["id"], "cantidad": 2}],
                 "metodo_pago": "contrareembolso", "tipo_entrega": "envio_propio"}
        r = api.dispatch("POST", "/api/public/pedidos", {}, datos, {"x-tienda": "demo", "x-cc-client-ip": ip, "x-cc-request": "1"})
        self.assertEqual(r.status, 201, r.payload)
        return r.payload

    def token_del_ultimo_correo(self):
        return re.search(r"token=([A-Za-z0-9_\-]+)", correo.SIMULADOS[-1]["body"]).group(1)

    def activar(self, token, password="ClaveNueva-123"):
        return api.dispatch("POST", "/api/auth/activar", {}, {"token": token, "password": password}, {"x-cc-request": "1", "x-cc-client-ip": "10.7.9.9"})

    def test_compra_como_invitado_crea_la_cuenta_y_envia_el_enlace(self):
        pedido = self.comprar_invitado()
        self.assertEqual(len(correo.SIMULADOS), 1)
        self.assertEqual(correo.SIMULADOS[-1]["to"], "lucia@cliente.test")
        self.assertIn("#/cuenta/activar?token=", correo.SIMULADOS[-1]["body"])
        with db.session() as conn:
            u = db.one(conn, "SELECT rol, tienda_id, activo FROM usuarios WHERE email='lucia@cliente.test'")
            p = db.one(conn, "SELECT cliente_id FROM pedidos WHERE id=?", (pedido["id"],))
        self.assertEqual(u["rol"], "cliente")
        self.assertEqual(u["tienda_id"], self.tid)
        self.assertIsNotNone(p["cliente_id"])

    def test_el_enlace_activa_la_cuenta_una_sola_vez(self):
        self.comprar_invitado()
        token = self.token_del_ultimo_correo()
        self.assertEqual(self.activar(token).status, 200)
        self.assertEqual(self.activar(token).status, 400)  # ya usado
        self.cookie = None
        r = self.login_cliente("lucia@cliente.test", "ClaveNueva-123")
        self.assertIn("usuario", r)

    def test_enlace_caducado_no_sirve(self):
        self.comprar_invitado()
        token = self.token_del_ultimo_correo()
        with db.session(write=True) as conn:
            conn.execute("UPDATE tokens_cuenta SET expira_at=?", ((datetime.now().astimezone() - timedelta(days=1)).isoformat(timespec="seconds"),))
        self.assertEqual(self.activar(token).status, 400)

    def test_contraseña_debil_no_activa(self):
        self.comprar_invitado()
        self.assertEqual(self.activar(self.token_del_ultimo_correo(), password="corta").status, 400)

    def test_cuenta_existente_de_la_tienda_vincula_sin_enviar_correo(self):
        self.comprar_invitado()
        self.activar(self.token_del_ultimo_correo())
        correo.SIMULADOS.clear()
        self.comprar_invitado(ip="10.7.0.2")
        self.assertEqual(correo.SIMULADOS, [])
        with db.session() as conn:
            n = db.one(conn, "SELECT COUNT(*) AS n FROM pedidos WHERE cliente_email='lucia@cliente.test' AND cliente_id IS NOT NULL")["n"]
        self.assertEqual(n, 2)

    def test_cuenta_de_otra_tienda_no_se_vincula(self):
        with db.session(write=True) as conn:
            conn.execute("INSERT INTO tiendas (id, slug, nombre, estado, dominio_provisional, config, created_at, updated_at) "
                         "VALUES ('TOTRA','otra-cli','Otra','activa','','{}',?,?)", (iso_now(), iso_now()))
            conn.execute("INSERT INTO usuarios (id, nombre, email, password_hash, rol, tienda_id, activo, session_version, ultimo_acceso, created_at) "
                         "VALUES ('USRX','Ajena','ajena@cliente.test','x','cliente','TOTRA',1,0,'',?)", (iso_now(),))
        pedido = self.comprar_invitado(email="ajena@cliente.test", ip="10.7.0.3")
        with db.session() as conn:
            p = db.one(conn, "SELECT cliente_id FROM pedidos WHERE id=?", (pedido["id"],))
        self.assertIsNone(p["cliente_id"])
        self.assertEqual(correo.SIMULADOS, [])

    def test_reenviar_enlace_responde_igual_exista_o_no(self):
        self.comprar_invitado()
        a = api.dispatch("POST", "/api/auth/reenviar-activacion", {}, {"email": "lucia@cliente.test"}, {"x-tienda": "demo", "x-cc-client-ip": "10.7.1.1", "x-cc-request": "1"})
        b = api.dispatch("POST", "/api/auth/reenviar-activacion", {}, {"email": "nadie@x.test"}, {"x-tienda": "demo", "x-cc-client-ip": "10.7.1.2", "x-cc-request": "1"})
        self.assertEqual((a.status, a.payload), (b.status, b.payload))
        self.assertGreaterEqual(len(correo.SIMULADOS), 2)

    def test_ficha_de_cliente_para_el_administrador(self):
        self.comprar_invitado()
        self.comprar_invitado(ip="10.7.0.4")
        lista = self.api("GET", "/api/admin/clientes").payload["items"]
        cliente = [c for c in lista if c["email"] == "lucia@cliente.test"][0]
        self.assertEqual(cliente["pedidos"], 2)
        with db.session() as conn:
            esperado = db.one(conn, "SELECT COALESCE(SUM(total),0) AS t FROM pedidos WHERE LOWER(cliente_email)='lucia@cliente.test' AND estado<>'cancelado'")["t"]
        self.assertAlmostEqual(cliente["gastado"], float(esperado), places=2)
        detalle = self.api("GET", "/api/admin/clientes/lucia@cliente.test").payload
        self.assertEqual(detalle["telefono"], "611222333")
        self.assertEqual(detalle["direccion"]["ciudad"], "Terrassa")
        self.assertEqual(len(detalle["pedidos"]), 2)

    def test_una_tienda_no_ve_los_clientes_de_otra(self):
        self.comprar_invitado()
        with db.session(write=True) as conn:
            conn.execute("INSERT INTO tiendas (id, slug, nombre, estado, dominio_provisional, config, created_at, updated_at) "
                         "VALUES ('TOTRA2','otra-cli2','Otra','activa','','{}',?,?)", (iso_now(), iso_now()))
            conn.execute("INSERT INTO pedidos (id, tienda_id, numero, cliente_nombre, cliente_email, estado, total, base, iva, envio, notas, stock_descontado, stock_devuelto, created_at, updated_at, pago_estado, metodo_pago, tipo_entrega, direccion, ciudad, cp, provincia, pais, cliente_telefono, nif, recogida_fecha, recogida_hora, envio_cobro, envio_pagado, envio_cobrado, envio_pendiente, token) "
                         "VALUES ('PEDX','TOTRA2','PED-X-1','Ajena','ajena@otra.test','pendiente',10,8,2,0,'',0,0,?,?,'pendiente_verificacion','transferencia','recogida','','','','','España','','','','',0,0,0,0,'tok')", (iso_now(), iso_now()))
        lista = [c["email"] for c in self.api("GET", "/api/admin/clientes").payload["items"]]
        self.assertIn("lucia@cliente.test", lista)
        self.assertNotIn("ajena@otra.test", lista)
        self.assertEqual(self.api("GET", "/api/admin/clientes/ajena@otra.test").status, 404)

    def login_cliente(self, email, password):
        r = api.dispatch("POST", "/api/auth/login", {}, {"email": email, "password": password}, {"x-tienda": "demo", "x-cc-client-ip": "10.7.5.5", "x-cc-request": "1"})
        self.assertEqual(r.status, 200, r.payload)
        return r.payload
