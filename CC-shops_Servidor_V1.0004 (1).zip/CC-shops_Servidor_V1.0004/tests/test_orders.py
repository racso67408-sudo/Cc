"""Tests de pedidos: cálculo de totales, stock, estados y devolución al Kardex."""
from __future__ import annotations

import unittest

from server import kardex, orders
from server.db import one, session
from server.util import ApiError

from .harness import BaseCase


class OrderTests(BaseCase):
    def setUp(self):
        super().setUp()
        self.a = self.nuevo_producto(nombre="Producto A", sku="A-001", precio=10, coste=4, stock_inicial=10)
        self.b = self.nuevo_producto(nombre="Producto B", sku="B-001", precio=20, coste=8, stock_inicial=5)

    def test_creacion_calcula_totales_y_descuenta_stock(self):
        pedido = self.crear_pedido(
            [{"producto_id": self.a["id"], "cantidad": 2}, {"producto_id": self.b["id"], "cantidad": 1}]
        )
        self.assertEqual(pedido["estado"], "pendiente")
        self.assertAlmostEqual(pedido["total"], 40.00, places=2)
        fila = self.pedido_db(pedido["numero"])
        self.assertAlmostEqual(float(fila["total"]), 40.00, places=2)
        self.assertAlmostEqual(float(fila["base"]), 33.06, places=2)
        self.assertAlmostEqual(float(fila["iva"]), 6.94, places=2)
        self.assertAlmostEqual(float(fila["envio"]), 0.0, places=2)
        self.assertEqual(float(self.producto_db(self.a["id"])["stock"]), 8)
        self.assertEqual(float(self.producto_db(self.b["id"])["stock"]), 4)
        self.assertKardexCuadra(self.a["id"])
        self.assertKardexCuadra(self.b["id"])
        with session() as conn:
            movs = kardex.listar(conn, self.a["id"])
        self.assertEqual(movs[-1]["tipo"], "salida_venta")
        self.assertEqual(movs[-1]["documento_numero"], pedido["numero"])

    def test_los_precios_del_cliente_se_ignoran(self):
        pedido = self.crear_pedido(
            [{"producto_id": self.a["id"], "cantidad": 1, "precio": 0.01, "precio_unit": 0.01}]
        )
        self.assertAlmostEqual(pedido["total"], 10.00, places=2)

    def test_stock_insuficiente_no_crea_pedido(self):
        with self.assertRaises(ApiError) as ctx:
            self.crear_pedido([{"producto_id": self.a["id"], "cantidad": 99}])
        self.assertEqual(ctx.exception.status, 409)
        with session() as conn:
            self.assertEqual(one(conn, "SELECT COUNT(*) n FROM pedidos")["n"], 0)
            self.assertEqual(one(conn, "SELECT COUNT(*) n FROM movimientos WHERE tipo='salida_venta'")["n"], 0)

    def test_cancelar_devuelve_stock_y_es_idempotente(self):
        pedido = self.crear_pedido([{"producto_id": self.a["id"], "cantidad": 3}])
        with session(write=True) as conn:
            cancelado = orders.cancelar_pedido(conn, pedido["id"], nota="Cliente anula", usuario_id=self.user["id"])
        self.assertEqual(cancelado["estado"], "cancelado")
        self.assertEqual(float(self.producto_db(self.a["id"])["stock"]), 10)
        self.assertKardexCuadra(self.a["id"])
        with session() as conn:
            movs = kardex.listar(conn, self.a["id"])
        self.assertEqual(movs[-1]["tipo"], "entrada_devolucion")
        self.assertEqual(movs[-1]["documento_numero"], pedido["numero"])
        with self.assertRaises(ApiError):
            with session(write=True) as conn:
                orders.cancelar_pedido(conn, pedido["id"])

    def test_transiciones_de_estado(self):
        pedido = self.crear_pedido([{"producto_id": self.a["id"], "cantidad": 1}], tipo_entrega="recogida")
        with self.assertRaises(ApiError):
            with session(write=True) as conn:
                orders.cambiar_estado(conn, pedido["id"], "entregado")
        with session(write=True) as conn:
            orders.cambiar_estado(conn, pedido["id"], "pagado")
            orders.cambiar_estado(conn, pedido["id"], "preparando")
            orders.cambiar_estado(conn, pedido["id"], "preparado")
            enviado = orders.cambiar_estado(conn, pedido["id"], "enviado")
        self.assertEqual(enviado["estado"], "enviado")
        with session(write=True) as conn:
            entregado = orders.cambiar_estado(conn, pedido["id"], "entregado")
        self.assertEqual(entregado["estado"], "entregado")
        self.assertEqual(len(entregado["eventos"]), 6)  # pendiente + 5 transiciones
        with self.assertRaises(ApiError):
            with session(write=True) as conn:
                orders.cancelar_pedido(conn, pedido["id"])

    def test_consulta_publica_con_token(self):
        pedido = self.crear_pedido([{"producto_id": self.a["id"], "cantidad": 1}])
        with session() as conn:
            publico = orders.pedido_publico(conn, pedido["numero"], pedido["token"])
            self.assertEqual(publico["numero"], pedido["numero"])
            self.assertEqual(len(publico["lineas"]), 1)
            self.assertNotIn("token", publico)
            self.assertNotIn("coste_medio", publico["lineas"][0])
            with self.assertRaises(ApiError):
                orders.pedido_publico(conn, pedido["numero"], "token-inventado")

    def test_envio_gratis_a_partir_del_umbral(self):
        pedido = self.crear_pedido([{"producto_id": self.b["id"], "cantidad": 3}])
        self.assertAlmostEqual(pedido["total"], 60.0, places=2)
        self.assertEqual(float(self.pedido_db(pedido["numero"])["envio"]), 0.0)

    def test_contrareembolso_suma_recargo(self):
        # El recargo por defecto de la tienda (2,50 €) se suma al total del contrareembolso.
        pedido = self.crear_pedido([{"producto_id": self.a["id"], "cantidad": 1}], metodo_pago="contrareembolso")
        self.assertAlmostEqual(pedido["total"], 12.50, places=2)


if __name__ == "__main__":
    unittest.main()
