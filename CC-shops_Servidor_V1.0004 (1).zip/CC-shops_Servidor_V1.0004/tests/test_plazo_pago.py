"""Plazo de pago: el cliente tiene 8 h; después, el administrador tiene 24 h más antes de la cancelación automática."""
from __future__ import annotations

from datetime import datetime, timedelta

from server import db, orders
from server.util import parse_dt

from .harness import BaseCase


class PlazoPago(BaseCase):
    def setUp(self):
        super().setUp()
        self.producto = self.nuevo_producto(nombre="Plazo", sku="PLZ-1", stock_inicial=20, coste=2)

    def stock(self):
        return float(self.producto_db(self.producto["id"])["stock"])

    def pedido(self, metodo="transferencia", cantidad=3):
        return self.crear_pedido([{"producto_id": self.producto["id"], "cantidad": cantidad}], metodo_pago=metodo, tipo_entrega="recogida")

    def test_el_pedido_con_pago_previo_tiene_8_y_32_horas(self):
        p = self.pedido()
        d = self.pedido_db(p["numero"])
        ahora = datetime.now().astimezone()
        self.assertAlmostEqual((parse_dt(d["pago_vence_at"]) - ahora).total_seconds() / 3600, 8, delta=0.1)
        self.assertAlmostEqual((parse_dt(d["pago_cancela_at"]) - ahora).total_seconds() / 3600, 32, delta=0.1)

    def test_el_stock_queda_separado_mientras_no_se_paga(self):
        self.assertEqual(self.stock(), 20)
        self.pedido(cantidad=3)
        self.assertEqual(self.stock(), 17)

    def test_pasado_el_plazo_del_administrador_se_cancela_y_vuelve_el_stock(self):
        p = self.pedido(cantidad=3)
        with db.session(write=True) as conn:
            n = orders.procesar_vencimientos(conn, ahora=datetime.now().astimezone() + timedelta(hours=33))
        self.assertEqual(n, 1)
        d = self.pedido_db(p["numero"])
        self.assertEqual(d["estado"], "cancelado")
        self.assertEqual(d["pago_estado"], "cancelado_sin_pago")
        self.assertEqual(self.stock(), 20)
        notis = self.api("GET", "/api/admin/notificaciones").payload["items"]
        self.assertIn("pedido_cancelado_sin_pago", [x["tipo"] for x in notis])

    def test_antes_de_la_cancelacion_solo_esta_vencido(self):
        p = self.pedido()
        with db.session(write=True) as conn:
            self.assertEqual(orders.procesar_vencimientos(conn, ahora=datetime.now().astimezone() + timedelta(hours=9)), 0)
        d = self.api("GET", f"/api/admin/pedidos/{p['id']}").payload["pedido"]
        self.assertFalse(d["pago_vencido"])  # recién creado: aún dentro del plazo
        vencido = {"pago_estado": "pendiente_verificacion", "pago_vence_at": (datetime.now().astimezone() - timedelta(minutes=5)).isoformat()}
        self.assertTrue(orders._pago_vencido(vencido))
        self.assertEqual(self.pedido_db(p["numero"])["estado"], "pendiente")

    def test_un_pedido_pagado_no_se_cancela(self):
        p = self.pedido()
        self.api("POST", f"/api/admin/pedidos/{p['id']}/verificar-pago")
        with db.session(write=True) as conn:
            self.assertEqual(orders.procesar_vencimientos(conn, ahora=datetime.now().astimezone() + timedelta(days=3)), 0)
        self.assertEqual(self.pedido_db(p["numero"])["estado"], "pagado")

    def test_contrareembolso_no_tiene_plazo_de_pago(self):
        p = self.pedido(metodo="contrareembolso")
        self.assertEqual(self.pedido_db(p["numero"])["pago_cancela_at"], "")
        with db.session(write=True) as conn:
            self.assertEqual(orders.procesar_vencimientos(conn, ahora=datetime.now().astimezone() + timedelta(days=3)), 0)

    def test_pedidos_importados_con_fecha_no_caducan(self):
        from datetime import date
        datos = {"cliente": {"nombre": "Importado Test", "email": "imp@x.es", "telefono": "+34 600 000 000",
                             "direccion": "Calle 1 nº 2", "ciudad": "Terrassa", "cp": "08221", "provincia": "Barcelona"},
                 "items": [{"producto_id": self.producto["id"], "cantidad": 1}], "metodo_pago": "transferencia"}
        with db.session(write=True) as conn:
            creado = orders.crear_pedido(conn, datos, fecha=f"{date.today().isoformat()}T10:00:00+01:00", tienda_id=self.user["tienda_id"])
        self.assertEqual(self.pedido_db(creado["numero"])["pago_cancela_at"], "")

    def test_la_tienda_configura_los_plazos_y_el_aviso(self):
        self.assertEqual(self.api("PUT", "/api/admin/ajustes", {"pago_plazo_horas": "12", "pago_gracia_admin_horas": "48"}).status, 200)
        p = self.pedido()
        d = self.pedido_db(p["numero"])
        ahora = datetime.now().astimezone()
        self.assertAlmostEqual((parse_dt(d["pago_cancela_at"]) - ahora).total_seconds() / 3600, 60, delta=0.1)
        self.assertEqual(self.api("PUT", "/api/admin/ajustes", {"pago_plazo_horas": "0"}).status, 400)
        config = self.api("GET", "/api/public/config", auth=False).payload["tienda"]
        self.assertEqual(config["pago_plazo_horas"], 12)
        self.assertIn("12 horas", config["aviso_plazo_pago"])
        self.assertNotIn("{horas}", config["aviso_plazo_pago"])

    def test_el_pedido_publico_muestra_el_plazo(self):
        p = self.pedido()
        publico = self.api("GET", f"/api/public/pedidos/{p['numero']}", query={"t": p["token"]}, auth=False).payload
        self.assertTrue(publico["pago_vence_at"])
        self.assertFalse(publico["pago_vencido"])
