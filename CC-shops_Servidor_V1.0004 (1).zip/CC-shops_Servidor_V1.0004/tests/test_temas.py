"""Temas visuales: «clasico» (por defecto) y «tech», con ajuste propio para backoffice y tienda."""
from __future__ import annotations

from server import api

from .harness import OPERADOR_PASSWORD, BaseCase


class TemasTests(BaseCase):
    def test_por_defecto_ambos_temas_son_clasicos(self):
        ajustes = self.api("GET", "/api/admin/ajustes").payload["ajustes"]
        self.assertEqual(ajustes["tema_backoffice"], "clasico")
        self.assertEqual(ajustes["tema_tienda"], "clasico")

    def test_admin_cambia_tema_de_backoffice_y_tienda(self):
        r = self.api("PUT", "/api/admin/ajustes", {"tema_backoffice": "tech", "tema_tienda": "tech"})
        self.assertEqual(r.status, 200, r.payload)
        ajustes = self.api("GET", "/api/admin/ajustes").payload["ajustes"]
        self.assertEqual(ajustes["tema_backoffice"], "tech")
        self.assertEqual(ajustes["tema_tienda"], "tech")

    def test_tema_de_la_tienda_llega_a_la_web_publica(self):
        self.api("PUT", "/api/admin/ajustes", {"tema_tienda": "tech"})
        config = self.api("GET", "/api/public/config", auth=False).payload
        self.assertEqual(config["tienda"]["tema"], "tech")
        # El tema del backoffice no afecta a la tienda pública.
        self.api("PUT", "/api/admin/ajustes", {"tema_backoffice": "clasico"})
        self.assertEqual(self.api("GET", "/api/public/config", auth=False).payload["tienda"]["tema"], "tech")

    def test_tema_no_valido_se_rechaza(self):
        r = self.api("PUT", "/api/admin/ajustes", {"tema_tienda": "neon"})
        self.assertEqual(r.status, 400)
        self.assertEqual(r.payload.get("campo"), "tema_tienda")
        self.assertEqual(self.api("GET", "/api/admin/ajustes").payload["ajustes"]["tema_tienda"], "clasico")

    def test_operador_no_puede_cambiar_el_tema(self):
        cookie_admin = self.cookie
        self.cookie = self.login("equipo@ccshops.es", OPERADOR_PASSWORD)
        self.assertEqual(self.api("PUT", "/api/admin/ajustes", {"tema_backoffice": "tech"}).status, 403)
        self.cookie = cookie_admin
        self.assertEqual(self.api("GET", "/api/admin/ajustes").payload["ajustes"]["tema_backoffice"], "clasico")

    def test_cada_tienda_tiene_su_propio_tema(self):
        from server import db
        from server.util import iso_now
        with db.session(write=True) as conn:
            conn.execute("INSERT INTO tiendas (id, slug, nombre, estado, dominio_provisional, config, created_at, updated_at) "
                         "VALUES ('TDT','tienda-t','Tienda T','activa','','{}',?,?)", (iso_now(), iso_now()))
        self.api("PUT", "/api/admin/ajustes", {"tema_tienda": "tech"})
        otra = api.dispatch("GET", "/api/public/config", {}, {}, {"x-cc-client-ip": "10.0.0.20", "x-tienda": "tienda-t"}).payload
        self.assertEqual(otra["tienda"]["tema"], "clasico")

    def test_ajustes_incluyen_el_slug_de_la_tienda(self):
        self.assertEqual(self.api("GET", "/api/admin/ajustes").payload["tienda_slug"], "demo")
