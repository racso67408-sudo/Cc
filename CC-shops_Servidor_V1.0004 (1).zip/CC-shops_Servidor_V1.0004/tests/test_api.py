"""Tests de integración del router: auth, catálogo, pedidos y backoffice."""
from __future__ import annotations

import unittest

from server import api

from .harness import OPERADOR_PASSWORD, BaseCase


class ApiTests(BaseCase):
    demo = True

    def test_login_sesion_y_csrf(self):
        malo = api.dispatch(
            "POST", "/api/auth/login", {}, {"email": "admin@ccshops.es", "password": "nope"},
            {"x-cc-request": "1", "x-cc-client-ip": "10.1.0.1"},
        )
        self.assertEqual(malo.status, 401)
        sin_csrf = api.dispatch("POST", "/api/auth/login", {}, {}, {"x-cc-client-ip": "10.1.0.2"})
        self.assertEqual(sin_csrf.status, 403)
        yo = self.api("GET", "/api/auth/me")
        self.assertEqual(yo.status, 200)
        self.assertTrue(yo.payload["autenticado"])
        self.assertEqual(yo.payload["usuario"]["rol"], "admin")
        fuera = self.api("GET", "/api/admin/dashboard", auth=False)
        self.assertEqual(fuera.status, 401)

    def test_catalogo_publico(self):
        config = self.api("GET", "/api/public/config", auth=False)
        self.assertEqual(config.status, 200)
        self.assertEqual(config.payload["tienda"]["nombre"], "CC Shop's")
        self.assertEqual(len(config.payload["categorias"]), 6)
        self.assertEqual(len(config.payload["destacados"]), 4)
        self.assertNotIn("coste_medio", config.payload["destacados"][0])

        lista = self.api(
            "GET", "/api/public/productos", query={"categoria": "limpieza", "orden": "precio_asc"}, auth=False
        )
        self.assertEqual(lista.status, 200)
        self.assertGreater(lista.payload["total"], 0)
        precios = [p["precio"] for p in lista.payload["items"]]
        self.assertEqual(precios, sorted(precios))

        detalle = self.api("GET", "/api/public/productos/pestanas-clasicas-0-15-c-bandeja-16-lineas", auth=False)
        self.assertEqual(detalle.status, 200)
        self.assertEqual(detalle.payload["sku"], "PES-001")
        self.assertIn("relacionados", detalle.payload)
        self.assertNotIn("valor_stock", detalle.payload)

    def test_crud_producto_kardex_y_ajuste(self):
        creado = self.api(
            "POST",
            "/api/admin/productos",
            {
                "nombre": "Producto API",
                "sku": "API-001",
                "precio": 15.5,
                "iva": 21,
                "coste": 6.2,
                "stock_inicial": 12,
                "stock_minimo": 2,
            },
        )
        self.assertEqual(creado.status, 201, creado.payload)
        p = creado.payload["producto"]
        self.assertEqual(float(p["stock"]), 12)
        self.assertEqual(float(p["valor_stock"]), 74.4)

        editado = self.api("PUT", f"/api/admin/productos/{p['id']}", {"precio": 16.9, "destacado": True})
        self.assertEqual(editado.status, 200)
        self.assertEqual(editado.payload["producto"]["precio"], 16.9)

        ajuste = self.api(
            "POST",
            f"/api/admin/productos/{p['id']}/ajuste",
            {"nuevo_stock": 10, "motivo": "Merma en almacén"},
        )
        self.assertEqual(ajuste.status, 200)
        self.assertEqual(float(ajuste.payload["producto"]["stock"]), 10)

        kardex = self.api("GET", f"/api/admin/productos/{p['id']}/kardex")
        self.assertEqual(kardex.status, 200)
        self.assertEqual(len(kardex.payload["movimientos"]), 2)
        self.assertTrue(kardex.payload["verificacion"]["correcto"])
        self.assertEqual(kardex.payload["movimientos"][0]["tipo_label"], "Entrada · ajuste")

        lista = self.api("GET", "/api/admin/productos", query={"q": "API-001"})
        self.assertEqual(lista.payload["total"], 1)

        borrado = self.api("DELETE", f"/api/admin/productos/{p['id']}")
        self.assertEqual(borrado.status, 200)
        publico = self.api("GET", "/api/public/productos/producto-api", auth=False)
        self.assertEqual(publico.status, 404)

    def test_pedido_publico_y_gestion(self):
        config = self.api("GET", "/api/public/config", auth=False).payload
        producto = config["destacados"][0]
        antes = self.producto_db(producto["id"])

        creado = self.api(
            "POST",
            "/api/public/pedidos",
            {
                "cliente": {
                    "nombre": "Ana Prueba",
                    "email": "ana@example.com",
                    "direccion": "Calle Sol, 3",
                    "ciudad": "Terrassa",
                    "cp": "08221",
                },
                "items": [{"producto_id": producto["id"], "cantidad": 2}],
                "metodo_pago": "bizum",
            },
            auth=False,
        )
        self.assertEqual(creado.status, 201, creado.payload)
        numero, token = creado.payload["numero"], creado.payload["token"]
        despues = self.producto_db(producto["id"])
        self.assertEqual(float(despues["stock"]), float(antes["stock"]) - 2)

        publico = self.api("GET", f"/api/public/pedidos/{numero}", query={"t": token}, auth=False)
        self.assertEqual(publico.status, 200)
        self.assertEqual(publico.payload["numero"], numero)
        self.assertEqual(len(publico.payload["lineas"]), 1)
        sin_token = self.api("GET", f"/api/public/pedidos/{numero}", auth=False)
        self.assertEqual(sin_token.status, 403)

        bandeja = self.api("GET", "/api/admin/pedidos", query={"estado": "pendiente"})
        self.assertEqual(bandeja.status, 200)
        self.assertGreaterEqual(bandeja.payload["conteos"]["pendiente"], 1)

        detalle = self.api("GET", f"/api/admin/pedidos/{creado.payload['id']}")
        self.assertEqual(detalle.status, 200)
        self.assertEqual(detalle.payload["pedido"]["cliente"]["email"], "ana@example.com")

        pagado = self.api(
            "POST", f"/api/admin/pedidos/{creado.payload['id']}/estado", {"estado": "pagado", "nota": "Cobrado"}
        )
        self.assertEqual(pagado.status, 200)
        self.assertEqual(pagado.payload["pedido"]["estado"], "pagado")

        cancelado = self.api(
            "POST", f"/api/admin/pedidos/{creado.payload['id']}/cancelar", {"motivo": "Prueba de devolución"}
        )
        self.assertEqual(cancelado.status, 200)
        self.assertEqual(cancelado.payload["pedido"]["estado"], "cancelado")
        restaurado = self.producto_db(producto["id"])
        self.assertEqual(float(restaurado["stock"]), float(antes["stock"]))
        self.assertKardexCuadra(producto["id"])

    def test_dashboard_metricas_e_inventario(self):
        dashboard = self.api("GET", "/api/admin/dashboard")
        self.assertEqual(dashboard.status, 200)
        self.assertEqual(len(dashboard.payload["serie"]), 14)
        self.assertGreater(dashboard.payload["kpis"]["inventario_valor"], 0)
        self.assertGreaterEqual(len(dashboard.payload["top_productos"]), 1)
        self.assertEqual(len(dashboard.payload["bajo_stock"]), 0)

        metricas = self.api("GET", "/api/admin/metricas", query={"desde": "2026-09-01", "hasta": "2026-10-31"})
        self.assertEqual(metricas.status, 200)
        self.assertGreater(metricas.payload["kpis"]["ventas"], 0)
        self.assertIn("metodos_pago", metricas.payload)

        inventario = self.api("GET", "/api/admin/inventario")
        self.assertEqual(inventario.status, 200)
        self.assertGreater(inventario.payload["resumen"]["valor"], 0)
        self.assertGreater(len(inventario.payload["ultimos"]), 0)

        movimientos = self.api("GET", "/api/admin/movimientos", query={"tipo": "salida_venta"})
        self.assertEqual(movimientos.status, 200)
        self.assertGreater(movimientos.payload["total"], 0)
        self.assertTrue(all(m["tipo"] == "salida_venta" for m in movimientos.payload["items"]))

    def test_ajustes_solo_los_edita_el_admin(self):
        actual = self.api("GET", "/api/admin/ajustes")
        self.assertEqual(actual.status, 200)
        self.assertIn("tienda_nombre", actual.payload["ajustes"])

        cambio = self.api(
            "PUT",
            "/api/admin/ajustes",
            {"tienda_claim": "Nuevo claim de prueba", "envio_coste": 5.5},
        )
        self.assertEqual(cambio.status, 200)
        self.assertEqual(self.api("GET", "/api/admin/ajustes").payload["ajustes"]["tienda_claim"], "Nuevo claim de prueba")

        # El rol operador no puede cambiar los ajustes de la tienda.
        cookie_admin = self.cookie
        self.cookie = self.login("equipo@ccshops.es", OPERADOR_PASSWORD)
        denegado = self.api("PUT", "/api/admin/ajustes", {"tienda_claim": "No permitido"})
        self.assertEqual(denegado.status, 403)
        self.cookie = cookie_admin

    def test_categorias_y_proveedores(self):
        categoria = self.api("POST", "/api/admin/categorias", {"nombre": "Test cat", "descripcion": "x"})
        self.assertEqual(categoria.status, 201)
        cid = categoria.payload["categoria"]["id"]
        self.assertEqual(categoria.payload["categoria"]["slug"], "test-cat")
        actualizada = self.api("PUT", f"/api/admin/categorias/{cid}", {"nombre": "Test cat 2", "activo": True})
        self.assertEqual(actualizada.status, 200)
        borrada = self.api("DELETE", f"/api/admin/categorias/{cid}")
        self.assertEqual(borrada.status, 200)

        proveedor = self.api(
            "POST",
            "/api/admin/proveedores",
            {"nombre": "Proveedor Test", "email": "proveedor@example.com"},
        )
        self.assertEqual(proveedor.status, 201)
        lista = self.api("GET", "/api/admin/proveedores", query={"q": "Proveedor Test"})
        self.assertEqual(len(lista.payload["items"]), 1)


if __name__ == "__main__":
    unittest.main()


class ListadoAdminTests(BaseCase):
    demo = True

    def test_el_backoffice_puede_pedir_hasta_500_productos(self):
        self.assertEqual(self.api("GET", "/api/admin/productos", query={"por_pagina": "200"}).status, 200)
        self.assertEqual(self.api("GET", "/api/admin/productos", query={"por_pagina": "501"}).status, 400)
