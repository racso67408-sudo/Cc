"""Formulario de contacto: llega al correo de la cuenta del propietario, enviado desde la plataforma."""
from __future__ import annotations

import os
from unittest.mock import MagicMock, patch

from server import api, correo, ratelimit, tiendas

from .harness import BaseCase


class Contacto(BaseCase):
    demo = True

    def setUp(self):
        super().setUp()
        ratelimit.reset_all()
        correo.SIMULADOS.clear()

    def enviar(self, cuerpo, ip="10.0.9.1"):
        return api.dispatch("POST", "/api/public/contacto", {}, cuerpo, {"x-tienda": "demo", "x-cc-client-ip": ip, "x-cc-request": "1"})

    def mensaje(self, **extra):
        return {"nombre": "Lucía García", "email": "lucia@cliente.test", "empresa": "", "mensaje": "Necesito 20 cajas de guantes", **extra}

    def test_el_mensaje_va_al_correo_de_la_cuenta_del_propietario(self):
        with db_conn() as conn:
            esperado = tiendas.email_de_contacto(conn, self.user["tienda_id"])
        self.assertTrue(esperado)
        r = self.enviar(self.mensaje())
        self.assertEqual(r.status, 200, r.payload)
        self.assertEqual(correo.SIMULADOS[-1]["to"], esperado)
        self.assertEqual(correo.SIMULADOS[-1]["reply_to"], "lucia@cliente.test")

    def test_el_remitente_es_la_plataforma_y_no_hay_que_configurar_nada(self):
        self.assertIn("ccshops", correo.config_efectiva()["correo_remitente"].lower())
        with db_conn() as conn:
            self.assertEqual(tiendas.email_de_contacto(conn, self.user["tienda_id"]), self.user["email"])
        config = api.dispatch("GET", "/api/public/config", {}, {}, {"x-tienda": "demo", "x-cc-client-ip": "10.0.9.2"}).payload
        self.assertEqual(config["tienda"]["email"], self.user["email"])

    def test_envio_real_por_smtp_con_el_remitente_de_la_plataforma(self):
        env = {"CC_SMTP_HOST": "smtp.ejemplo.test", "CC_SMTP_PORT": "587", "CC_SMTP_USER": "u", "CC_SMTP_PASSWORD": "p", "CC_SMTP_TLS": "1"}
        smtp = MagicMock()
        with patch.dict(os.environ, env), patch("server.correo.smtplib.SMTP") as clase:
            clase.return_value.__enter__.return_value = smtp
            r = self.enviar(self.mensaje(), ip="10.0.9.3")
        self.assertEqual(r.status, 200)
        mensaje = smtp.send_message.call_args[0][0]
        self.assertIn("ccshops", mensaje["From"].lower())
        self.assertEqual(mensaje["Reply-To"], "lucia@cliente.test")
        self.assertEqual(mensaje["To"], self.user["email"])

    def test_fallo_del_servidor_de_correo_no_pierde_el_mensaje(self):
        env = {"CC_SMTP_HOST": "smtp.caido.test"}
        with patch.dict(os.environ, env), patch("server.correo.smtplib.SMTP", side_effect=OSError("sin conexión")):
            r = self.enviar(self.mensaje(), ip="10.0.9.4")
        self.assertEqual(r.status, 503)
        with db_conn() as conn:
            from server.db import one
            fila = one(conn, "SELECT estado FROM mensajes_contacto ORDER BY created_at DESC LIMIT 1")
        self.assertEqual(fila["estado"], "error")

    def test_campo_trampa_no_envia_nada(self):
        r = self.enviar(self.mensaje(website="spam"), ip="10.0.9.5")
        self.assertEqual(r.status, 200)
        self.assertEqual(correo.SIMULADOS, [])

    def test_validaciones(self):
        self.assertEqual(self.enviar(self.mensaje(email="no-es-email"), ip="10.0.9.6").status, 400)
        self.assertEqual(self.enviar(self.mensaje(mensaje="hola"), ip="10.0.9.7").status, 400)
        self.assertEqual(self.enviar(self.mensaje(nombre="A"), ip="10.0.9.8").status, 400)

    def test_limite_de_envios_por_ip(self):
        for _ in range(5):
            self.assertEqual(self.enviar(self.mensaje(), ip="10.0.9.9").status, 200)
        self.assertEqual(self.enviar(self.mensaje(), ip="10.0.9.9").status, 429)

    def test_ajustes_ya_no_permiten_cambiar_el_correo(self):
        self.api("PUT", "/api/admin/ajustes", {"tienda_email": "otro@x.test", "tienda_nombre": "Nombre nuevo"})
        self.assertEqual(self.api("GET", "/api/admin/ajustes").payload["ajustes"]["tienda_nombre"], "Nombre nuevo")
        self.assertEqual(self.api("GET", "/api/admin/ajustes").payload["ajustes"]["tienda_email"], self.user["email"])


def db_conn():
    from server import db
    return db.session()  # contexto que entrega una conexión abierta
