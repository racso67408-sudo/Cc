"""Landing de CC Shops: se muestra cuando no hay tienda identificada y no menciona la plataforma central."""
from __future__ import annotations

import re
import unittest
from pathlib import Path

from server import httpd

from .harness import BaseCase

RAIZ = Path(__file__).resolve().parent.parent
LANDING = RAIZ / "static" / "landing.html"
CSS = RAIZ / "static" / "css" / "landing.css"


class DecisionDeLanding(BaseCase):
    def test_sin_tienda_se_muestra_la_landing(self):
        self.assertFalse(httpd.es_tienda({}, {}))

    def test_con_tienda_se_muestra_la_tienda(self):
        self.assertTrue(httpd.es_tienda({"x-tienda": "demo"}, {}))
        self.assertTrue(httpd.es_tienda({}, {"tienda": ["demo"]}))

    def test_tienda_desconocida_muestra_la_landing(self):
        # Con un slug que no existe, la tienda no se identifica: se muestra la landing.
        self.assertFalse(httpd.es_tienda({"x-tienda": "no-existe"}, {}))


class ContenidoDeLanding(unittest.TestCase):
    def setUp(self):
        self.html = LANDING.read_text(encoding="utf-8")

    def test_secciones_y_accesos_necesarios(self):
        for ancla in ("#producto", "#temas", "#como", "#quienes"):
            self.assertIn(f'href="{ancla}"', self.html, ancla)
            self.assertIn(f'id="{ancla[1:]}"', self.html, ancla)
        self.assertIn("Quiénes somos", self.html)
        self.assertIn('href="/admin"', self.html)  # acceso de clientes
        self.assertIn("Acceso clientes", self.html)

    def test_no_menciona_la_plataforma_central(self):
        textos = self.html + CSS.read_text(encoding="utf-8")
        self.assertIsNone(re.search(r"innovation|ecosistema|cc\s*innovation", textos, re.I))

    def test_imagenes_referenciadas_existen(self):
        for ruta in re.findall(r'src="(/static/[^"]+)"', self.html):
            self.assertTrue((RAIZ / ruta.lstrip("/")).exists(), ruta)

    def test_hoja_de_estilos_enlazada_y_existe(self):
        self.assertIn('href="/static/css/landing.css"', self.html)
        self.assertTrue(CSS.exists())


if __name__ == "__main__":
    unittest.main()
