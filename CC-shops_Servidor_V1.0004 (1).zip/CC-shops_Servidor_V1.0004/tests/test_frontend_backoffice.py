"""Comprobaciones estáticas del backoffice que evitan los fallos encontrados en el navegador."""
from __future__ import annotations

import json
import re
import shutil
import subprocess
import unittest
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
ADMIN_JS = (RAIZ / "static" / "js" / "admin.js").read_text(encoding="utf-8")
LIB_JS = RAIZ / "static" / "js" / "lib.js"


class BackofficeFrontend(unittest.TestCase):
    def test_funciones_de_lib_usadas_en_admin_estan_importadas(self):
        bloque = re.search(r"import\s*\{([^}]*)\}\s*from\s*\"\./lib\.js", ADMIN_JS, re.S).group(1)
        importadas = {x.strip() for x in bloque.split(",") if x.strip()}
        exportadas = set(re.findall(r"export\s+(?:async\s+)?(?:function|const|let)\s+([A-Za-z_$][\w$]*)", LIB_JS.read_text(encoding="utf-8")))
        definidas = set(re.findall(r"(?:function|const|let)\s+([A-Za-z_$][\w$]*)", ADMIN_JS))
        usadas = set(re.findall(r"(?<![.\w$])(setBusy|toast|api|formObject|parseMoney|compressImage|openModal|closeModal|confirmDialog|emptyState|downloadCSV|esc|money|number|icon|fmtDate|fmtDateTime|estadoBadge|stockBadge)\s*\(", ADMIN_JS))
        faltan = sorted(u for u in usadas if u not in importadas and u not in definidas)
        self.assertEqual(faltan, [], "Funciones usadas sin importar en admin.js")
        self.assertTrue(set(importadas) <= exportadas | definidas, "Importaciones inexistentes en lib.js")

    def test_detalles_leen_la_clave_que_devuelve_el_servidor(self):
        # El servidor devuelve {"pedido": ...} y {"compra": ...}; el frontend debe leer esas claves.
        self.assertIn("const p = d.pedido;", ADMIN_JS)
        self.assertIn("const c = d.compra;", ADMIN_JS)

    def test_parse_money_respeta_el_decimal_de_los_campos_numericos(self):
        node = shutil.which("node")
        if not node:
            self.skipTest("Node no disponible")
        script = (
            f'import {{ parseMoney }} from "{LIB_JS.as_uri()}";'
            'const casos = [["24.5", 24.5], ["19.9", 19.9], ["1234.56", 1234.56], ["1.234,56", 1234.56], ["24,5", 24.5], ["12,00 €", 12]];'
            'console.log(JSON.stringify(casos.map(([e, x]) => [e, parseMoney(e) === x])));'
        )
        salida = subprocess.run([node, "--input-type=module", "-e", script], capture_output=True, text=True, timeout=30)
        self.assertEqual(salida.returncode, 0, salida.stderr)
        self.assertTrue(all(ok for _, ok in json.loads(salida.stdout)), salida.stdout)


if __name__ == "__main__":
    unittest.main()
