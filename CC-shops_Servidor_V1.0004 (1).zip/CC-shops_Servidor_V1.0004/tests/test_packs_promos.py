"""Packs (producto virtual formado por productos), promociones por tiempo limitado y temas."""
from __future__ import annotations

from datetime import datetime, timedelta

from server import api, db, kardex, orders
from server.util import ApiError

from .harness import BaseCase


class PacksPromos(BaseCase):
    def setUp(self):
        super().setUp()
        self.a = self.nuevo_producto(nombre="Pinza A", sku="PA-1", stock_inicial=10, coste=2, precio=5)
        self.b = self.nuevo_producto(nombre="Lima B", sku="LB-1", stock_inicial=6, coste=1, precio=3)

    def crear_pack(self, comps=None, **extra):
        comps = comps or [{"producto_id": self.a["id"], "cantidad": 1}, {"producto_id": self.b["id"], "cantidad": 2}]
        datos = {"nombre": "Kit Pinza", "sku": "KIT-1", "precio": 9, "iva": 21, "stock_minimo": 0, "unidad": "ud",
                 "es_pack": True, "componentes": comps, "imagen": "", **extra}
        r = self.api("POST", "/api/admin/productos", datos)
        self.assertEqual(r.status, 201, r.payload)
        return r.payload["producto"]

    def stock(self, pid):
        return float(self.producto_db(pid)["stock"])

    def pedido(self, pid, cantidad=1, metodo="contrareembolso"):
        return self.crear_pedido([{"producto_id": pid, "cantidad": cantidad}], metodo_pago=metodo, tipo_entrega="recogida")

    # --- Packs ---
    def test_pack_necesita_al_menos_dos_productos(self):
        r = self.api("POST", "/api/admin/productos", {"nombre": "Pack malo", "sku": "PM-1", "precio": 5, "iva": 21, "es_pack": True,
                                                      "componentes": [{"producto_id": self.a["id"], "cantidad": 1}]})
        self.assertEqual(r.status, 400)
        self.assertEqual(r.payload["campo"], "componentes")

    def test_pack_no_puede_contener_packs_ni_repetir_productos(self):
        pack = self.crear_pack()
        r = self.api("POST", "/api/admin/productos", {"nombre": "Pack en pack", "sku": "PP-1", "precio": 5, "iva": 21, "es_pack": True,
                                                      "componentes": [{"producto_id": pack["id"], "cantidad": 1}, {"producto_id": self.a["id"], "cantidad": 1}]})
        self.assertEqual(r.status, 400)
        r = self.api("POST", "/api/admin/productos", {"nombre": "Repetido", "sku": "RP-1", "precio": 5, "iva": 21, "es_pack": True,
                                                      "componentes": [{"producto_id": self.a["id"], "cantidad": 1}, {"producto_id": self.a["id"], "cantidad": 2}]})
        self.assertEqual(r.status, 400)

    def test_stock_del_pack_es_el_del_componente_con_menos_unidades(self):
        pack = self.crear_pack()  # A: 10 uds (x1), B: 6 uds (x2) → 3 packs
        self.assertEqual(self.stock(pack["id"]), 3)
        self.pedido(pack["id"], cantidad=1)  # consume 1 A y 2 B
        self.assertEqual(self.stock(self.a["id"]), 9)
        self.assertEqual(self.stock(self.b["id"]), 4)
        self.assertEqual(self.stock(pack["id"]), 2)

    def test_vender_pack_descuenta_componentes_y_cancelar_los_devuelve(self):
        pack = self.crear_pack()
        p = self.pedido(pack["id"], cantidad=2)
        self.assertEqual(self.stock(self.a["id"]), 8)
        self.assertEqual(self.stock(self.b["id"]), 2)
        self.api("POST", f"/api/admin/pedidos/{p['id']}/cancelar", {"motivo": "prueba"})
        self.assertEqual(self.stock(self.a["id"]), 10)
        self.assertEqual(self.stock(self.b["id"]), 6)
        self.assertEqual(self.stock(pack["id"]), 3)

    def test_no_se_vende_mas_pack_del_disponible(self):
        pack = self.crear_pack()
        with self.assertRaises(ApiError):
            self.pedido(pack["id"], cantidad=4)

    def test_el_pack_no_tiene_stock_propio(self):
        pack = self.crear_pack()
        with db.session(write=True) as conn:
            with self.assertRaises(ApiError):
                kardex.entrada(conn, pack["id"], 5, 1, tipo="entrada_ajuste")

    def test_pack_sin_foto_ni_precio_no_se_crea_sin_precio(self):
        r = self.api("POST", "/api/admin/productos", {"nombre": "Pack sin precio", "sku": "SP-1", "iva": 21, "es_pack": True,
                                                      "componentes": [{"producto_id": self.a["id"], "cantidad": 1}, {"producto_id": self.b["id"], "cantidad": 1}]})
        self.assertEqual(r.status, 201)
        self.assertEqual(float(r.payload["producto"]["precio"]), 0.0)  # el precio se configura en el formulario

    # --- Promociones ---
    def promo(self, pid, precio=4, unidades=4, horas=24, **extra):
        fin = (datetime.now() + timedelta(hours=horas)).strftime("%Y-%m-%dT%H:%M")
        r = self.api("PUT", f"/api/admin/productos/{pid}", {"promo_activa": True, "promo_precio": precio,
                                                            "promo_stock": unidades, "promo_fin": fin, **extra})
        self.assertEqual(r.status, 200, r.payload)
        return r.payload["producto"]

    def test_promocion_cambia_el_precio_y_muestra_el_stock_disponible(self):
        self.promo(self.a["id"], precio=4, unidades=4)
        publico = api.dispatch("GET", "/api/public/productos", {"q": "Pinza A"}, {}, {"x-tienda": "demo", "x-cc-client-ip": "10.0.8.1"}).payload["items"]
        item = [i for i in publico if i["id"] == self.a["id"]][0]
        self.assertEqual(item["precio"], 4.0)
        self.assertEqual(item["precio_original"], 5.0)
        self.assertEqual(item["promo"]["stock"], 4.0)

    def test_pedido_en_promocion_usa_el_precio_promocional_y_consume_unidades(self):
        self.promo(self.a["id"], precio=4, unidades=4)
        p = self.pedido(self.a["id"], cantidad=3)
        linea = self.api("GET", f"/api/admin/pedidos/{p['id']}").payload["pedido"]["lineas"][0]
        self.assertEqual(float(linea["precio_unit"]), 4.0)
        self.assertEqual(float(self.producto_db(self.a["id"])["promo_stock_restante"]), 1)

    def test_no_se_supera_el_stock_de_promocion(self):
        self.promo(self.a["id"], precio=4, unidades=2)
        with self.assertRaises(ApiError):
            self.pedido(self.a["id"], cantidad=3)

    def test_al_agotarse_la_promocion_pierde_la_etiqueta_y_vuelve_el_precio(self):
        self.promo(self.a["id"], precio=4, unidades=2)
        self.pedido(self.a["id"], cantidad=2)
        publico = api.dispatch("GET", "/api/public/productos", {"q": "Pinza A"}, {}, {"x-tienda": "demo", "x-cc-client-ip": "10.0.8.2"}).payload["items"]
        item = [i for i in publico if i["id"] == self.a["id"]][0]
        self.assertIsNone(item["promo"])
        self.assertEqual(item["precio"], 5.0)

    def test_al_vencer_la_fecha_pierde_la_etiqueta(self):
        self.promo(self.a["id"], precio=4, unidades=4, horas=24)
        with db.session(write=True) as conn:
            conn.execute("UPDATE productos SET promo_fin=? WHERE id=?", ((datetime.now() - timedelta(minutes=5)).isoformat(timespec="minutes"), self.a["id"]))
        publico = api.dispatch("GET", "/api/public/productos", {"q": "Pinza A"}, {}, {"x-tienda": "demo", "x-cc-client-ip": "10.0.8.3"}).payload["items"]
        self.assertIsNone([i for i in publico if i["id"] == self.a["id"]][0]["promo"])

    def test_promocion_debe_ser_mas_barata_y_tener_fecha_futura(self):
        r = self.api("PUT", f"/api/admin/productos/{self.a['id']}", {"promo_activa": True, "promo_precio": 6, "promo_stock": 2,
                                                                       "promo_fin": (datetime.now() + timedelta(hours=2)).strftime("%Y-%m-%dT%H:%M")})
        self.assertEqual(r.status, 400)
        self.assertEqual(r.payload["campo"], "promo_precio")
        r = self.api("PUT", f"/api/admin/productos/{self.a['id']}", {"promo_activa": True, "promo_precio": 4, "promo_stock": 2,
                                                                       "promo_fin": (datetime.now() - timedelta(hours=2)).strftime("%Y-%m-%dT%H:%M")})
        self.assertEqual(r.status, 400)
        self.assertEqual(r.payload["campo"], "promo_fin")

    def test_categoria_promociones_solo_aparece_con_promociones(self):
        cats = api.dispatch("GET", "/api/public/categorias", {}, {}, {"x-tienda": "demo", "x-cc-client-ip": "10.0.8.4"}).payload["items"]
        self.assertNotIn("promociones", [c["slug"] for c in cats])
        self.promo(self.a["id"])
        cats = api.dispatch("GET", "/api/public/categorias", {}, {}, {"x-tienda": "demo", "x-cc-client-ip": "10.0.8.5"}).payload["items"]
        self.assertIn("promociones", [c["slug"] for c in cats])
        listado = api.dispatch("GET", "/api/public/productos", {"categoria": "promociones"}, {}, {"x-tienda": "demo", "x-cc-client-ip": "10.0.8.6"}).payload["items"]
        self.assertEqual([i["id"] for i in listado], [self.a["id"]])

    def test_promocion_de_pack(self):
        pack = self.crear_pack()
        self.promo(pack["id"], precio=7, unidades=2)
        p = self.pedido(pack["id"], cantidad=1)
        self.assertEqual(float(self.api("GET", f"/api/admin/pedidos/{p['id']}").payload["pedido"]["lineas"][0]["precio_unit"]), 7.0)

    # --- Temas ---
    def test_temas_por_nicho_disponibles(self):
        from server import config
        self.assertEqual(config.TEMAS, ("clasico", "tech", "moda", "belleza", "mascotas", "hogar", "deporte", "gourmet"))
        for t in ("moda", "belleza", "mascotas", "hogar", "deporte", "gourmet"):
            self.assertEqual(self.api("PUT", "/api/admin/ajustes", {"tema_tienda": t}).status, 200)
        self.assertEqual(self.api("PUT", "/api/admin/ajustes", {"tema_tienda": "claro"}).status, 400)

    def test_temas_retirados_pasan_a_clasico_en_la_migracion(self):
        with db.session(write=True) as conn:
            conn.execute("INSERT INTO configuracion (clave, valor, tienda_id) VALUES ('TDEMO:tema_tienda','moderno',NULL)")
        with db.session(write=True) as conn:
            conn.execute("UPDATE configuracion SET valor='clasico' WHERE clave LIKE '%:tema_tienda' AND valor IN ('claro','moderno')")
        with db.session() as conn:
            self.assertEqual(db.one(conn, "SELECT valor FROM configuracion WHERE clave='TDEMO:tema_tienda'")["valor"], "clasico")
