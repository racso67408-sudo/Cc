"""Forma de entrega: recogida, envío propio o transportista. El coste de envío lo asigna el administrador."""
from __future__ import annotations

from server import api

from .harness import OPERADOR_PASSWORD, BaseCase


class EnvioTests(BaseCase):
    demo = True

    def setUp(self):
        super().setUp()
        self.producto = self.nuevo_producto(nombre="Envio prueba", sku="ENV-1", stock_inicial=30, coste=2, precio=10)

    def pedido(self, tipo: str, metodo: str = "transferencia", cantidad: int = 1) -> dict:
        return self.crear_pedido([{"producto_id": self.producto["id"], "cantidad": cantidad}], metodo_pago=metodo, tipo_entrega=tipo)

    def test_recogida_no_requiere_envio_ni_direccion(self):
        p = self.pedido("recogida")
        pedido = self.pedido_db(p["numero"])
        self.assertEqual(pedido["tipo_entrega"], "recogida")
        self.assertEqual(pedido["envio_pendiente"], 0)
        notis = self.api("GET", "/api/admin/notificaciones").payload["items"]
        self.assertNotIn(p["id"], [n["referencia"] for n in notis if n["tipo"] == "envio_pendiente"])

    def test_envio_queda_pendiente_de_asignar_y_avisa_al_administrador(self):
        p = self.pedido("envio_transportista")
        pedido = self.api("GET", f"/api/admin/pedidos/{p['id']}").payload["pedido"]
        self.assertTrue(pedido["envio_pendiente"])
        self.assertIsNone(pedido["a_cobrar"])
        notis = self.api("GET", "/api/admin/notificaciones").payload["items"]
        self.assertIn("envio_pendiente", [n["tipo"] for n in notis])

    def test_el_total_no_incluye_el_envio_y_el_envio_se_asigna_aparte(self):
        p = self.pedido("envio_propio")
        total_inicial = self.pedido_db(p["numero"])["total"]
        r = self.api("POST", f"/api/admin/pedidos/{p['id']}/envio", {"importe": 4.95, "transportista": "Furgoneta propia", "cobro": "entrega"})
        self.assertEqual(r.status, 200, r.payload)
        pedido = r.payload["pedido"]
        self.assertEqual(pedido["envio"], 4.95)
        self.assertFalse(pedido["envio_pendiente"])
        self.assertEqual(pedido["total"], total_inicial)
        self.assertEqual(self.pedido_db(p["numero"])["transportista"], "Furgoneta propia")
        notis = [n for n in self.api("GET", "/api/admin/notificaciones").payload["items"] if n["tipo"] == "envio_pendiente"]
        self.assertTrue(all(n["leida"] for n in notis))

    def test_no_se_envia_sin_coste_de_envio_asignado(self):
        p = self.pedido("envio_transportista")
        self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": "pagado"})
        self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": "preparando"})
        self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": "preparado"})
        self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": "preparado"})
        r = self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": "enviado"})
        self.assertEqual(r.status, 409)
        self.api("POST", f"/api/admin/pedidos/{p['id']}/envio", {"importe": 0, "cobro": "entrega"})
        self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": "preparado"})
        self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": "preparado"})
        self.assertEqual(self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": "enviado"}).status, 200)

    def test_importe_no_valido_y_recogida_rechazados(self):
        p = self.pedido("envio_transportista")
        self.assertEqual(self.api("POST", f"/api/admin/pedidos/{p['id']}/envio", {"importe": -1, "cobro": "entrega"}).status, 400)
        self.assertEqual(self.api("POST", f"/api/admin/pedidos/{p['id']}/envio", {"importe": "abc", "cobro": "entrega"}).status, 400)
        r = self.pedido("recogida")
        self.assertEqual(self.api("POST", f"/api/admin/pedidos/{r['id']}/envio", {"importe": 3, "cobro": "entrega"}).status, 409)

    def test_contrareembolso_cobra_total_mas_envio(self):
        self.api("PUT", "/api/admin/ajustes", {"recargo_contrareembolso": "2.50"})
        p = self.pedido("envio_transportista", metodo="contrareembolso")
        pedido = self.pedido_db(p["numero"])
        self.assertAlmostEqual(pedido["total"], round(pedido["total"], 2))
        self.assertAlmostEqual(pedido["total"] - 2.5, 10.0, places=2)  # 1 unidad a 10 € con recargo
        self.api("POST", f"/api/admin/pedidos/{p['id']}/envio", {"importe": 4.95, "cobro": "entrega"})
        pagos = self.api("GET", "/api/admin/pagos").payload["contrareembolso"]
        fila = [x for x in pagos if x["id"] == p["id"]][0]
        self.assertAlmostEqual(fila["a_cobrar"], 17.45, places=2)
        self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": "preparando"})
        self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": "preparado"})
        self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": "preparado"})
        self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": "enviado"})
        r = self.api("POST", f"/api/admin/pedidos/{p['id']}/confirmar-cobro")
        self.assertEqual(r.status, 200, r.payload)

    def test_el_preparador_no_asigna_el_envio(self):
        p = self.pedido("envio_transportista")
        cookie = self.cookie
        self.cookie = self.login("equipo@ccshops.es", OPERADOR_PASSWORD)
        self.assertEqual(self.api("POST", f"/api/admin/pedidos/{p['id']}/envio", {"importe": 5, "cobro": "entrega"}).status, 403)
        self.cookie = cookie

    def test_nota_de_envio_configurable_en_la_tienda(self):
        self.api("PUT", "/api/admin/ajustes", {"aviso_envio": "El total no incluye el envío. {tienda} te contactará."})
        aviso = self.api("GET", "/api/public/config", auth=False).payload["envio"]["aviso"]
        self.assertIn("te contactará", aviso)
        self.assertNotIn("{tienda}", aviso)

    def test_forma_de_entrega_no_valida(self):
        r = api.dispatch("POST", "/api/public/pedidos", {}, {
            "cliente": {"nombre": "Ana Prueba", "email": "ana@x.es", "telefono": "+34 600 000 000", "direccion": "Calle 1 nº 2", "ciudad": "Terrassa", "cp": "08221", "provincia": "Barcelona"},
            "items": [{"producto_id": self.producto["id"], "cantidad": 1}], "tipo_entrega": "dron"}, {"x-cc-request": "1", "x-tienda": "demo", "x-cc-client-ip": "10.0.7.1"})
        self.assertEqual(r.status, 400)
        self.assertEqual(r.payload["campo"], "tipo_entrega")

    def test_recargo_por_defecto_se_aplica_al_contrareembolso(self):
        # Sin tocar ajustes, la tienda usa su recargo por defecto.
        p = self.pedido("recogida", metodo="contrareembolso")
        sin_recargo = self.pedido("recogida", metodo="transferencia")
        self.assertGreater(self.pedido_db(p["numero"])["total"], self.pedido_db(sin_recargo["numero"])["total"])
