"""Suite de tests de CC-Shops."""
