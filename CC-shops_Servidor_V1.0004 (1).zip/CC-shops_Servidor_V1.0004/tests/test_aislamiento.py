"""Aislamiento entre tiendas (CC_ECOSYSTEM_STANDARD, sección 13).

Escenario: la tienda A (demo) y la tienda B, cada una con su administrador.
Ningún dato de A debe ser visible ni modificable desde B, ni por cabeceras ni por parámetros.
"""
from __future__ import annotations

from server import api, auth, db
from server.util import iso_now

from .harness import BaseCase

TIENDA_B = "TDB"
ADMIN_B = "admin.b@ccshops.test"
PASS_B = "ClaveTiendaB123"


class AislamientoTiendas(BaseCase):
    def setUp(self):
        super().setUp()
        self.tienda_a = self.user["tienda_id"]
        self.cookie_a = self.cookie
        with db.session(write=True) as conn:
            conn.execute(
                "INSERT INTO tiendas (id, slug, nombre, estado, dominio_provisional, config, created_at, updated_at) "
                "VALUES (?,?,?,?,?,?,?,?)",
                (TIENDA_B, "tienda-b", "Tienda B", "activa", "", "{}", iso_now(), iso_now()),
            )
            conn.execute(
                "INSERT INTO usuarios (id, nombre, email, password_hash, rol, tienda_id, activo, session_version, ultimo_acceso, created_at) "
                "VALUES (?,?,?,?,?,?,1,0,'',?)",
                ("USRB", "Admin B", ADMIN_B, auth.hash_password(PASS_B), "admin", TIENDA_B, iso_now()),
            )
        self.cookie_b = self.login(ADMIN_B, PASS_B)

    def como(self, cookie: str | None):
        self.cookie = cookie

    # ------------------------------------------------------------------
    def test_producto_de_a_no_es_accesible_desde_b(self):
        p = self.nuevo_producto(nombre="Producto secreto A", sku="A-SEC-1", stock_inicial=5)
        self.como(self.cookie_b)
        self.assertEqual(self.api("GET", f"/api/admin/productos/{p['id']}").status, 404)
        self.assertEqual(self.api("PUT", f"/api/admin/productos/{p['id']}", {"nombre": "HACKEADO"}).status, 404)
        self.assertEqual(self.api("DELETE", f"/api/admin/productos/{p['id']}").status, 404)
        self.assertEqual(self.api("GET", f"/api/admin/productos/{p['id']}/kardex").status, 404)
        self.assertEqual(self.api("POST", f"/api/admin/productos/{p['id']}/ajuste", {"nuevo_stock": 0, "motivo": "x"}).status, 404)
        self.assertEqual(self.api("GET", f"/api/admin/productos/{p['id']}/verificar").status, 404)
        self.assertEqual(self.producto_db(p["id"])["nombre"], "Producto secreto A")
        self.assertEqual(self.producto_db(p["id"])["activo"], 1)

    def test_listados_de_b_no_muestran_datos_de_a(self):
        p = self.nuevo_producto(nombre="Solo de A", sku="A-LIST-1")
        self.como(self.cookie_a)
        self.assertEqual(self.api("POST", "/api/admin/categorias", {"nombre": "Categoria A"}).status, 201)
        self.como(self.cookie_b)
        listado = self.api("GET", "/api/admin/productos")
        self.assertEqual(listado.status, 200)
        self.assertNotIn(p["id"], [i["id"] for i in listado.payload["items"]])
        categorias = self.api("GET", "/api/admin/categorias").payload["items"]
        self.assertNotIn("Categoria A", [c["nombre"] for c in categorias])

    def test_cabecera_o_parametro_no_cambian_la_tienda_del_backoffice(self):
        p = self.nuevo_producto(nombre="Producto de A con cabecera", sku="A-HDR-1")
        # Como B, pidiendo explícitamente la tienda A por cabecera y por parámetro.
        cabeceras = {"x-cc-request": "1", "x-cc-client-ip": "10.0.0.9", "Cookie": self.cookie_b, "x-tienda": self.tienda_a}
        r = api.dispatch("GET", "/api/admin/productos", {"tienda": self.tienda_a}, {}, cabeceras)
        self.assertEqual(r.status, 200)
        self.assertNotIn(p["id"], [i["id"] for i in r.payload["items"]])
        cabeceras_get = {"x-cc-request": "1", "x-cc-client-ip": "10.0.0.9", "Cookie": self.cookie_b, "x-tienda": self.tienda_a}
        r2 = api.dispatch("GET", f"/api/admin/productos/{p['id']}", {"tienda": self.tienda_a}, {}, cabeceras_get)
        self.assertEqual(r2.status, 404)

    def test_crear_en_b_no_aparece_en_a_y_categoria_ajena_se_rechaza(self):
        self.como(self.cookie_a)
        cat_a = self.api("POST", "/api/admin/categorias", {"nombre": "Cat solo A"})
        self.assertEqual(cat_a.status, 201)
        cat_a_id = cat_a.payload["categoria"]["id"]
        self.como(self.cookie_b)
        # B no puede usar la categoría de A para su producto.
        r = self.api("POST", "/api/admin/productos", {"nombre": "Prod B", "sku": "B-CAT-1", "precio": 5, "iva": 21, "categoria_id": cat_a_id, "stock_inicial": 1, "stock_minimo": 0, "unidad": "ud", "coste": 1})
        self.assertEqual(r.status, 400)
        # Pero sí puede crear el suyo, y no aparece en A.
        creado = self.api("POST", "/api/admin/productos", {"nombre": "Prod B", "sku": "B-OK-1", "precio": 5, "iva": 21, "stock_inicial": 1, "stock_minimo": 0, "unidad": "ud", "coste": 1})
        self.assertEqual(creado.status, 201, creado.payload)
        self.como(self.cookie_a)
        nombres_a = [i["nombre"] for i in self.api("GET", "/api/admin/productos").payload["items"]]
        self.assertNotIn("Prod B", nombres_a)

    def test_categorias_y_proveedores_de_a_no_se_editan_desde_b(self):
        self.como(self.cookie_a)
        cat = self.api("POST", "/api/admin/categorias", {"nombre": "Cat protegida"}).payload["categoria"]
        prov = self.api("POST", "/api/admin/proveedores", {"nombre": "Proveedor A", "email": "a@prov.test"}).payload["proveedor"]
        self.como(self.cookie_b)
        self.assertEqual(self.api("PUT", f"/api/admin/categorias/{cat['id']}", {"nombre": "X"}).status, 404)
        self.assertEqual(self.api("DELETE", f"/api/admin/categorias/{cat['id']}").status, 404)
        self.assertEqual(self.api("PUT", f"/api/admin/proveedores/{prov['id']}", {"nombre": "X"}).status, 404)
        self.assertEqual(self.api("DELETE", f"/api/admin/proveedores/{prov['id']}").status, 404)
        proveedores_b = [p["nombre"] for p in self.api("GET", "/api/admin/proveedores").payload["items"]]
        self.assertNotIn("Proveedor A", proveedores_b)

    def test_pedidos_y_chat_de_a_no_son_accesibles_desde_b(self):
        p = self.nuevo_producto(nombre="Para pedido A", sku="A-PED-1", stock_inicial=10)
        pedido = self.crear_pedido([{"producto_id": p["id"], "cantidad": 1}])
        self.como(self.cookie_b)
        self.assertEqual(self.api("GET", f"/api/admin/pedidos/{pedido['id']}").status, 404)
        self.assertEqual(self.api("GET", f"/api/admin/pedidos/{pedido['id']}/chat").status, 404)
        self.assertEqual(self.api("POST", f"/api/admin/pedidos/{pedido['id']}/estado", {"estado": "cancelado"}).status, 404)
        self.assertEqual(self.api("POST", f"/api/admin/pedidos/{pedido['id']}/cancelar", {}).status, 404)
        self.assertEqual(self.pedido_db(pedido["numero"])["estado"], "pendiente")
        listado = self.api("GET", "/api/admin/pedidos").payload["items"]
        self.assertNotIn(pedido["id"], [i["id"] for i in listado])

    def test_compra_de_a_no_se_ve_desde_b_y_no_usa_productos_ajenos(self):
        p_a = self.nuevo_producto(nombre="Producto A compra", sku="A-CMP-1")
        self.como(self.cookie_a)
        compra = self.api("POST", "/api/admin/compras", {"lineas": [{"producto_id": p_a["id"], "cantidad": 2, "coste_unit": 3}]})
        self.assertEqual(compra.status, 201, compra.payload)
        cid = compra.payload["compra"]["id"]
        self.como(self.cookie_b)
        self.assertEqual(self.api("GET", f"/api/admin/compras/{cid}").status, 404)
        self.assertEqual(self.api("POST", f"/api/admin/compras/{cid}/recibir").status, 404)
        # B no puede comprar un producto de A.
        r = self.api("POST", "/api/admin/compras", {"lineas": [{"producto_id": p_a["id"], "cantidad": 1, "coste_unit": 1}]})
        self.assertEqual(r.status, 400)
        self.assertNotIn(cid, [c["id"] for c in self.api("GET", "/api/admin/compras").payload["items"]])

    def test_metricas_de_b_no_incluyen_ventas_de_a(self):
        p = self.nuevo_producto(nombre="Venta A", sku="A-MET-1", stock_inicial=10)
        self.crear_pedido([{"producto_id": p["id"], "cantidad": 2}])
        self.como(self.cookie_a)
        dash_a = self.api("GET", "/api/admin/dashboard").payload
        self.assertEqual(dash_a["kpis"]["pendientes"], 1)
        self.como(self.cookie_b)
        dash_b = self.api("GET", "/api/admin/dashboard").payload
        self.assertEqual(dash_b["kpis"]["pendientes"], 0)
        self.assertEqual(dash_b["kpis"]["inventario_referencias"], 0)
        self.assertEqual(dash_b["top_productos"], [])
        met_b = self.api("GET", "/api/admin/metricas", query={"dias": "30"}).payload
        self.assertEqual(met_b["kpis"]["pedidos"], 0)
        self.assertEqual(self.api("GET", "/api/admin/inventario").payload["resumen"]["referencias"], 0)

    def test_ajustes_de_b_no_cambian_los_de_a(self):
        self.como(self.cookie_b)
        self.assertEqual(self.api("PUT", "/api/admin/ajustes", {"tienda_nombre": "Nombre de B"}).status, 200)
        self.como(self.cookie_a)
        ajustes_a = self.api("GET", "/api/admin/ajustes").payload["ajustes"]
        self.assertNotEqual(ajustes_a["tienda_nombre"], "Nombre de B")
        publico_b = api.dispatch("GET", "/api/public/config", {"tienda": TIENDA_B}, {}, {"x-cc-client-ip": "10.0.0.8"})
        self.assertEqual(publico_b.payload["tienda"]["nombre"], "Nombre de B")

    def test_eventos_de_b_no_muestran_acciones_de_a(self):
        self.como(self.cookie_a)
        creado = self.api("POST", "/api/admin/productos", {"nombre": "Auditado A", "sku": "A-AUD-1", "precio": 5, "iva": 21, "stock_inicial": 0, "stock_minimo": 0, "unidad": "ud", "coste": 1})
        self.assertEqual(creado.status, 201, creado.payload)
        pid = creado.payload["producto"]["id"]
        self.como(self.cookie_a)
        visibles_a = [e["entidad_id"] for e in self.api("GET", "/api/admin/eventos", query={"limite": "200"}).payload["items"]]
        self.assertIn(pid, visibles_a)  # A ve su propio evento (el registro sí se genera)
        self.como(self.cookie_b)
        visibles_b = [e["entidad_id"] for e in self.api("GET", "/api/admin/eventos", query={"limite": "200"}).payload["items"]]
        self.assertNotIn(pid, visibles_b)

    def test_catalogo_publico_separado_por_tienda(self):
        self.como(self.cookie_a)
        self.assertEqual(self.api("POST", "/api/admin/categorias", {"nombre": "Cat solo A"}).status, 201)
        self.assertEqual(self.api("POST", "/api/admin/productos", {"nombre": "Publico A", "sku": "A-PUB-1", "precio": 5, "iva": 21, "stock_inicial": 3, "stock_minimo": 0, "unidad": "ud", "coste": 1, "categoria_id": ""}).status, 201)
        with db.session(write=True) as conn:
            conn.execute("INSERT INTO categorias (id, tienda_id, nombre, slug, descripcion, icono, orden, activo) VALUES ('CATB',?,?,?,?,?,1,1)",
                         (TIENDA_B, "Cat publica B", "cat-publica-b", "", ""))
            conn.execute("INSERT INTO productos (id, tienda_id, sku, nombre, slug, descripcion, descripcion_corta, especificaciones, categoria_id, marca, unidad, precio, iva, stock, stock_minimo, coste_medio, valor_stock, imagen, activo, destacado, created_at, updated_at) "
                         "VALUES ('PRDB',?,?,?,?, '', '', '[]', 'CATB', '', 'ud', 9, 21, 4, 0, 1, 4, '', 1, 0, ?, ?)",
                         (TIENDA_B, "B-PUB-1", "Publico B", "publico-b", iso_now(), iso_now()))
        pub_b = api.dispatch("GET", "/api/public/productos", {"tienda": TIENDA_B, "por_pagina": "48"}, {}, {"x-cc-client-ip": "10.0.0.8"}).payload
        nombres_b = [i["nombre"] for i in pub_b["items"]]
        self.assertIn("Publico B", nombres_b)
        self.assertNotIn("Publico A", nombres_b)
        cats_b = api.dispatch("GET", "/api/public/categorias", {"tienda": TIENDA_B}, {}, {"x-cc-client-ip": "10.0.0.8"}).payload["items"]
        self.assertNotIn("Cat solo A", [c["nombre"] for c in cats_b])
        portada_b = api.dispatch("GET", "/api/public/config", {"tienda": TIENDA_B}, {}, {"x-cc-client-ip": "10.0.0.8"}).payload
        self.assertNotIn("Publico A", [d["nombre"] for d in portada_b["destacados"]])
        self.assertNotIn("Cat solo A", [c["nombre"] for c in portada_b["categorias"]])
        self.assertEqual(portada_b["total_productos"], 1)

    def test_pedido_publico_no_puede_usar_productos_de_otra_tienda(self):
        with db.session(write=True) as conn:
            conn.execute("INSERT INTO productos (id, tienda_id, sku, nombre, slug, descripcion, descripcion_corta, especificaciones, categoria_id, marca, unidad, precio, iva, stock, stock_minimo, coste_medio, valor_stock, imagen, activo, destacado, created_at, updated_at) "
                         "VALUES ('PRDBP',?,?,?,?, '', '', '[]', NULL, '', 'ud', 9, 21, 4, 0, 1, 4, '', 1, 0, ?, ?)",
                         (TIENDA_B, "B-PED-1", "Solo de B", "solo-de-b", iso_now(), iso_now()))
        cuerpo = {
            "cliente": {"nombre": "Cliente", "email": "c@test.es", "telefono": "+34 600 000 001",
                        "direccion": "Calle 1", "ciudad": "Terrassa", "cp": "08221", "provincia": "Barcelona"},
            "items": [{"producto_id": "PRDBP", "cantidad": 1}],
            "metodo_pago": "transferencia",
        }
        # Pedido enviado a la tienda A: un producto de B no debe aceptarse.
        r = api.dispatch("POST", "/api/public/pedidos", {}, cuerpo, {"x-cc-request": "1", "x-cc-client-ip": "10.0.0.7", "x-tienda": "demo"})
        self.assertEqual(r.status, 409, r.payload)

    def test_usuario_sin_tienda_no_opera_el_backoffice(self):
        with db.session(write=True) as conn:
            conn.execute(
                "INSERT INTO usuarios (id, nombre, email, password_hash, rol, tienda_id, activo, session_version, ultimo_acceso, created_at) "
                "VALUES ('USRN','Sin tienda','sin@ccshops.test',?,'admin',NULL,1,0,'',?)",
                (auth.hash_password("ClaveSinTienda123"), iso_now()),
            )
        self.como(self.login("sin@ccshops.test", "ClaveSinTienda123"))
        self.assertEqual(self.api("GET", "/api/admin/productos").status, 403)
