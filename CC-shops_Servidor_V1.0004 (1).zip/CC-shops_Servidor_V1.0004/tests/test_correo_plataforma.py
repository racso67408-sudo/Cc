"""Configuración del correo de la plataforma desde el superadmin."""
from __future__ import annotations

import os
from unittest.mock import MagicMock, patch

from server import api, correo, ratelimit

from .harness import SUPERADMIN_PASSWORD, BaseCase

DATOS = {"correo_remitente": "CC Shops <hola@ccshops.es>", "smtp_host": "smtp.ejemplo.test", "smtp_port": "587",
         "smtp_usuario": "envio@ccshops.es", "smtp_password": "clave-secreta-123", "smtp_tls": "1"}


class CorreoPlataforma(BaseCase):
    def setUp(self):
        super().setUp()
        correo.SIMULADOS.clear()
        ratelimit.reset_all()
        self.cookie_admin = self.cookie
        self.cookie = self.login("superadmin@ccshops.com", SUPERADMIN_PASSWORD)

    def test_la_contrasena_nunca_vuelve_al_navegador(self):
        self.assertEqual(self.api("PUT", "/api/superadmin/correo", DATOS).status, 200)
        cfg = self.api("GET", "/api/superadmin/correo").payload
        self.assertTrue(cfg["smtp_password_configurada"])
        self.assertTrue(cfg["configurado"])
        self.assertNotIn("clave-secreta-123", str(cfg))
        self.assertNotIn("smtp_password", cfg)

    def test_una_contrasena_vacia_no_borra_la_guardada(self):
        self.api("PUT", "/api/superadmin/correo", DATOS)
        self.api("PUT", "/api/superadmin/correo", {**DATOS, "smtp_password": ""})
        self.assertEqual(correo.config_efectiva()["smtp_password"], "clave-secreta-123")

    def test_valida_remitente_y_puerto(self):
        r = self.api("PUT", "/api/superadmin/correo", {**DATOS, "correo_remitente": "no-es-correo"})
        self.assertEqual(r.status, 400)
        self.assertEqual(r.payload["campo"], "correo_remitente")
        r = self.api("PUT", "/api/superadmin/correo", {**DATOS, "smtp_port": "99999"})
        self.assertEqual(r.status, 400)
        self.assertEqual(r.payload["campo"], "smtp_port")

    def test_la_prueba_usa_la_configuracion_guardada(self):
        self.api("PUT", "/api/superadmin/correo", DATOS)
        smtp = MagicMock()
        with patch("server.correo.smtplib.SMTP") as clase:
            clase.return_value.__enter__.return_value = smtp
            r = self.api("POST", "/api/superadmin/correo/prueba")
        self.assertEqual(r.status, 200, r.payload)
        clase.assert_called_with("smtp.ejemplo.test", 587, timeout=20)
        smtp.login.assert_called_with("envio@ccshops.es", "clave-secreta-123")
        mensaje = smtp.send_message.call_args[0][0]
        self.assertEqual(mensaje["From"], "CC Shops <hola@ccshops.es>")
        self.assertEqual(mensaje["To"], "superadmin@ccshops.com")

    def test_el_error_del_servidor_se_muestra_tal_cual(self):
        self.api("PUT", "/api/superadmin/correo", DATOS)
        with patch("server.correo.smtplib.SMTP", side_effect=OSError("Connection refused")):
            r = self.api("POST", "/api/superadmin/correo/prueba")
        self.assertEqual(r.status, 502)
        self.assertIn("Connection refused", r.payload["error"])

    def test_sin_servidor_la_prueba_queda_simulada(self):
        r = self.api("POST", "/api/superadmin/correo/prueba")
        self.assertEqual(r.payload["estado"], "simulado")

    def test_el_formulario_de_contacto_usa_la_configuracion_guardada(self):
        self.api("PUT", "/api/superadmin/correo", DATOS)
        self.cookie = self.cookie_admin
        smtp = MagicMock()
        with patch("server.correo.smtplib.SMTP") as clase:
            clase.return_value.__enter__.return_value = smtp
            r = api.dispatch("POST", "/api/public/contacto", {}, {"nombre": "Ana Cliente", "email": "ana@cliente.test", "mensaje": "Quiero un pedido grande"},
                             {"x-tienda": "demo", "x-cc-client-ip": "10.1.1.1", "x-cc-request": "1"})
        self.assertEqual(r.status, 200, r.payload)
        self.assertEqual(smtp.send_message.call_args[0][0]["From"], "CC Shops <hola@ccshops.es>")

    def test_solo_el_superadmin_accede(self):
        self.cookie = self.cookie_admin
        self.assertEqual(self.api("GET", "/api/superadmin/correo").status, 403)
        self.assertEqual(self.api("PUT", "/api/superadmin/correo", DATOS).status, 403)
