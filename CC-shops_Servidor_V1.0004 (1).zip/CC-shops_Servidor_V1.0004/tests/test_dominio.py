"""Dominio propio: dos caminos (propio y compra), verificación DNS y complemento mensual."""
from __future__ import annotations

from server import api, db, dominios, tenant
from server.util import ApiError, iso_now

from .harness import SUPERADMIN_PASSWORD, BaseCase

IP = "203.0.113.10"


class Dominio(BaseCase):
    demo = True

    def setUp(self):
        super().setUp()
        self.cookie_tienda = self.cookie
        self.cookie = self.login("superadmin@ccshops.com", SUPERADMIN_PASSWORD)
        self.api("PUT", "/api/superadmin/dominios/config", {"dominio_dns_ip": IP, "dominio_mensual": "5", "dominio_compra_anual": "12"})
        self.dns = {}  # dominio -> IPs que devuelve el resolvedor simulado
        dominios.resolver = lambda host: set(self.dns.get(host, set()))
        self.cookie = self.cookie_tienda

    def tearDown(self):
        dominios.resolver = None
        super().tearDown()

    def como_plataforma(self):
        self.cookie = self.login("superadmin@ccshops.com", SUPERADMIN_PASSWORD)

    def como_tienda(self):
        self.cookie = self.cookie_tienda

    def apuntar(self, dominio):
        self.dns = {dominio: {IP}, "www." + dominio: {IP}}

    def servida(self, host):
        with db.session() as conn:
            return tenant.resolve_tienda_id(conn, {"host": host}, {}) is not None

    def accion(self, nombre):
        tid = self.user["tienda_id"]
        self.como_plataforma()
        r = self.api("POST", f"/api/superadmin/dominios/{tid}/accion", {"accion": nombre})
        self.como_tienda()
        return r

    # --- normalización y validación ---
    def test_normaliza_y_valida_el_dominio(self):
        self.assertEqual(dominios.normalizar("https://www.Mi-Tienda.com/catalogo"), "mi-tienda.com")
        for malo in ("", "hola", "203.0.113.5", "ccshops.es", "tienda.ccshops.es", "con espacio.com"):
            with self.assertRaises(ApiError, msg=malo):
                dominios.validar(dominios.normalizar(malo))

    # --- camino propio ---
    def test_propio_pasa_por_dns_y_complemento(self):
        r = self.api("POST", "/api/admin/dominio/configurar", {"modo": "propio", "dominio": "mitienda.com"})
        self.assertEqual(r.payload["estado"], "pendiente_dns")
        self.assertEqual(self.api("POST", "/api/admin/dominio/verificar").status, 409)  # DNS sin apuntar
        self.apuntar("mitienda.com")
        r = self.api("POST", "/api/admin/dominio/verificar")
        self.assertEqual(r.status, 200, r.payload)
        self.assertEqual(r.payload["estado"], "dns_ok")
        self.assertFalse(self.servida("mitienda.com"))  # sin complemento no se sirve
        self.assertEqual(self.accion("add_on_on").status, 200)
        self.assertEqual(self.api("GET", "/api/admin/dominio").payload["estado"], "activo")
        self.assertTrue(self.servida("mitienda.com"))
        self.assertTrue(self.servida("www.mitienda.com"))
        self.assertFalse(self.servida("otra.com"))

    def test_el_dns_muestra_las_instrucciones(self):
        self.api("POST", "/api/admin/dominio/configurar", {"modo": "propio", "dominio": "mitienda.com"})
        dns = self.api("GET", "/api/admin/dominio").payload["dns"]
        self.assertEqual(dns["ip"], IP)
        self.assertTrue(dns["host"])

    def test_no_se_activa_el_complemento_sin_dns_verificado(self):
        self.api("POST", "/api/admin/dominio/configurar", {"modo": "propio", "dominio": "mitienda.com"})
        self.assertEqual(self.accion("add_on_on").status, 409)

    def test_servidor_https_solo_certifica_dominios_activos(self):
        self.api("POST", "/api/admin/dominio/configurar", {"modo": "propio", "dominio": "mitienda.com"})
        self.apuntar("mitienda.com")
        self.api("POST", "/api/admin/dominio/verificar")
        self.accion("add_on_on")
        self.cookie = None
        ok = api.dispatch("GET", "/api/public/dominio-permitido", {"domain": "mitienda.com"}, {}, {"x-cc-client-ip": "10.4.4.1"})
        self.assertEqual(ok.status, 200)
        no = api.dispatch("GET", "/api/public/dominio-permitido", {"dominio": "desconocido.com"}, {}, {"x-cc-client-ip": "10.4.4.2"})
        self.assertEqual(no.status, 404)
        self.cookie = self.cookie_tienda

    def test_desactivar_el_complemento_deja_de_servir_el_dominio(self):
        self.api("POST", "/api/admin/dominio/configurar", {"modo": "propio", "dominio": "mitienda.com"})
        self.apuntar("mitienda.com")
        self.api("POST", "/api/admin/dominio/verificar")
        self.accion("add_on_on")
        self.accion("add_on_off")
        self.assertFalse(self.servida("mitienda.com"))

    # --- camino compra ---
    def test_compra_sigue_los_pasos_y_el_propietario_paga_el_dominio(self):
        r = self.api("POST", "/api/admin/dominio/configurar", {"modo": "compra", "dominio": "nuevo-dominio.com"})
        self.assertEqual(r.payload["estado"], "pendiente_pago_dominio")
        self.assertEqual(r.payload["precios"]["compra_anual"], 12.0)
        self.assertIn("íntegro", r.payload["nota"])
        self.assertEqual(self.accion("pago_dominio_ok").status, 200)
        self.assertEqual(self.api("GET", "/api/admin/dominio").payload["estado"], "pendiente_registro")
        self.assertEqual(self.api("POST", "/api/admin/dominio/cancelar").status, 409)  # ya se está registrando
        self.assertEqual(self.accion("registrado").status, 200)
        self.apuntar("nuevo-dominio.com")
        self.assertEqual(self.api("POST", "/api/admin/dominio/verificar").payload["estado"], "dns_ok")
        self.accion("add_on_on")
        self.assertTrue(self.servida("nuevo-dominio.com"))

    def test_la_nota_solo_aparece_en_la_compra(self):
        self.api("POST", "/api/admin/dominio/configurar", {"modo": "propio", "dominio": "mitienda.com"})
        self.assertEqual(self.api("GET", "/api/admin/dominio").payload["nota"], "")

    def test_compra_no_se_registra_sin_pago_del_dominio(self):
        self.api("POST", "/api/admin/dominio/configurar", {"modo": "compra", "dominio": "nuevo-dominio.com"})
        self.assertEqual(self.accion("registrado").status, 409)

    def test_cancelar_antes_de_registrar_libera_el_nombre(self):
        self.api("POST", "/api/admin/dominio/configurar", {"modo": "compra", "dominio": "nuevo-dominio.com"})
        r = self.api("POST", "/api/admin/dominio/cancelar")
        self.assertEqual(r.payload["estado"], "sin_configurar")
        self.assertEqual(self.api("GET", "/api/admin/dominio").payload["dominio"], "")

    def test_un_dominio_no_puede_estar_en_dos_tiendas(self):
        self.api("POST", "/api/admin/dominio/configurar", {"modo": "propio", "dominio": "mitienda.com"})
        with db.session(write=True) as conn:
            conn.execute("INSERT INTO tiendas (id, slug, nombre, estado, dominio_provisional, config, created_at, updated_at) "
                         "VALUES ('TDOM','otra-dom','Otra','activa','','{}',?,?)", (iso_now(), iso_now()))
        with db.session() as conn:
            with self.assertRaises(Exception):
                conn.execute("UPDATE tiendas SET dominio_propio='mitienda.com' WHERE id='TDOM'")
                conn.commit()
        self.assertEqual(self.api("POST", "/api/admin/dominio/configurar", {"modo": "propio", "dominio": "mitienda.com"}).status, 200)

    def test_tienda_suspendida_no_se_sirve_por_su_dominio(self):
        self.api("POST", "/api/admin/dominio/configurar", {"modo": "propio", "dominio": "mitienda.com"})
        self.apuntar("mitienda.com")
        self.api("POST", "/api/admin/dominio/verificar")
        self.accion("add_on_on")
        self.como_plataforma()
        self.api("PUT", f"/api/superadmin/tiendas/{self.user['tienda_id']}/estado", {"estado": "suspendida"})
        self.assertFalse(self.servida("mitienda.com"))
        self.api("PUT", f"/api/superadmin/tiendas/{self.user['tienda_id']}/estado", {"estado": "activa"})

    # --- configuración del superadmin ---
    def test_superadmin_fija_precios_y_datos_de_dns(self):
        self.como_plataforma()
        self.assertEqual(self.api("PUT", "/api/superadmin/dominios/config", {"dominio_mensual": "-1"}).status, 400)
        self.assertEqual(self.api("PUT", "/api/superadmin/dominios/config", {"dominio_dns_ip": "no-es-ip"}).status, 400)
        cfg = self.api("PUT", "/api/superadmin/dominios/config", {"dominio_mensual": "7.5", "plataforma_iban": "ES00 0000"}).payload
        self.assertEqual(cfg["mensual"], 7.5)
        self.como_tienda()
        self.assertEqual(self.api("GET", "/api/admin/dominio").payload["precios"]["mensual"], 7.5)

    def test_solo_el_superadmin_ve_el_listado_de_dominios(self):
        self.assertEqual(self.api("GET", "/api/superadmin/dominios").status, 403)
        self.como_plataforma()
        self.assertEqual(self.api("GET", "/api/superadmin/dominios").status, 200)
