"""Cobro del envío: en la entrega (propio o a cargo del destinatario) o pagado por adelantado."""
from __future__ import annotations

from .harness import BaseCase


class EnvioCobro(BaseCase):
    demo = True

    def setUp(self):
        super().setUp()
        self.producto = self.nuevo_producto(nombre="Cobro envio", sku="CEN-1", stock_inicial=30, coste=2, precio=10)

    def pedido(self, tipo: str, metodo: str = "transferencia") -> dict:
        return self.crear_pedido([{"producto_id": self.producto["id"], "cantidad": 1}], metodo_pago=metodo, tipo_entrega=tipo)

    def asignar(self, p, importe, cobro=None, **extra):
        cuerpo = {"importe": importe, **extra}
        if cobro is not None:
            cuerpo["cobro"] = cobro
        return self.api("POST", f"/api/admin/pedidos/{p['id']}/envio", cuerpo)

    def test_transportista_exige_elegir_como_se_cobra_el_envio(self):
        p = self.pedido("envio_transportista")
        self.assertEqual(self.asignar(p, 4.95).status, 400)
        self.assertEqual(self.asignar(p, 4.95, cobro="otra").status, 400)
        self.assertEqual(self.asignar(p, 4.95, cobro="anticipado").status, 200)

    def test_envio_propio_se_cobra_siempre_en_la_entrega(self):
        p = self.pedido("envio_propio")
        r = self.asignar(p, 3.50)
        self.assertEqual(r.status, 200, r.payload)
        self.assertEqual(r.payload["pedido"]["envio_cobro"], "entrega")

    def test_envio_anticipado_aparece_para_verificar_y_se_verifica(self):
        p = self.pedido("envio_transportista")
        self.asignar(p, 4.95, cobro="anticipado")
        pagos = self.api("GET", "/api/admin/pagos").payload
        self.assertIn(p["id"], [x["id"] for x in pagos["envios_por_verificar"]])
        self.assertEqual(self.api("POST", f"/api/admin/pedidos/{p['id']}/verificar-envio").status, 200)
        pagos = self.api("GET", "/api/admin/pagos").payload
        self.assertNotIn(p["id"], [x["id"] for x in pagos["envios_por_verificar"]])
        self.assertEqual(self.api("POST", f"/api/admin/pedidos/{p['id']}/verificar-envio").status, 409)

    def test_no_se_entrega_un_pedido_con_envio_anticipado_sin_pagar(self):
        p = self.pedido("envio_transportista")
        self.asignar(p, 4.95, cobro="anticipado")
        for estado in ["pagado", "preparando", "preparado", "enviado"]:
            self.assertEqual(self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": estado}).status, 200)
        self.assertEqual(self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": "entregado"}).status, 409)
        self.api("POST", f"/api/admin/pedidos/{p['id']}/verificar-envio")
        # Envío pagado y nada que cobrar en la entrega: el pedido puede cerrarse.
        self.assertEqual(self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": "entregado"}).status, 200)

    def test_cobro_en_entrega_del_envio_con_producto_ya_pagado(self):
        p = self.pedido("envio_transportista")
        self.api("POST", f"/api/admin/pedidos/{p['id']}/verificar-pago")
        self.asignar(p, 4.95, cobro="entrega")
        pagos = self.api("GET", "/api/admin/pagos").payload
        fila = [x for x in pagos["contrareembolso"] if x["id"] == p["id"]][0]
        self.assertAlmostEqual(fila["a_cobrar"], 4.95, places=2)
        for estado in ["preparando", "preparado", "enviado"]:
            self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": estado})
        r = self.api("POST", f"/api/admin/pedidos/{p['id']}/confirmar-cobro")
        self.assertEqual(r.status, 200, r.payload)
        self.assertEqual(r.payload["pedido"]["estado"], "entregado")
        self.assertEqual(r.payload["pedido"]["envio_cobrado"], True)
        pagos = self.api("GET", "/api/admin/pagos").payload
        self.assertNotIn(p["id"], [x["id"] for x in pagos["contrareembolso"]])

    def test_contrareembolso_mas_envio_en_la_entrega_se_cobra_junto(self):
        p = self.pedido("envio_propio", metodo="contrareembolso")
        self.asignar(p, 4.95)
        fila = [x for x in self.api("GET", "/api/admin/pagos").payload["contrareembolso"] if x["id"] == p["id"]][0]
        self.assertAlmostEqual(fila["a_cobrar"], round(fila["total"] + 4.95, 2), places=2)
        self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": "preparando"})
        self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": "preparado"})
        self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": "enviado"})
        self.assertEqual(self.api("POST", f"/api/admin/pedidos/{p['id']}/confirmar-cobro").status, 200)

    def test_no_se_confirma_cobro_sin_nada_pendiente(self):
        p = self.pedido("envio_transportista")
        self.api("POST", f"/api/admin/pedidos/{p['id']}/verificar-pago")
        self.asignar(p, 4.95, cobro="anticipado")
        self.api("POST", f"/api/admin/pedidos/{p['id']}/verificar-envio")
        for estado in ["preparando", "preparado", "enviado"]:
            self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": estado})
        self.assertEqual(self.api("POST", f"/api/admin/pedidos/{p['id']}/confirmar-cobro").status, 409)

    def test_no_se_cambia_la_forma_de_cobro_si_ya_esta_pagado(self):
        p = self.pedido("envio_transportista")
        self.asignar(p, 4.95, cobro="anticipado")
        self.api("POST", f"/api/admin/pedidos/{p['id']}/verificar-envio")
        self.assertEqual(self.asignar(p, 5.00, cobro="entrega").status, 409)
        self.assertEqual(self.asignar(p, 5.50, cobro="anticipado").status, 200)
