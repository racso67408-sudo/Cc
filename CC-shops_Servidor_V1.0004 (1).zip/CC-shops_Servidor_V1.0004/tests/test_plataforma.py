"""Superadmin: métricas, planes, suscripciones, tiendas, usuarios, landing y soporte."""
from __future__ import annotations

from server import api, db
from server.util import iso_now

from .harness import OPERADOR_PASSWORD, SUPERADMIN_PASSWORD, BaseCase


class Plataforma(BaseCase):
    demo = True

    def setUp(self):
        super().setUp()
        self.cookie_tienda = self.cookie
        self.cookie = self.login("superadmin@ccshops.com", SUPERADMIN_PASSWORD)

    def tienda_api(self, metodo, ruta, cuerpo=None):
        self.cookie, guardada = self.cookie_tienda, self.cookie
        r = self.api(metodo, ruta, cuerpo)
        self.cookie = guardada
        return r

    def test_metricas_por_tienda_y_totales(self):
        m = self.api("GET", "/api/superadmin/metricas").payload
        self.assertGreaterEqual(m["tiendas"], 1)
        fila = [t for t in m["por_tienda"] if t["slug"] == "demo"][0]
        for clave in ("productos", "pedidos", "ventas", "clientes", "clientes_medios_dia", "almacenamiento_kb"):
            self.assertIn(clave, fila)
        self.assertIn("almacenamiento_bd_mb", m)
        self.assertGreater(fila["productos"], 0)

    def test_planes_crear_y_editar(self):
        r = self.api("POST", "/api/superadmin/planes", {"nombre": "Pro Test", "precio": 49, "max_productos": 50, "max_usuarios": 3, "max_storage_mb": 300})
        self.assertEqual(r.status, 201, r.payload)
        pid = r.payload["plan"]["id"]
        r = self.api("PUT", f"/api/superadmin/planes/{pid}", {"nombre": "Pro Test", "precio": 59, "max_productos": 60, "max_usuarios": 4, "max_storage_mb": 400})
        self.assertEqual(r.payload["plan"]["precio"], 59.0)
        self.assertEqual(self.api("POST", "/api/superadmin/planes", {"nombre": "X", "precio": -1, "max_productos": 1, "max_usuarios": 1, "max_storage_mb": 1}).status, 400)

    def test_suscripcion_asigna_plan_y_limita_productos(self):
        plan = self.api("POST", "/api/superadmin/planes", {"nombre": "Mini", "precio": 9, "max_productos": 1, "max_usuarios": 2, "max_storage_mb": 50}).payload["plan"]
        tienda = self.api("GET", "/api/superadmin/tiendas").payload["items"][0]
        r = self.api("POST", "/api/superadmin/suscripciones", {"tienda_id": tienda["id"], "plan_id": plan["id"], "estado": "activa"})
        self.assertEqual(r.status, 201, r.payload)
        self.assertEqual(self.api("GET", "/api/superadmin/tiendas").payload["items"][0]["plan_nombre"], "Mini")
        self.cookie = self.cookie_tienda
        r = self.api("POST", "/api/admin/productos", {"nombre": "Segundo", "sku": "LIM-2", "precio": 5, "iva": 21, "stock_inicial": 0, "stock_minimo": 0, "unidad": "ud", "coste": 1})
        self.assertEqual(r.status, 409, r.payload)

    def test_suspender_tienda_bloquea_backoffice_y_tienda_publica(self):
        tienda = self.api("GET", "/api/superadmin/tiendas").payload["items"][0]
        self.assertEqual(self.api("PUT", f"/api/superadmin/tiendas/{tienda['id']}/estado", {"estado": "suspendida"}).status, 200)
        self.cookie = self.cookie_tienda
        self.assertEqual(self.api("GET", "/api/admin/productos").status, 403)
        publica = api.dispatch("GET", "/api/public/productos", {}, {}, {"x-tienda": "demo", "x-cc-client-ip": "10.2.2.2"})
        self.assertEqual(publica.status, 404)
        self.cookie = self.login("superadmin@ccshops.com", SUPERADMIN_PASSWORD)
        self.api("PUT", f"/api/superadmin/tiendas/{tienda['id']}/estado", {"estado": "activa"})

    def test_desactivar_usuario(self):
        usuarios = self.api("GET", "/api/superadmin/usuarios").payload["items"]
        tienda_admin = [u for u in usuarios if u["rol"] == "admin"][0]
        self.assertEqual(self.api("PUT", f"/api/superadmin/usuarios/{tienda_admin['id']}", {"activo": False}).status, 200)
        self.assertEqual(self.api("PUT", f"/api/superadmin/usuarios/{tienda_admin['id']}", {"activo": True}).status, 200)
        sa = [u for u in usuarios if u["rol"] == "superadmin"][0]
        self.assertEqual(self.api("PUT", f"/api/superadmin/usuarios/{sa['id']}", {"activo": False}).status, 409)

    def test_landing_y_seo_editables(self):
        cfg = self.api("GET", "/api/superadmin/landing").payload
        self.assertIn("seo_titulo", cfg)
        r = self.api("PUT", "/api/superadmin/landing", {"seo_titulo": "CC Shops · Prueba", "landing_titulo": "Titular de prueba"})
        self.assertEqual(r.payload["seo_titulo"], "CC Shops · Prueba")
        self.assertEqual(self.api("PUT", "/api/superadmin/landing", {"seo_titulo": ""}).status, 400)

