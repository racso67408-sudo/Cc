"""Recogida en tienda: fecha y hora aproximada obligatorias."""
from __future__ import annotations

from datetime import timedelta

from server import db
from server.util import ApiError, biz_today

from .harness import BaseCase


class RecogidaHorario(BaseCase):
    def setUp(self):
        super().setUp()
        self.producto = self.nuevo_producto(nombre="Recogida prueba", sku="REC-1", stock_inicial=10, coste=2)
        self.manana = (biz_today() + timedelta(days=1)).isoformat()

    def pedido(self, **cambios):
        return self.crear_pedido([{"producto_id": self.producto["id"], "cantidad": 1}], tipo_entrega="recogida", **cambios)

    def test_recogida_exige_fecha_y_hora(self):
        with self.assertRaises(ApiError) as ctx:
            self.pedido(recogida_fecha=None, recogida_hora="10:30")
        self.assertEqual(ctx.exception.campo, "recogida_fecha")
        with self.assertRaises(ApiError) as ctx:
            self.pedido(recogida_fecha=self.manana, recogida_hora=None)
        self.assertEqual(ctx.exception.campo, "recogida_hora")

    def test_no_admite_fechas_pasadas_ni_horas_no_validas(self):
        ayer = (biz_today() - timedelta(days=1)).isoformat()
        with self.assertRaises(ApiError) as ctx:
            self.pedido(recogida_fecha=ayer, recogida_hora="10:30")
        self.assertEqual(ctx.exception.campo, "recogida_fecha")
        for hora in ("25:00", "9:5", "soon", "10.30"):
            with self.assertRaises(ApiError) as ctx:
                self.pedido(recogida_fecha=self.manana, recogida_hora=hora)
            self.assertEqual(ctx.exception.campo, "recogida_hora")

    def test_fecha_y_hora_se_guardan_y_se_muestran_al_administrador(self):
        p = self.pedido(recogida_fecha=self.manana, recogida_hora="18:00")
        pedido = self.pedido_db(p["numero"])
        self.assertEqual(pedido["recogida_fecha"], self.manana)
        self.assertEqual(pedido["recogida_hora"], "18:00")
        detalle = self.api("GET", f"/api/admin/pedidos/{p['id']}").payload["pedido"]
        self.assertEqual(detalle["recogida_fecha"], self.manana)
        self.assertEqual(detalle["recogida_hora"], "18:00")

    def test_envio_no_pide_horario_de_recogida(self):
        p = self.crear_pedido([{"producto_id": self.producto["id"], "cantidad": 1}], tipo_entrega="envio_propio")
        self.assertEqual(self.pedido_db(p["numero"])["recogida_fecha"], "")
