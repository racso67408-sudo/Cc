"""Roles del equipo: administrador, preparación y domiciliario. Límite de administradores por tienda."""
from __future__ import annotations

from server import api, auth, db, ratelimit
from server.util import iso_now, new_id

from .harness import SUPERADMIN_PASSWORD, BaseCase

PASS_PREP = "PreparaPrueba-1"
PASS_DOM = "RepartoPrueba-1"


class Roles(BaseCase):
    def setUp(self):
        super().setUp()
        self.tienda = self.user["tienda_id"]
        self.producto = self.nuevo_producto(nombre="Rol prueba", sku="ROL-1", stock_inicial=30, coste=2, precio=10)
        self.admin_cookie = self.cookie
        self._usuario("prep@ccshops.test", "preparador", PASS_PREP)
        self._usuario("dom@ccshops.test", "domiciliario", PASS_DOM)

    def _usuario(self, email, rol, password):
        with db.session(write=True) as conn:
            conn.execute("INSERT INTO usuarios (id, nombre, email, password_hash, rol, tienda_id, activo, session_version, ultimo_acceso, created_at) "
                         "VALUES (?,?,?,?,?,?,1,0,'',?)",
                         (new_id("USR"), rol, email, auth.hash_password(password), rol, self.tienda, iso_now()))

    def como(self, email, password):
        self.cookie = self.login(email, password)

    def pedido(self, metodo="transferencia", tipo="envio_transportista"):
        return self.crear_pedido([{"producto_id": self.producto["id"], "cantidad": 1}], metodo_pago=metodo, tipo_entrega=tipo)

    # --- Preparación ---
    def test_preparacion_puede_preparar_aunque_el_pago_no_este_verificado(self):
        p = self.pedido()
        self.como("prep@ccshops.test", PASS_PREP)
        self.assertEqual(self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": "preparando"}).status, 200)
        r = self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": "preparado"})
        self.assertEqual(r.status, 200, r.payload)
        self.assertEqual(r.payload["pedido"]["pago_estado"], "pendiente_verificacion")

    def test_preparacion_no_envia_ni_cobra_ni_verifica_pagos(self):
        p = self.pedido()
        self.como("prep@ccshops.test", PASS_PREP)
        self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": "preparando"})
        self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": "preparado"})
        self.assertEqual(self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": "enviado"}).status, 403)
        self.assertEqual(self.api("POST", f"/api/admin/pedidos/{p['id']}/verificar-pago").status, 403)
        self.assertEqual(self.api("POST", f"/api/admin/pedidos/{p['id']}/envio", {"importe": 2, "cobro": "entrega"}).status, 403)
        self.assertEqual(self.api("GET", "/api/admin/equipo").status, 403)
        self.assertEqual(self.api("POST", "/api/admin/productos", {"nombre": "x"}).status, 403)

    def test_preparacion_ve_pedidos_y_productos(self):
        self.pedido()
        self.como("prep@ccshops.test", PASS_PREP)
        self.assertEqual(self.api("GET", "/api/admin/pedidos").status, 200)
        self.assertEqual(self.api("GET", "/api/admin/productos").status, 200)
        self.assertEqual(self.api("GET", "/api/admin/inventario").status, 200)

    # --- Domiciliario ---
    def test_domiciliario_solo_ve_su_hoja_de_ruta(self):
        self.como("dom@ccshops.test", PASS_DOM)
        self.assertEqual(self.api("GET", "/api/admin/pedidos").status, 403)
        self.assertEqual(self.api("GET", "/api/admin/productos").status, 403)
        self.assertEqual(self.api("GET", "/api/admin/ajustes").status, 403)
        self.assertEqual(self.api("GET", "/api/admin/ruta").status, 200)

    def test_ruta_solo_incluye_pedidos_preparados_con_pago_listo(self):
        sin_pagar = self.pedido("transferencia")
        contra = self.pedido("contrareembolso")
        verificado = self.pedido("transferencia")
        self.api("POST", f"/api/admin/pedidos/{verificado['id']}/verificar-pago")
        recogida = self.pedido("transferencia", tipo="recogida")
        for p in (sin_pagar, contra, verificado, recogida):
            self.api("POST", f"/api/admin/pedidos/{p['id']}/envio", {"importe": 0, "cobro": "entrega"}) if p["id"] != recogida["id"] else None
            self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": "preparando"})
            self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": "preparado"})
        self.como("dom@ccshops.test", PASS_DOM)
        ids = [i["id"] for i in self.api("GET", "/api/admin/ruta").payload["items"]]
        self.assertIn(contra["id"], ids)
        self.assertIn(verificado["id"], ids)
        self.assertNotIn(sin_pagar["id"], ids)
        self.assertNotIn(recogida["id"], ids)
        self.assertEqual(self.api("GET", f"/api/admin/pedidos/{sin_pagar['id']}").status, 403)

    def test_domiciliario_cobra_solo_lo_pendiente_en_la_ruta(self):
        p = self.pedido("transferencia")
        self.api("POST", f"/api/admin/pedidos/{p['id']}/verificar-pago")
        self.api("POST", f"/api/admin/pedidos/{p['id']}/envio", {"importe": 4.95, "cobro": "entrega"})
        self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": "preparando"})
        self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": "preparado"})
        self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": "enviado"})
        self.como("dom@ccshops.test", PASS_DOM)
        fila = [i for i in self.api("GET", "/api/admin/ruta").payload["items"] if i["id"] == p["id"]][0]
        self.assertAlmostEqual(fila["importe_cobrar"], 4.95, places=2)  # producto ya pagado: solo el envío
        self.assertEqual(self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": "entregado"}).status, 409)  # hay que cobrar
        self.assertEqual(self.api("POST", f"/api/admin/pedidos/{p['id']}/confirmar-cobro").status, 200)

    def test_domiciliario_envia_y_no_prepara(self):
        p = self.pedido("contrareembolso")
        self.api("POST", f"/api/admin/pedidos/{p['id']}/envio", {"importe": 3, "cobro": "entrega"})
        self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": "preparando"})
        self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": "preparado"})
        self.como("dom@ccshops.test", PASS_DOM)
        self.assertEqual(self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": "preparando"}).status, 403)
        self.assertEqual(self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": "enviado"}).status, 200)

    # --- Equipo y límite de administradores ---
    def test_el_limite_de_administradores_es_tres_por_defecto(self):
        # El administrador de la tienda ya cuenta como uno.
        for i in range(2):
            r = self.api("POST", "/api/admin/equipo", {"nombre": f"Admin {i}", "email": f"adm{i}@ccshops.test", "rol": "admin", "password": "AdminExtra-1"})
            self.assertEqual(r.status, 201, r.payload)
        r = self.api("POST", "/api/admin/equipo", {"nombre": "Cuarto", "email": "adm9@ccshops.test", "rol": "admin", "password": "AdminExtra-1"})
        self.assertEqual(r.status, 409)
        self.assertEqual(r.payload["campo"], "rol")
        # Pero sí puede añadir preparadores y domiciliarios.
        self.assertEqual(self.api("POST", "/api/admin/equipo", {"nombre": "Ana Prep", "email": "ana@ccshops.test", "rol": "preparador", "password": "AnaPrep-123"}).status, 201)

    def test_superadmin_amplia_el_limite(self):
        for i in range(2):
            self.api("POST", "/api/admin/equipo", {"nombre": f"Admin {i}", "email": f"lim{i}@ccshops.test", "rol": "admin", "password": "AdminExtra-1"})
        self.cookie = self.login("superadmin@ccshops.com", SUPERADMIN_PASSWORD)
        self.assertEqual(self.api("PUT", f"/api/superadmin/tiendas/{self.tienda}/limite-admins", {"max_admins": 2}).status, 409)
        self.assertEqual(self.api("PUT", f"/api/superadmin/tiendas/{self.tienda}/limite-admins", {"max_admins": 5}).status, 200)
        self.cookie = self.admin_cookie
        r = self.api("POST", "/api/admin/equipo", {"nombre": "Quinto", "email": "quinto@ccshops.test", "rol": "admin", "password": "AdminExtra-1"})
        self.assertEqual(r.status, 201, r.payload)

    def test_no_se_puede_quitar_el_ultimo_administrador(self):
        equipo = self.api("GET", "/api/admin/equipo").payload
        yo = [u for u in equipo["items"] if u["email"] == self.user["email"]][0]
        r = self.api("PUT", f"/api/admin/equipo/{yo['id']}", {"rol": "preparador"})
        self.assertEqual(r.status, 409)
        self.assertEqual(self.api("PUT", f"/api/admin/equipo/{yo['id']}", {"activo": False}).status, 409)

    def test_admin_cambia_el_rol_de_un_miembro(self):
        r = self.api("POST", "/api/admin/equipo", {"nombre": "Luis", "email": "luis@ccshops.test", "rol": "preparador", "password": "LuisPrep-123"})
        uid = r.payload["usuario"]["id"]
        self.assertEqual(self.api("PUT", f"/api/admin/equipo/{uid}", {"rol": "domiciliario"}).payload["usuario"]["rol"], "domiciliario")

    def test_roles_antiguos_se_tratan_como_los_nuevos(self):
        with db.session(write=True) as conn:
            conn.execute("UPDATE usuarios SET rol='operador' WHERE email='prep@ccshops.test'")
        self.como("prep@ccshops.test", PASS_PREP)
        self.assertEqual(self.api("GET", "/api/auth/me").payload["usuario"]["rol"], "preparador")
        self.assertEqual(self.api("GET", "/api/admin/pedidos").status, 200)
