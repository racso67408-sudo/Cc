"""Tests del corazón del sistema: Kardex, coste medio y ajustes."""
from __future__ import annotations

import unittest

from server import catalog, kardex
from server.db import one, session
from server.util import ApiError

from .harness import BaseCase


class KardexTests(BaseCase):
    def test_promedio_ponderado_y_saldos(self):
        p = self.nuevo_producto(stock_inicial=10, coste=5)
        self.assertEqual(float(p["stock"]), 10)
        self.assertEqual(float(p["coste_medio"]), 5)
        self.assertEqual(float(p["valor_stock"]), 50)

        with session(write=True) as conn:
            kardex.entrada(conn, p["id"], 10, 7, tipo="entrada_compra", motivo="Compra test")
        p = self.producto_db(p["id"])
        self.assertEqual(float(p["stock"]), 20)
        self.assertEqual(float(p["valor_stock"]), 120)
        self.assertAlmostEqual(float(p["coste_medio"]), 6.0, places=4)

        with session(write=True) as conn:
            mov = kardex.salida(conn, p["id"], 5, tipo="salida_venta", motivo="Venta test")
        p = self.producto_db(p["id"])
        self.assertEqual(float(p["stock"]), 15)
        self.assertEqual(float(p["valor_stock"]), 90)
        self.assertAlmostEqual(float(p["coste_medio"]), 6.0, places=4)
        self.assertAlmostEqual(mov["coste_unit"], 6.0, places=4)
        self.assertAlmostEqual(mov["coste_total"], -30.0, places=2)
        self.assertKardexCuadra(p["id"])

        with session() as conn:
            movs = kardex.listar(conn, p["id"])
        self.assertEqual(len(movs), 3)
        self.assertEqual([m["tipo"] for m in movs], ["entrada_ajuste", "entrada_compra", "salida_venta"])
        self.assertEqual(float(movs[-1]["saldo_cantidad"]), 15)

    def test_no_permite_stock_negativo_y_no_deja_rastro(self):
        p = self.nuevo_producto(stock_inicial=3, coste=4)
        with self.assertRaises(ApiError) as ctx:
            with session(write=True) as conn:
                kardex.salida(conn, p["id"], 4, tipo="salida_venta")
        self.assertEqual(ctx.exception.status, 409)
        p2 = self.producto_db(p["id"])
        self.assertEqual(float(p2["stock"]), 3)
        self.assertEqual(float(p2["valor_stock"]), 12)
        with session() as conn:
            self.assertEqual(one(conn, "SELECT COUNT(*) n FROM movimientos WHERE producto_id=?", (p["id"],))["n"], 1)

    def test_ajuste_por_recuento_y_motivo_obligatorio(self):
        p = self.nuevo_producto(stock_inicial=10, coste=5, stock_minimo=3)
        with self.assertRaises(ApiError):
            with session(write=True) as conn:
                catalog.ajustar_stock(conn, p["id"], {"nuevo_stock": 8, "motivo": ""}, self.user["id"])
        with session(write=True) as conn:
            resultado = catalog.ajustar_stock(
                conn, p["id"], {"nuevo_stock": 8, "motivo": "Rotura de envase"}, self.user["id"]
            )
        self.assertEqual(float(resultado["producto"]["stock"]), 8)
        self.assertEqual(float(resultado["producto"]["valor_stock"]), 40)
        self.assertEqual(resultado["movimiento"]["tipo"], "salida_ajuste")
        self.assertEqual(resultado["movimiento"]["cantidad"], -2)
        self.assertKardexCuadra(p["id"])

        with session(write=True) as conn:
            resultado = catalog.ajustar_stock(
                conn, p["id"], {"nuevo_stock": 9, "motivo": "Recuento", "coste": 6}, self.user["id"]
            )
        self.assertEqual(float(resultado["producto"]["stock"]), 9)
        self.assertEqual(float(resultado["producto"]["valor_stock"]), 46)
        self.assertAlmostEqual(float(resultado["producto"]["coste_medio"]), 5.1111, places=4)
        self.assertKardexCuadra(p["id"])

    def test_verificacion_detecta_libro_correcto(self):
        p = self.nuevo_producto(stock_inicial=5, coste=2.5)
        with session() as conn:
            revision = kardex.verificar(conn, p["id"])
        self.assertTrue(revision["correcto"])
        self.assertEqual(revision["libro_unidades"], 5)
        self.assertEqual(revision["libro_valor"], 12.5)

    def test_movimiento_con_cantidad_cero_falla(self):
        p = self.nuevo_producto(stock_inicial=1, coste=1)
        with self.assertRaises(ApiError):
            with session(write=True) as conn:
                kardex.entrada(conn, p["id"], 0, 1, tipo="entrada_ajuste")


if __name__ == "__main__":
    unittest.main()
