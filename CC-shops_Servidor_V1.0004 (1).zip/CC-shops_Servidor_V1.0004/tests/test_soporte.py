"""Soporte al estilo CC: conversaciones, tickets, categorías, sondeo y migración."""
from __future__ import annotations

import sqlite3
import unittest

from server import config, db, soporte
from server.util import iso_now

from .harness import OPERADOR_PASSWORD, SUPERADMIN_PASSWORD, BaseCase


class Soporte(BaseCase):
    def setUp(self):
        super().setUp()
        self.cookie_tienda = self.cookie
        self.cat = self.api("GET", "/api/admin/soporte/categorias").payload["items"][0]["id"]

    def como_plataforma(self):
        self.cookie = self.login("superadmin@ccshops.com", SUPERADMIN_PASSWORD)

    def como_tienda(self):
        self.cookie = self.cookie_tienda

    def ticket(self, **extra):
        datos = {"tipo": "incidencia", "categoria_id": self.cat, "asunto": "No veo mis pedidos",
                 "descripcion": "El panel de pedidos aparece vacío desde esta mañana.", **extra}
        r = self.api("POST", "/api/admin/soporte/tickets", datos)
        self.assertEqual(r.status, 201, r.payload)
        return r.payload["id"]

    # --- categorías ---
    def test_siete_categorias_por_defecto(self):
        nombres = {c["nombre"] for c in self.api("GET", "/api/admin/soporte/categorias").payload["items"]}
        self.assertEqual(nombres, {"General", "Agenda", "Clientes", "Cobros", "Inventario", "Consentimientos", "Otros"})

    def test_categoria_desactivada_no_admite_tickets_nuevos(self):
        self.como_plataforma()
        cid = self.api("GET", "/api/superadmin/soporte/categorias", query={"todas": "1"}).payload["items"][0]["id"]
        self.assertEqual(self.api("PUT", f"/api/superadmin/soporte/categorias/{cid}", {"activa": False}).status, 200)
        self.como_tienda()
        r = self.api("POST", "/api/admin/soporte/tickets", {"tipo": "mejora", "categoria_id": cid, "asunto": "Otra cosa", "descripcion": "Texto suficiente"})
        self.assertEqual(r.status, 400)
        self.assertNotIn(cid, [c["id"] for c in self.api("GET", "/api/admin/soporte/categorias").payload["items"]])

    def test_categoria_duplicada_se_rechaza(self):
        self.como_plataforma()
        self.assertEqual(self.api("POST", "/api/superadmin/soporte/categorias", {"nombre": "Cobros"}).status, 409)
        self.assertEqual(self.api("POST", "/api/superadmin/soporte/categorias", {"nombre": "Envíos"}).status, 201)

    # --- tickets ---
    def test_ticket_validaciones(self):
        self.assertEqual(self.api("POST", "/api/admin/soporte/tickets", {"tipo": "otra", "categoria_id": self.cat, "asunto": "Hola", "descripcion": "Texto"}).status, 400)
        self.assertEqual(self.api("POST", "/api/admin/soporte/tickets", {"tipo": "mejora", "categoria_id": "", "asunto": "Hola", "descripcion": "Texto"}).status, 400)
        self.assertEqual(self.api("POST", "/api/admin/soporte/tickets", {"tipo": "mejora", "categoria_id": self.cat, "asunto": "   ", "descripcion": "Texto"}).status, 400)

    def test_ticket_nuevo_avisa_a_plataforma(self):
        tid = self.ticket()
        self.como_plataforma()
        self.assertTrue(any(t["id"] == tid for t in self.api("GET", "/api/superadmin/soporte/tickets").payload["items"]))
        vista = self.api("GET", f"/api/superadmin/soporte/tickets/{tid}").payload
        self.assertEqual(vista["mensajes"][0]["autor_rol"], "centro")
        self.assertEqual(vista["sin_leer_plataforma"], 0)  # al abrirlo el equipo, queda leído

    def test_respuesta_de_plataforma_avisa_a_la_tienda(self):
        tid = self.ticket()
        self.como_plataforma()
        self.api("POST", f"/api/superadmin/soporte/tickets/{tid}/mensajes", {"texto": "Lo revisamos."})
        self.como_tienda()
        listado = self.api("GET", "/api/admin/soporte/tickets").payload["items"]
        self.assertEqual([t for t in listado if t["id"] == tid][0]["sin_leer_tienda"], 1)
        vista = self.api("GET", f"/api/admin/soporte/tickets/{tid}").payload
        self.assertEqual(vista["sin_leer_tienda"], 0)
        self.assertEqual(vista["mensajes"][-1]["autor_rol"], "ccpro")

    def test_respuesta_de_tienda_reabre_un_ticket_resuelto(self):
        tid = self.ticket()
        self.como_plataforma()
        self.api("PUT", f"/api/superadmin/soporte/tickets/{tid}", {"estado": "resuelto"})
        self.assertEqual(self.api("GET", f"/api/superadmin/soporte/tickets/{tid}").payload["estado"], "resuelto")
        self.como_tienda()
        self.api("POST", f"/api/admin/soporte/tickets/{tid}/mensajes", {"texto": "Sigue sin funcionar."})
        self.como_plataforma()
        vista = self.api("GET", f"/api/superadmin/soporte/tickets/{tid}").payload
        self.assertEqual(vista["estado"], "en_proceso")
        self.assertEqual(vista["sin_leer_plataforma"], 0)  # acaba de abrirlo el equipo

    def test_ocultar_ticket_no_lo_borra_y_lo_ve_plataforma(self):
        tid = self.ticket()
        self.api("PUT", f"/api/admin/soporte/tickets/{tid}", {"oculto": True})
        self.assertNotIn(tid, [t["id"] for t in self.api("GET", "/api/admin/soporte/tickets").payload["items"]])
        self.assertIn(tid, [t["id"] for t in self.api("GET", "/api/admin/soporte/tickets", query={"historial": "1"}).payload["items"]])
        self.como_plataforma()
        self.assertIn(tid, [t["id"] for t in self.api("GET", "/api/superadmin/soporte/tickets", query={"historial": "1"}).payload["items"]])

    def test_resuelto_va_al_historial_de_la_tienda(self):
        tid = self.ticket()
        self.como_plataforma()
        self.api("PUT", f"/api/superadmin/soporte/tickets/{tid}", {"estado": "resuelto"})
        self.como_tienda()
        self.assertNotIn(tid, [t["id"] for t in self.api("GET", "/api/admin/soporte/tickets").payload["items"]])
        self.assertIn(tid, [t["id"] for t in self.api("GET", "/api/admin/soporte/tickets", query={"historial": "1"}).payload["items"]])

    def test_asunto_y_mensajes_se_recortan_al_limite(self):
        tid = self.ticket(asunto="A" * 300)
        self.assertEqual(len(self.api("GET", f"/api/admin/soporte/tickets/{tid}").payload["asunto"]), 160)

    # --- conversaciones ---
    def conversacion(self, mensaje="¿Cómo cambio mis horarios?"):
        r = self.api("POST", "/api/admin/soporte/conversaciones", {"asunto": "Horarios", "mensaje": mensaje})
        self.assertEqual(r.status, 201, r.payload)
        return r.payload["id"]

    def test_conversacion_con_primer_mensaje(self):
        cid = self.conversacion()
        vista = self.api("GET", f"/api/admin/soporte/conversaciones/{cid}").payload
        self.assertEqual(vista["mensajes"][0]["cuerpo"], "¿Cómo cambio mis horarios?")
        self.assertEqual(vista["conversacion"]["estado"], "abierta")

    def test_equipo_responde_y_tienda_ve_la_respuesta(self):
        cid = self.conversacion()
        self.como_plataforma()
        self.api("POST", f"/api/superadmin/soporte/conversaciones/{cid}/mensajes", {"cuerpo": "En Ajustes, pestaña Horarios."})
        self.como_tienda()
        self.assertEqual(self.api("GET", f"/api/admin/soporte/conversaciones/{cid}").payload["mensajes"][-1]["cuerpo"], "En Ajustes, pestaña Horarios.")

    def test_conversacion_cerrada_se_reabre_si_la_tienda_escribe(self):
        cid = self.conversacion()
        self.como_plataforma()
        self.api("PUT", f"/api/superadmin/soporte/conversaciones/{cid}", {"estado": "cerrada"})
        self.como_tienda()
        self.api("POST", f"/api/admin/soporte/conversaciones/{cid}/mensajes", {"cuerpo": "Gracias, otra duda."})
        self.assertEqual(self.api("GET", f"/api/admin/soporte/conversaciones/{cid}").payload["conversacion"]["estado"], "abierta")

    def test_ocultar_conversacion_la_mueve_al_historial(self):
        cid = self.conversacion()
        self.api("PUT", f"/api/admin/soporte/conversaciones/{cid}", {"oculta": True})
        self.assertNotIn(cid, [c["id"] for c in self.api("GET", "/api/admin/soporte/conversaciones").payload["items"]])
        self.assertIn(cid, [c["id"] for c in self.api("GET", "/api/admin/soporte/conversaciones", query={"historial": "1"}).payload["items"]])

    def test_cerrar_con_estado_no_valido_falla(self):
        cid = self.conversacion()
        self.como_plataforma()
        self.assertEqual(self.api("PUT", f"/api/superadmin/soporte/conversaciones/{cid}", {"estado": "respondida"}).status, 400)

    def test_orden_de_mensajes_con_la_misma_marca_de_tiempo(self):
        cid = self.conversacion(mensaje="uno")
        for texto in ("dos", "tres", "cuatro"):
            self.api("POST", f"/api/admin/soporte/conversaciones/{cid}/mensajes", {"cuerpo": texto})
        cuerpos = [m["cuerpo"] for m in self.api("GET", f"/api/admin/soporte/conversaciones/{cid}").payload["mensajes"]]
        self.assertEqual(cuerpos, ["uno", "dos", "tres", "cuatro"])

    # --- aislamiento, sondeo y roles ---
    def test_una_tienda_no_ve_lo_de_otra(self):
        tid = self.ticket()
        with db.session(write=True) as conn:
            conn.execute("INSERT INTO tiendas (id, slug, nombre, estado, dominio_provisional, config, created_at, updated_at) "
                         "VALUES ('TDOT','otra-sop','Otra','activa','','{}',?,?)", (iso_now(), iso_now()))
            conn.execute("INSERT INTO tickets (id, tienda_id, asunto, descripcion, estado, created_at, updated_at) "
                         "VALUES ('TKTX','TDOT','Ajeno','','recibido',?,?)", (iso_now(), iso_now()))
        self.assertEqual(self.api("GET", "/api/admin/soporte/tickets/TKTX").status, 404)
        self.assertNotIn("TKTX", [t["id"] for t in self.api("GET", "/api/admin/soporte/tickets").payload["items"]])
        self.assertEqual(self.api("GET", f"/api/admin/soporte/tickets/{tid}").status, 200)

    def test_sondeo_cambia_solo_cuando_hay_novedades(self):
        cid = self.conversacion()
        v1 = self.api("GET", f"/api/admin/soporte/estado", query={"conv": cid}).payload
        self.assertEqual(self.api("GET", f"/api/admin/soporte/estado", query={"conv": cid}).payload, v1)
        self.api("POST", f"/api/admin/soporte/conversaciones/{cid}/mensajes", {"cuerpo": "Nuevo"})
        self.assertNotEqual(self.api("GET", f"/api/admin/soporte/estado", query={"conv": cid}).payload["hilo"], v1["hilo"])

    def test_preparacion_no_accede_a_soporte(self):
        self.cookie = self.login("equipo@ccshops.es", OPERADOR_PASSWORD)
        self.assertEqual(self.api("GET", "/api/admin/soporte/tickets").status, 403)
        self.assertEqual(self.api("GET", "/api/admin/soporte/conversaciones").status, 403)

    # --- migración ---
    @unittest.skipIf(config.ES_POSTGRES, "migración desde la versión SQLite antigua; no aplica a PostgreSQL")
    def test_migracion_traslada_los_tickets_antiguos(self):
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.executescript("""
            CREATE TABLE tiendas (id TEXT PRIMARY KEY);
            CREATE TABLE usuarios (id TEXT PRIMARY KEY, email TEXT);
            CREATE TABLE soporte_tickets (id TEXT PRIMARY KEY, tienda_id TEXT, asunto TEXT, estado TEXT, creado_por TEXT, created_at TEXT, updated_at TEXT);
            CREATE TABLE soporte_mensajes (id TEXT PRIMARY KEY, ticket_id TEXT, autor_id TEXT, autor_tipo TEXT, texto TEXT, created_at TEXT);
            INSERT INTO usuarios VALUES ('U1','admin@tienda.test');
            INSERT INTO soporte_tickets VALUES ('TK1','T1','Pedidos vacíos','en_curso','U1','2026-10-01T10:00:00','2026-10-02T10:00:00');
            INSERT INTO soporte_tickets VALUES ('TK2','T1','Antiguo','cerrado','U1','2026-09-01T10:00:00','2026-09-02T10:00:00');
            INSERT INTO soporte_mensajes VALUES ('M1','TK1','U1','tienda','No veo pedidos','2026-10-01T10:00:00');
            INSERT INTO soporte_mensajes VALUES ('M2','TK1',NULL,'plataforma','Lo miramos','2026-10-01T11:00:00');
        """)
        soporte.migrar(conn)
        t1 = conn.execute("SELECT * FROM tickets WHERE id='TK1'").fetchone()
        self.assertEqual(t1["estado"], "en_proceso")
        t2 = conn.execute("SELECT * FROM tickets WHERE id='TK2'").fetchone()
        self.assertEqual(t2["oculto_tienda"], 1)
        mensajes = conn.execute("SELECT autor_rol, autor_email, texto FROM tickets_mensajes WHERE ticket_id='TK1' ORDER BY created_at").fetchall()
        self.assertEqual([m["autor_rol"] for m in mensajes], ["centro", "ccpro"])
        self.assertEqual(mensajes[0]["autor_email"], "admin@tienda.test")
        # Idempotente: una segunda ejecución no duplica nada
        soporte.migrar(conn)
        self.assertEqual(conn.execute("SELECT COUNT(*) FROM tickets").fetchone()[0], 2)
