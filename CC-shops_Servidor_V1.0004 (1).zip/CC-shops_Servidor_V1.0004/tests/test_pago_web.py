"""Pago online: configuración y plataforma preparadas. El cobro lo confirma la pasarela de la otra instancia."""
from __future__ import annotations

import hashlib
import hmac
import json
import os
from unittest.mock import patch

from server import api

from .harness import BaseCase

SECRETO = "secreto-pruebas-pasarela"


def firma(cuerpo: dict) -> str:
    raw = json.dumps(cuerpo, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hmac.new(SECRETO.encode("utf-8"), raw, hashlib.sha256).hexdigest()


class PagoWeb(BaseCase):
    demo = True

    def setUp(self):
        super().setUp()
        self.producto = self.nuevo_producto(nombre="Prueba web", sku="WEB-1", stock_inicial=10, coste=2)

    def test_desactivado_por_defecto_y_no_aparece_en_la_tienda(self):
        self.assertFalse(self.api("GET", "/api/public/config", auth=False).payload["tienda"]["pago_web_activo"])

    def test_no_se_puede_activar_sin_cuenta_conectada(self):
        r = self.api("PUT", "/api/admin/ajustes", {"pago_web_activo": "1", "pago_web_cuenta": ""})
        self.assertEqual(r.status, 400)
        self.assertEqual(r.payload["campo"], "pago_web_cuenta")

    def test_pedido_con_tarjeta_rechazado_si_no_esta_activo(self):
        r = self.api("POST", "/api/public/pedidos", {
            "cliente": {"nombre": "Ana Prueba", "email": "ana@x.es", "telefono": "+34 600 000 000", "direccion": "Calle 1", "ciudad": "Terrassa", "cp": "08221", "provincia": "Barcelona"},
            "items": [{"producto_id": self.producto["id"], "cantidad": 1}], "metodo_pago": "tarjeta_web"}, auth=False)
        self.assertEqual(r.status, 400)
        self.assertEqual(r.payload["campo"], "metodo_pago")

    def test_activado_con_cuenta_crea_pedido_pendiente_de_pago(self):
        self.assertEqual(self.api("PUT", "/api/admin/ajustes", {"pago_web_activo": "1", "pago_web_cuenta": "acct_prueba123"}).status, 200)
        self.assertTrue(self.api("GET", "/api/public/config", auth=False).payload["tienda"]["pago_web_activo"])
        p = self.crear_pedido([{"producto_id": self.producto["id"], "cantidad": 1}], metodo_pago="tarjeta_web", tipo_entrega="recogida")
        pedido = self.pedido_db(p["numero"])
        self.assertEqual(pedido["pago_estado"], "pendiente_pago_web")
        self.assertEqual(pedido["estado"], "pendiente")
        pagos = self.api("GET", "/api/admin/pagos").payload
        self.assertNotIn(p["id"], [x["id"] for x in pagos["por_verificar"] + pagos["contrareembolso"]])
        self.assertEqual(self.api("GET", "/api/admin/notificaciones").payload["no_leidas"], 0)

    def test_confirmacion_firmada_marca_el_pedido_pagado(self):
        self.api("PUT", "/api/admin/ajustes", {"pago_web_activo": "1", "pago_web_cuenta": "acct_prueba123"})
        p = self.crear_pedido([{"producto_id": self.producto["id"], "cantidad": 1}], metodo_pago="tarjeta_web", tipo_entrega="recogida")
        cuerpo = {"numero": p["numero"], "referencia": "pi_test_1"}
        with patch.dict(os.environ, {"CC_PAGOS_WEBHOOK_SECRET": SECRETO}):
            mala = api.dispatch("POST", "/api/public/pagos-web/confirmacion", {}, cuerpo,
                                {"x-cc-request": "1", "x-cc-firma": "0" * 64, "x-cc-client-ip": "10.0.5.1"})
            self.assertEqual(mala.status, 401)
            ok = api.dispatch("POST", "/api/public/pagos-web/confirmacion", {}, cuerpo,
                              {"x-cc-request": "1", "x-cc-firma": firma(cuerpo), "x-cc-client-ip": "10.0.5.2"})
            self.assertEqual(ok.status, 200, ok.payload)
            self.assertFalse(ok.payload["ya_confirmado"])
            otra = api.dispatch("POST", "/api/public/pagos-web/confirmacion", {}, cuerpo,
                                {"x-cc-request": "1", "x-cc-firma": firma(cuerpo), "x-cc-client-ip": "10.0.5.3"})
            self.assertTrue(otra.payload["ya_confirmado"])
        pedido = self.pedido_db(p["numero"])
        self.assertEqual(pedido["estado"], "pagado")
        self.assertEqual(pedido["pago_estado"], "verificado")

    def test_sin_secreto_la_ruta_no_existe(self):
        cuerpo = {"numero": "PED-X", "referencia": "r"}
        with patch.dict(os.environ, {"CC_PAGOS_WEBHOOK_SECRET": ""}):
            r = api.dispatch("POST", "/api/public/pagos-web/confirmacion", {}, cuerpo,
                             {"x-cc-request": "1", "x-cc-firma": firma(cuerpo), "x-cc-client-ip": "10.0.5.4"})
        self.assertEqual(r.status, 404)

    def test_un_pedido_por_transferencia_no_se_confirma_por_pasarela(self):
        p = self.crear_pedido([{"producto_id": self.producto["id"], "cantidad": 1}], metodo_pago="transferencia", tipo_entrega="recogida")
        cuerpo = {"numero": p["numero"], "referencia": "r"}
        with patch.dict(os.environ, {"CC_PAGOS_WEBHOOK_SECRET": SECRETO}):
            r = api.dispatch("POST", "/api/public/pagos-web/confirmacion", {}, cuerpo,
                             {"x-cc-request": "1", "x-cc-firma": firma(cuerpo), "x-cc-client-ip": "10.0.5.5"})
        self.assertEqual(r.status, 409)
