"""Credenciales y tienda por defecto: no deben existir valores fijos ni tienda implícita."""
from __future__ import annotations

import io
import os
import re
import contextlib
import unittest
from pathlib import Path
from unittest.mock import patch

from server import api, auth, db
from server.seed import ensure_admin

from .harness import BaseCase

RAIZ = Path(__file__).resolve().parent.parent
CONTRASEÑAS_ANTIGUAS = ("Admin1234!", "Super1234!", "Equipo1234!")


class SinTiendaPorDefecto(BaseCase):
    def test_api_publica_sin_tienda_responde_404(self):
        for ruta in ("/api/public/config", "/api/public/productos", "/api/public/categorias"):
            r = api.dispatch("GET", ruta, {}, {}, {"x-cc-client-ip": "10.0.0.6"})
            self.assertEqual(r.status, 404, ruta)

    def test_api_publica_con_tienda_responde_200(self):
        r = api.dispatch("GET", "/api/public/config", {}, {}, {"x-cc-client-ip": "10.0.0.6", "x-tienda": "demo"})
        self.assertEqual(r.status, 200)


class SinCredencialesFijas(unittest.TestCase):
    def test_no_quedan_contrasenas_antiguas_en_el_codigo(self):
        ficheros = [p for p in RAIZ.rglob("*") if p.is_file() and ".git" not in p.parts and p.suffix in {".py", ".js", ".html", ".md", ".css"}]
        hallazgos = []
        for fichero in ficheros:
            if fichero.name == "test_seguridad_inicial.py":
                continue
            texto = fichero.read_text(encoding="utf-8", errors="ignore")
            for clave in CONTRASEÑAS_ANTIGUAS:
                if clave in texto:
                    hallazgos.append(f"{fichero.relative_to(RAIZ)}: {clave}")
        self.assertEqual(hallazgos, [])


class ContrasenaInicialGenerada(BaseCase):
    def test_sin_variable_de_entorno_se_genera_y_funciona(self):
        # patch.dict restaura el entorno al salir, así las demás pruebas siguen con sus contraseñas.
        with patch.dict(os.environ, {}, clear=False):
            for var in ("CC_ADMIN_PASSWORD", "CC_SUPERADMIN_PASSWORD", "CC_OPERADOR_PASSWORD"):
                os.environ.pop(var, None)
            salida = io.StringIO()
            with contextlib.redirect_stderr(salida):
                with db.session(write=True) as conn:
                    conn.execute("DELETE FROM usuarios")
                    ensure_admin(conn)
        generadas = re.findall(r"generada para [^:]+: (\S+)", salida.getvalue())
        self.assertEqual(len(generadas), 3)
        self.assertNotIn("Admin1234!", salida.getvalue())
        r = api.dispatch(
            "POST", "/api/auth/login", {}, {"email": "admin@ccshops.es", "password": generadas[1]},
            {"x-cc-request": "1", "x-cc-client-ip": "10.0.0.11"},
        )
        self.assertEqual(r.status, 200)
        r_vieja = api.dispatch(
            "POST", "/api/auth/login", {}, {"email": "admin@ccshops.es", "password": "Admin1234!"},
            {"x-cc-request": "1", "x-cc-client-ip": "10.0.0.12"},
        )
        self.assertEqual(r_vieja.status, 401)
