"""Arranque común de tests: base SQLite temporal, admin y helpers de API."""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from server import api, catalog, config, db, orders, purchases, ratelimit
import os

from server.seed import ADMIN_EMAIL

# Contraseñas de prueba: se pasan a la semilla por entorno, nunca quedan fijas en el código.
ADMIN_PASSWORD = "PruebaAdmin-123"
OPERADOR_PASSWORD = "PruebaOperador-123"
SUPERADMIN_PASSWORD = "PruebaSuper-123"
os.environ["CC_ADMIN_PASSWORD"] = ADMIN_PASSWORD
os.environ["CC_OPERADOR_PASSWORD"] = OPERADOR_PASSWORD
os.environ["CC_SUPERADMIN_PASSWORD"] = SUPERADMIN_PASSWORD


class BaseCase(unittest.TestCase):
    demo = False

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="cc-shops-test-")
        root = Path(self.tmp.name)
        config.DATA_DIR = root / "data"
        config.DB_PATH = config.DATA_DIR / "test.db"
        config.SECRET_PATH = config.DATA_DIR / ".secret"
        config.STATIC_DIR = Path(__file__).resolve().parent.parent / "static"
        config.IS_PROD = False
        config.PUBLIC_URL = "http://test.local"
        ratelimit.reset_all()
        if config.ES_POSTGRES:  # base limpia en cada prueba: se reinicia el esquema
            with db.session() as _c:
                _c.execute("DROP SCHEMA IF EXISTS public CASCADE")
                _c.execute("CREATE SCHEMA public")
        db.init_db(seed_demo=self.demo)
        with db.session() as conn:
            self.user = dict(db.one(conn, "SELECT * FROM usuarios WHERE email=?", (ADMIN_EMAIL,)))
        self.cookie = self.login()

    def tearDown(self):
        self.tmp.cleanup()

    # ------------------------------------------------------------------
    def login(self, email: str = ADMIN_EMAIL, password: str = ADMIN_PASSWORD) -> str:
        respuesta = api.dispatch(
            "POST",
            "/api/auth/login",
            {},
            {"email": email, "password": password},
            {"x-cc-request": "1", "x-cc-client-ip": "10.0.0.1"},
        )
        self.assertEqual(respuesta.status, 200, respuesta.payload)
        return respuesta.headers["Set-Cookie"].split(";", 1)[0]

    def api(self, method: str, path: str, body: dict | None = None, query: dict | None = None, auth: bool = True):
        headers = {"x-cc-request": "1", "x-cc-client-ip": "10.0.0.2"}
        if auth and self.cookie:
            headers["Cookie"] = self.cookie
        if path.startswith("/api/public/"):
            headers["x-tienda"] = "demo"  # la tienda pública siempre se identifica en la petición
        return api.dispatch(method, path, query or {}, body or {}, headers)

    def nuevo_producto(self, **cambios) -> dict:
        datos = {
            "nombre": "Producto de prueba",
            "sku": "TST-001",
            "precio": 12.10,
            "iva": 21,
            "coste": 5.00,
            "stock_inicial": 10,
            "stock_minimo": 2,
            "unidad": "ud",
            "categoria_id": "",
            "descripcion": "Producto para tests",
        }
        datos.update(cambios)
        with db.session(write=True) as conn:
            return catalog.crear_producto(conn, datos, self.user["id"], self.user["tienda_id"])

    def crear_pedido(self, items: list[dict], **cambios) -> dict:
        datos = {
            "cliente": {
                "nombre": "Cliente Test",
                "email": "cliente@example.com",
                "telefono": "+34 600 111 222",
                "direccion": "Calle Mayor, 1",
                "ciudad": "Terrassa",
                "cp": "08221",
                "provincia": "Barcelona",
            },
            "items": items,
            "metodo_pago": "transferencia",
            "notas": "",
        }
        datos.update(cambios)
        if datos.get("tipo_entrega") == "recogida":
            from datetime import timedelta

            from server.util import biz_today

            datos.setdefault("recogida_fecha", (biz_today() + timedelta(days=1)).isoformat())
            datos.setdefault("recogida_hora", "10:00")
        with db.session(write=True) as conn:
            return orders.crear_pedido(conn, datos, ip="10.0.0.3", tienda_id=self.user["tienda_id"])

    def producto_db(self, producto_id: str) -> dict:
        with db.session() as conn:
            return dict(db.one(conn, "SELECT * FROM productos WHERE id=?", (producto_id,)))

    def pedido_db(self, numero: str) -> dict:
        with db.session() as conn:
            return dict(db.one(conn, "SELECT * FROM pedidos WHERE numero=?", (numero,)))

    def assertKardexCuadra(self, producto_id: str) -> None:
        from server import kardex

        with db.session() as conn:
            revision = kardex.verificar(conn, producto_id)
        self.assertTrue(revision["correcto"], revision["diferencias"])
