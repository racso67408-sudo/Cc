"""Categorías y subcategorías, marcas y pedidos por preparar."""
from __future__ import annotations

from server import db
from server.util import iso_now

from .harness import BaseCase


class CategoriasTests(BaseCase):

    def crear_cat(self, nombre, padre=None):
        cuerpo = {"nombre": nombre}
        if padre:
            cuerpo["padre_id"] = padre
        r = self.api("POST", "/api/admin/categorias", cuerpo)
        self.assertEqual(r.status, 201, r.payload)
        return r.payload["categoria"]

    def producto(self, **extra):
        datos = {"nombre": extra.pop("nombre", "Prod cat"), "sku": extra.pop("sku", "CAT-" + str(id(extra))[-6:]),
                 "precio": 10, "iva": 21, "stock_inicial": 0, "stock_minimo": 0, "unidad": "ud", "coste": 1, **extra}
        r = self.api("POST", "/api/admin/productos", datos)
        self.assertEqual(r.status, 201, r.payload)
        return r.payload["producto"]

    def test_crear_subcategoria_bajo_una_categoria(self):
        principal = self.crear_cat("Pestañas")
        sub = self.crear_cat("Volumen ruso", padre=principal["id"])
        self.assertEqual(sub["padre_id"], principal["id"])
        lista = self.api("GET", "/api/admin/categorias").payload["items"]
        self.assertEqual({c["id"] for c in lista}, {c["id"] for c in lista if c["id"] in (principal["id"], sub["id"])} | {c["id"] for c in lista})
        self.assertIn(sub["id"], [c["id"] for c in lista if c["padre_id"] == principal["id"]])

    def test_solo_dos_niveles(self):
        principal = self.crear_cat("Nivel uno")
        sub = self.crear_cat("Nivel dos", padre=principal["id"])
        r = self.api("POST", "/api/admin/categorias", {"nombre": "Nivel tres", "padre_id": sub["id"]})
        self.assertEqual(r.status, 400)
        self.assertEqual(r.payload["campo"], "padre_id")

    def test_nombre_repetido_solo_dentro_del_mismo_nivel(self):
        a = self.crear_cat("Cuidado")
        self.crear_cat("Limpieza", padre=a["id"])
        r = self.api("POST", "/api/admin/categorias", {"nombre": "Limpieza"})  # mismo nombre, otro nivel: permitido
        self.assertEqual(r.status, 201)
        r = self.api("POST", "/api/admin/categorias", {"nombre": "limpieza", "padre_id": a["id"]})
        self.assertEqual(r.status, 409)

    def test_nombre_repetido_en_otra_tienda_no_choca(self):
        self.crear_cat("Exclusiva")
        with db.session(write=True) as conn:
            conn.execute("INSERT INTO tiendas (id, slug, nombre, estado, dominio_provisional, config, created_at, updated_at) "
                         "VALUES ('TDX','otra-x','Otra X','activa','','{}',?,?)", (iso_now(), iso_now()))
            conn.execute("INSERT INTO categorias (id, tienda_id, nombre, slug, descripcion, icono, orden, activo, padre_id) "
                         "VALUES ('CATX','TDX','Exclusiva','exclusiva-otra','','',0,1,NULL)")
        with db.session() as conn:
            n = db.one(conn, "SELECT COUNT(*) AS n FROM categorias WHERE nombre='Exclusiva'")["n"]
        self.assertEqual(n, 2)

    def test_producto_tiene_una_categoria_y_hasta_dos_subcategorias(self):
        principal = self.crear_cat("Adhesivos")
        s1 = self.crear_cat("Transparente", padre=principal["id"])
        s2 = self.crear_cat("Negro", padre=principal["id"])
        s3 = self.crear_cat("Blanco", padre=principal["id"])
        p = self.producto(categoria_id=principal["id"], subcategoria_ids=[s1["id"], s2["id"]])
        self.assertEqual({s["id"] for s in p["subcategorias"]}, {s1["id"], s2["id"]})
        r = self.api("PUT", f"/api/admin/productos/{p['id']}", {"subcategoria_ids": [s1["id"], s2["id"], s3["id"]]})
        self.assertEqual(r.status, 400)
        self.assertEqual(r.payload["campo"], "subcategoria_ids")

    def test_no_se_puede_elegir_una_subcategoria_como_categoria(self):
        principal = self.crear_cat("Herramientas")
        sub = self.crear_cat("Pinzas", padre=principal["id"])
        r = self.api("POST", "/api/admin/productos", {"nombre": "Pinza", "sku": "PNZ-1", "precio": 5, "iva": 21, "stock_inicial": 0, "stock_minimo": 0, "unidad": "ud", "coste": 1, "categoria_id": sub["id"]})
        self.assertEqual(r.status, 400)
        self.assertEqual(r.payload["campo"], "categoria_id")

    def test_subcategorias_deben_ser_de_la_categoria_del_producto(self):
        a = self.crear_cat("Cat A")
        b = self.crear_cat("Cat B")
        sub_b = self.crear_cat("Sub de B", padre=b["id"])
        r = self.api("POST", "/api/admin/productos", {"nombre": "X", "sku": "XX-1", "precio": 5, "iva": 21, "stock_inicial": 0, "stock_minimo": 0, "unidad": "ud", "coste": 1, "categoria_id": a["id"], "subcategoria_ids": [sub_b["id"]]})
        self.assertEqual(r.status, 400)
        self.assertEqual(r.payload["campo"], "subcategoria_ids")

    def test_cambiar_la_categoria_quita_las_subcategorias_anteriores(self):
        a = self.crear_cat("Cat X")
        b = self.crear_cat("Cat Y")
        sub_a = self.crear_cat("Sub X", padre=a["id"])
        p = self.producto(categoria_id=a["id"], subcategoria_ids=[sub_a["id"]])
        r = self.api("PUT", f"/api/admin/productos/{p['id']}", {"categoria_id": b["id"]})
        self.assertEqual(r.payload["producto"]["subcategorias"], [])

    def test_no_se_borra_una_categoria_con_subcategorias(self):
        a = self.crear_cat("Padre con hijos")
        self.crear_cat("Hijo", padre=a["id"])
        self.assertEqual(self.api("DELETE", f"/api/admin/categorias/{a['id']}").status, 409)

    def test_marcas_del_historico_de_la_tienda(self):
        self.producto(marca="Lash Pro", sku="M-1")
        self.producto(marca="Glow Labs", sku="M-2")
        self.producto(marca="Lash Pro", sku="M-3")
        marcas = self.api("GET", "/api/admin/marcas").payload["items"]
        self.assertEqual(sorted(marcas), ["Glow Labs", "Lash Pro"])

    def test_pedidos_por_preparar_incluye_los_pendientes_de_pago(self):
        p = self.nuevo_producto(nombre="Prep", sku="PRP-1", stock_inicial=10, coste=2)
        pendiente = self.crear_pedido([{"producto_id": p["id"], "cantidad": 1}], metodo_pago="transferencia", tipo_entrega="recogida")
        enviado = self.crear_pedido([{"producto_id": p["id"], "cantidad": 1}], metodo_pago="contrareembolso", tipo_entrega="recogida")
        self.api("POST", f"/api/admin/pedidos/{enviado['id']}/estado", {"estado": "preparando"})
        self.api("POST", f"/api/admin/pedidos/{enviado['id']}/estado", {"estado": "preparado"})
        self.api("POST", f"/api/admin/pedidos/{enviado['id']}/estado", {"estado": "entregado"})
        ids = [x["id"] for x in self.api("GET", "/api/admin/pedidos", query={"estado": "por_preparar"}).payload["items"]]
        self.assertIn(pendiente["id"], ids)
        self.assertNotIn(enviado["id"], ids)
