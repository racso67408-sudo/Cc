"""Tests de compras, recepción al Kardex y anulación."""
from __future__ import annotations

import unittest

from server import purchases
from server.db import session
from server.util import ApiError

from .harness import BaseCase


class PurchaseTests(BaseCase):
    def setUp(self):
        super().setUp()
        self.p = self.nuevo_producto(stock_inicial=10, coste=5, stock_minimo=2)

    def _compra(self, cantidad=10, coste=8, recibir=False):
        with session(write=True) as conn:
            return purchases.crear_compra(
                conn,
                {
                    "proveedor_id": "",
                    "fecha": "2026-10-01",
                    "lineas": [{"producto_id": self.p["id"], "cantidad": cantidad, "coste_unit": coste}],
                    "notas": "Compra test",
                },
                self.user["id"],
                recibir=recibir,
                tienda_id=self.user["tienda_id"],
            )

    def test_borrador_no_toca_stock_y_recepcion_si(self):
        compra = self._compra()
        self.assertEqual(compra["estado"], "borrador")
        self.assertEqual(float(self.producto_db(self.p["id"])["stock"]), 10)
        with session(write=True) as conn:
            recibida = purchases.recibir_compra(conn, compra["id"], self.user["id"])
        self.assertEqual(recibida["estado"], "recibida")
        p = self.producto_db(self.p["id"])
        self.assertEqual(float(p["stock"]), 20)
        self.assertAlmostEqual(float(p["coste_medio"]), 6.5, places=4)
        self.assertEqual(float(p["valor_stock"]), 130)
        self.assertKardexCuadra(self.p["id"])
        with self.assertRaises(ApiError):
            with session(write=True) as conn:
                purchases.recibir_compra(conn, compra["id"])

    def test_anular_compra_restaura_el_valor_original(self):
        compra = self._compra(recibir=True)
        with session(write=True) as conn:
            anulada = purchases.anular_compra(conn, compra["id"], self.user["id"])
        self.assertEqual(anulada["estado"], "anulada")
        p = self.producto_db(self.p["id"])
        self.assertEqual(float(p["stock"]), 10)
        self.assertAlmostEqual(float(p["coste_medio"]), 5.0, places=4)
        self.assertEqual(float(p["valor_stock"]), 50)
        self.assertKardexCuadra(self.p["id"])
        with self.assertRaises(ApiError):
            with session(write=True) as conn:
                purchases.anular_compra(conn, compra["id"])

    def test_no_anula_si_la_mercancia_ya_se_vendio(self):
        compra = self._compra(recibir=True)
        self.crear_pedido([{"producto_id": self.p["id"], "cantidad": 15}])
        with self.assertRaises(ApiError) as ctx:
            with session(write=True) as conn:
                purchases.anular_compra(conn, compra["id"])
        self.assertEqual(ctx.exception.status, 409)

    def test_solo_borra_borradores(self):
        compra = self._compra()
        with session(write=True) as conn:
            purchases.borrar_compra(conn, compra["id"])
        with session(write=True) as conn:
            with self.assertRaises(ApiError):
                purchases.borrar_compra(conn, compra["id"])


if __name__ == "__main__":
    unittest.main()
