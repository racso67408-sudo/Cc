"""Verificación de pagos por transferencia y cartera digital, y cobro en contrareembolso."""
from __future__ import annotations

from .harness import OPERADOR_PASSWORD, BaseCase


class PagosTests(BaseCase):
    def setUp(self):
        super().setUp()
        self.producto = self.nuevo_producto(nombre="Crema pago", sku="PAG-1", stock_inicial=20, coste=3)

    def pedido(self, metodo: str, cantidad: int = 1) -> dict:
        return self.crear_pedido([{"producto_id": self.producto["id"], "cantidad": cantidad}], metodo_pago=metodo, tipo_entrega="recogida")

    def test_transferencia_queda_pendiente_de_verificar_y_notifica(self):
        p = self.pedido("transferencia")
        self.assertEqual(self.pedido_db(p["numero"])["pago_estado"], "pendiente_verificacion")
        pagos = self.api("GET", "/api/admin/pagos").payload
        self.assertIn(p["id"], [x["id"] for x in pagos["por_verificar"]])
        notis = self.api("GET", "/api/admin/notificaciones").payload
        self.assertEqual(notis["no_leidas"], 1)
        self.assertIn(p["numero"], notis["items"][0]["texto"])
        self.assertEqual(notis["items"][0]["tipo"], "pago_pendiente")

    def test_cartera_digital_se_verifica_igual_y_el_alias_antiguo_se_acepta(self):
        p = self.pedido("bizum")
        self.assertEqual(self.pedido_db(p["numero"])["metodo_pago"], "cartera_digital")
        self.assertEqual(self.pedido_db(p["numero"])["pago_estado"], "pendiente_verificacion")

    def test_verificar_pago_pasa_a_pagado_y_marca_la_notificacion(self):
        p = self.pedido("transferencia")
        r = self.api("POST", f"/api/admin/pedidos/{p['id']}/verificar-pago")
        self.assertEqual(r.status, 200, r.payload)
        self.assertEqual(r.payload["pedido"]["estado"], "pagado")
        self.assertEqual(r.payload["pedido"]["pago_estado"], "verificado")
        self.assertEqual(self.api("GET", "/api/admin/pagos").payload["por_verificar"], [])
        self.assertEqual(self.api("GET", "/api/admin/notificaciones").payload["no_leidas"], 0)
        self.assertEqual(self.api("POST", f"/api/admin/pedidos/{p['id']}/verificar-pago").status, 409)

    def test_solo_el_administrador_verifica_pagos(self):
        p = self.pedido("transferencia")
        cookie = self.cookie
        self.cookie = self.login("equipo@ccshops.es", OPERADOR_PASSWORD)
        self.assertEqual(self.api("POST", f"/api/admin/pedidos/{p['id']}/verificar-pago").status, 403)
        self.cookie = cookie
        self.assertEqual(self.pedido_db(p["numero"])["pago_estado"], "pendiente_verificacion")

    def test_contrareembolso_no_aparece_para_verificar_y_se_cobra_en_la_entrega(self):
        p = self.pedido("contrareembolso")
        pagos = self.api("GET", "/api/admin/pagos").payload
        self.assertEqual(pagos["por_verificar"], [])
        self.assertIn(p["id"], [x["id"] for x in pagos["contrareembolso"]])
        self.assertEqual(self.api("GET", "/api/admin/notificaciones").payload["no_leidas"], 0)
        # No se puede cobrar antes del envío.
        self.assertEqual(self.api("POST", f"/api/admin/pedidos/{p['id']}/confirmar-cobro").status, 409)
        self.assertEqual(self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": "preparando"}).status, 200)
        self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": "preparado"})
        self.assertEqual(self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": "enviado"}).status, 200)
        r = self.api("POST", f"/api/admin/pedidos/{p['id']}/confirmar-cobro")
        self.assertEqual(r.status, 200, r.payload)
        self.assertEqual(r.payload["pedido"]["estado"], "entregado")
        self.assertEqual(r.payload["pedido"]["pago_estado"], "cobrado")
        self.assertEqual(self.api("GET", "/api/admin/pagos").payload["contrareembolso"], [])

    def test_el_domiciliario_confirma_el_cobro_de_su_ruta(self):
        from server import auth, db
        from server.util import iso_now, new_id
        with db.session(write=True) as conn:
            conn.execute("INSERT INTO usuarios (id, nombre, email, password_hash, rol, tienda_id, activo, session_version, ultimo_acceso, created_at) "
                         "VALUES (?,?,?,?,'domiciliario',?,1,0,'',?)",
                         (new_id("USR"), "Repartidor", "rep@ccshops.test", auth.hash_password("RepartoPrueba-1"), self.user["tienda_id"], iso_now()))
        p = self.crear_pedido([{"producto_id": self.producto["id"], "cantidad": 1}], metodo_pago="contrareembolso", tipo_entrega="envio_transportista")
        self.api("POST", f"/api/admin/pedidos/{p['id']}/envio", {"importe": 0, "cobro": "entrega"})
        self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": "preparando"})
        self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": "preparado"})
        self.api("POST", f"/api/admin/pedidos/{p['id']}/estado", {"estado": "enviado"})
        cookie = self.cookie
        self.cookie = self.login("rep@ccshops.test", "RepartoPrueba-1")
        self.assertEqual(self.api("POST", f"/api/admin/pedidos/{p['id']}/confirmar-cobro").status, 200)
        self.cookie = cookie

    def test_pedidos_cancelados_no_aparecen_en_pagos(self):
        p = self.pedido("transferencia")
        self.api("POST", f"/api/admin/pedidos/{p['id']}/cancelar", {})
        self.assertEqual(self.api("GET", "/api/admin/pagos").payload["por_verificar"], [])

    def test_datos_de_pago_de_la_tienda_se_publican(self):
        self.api("PUT", "/api/admin/ajustes", {"pago_iban": "ES00 0000 0000 0000 0000 0000", "pago_cartera": "600 000 000"})
        config = self.api("GET", "/api/public/config", auth=False).payload["tienda"]
        self.assertEqual(config["pago_iban"], "ES00 0000 0000 0000 0000 0000")
        self.assertEqual(config["pago_cartera"], "600 000 000")

    def test_el_pedido_publico_indica_el_estado_de_pago(self):
        p = self.pedido("transferencia")
        publico = self.api("GET", f"/api/public/pedidos/{p['numero']}", query={"t": p["token"]}, auth=False).payload
        self.assertEqual(publico["pago_estado_label"], "Pendiente de verificar")
