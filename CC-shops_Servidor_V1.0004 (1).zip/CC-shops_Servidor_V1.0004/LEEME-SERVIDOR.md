# CC-shops · paquete de servidor V1.0004

Guía completa: `docs/DESPLIEGUE-SERVIDOR.md` (incluye la sección de PostgreSQL y la migración desde SQLite).

Contenido de `deploy/`: variables de producción, servicio systemd, Caddy (HTTPS y dominios propios), túnel de Cloudflare como alternativa, y copia de seguridad (`pg_dump` con PostgreSQL, copia en caliente con SQLite).

Script de migración: `scripts/migrar_a_postgres.py`.
