# Despliegue de CC-Shops en un servidor

Guía para un servidor Linux (Debian o Ubuntu) con Python 3.11 o superior. CC-Shops no necesita dependencias externas.

## 1. Requisitos
- Un servidor con IP pública y acceso SSH.
- Un dominio (por ejemplo `tudominio.es`) con acceso a su panel DNS.
- Puertos 80 y 443 abiertos (si usas Caddy) o un túnel de Cloudflare (si no quieres abrir puertos).

## 2. Usuario, carpetas y archivos
```bash
sudo useradd --system --home /opt/cc-shops --shell /usr/sbin/nologin ccshops
sudo mkdir -p /opt/cc-shops /var/lib/cc-shops /var/backups/cc-shops /etc/cc-shops
sudo cp -r CC-shops_Servidor/* /opt/cc-shops/
sudo cp /opt/cc-shops/deploy/cc-shops.env.example /etc/cc-shops/cc-shops.env
sudo chmod 600 /etc/cc-shops/cc-shops.env
sudo chown -R ccshops:ccshops /var/lib/cc-shops /var/backups/cc-shops
```
Edita `/etc/cc-shops/cc-shops.env`: pon contraseñas largas (mínimo 8 caracteres, con letras y números), tu dominio en `CC_PUBLIC_URL` y la IP del servidor en `CC_DOMINIO_IP` si vas a usar dominios propios.

## 2b. Base de datos PostgreSQL (recomendada en producción)
SQLite funciona para empezar, pero PostgreSQL permite varias conexiones simultáneas y copias de seguridad más seguras. Para usarlo:
```bash
sudo apt install postgresql
sudo -u postgres psql -c "CREATE USER ccshops WITH PASSWORD 'cambia-esta-clave';"
sudo -u postgres psql -c "CREATE DATABASE ccshops OWNER ccshops;"
sudo -u ccshops python3 -m pip install --break-system-packages "psycopg[binary]"
```
En `/etc/cc-shops/cc-shops.env` añade: `CC_DATABASE_URL=postgresql://ccshops:cambia-esta-clave@127.0.0.1:5432/ccshops`.

Si ya tienes datos en SQLite, cópialos con el script de migración (con el servicio parado):
```bash
sudo systemctl stop cc-shops
sudo -u ccshops CC_DATABASE_URL=postgresql://ccshops:...@127.0.0.1:5432/ccshops \
    python3 /opt/cc-shops/scripts/migrar_a_postgres.py --origen /var/lib/cc-shops/cc_shops.db
sudo systemctl start cc-shops
```
El script vacía el destino, copia todas las filas en una transacción y compara el número de filas de cada tabla. Si algo no cuadra, no queda nada copiado. Guarda el archivo SQLite original como respaldo.

## 3. Servicio
```bash
sudo cp /opt/cc-shops/deploy/cc-shops.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now cc-shops
sudo systemctl status cc-shops
```
Comprueba que responde: `curl -I http://127.0.0.1:8100/`.

## 4. HTTPS y dominios

### Opción A: Caddy (recomendada si el servidor tiene IP pública)
1. Instala Caddy desde su repositorio oficial.
2. Copia `deploy/Caddyfile` a `/etc/caddy/Caddyfile` y cambia `tudominio.es`.
3. En tu DNS crea un registro `A` de `tudominio.es` y `www` apuntando a la IP del servidor.
4. `sudo systemctl reload caddy`. Caddy obtiene los certificados solo.

Los dominios propios de las tiendas se certifican bajo demanda: Caddy pregunta a `/api/public/dominio-permitido` y solo certifica los dominios con complemento activo y DNS verificado.

### Opción B: túnel de Cloudflare (sin abrir puertos)
1. `cloudflared tunnel create cc-shops` y copia `deploy/cloudflared.yml.example` a `/etc/cloudflared/config.yml`.
2. Crea el registro DNS del túnel para `tudominio.es`.
3. Los dominios propios de las tiendas con esta opción requieren **Cloudflare for SaaS** (certificados por nombre). Sin ese servicio, solo funciona la dirección de la plataforma.

## 5. Primer acceso y configuración
1. Entra en `https://tudominio.es/admin` con `superadmin@ccshops.com` y la contraseña de `CC_SUPERADMIN_PASSWORD`.
2. Cambia la contraseña en **Ajustes > Mi contraseña**.
3. En **Ajustes > Correo** configura el servidor SMTP. Envía una prueba: sin correo no llegan los enlaces de activación de cuenta ni los mensajes de contacto.
4. En **Ajustes > Dominios** fija el precio del complemento, la IP del servidor y los datos de cobro.
5. Crea las tiendas desde **Alta de tienda** (`/admin#/registro`) o desde el propio cliente.

## 6. Copias de seguridad
Con PostgreSQL, `backup.sh` usa `pg_dump` (archivo `.dump`). Con SQLite, copia la base en caliente.
```bash
sudo crontab -u ccshops -e
# añade:
0 3 * * * /opt/cc-shops/deploy/backup.sh
```
Las copias se guardan en `/var/backups/cc-shops` (se conservan las últimas 30). Copia también esa carpeta a otro lugar. Para restaurar: para el servicio, sustituye `/var/lib/cc-shops/cc_shops.db` por la copia y vuelve a arrancar.

## 7. Actualizar la versión
```bash
sudo systemctl stop cc-shops
sudo -u ccshops /opt/cc-shops/deploy/backup.sh
# copia los archivos nuevos a /opt/cc-shops (sin tocar /var/lib/cc-shops ni /etc/cc-shops)
sudo systemctl start cc-shops
```
Las migraciones de la base de datos se aplican solas al arrancar.

## 8. Lista de comprobación antes de abrirlo a clientes
- [ ] Contraseñas iniciales cambiadas (mínimo 8 caracteres, con letras y números).
- [ ] `CC_ENV=production` y `CC_SEED_DEMO=0` (no hay datos de demostración).
- [ ] HTTPS activo en `tudominio.es` (la cookie de sesión solo viaja por HTTPS).
- [ ] Correo de la plataforma probado desde Superadmin.
- [ ] Copia de seguridad programada y una restauración de prueba hecha.
- [ ] Puerto 8100 no accesible desde fuera del servidor (solo lo usa Caddy o el túnel).

## Limitaciones conocidas
- Con SQLite la base vive en un único servidor. Con PostgreSQL se pueden añadir réplicas, pero el servicio de CC-Shops sigue en un único proceso.
- El límite de peticiones y los sondeos se guardan en memoria: se reinician con el servicio.
- La compra con tarjeta todavía no está conectada a una pasarela (transferencia, cartera digital y contrareembolso sí).
- Los registros de dominio de las compras se hacen a mano: no hay integración con un proveedor de dominios.
