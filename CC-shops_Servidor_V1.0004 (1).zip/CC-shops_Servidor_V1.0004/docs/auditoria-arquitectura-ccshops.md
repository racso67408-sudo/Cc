# CC Shops · Auditoría del proyecto actual y propuesta de arquitectura multitienda

## 1. Auditoría del proyecto actual (CC-Shops)

### 1.1 Stack y estructura
- **Backend**: Python 3.12 (stdlib únicamente) + SQLite + servidor HTTP propio (`http.server.ThreadingHTTPServer`).
- **Frontend**: HTML + CSS + ES modules vanilla (sin build, sin npm).
- **Entrada**: `app.py` → `server/httpd.py` (estáticos + API JSON).
- **Dominio**: `server/*.py` (auth, catalog, orders, purchases, kardex, metrics, db, config, util, ratelimit).
- **Frontend**: `static/index.html`, `static/admin.html`, `static/js/{lib,store,admin}.js`, `static/css/{base,store,admin}.css`.
- **Tests**: 24 tests (unittest) cubriendo Kardex, pedidos, compras y API.

### 1.2 Funcionalidades existentes reutilizables
| Módulo | Estado | Reutilizable en CC Shops |
|---|---|---|
| Kardex (libro inmutable, coste medio ponderado) | Maduro, 0 inconsistencias | Sí, por tienda (añadir `tienda_id`) |
| Catálogo público + backoffice (productos, categorías, imágenes) | Completo | Sí, por tienda |
| Pedidos + estados + cancelación con devolución | Completo | Sí, por tienda |
| Compras (borrador/recepción/anulación) | Completo | Sí, por tienda |
| Proveedores | Completo | Sí, por tienda |
| Métricas por tienda (dashboard, top, series) | Completo | Sí, por tienda |
| Movimientos globales + export CSV | Completo | Sí |
| Auth por cookie + CSRF (`X-CC-Request`) | Completo | Extender con roles y tiendas |
| Cuentas de cliente + "Mis pedidos" | Nuevo | Reutilizar |
| Chat interno por pedido | Nuevo | Reutilizar |
| PWA (manifest + service worker) | Nuevo | Reutilizar por tienda |
| Ajustes de tienda (nombre, envío, etc.) | Completo | Reutilizar por tienda |

### 1.3 Problemas detectados (seguridad, rendimiento, escalabilidad)
1. **Monousuario/multitienda**: no existe concepto de `tienda_id`; toda la BD es compartida. Para multitienda hay que añadir `tienda_id` a todas las entidades y filtrar siempre por él.
2. **Roles limitados**: solo `admin`/`operador`/`cliente`. No hay SuperAdmin, ni roles personalizados ni permisos granulares. RBAC actual es binario.
3. **Sin aislamiento de datos**: las queries no filtran por tienda; un usuario de una tienda podría ver datos de otra si se conoce el ID.
4. **Sin suscripciones ni facturación**: no hay modelo de plan ni estado de suscripción.
5. **Sin Stripe Connect**: pagos simulados (transferencia, Bizum, contrareembolso). Tarjeta demo eliminada. Falta integración real.
6. **SQLite**: adecuado para MVP y pocas tiendas, pero para escalabilidad real conviene migrar a PostgreSQL (multi-tenant con RLS) en fase posterior. Se puede mantener SQLite por tienda (DB por tenant) o una BD compartida con `tienda_id`.
7. **Sesiones**: cookie firmada con secreto único; sin 2FA; sin revocación por tienda.
8. **Sin auditoría de permisos**: no hay log de acciones por usuario/tienda.
9. **Sin tests de aislamiento**: no se verifica que una tienda no vea datos de otra.
10. **Imágenes**: almacenadas como data URI o en `static/img/products`; para multitienda conviene almacenamiento por tenant (S3/MinIO) o rutas con `tienda_id`.

### 1.4 Riesgos de migración
- Cambiar el esquema para añadir `tienda_id` a todas las tablas rompe los datos existentes (1 tienda demo).
- Mitigación: script de migración que crea una tienda "demo" con todos los datos actuales asociados; mantener backup de la BD antes de migrar.
- Riesgo de pérdida de información: copia de seguridad obligatoria (`db.backup()` ya existe) y procedimiento de restauración documentado.

## 2. Arquitectura propuesta para CC Shops (multitienda)

### 2.1 Modelo de datos multitenant
- Nueva entidad **Tienda** (`tiendas`): id, slug, nombre, propietario_id, plan_id, estado_suscripcion, fecha_vencimiento, dominio_provisional, dominio_propio, tema_id, config (JSON), created_at.
- Nueva entidad **Plan** (`planes`): id, nombre, precio, periodicidad, límites (productos, usuarios, almacenamiento).
- Nueva entidad **Suscripcion** (`suscripciones`): tienda_id, plan_id, estado, fecha_inicio, fecha_fin, renovacion_automatica, metodo_pago.
- Añadir `tienda_id` (NOT NULL) a: categorias, productos, proveedores, compras, pedidos, movimientos, usuarios (salvo SuperAdmin), configuracion, eventos, pedido_chat.
- **SuperAdmin** es un usuario global sin tienda_id (tienda_id NULL) con rol `superadmin`.
- Aislamiento: toda query de negocio filtra por `tienda_id = ?` del usuario autenticado. El servidor valida, no solo la UI.

### 2.2 Resolución de tienda (routing)
- Subdominio: `mitienda.ccshops.com` → middleware resuelve `tienda_id` por slug.
- En desarrollo: `?tienda=slug` o path `/t/:slug`.
- Dominio propio (fase posterior): tabla `dominios` mapea dominio → tienda_id.

### 2.3 Autenticación y autorización
- Usuario tiene `tienda_id` (NULL para superadmin) y `rol`.
- Roles base: `superadmin`, `propietario`, `admin`, `operador`, `cliente`.
- RBAC granular: tabla `permisos` (rol/tienda → módulo → acción). El propietario puede crear roles personalizados (`roles_personalizados`, `rol_permisos`).
- 2FA: campos `two_factor_secret`, `two_factor_enabled`, `recovery_codes` en usuarios. Obligatorio para superadmin.
- Sesiones: cookie firmada con `tienda_id` y `session_version`; revocación por cambio de contraseña.

### 2.4 Suscripciones y creación automática de tienda
- Flujo: registro → elegir plan → pago (Stripe) → webhook → crear tienda + usuario propietario + datos iniciales (categorías demo, configuración por defecto) → email de bienvenida.
- Sin comisiones sobre ventas: CC Shops solo cobra suscripción.

### 2.5 Pagos
- Stripe Connect (OAuth) para que cada tienda cobre con su propia cuenta Stripe.
- Métodos adicionales por tienda: transferencia, Bizum, efectivo, contrareembolso.
- Verificación manual de pagos (transferencia/Bizum): tabla `verificaciones_pago` con historial (fecha, pedido, importe, medio, usuario, resultado, observaciones).
- Webhooks de Stripe para actualizar estado de pago.

### 2.6 Métricas
- Todas las métricas existentes, filtradas por `tienda_id`.
- Dashboard por tienda: ventas, pedidos, ticket medio, margen, top productos, categorías, series.
- SuperAdmin: métricas globales de plataforma (tiendas activas, MRR, churn) sin datos operativos privados.

### 2.7 SuperAdmin y soporte
- Panel SuperAdmin: tiendas, suscripciones, planes, estado global.
- Sistema de tickets: `tickets`, `ticket_mensajes` (conversaciones SuperAdmin ↔ propietario).
- Sin acceso automático a datos operativos de tiendas (privacidad).

### 2.8 Temas visuales (preparar desde el inicio)
- Tabla `temas` (id, nombre, config JSON de colores/fuentes/layout).
- `tiendas.tema_id` FK.
- Frontend: CSS variables inyectadas por tema; componentes parametrizables.
- Vista previa: parámetro `?preview=tema_id` renderiza sin guardar.

### 2.9 Seguridad
- HTTPS/TLS obligatorio en producción.
- Passwords: PBKDF2 (ya) o Argon2.
- CSRF: ya implementado (X-CC-Request).
- Rate limiting: ya implementado (login, pedidos).
- Aislamiento por tienda en todas las queries.
- Backups automatizados: `db.backup()` ya existe; programar.
- RGPD: consentimiento, exportación/borrado de datos de cliente.

### 2.10 Escalabilidad
- Mantener Python stdlib + SQLite para MVP multitienda (DB compartida con `tienda_id`).
- Migración futura a PostgreSQL con Row-Level Security si crece.
- Almacenamiento de imágenes: por tenant, con prefijo `tienda_id/`.

## 3. Plan de desarrollo por fases

| Fase | Alcance | Entregable |
|---|---|---|
| 1 | Auditoría, seguridad, arquitectura | Este documento + propuesta |
| 2 | Arquitectura multitienda + registro automático | `tiendas`, `planes`, `suscripciones`, middleware de resolución, registro |
| 3 | Suscripciones y creación automática de tiendas | Flujo completo de alta + tienda demo |
| 4 | Panel de administración y personalización básica | Configuración por tienda, logo, colores |
| 5 | Productos, categorías, inventario (multitienda) | CRUD por tienda, Kardex por tienda |
| 6 | Stripe Connect + medios de pago adicionales | Integración Stripe + transferencia/Bizum/efectivo/contrareembolso |
| 7 | Verificación de pagos y gestión de pedidos | Historial de verificaciones, estados |
| 8 | Envíos, fechas estimadas, tracking | Transportista, tracking, notificaciones |
| 9 | Métricas comerciales | Dashboard por tienda + gráficos |
| 10 | Usuarios, roles y permisos | RBAC granular, roles personalizados |
| 11 | Panel SuperAdmin, suscripciones, soporte | Tickets, gestión de planes |
| 12 | 2FA y refuerzo de seguridad | TOTP, recovery codes |
| 13 | Pruebas integrales y puesta en marcha | Tests de aislamiento, permisos, seguridad |

Cada fase se prueba y aprueba antes de avanzar.

## 4. Medidas de protección del proyecto actual

1. Backup completo de la BD antes de cualquier migración (`db.backup()`).
2. Rama Git `multitienda` para desarrollo; `main` permanece estable.
3. Migración: crear tienda "demo" con todos los datos actuales asociados a `tienda_id` demo.
4. Tests existentes deben seguir pasando (adaptados a `tienda_id`).
5. Procedimiento de rollback documentado.

## 5. Conclusión

La base actual (Kardex, pedidos, métricas, chat, PWA) es sólida y reutilizable. La transformación principal es añadir el concepto de `tienda_id` y el aislamiento, más suscripciones y SuperAdmin. Se recomienda empezar por la Fase 2 (arquitectura multitienda) en una rama nueva, manteniendo la tienda demo funcional.
SQL