# Dominio propio de una tienda

Una tienda puede usar su propio dominio (por ejemplo `midominio.com`) en lugar de la dirección de CC Shops. Es un complemento de pago mensual. El coste del dominio lo paga siempre el propietario.

## Para el propietario de la tienda

1. Entra en **Ajustes → Dominio propio**.
2. Elige una opción:
   - **Ya tengo un dominio**: lo registraste tú en el proveedor que quieras.
   - **Quiero comprarlo**: CC Shops lo registra por ti. Pagas el dominio completo (precio anual), aparte de la mensualidad.
3. Escribe el dominio y pulsa **Continuar**.
4. Si el dominio es tuyo, crea estos dos registros en el panel DNS de tu proveedor:

   | Tipo  | Nombre | Valor                    |
   |-------|--------|--------------------------|
   | A     | @      | la IP que te muestra la pantalla |
   | CNAME | www    | el destino que te muestra la pantalla |

5. Pulsa **Comprobar ahora**. Los cambios de DNS pueden tardar hasta 24 horas.
6. Paga el complemento mensual por transferencia o cartera digital, con la referencia que aparece en pantalla. CC Shops lo verifica y lo activa.

Cuando todo está listo, la tienda se muestra en tu dominio. Si el complemento se desactiva, el dominio deja de mostrarse y la tienda vuelve a estar en la dirección de CC Shops.

## Para CC Shops (superadmin)

En **Ajustes → Dominios** se fijan:
- El precio del complemento mensual.
- El precio anual del dominio cuando se compra (lo paga el propietario).
- La IP del servidor y el destino del «www».
- Los datos de cobro (IBAN y cartera digital).

Por cada tienda, según el camino:

- **Compra**: "Pago del dominio recibido" → se registra el dominio con tu proveedor → "Dominio registrado".
- **Propio o tras registrar**: cuando el DNS está verificado, "Activar complemento" tras verificar el pago mensual. "Desactivar complemento" quita el dominio.

No hay integración automática con un proveedor de dominios: el registro de la compra se hace a mano y se marca en la plataforma.

### Certificados HTTPS

El dominio necesita un certificado HTTPS. Se emite solo con un servidor delante de CC Shops, por ejemplo Caddy, que pide permiso a la plataforma antes de emitir cada certificado. Ejemplo de `Caddyfile`:

```
{
    on_demand_tls {
        ask http://127.0.0.1:8100/api/public/dominio-permitido
    }
}

https:// {
    tls {
        on_demand
    }
    reverse_proxy 127.0.0.1:8100
}
```

La plataforma responde 200 solo a los dominios con complemento activo y DNS verificado. Cualquier otro dominio recibe 404 y no se certifica.

Variables de entorno (opcionales, se pueden fijar también desde el superadmin):
- `CC_DOMINIO_IP`: IP pública del servidor.
- `CC_DOMINIO_DESTINO`: destino del CNAME de «www».

## Reglas

- Un dominio solo puede estar en una tienda.
- Los dominios de CC Shops no se pueden usar.
- Un dominio comprado y registrado a nombre de la tienda solo lo cambia CC Shops.
- Una tienda suspendida no se muestra en su dominio.
