/* ==========================================================================
   CC Shop's · tienda pública
   Router de hash + renderizado de páginas + carrito y checkout.
   ========================================================================== */
import {
  $, $$, esc, money, number, fmtDate, icon, categoryIcon, aplicarTema, toast, emptyState,
  api, cartItems, cartCount, cartSubtotal, cartAdd, cartSet, cartRemove,
  cartClear, onCart, cartShipping, estadoBadge, initials, formObject,
} from "./lib.js?v=6";

/* --------------------------------- Estado -------------------------------- */
const PLACEHOLDER =
  "data:image/svg+xml;charset=utf-8," +
  encodeURIComponent(
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400"><rect width="400" height="400" fill="#f1ece0"/><g fill="none" stroke="#c9bfa9" stroke-width="7" stroke-linejoin="round"><path d="M118 152h164v148H118z"/><path d="m118 152 22-42h120l22 42"/><path d="M178 152v34h44v-34"/></g></svg>'
  );

let CONFIG = null;
let ME = null;
const PRODUCTS = new Map();
let currentPath = "/";
let checkoutSubmitting = false;
const PAY_LABELS = {
  transferencia: "Transferencia bancaria",
  cartera_digital: "Cartera digital",
  tarjeta_web: "Tarjeta (pago online)",
  contrareembolso: "Contrareembolso",
};

/* -------------------------------- Utilidades ----------------------------- */
const imgSrc = (p) => (p && p.imagen ? p.imagen : PLACEHOLDER);

function unitText(p) {
  return p.unidad && p.unidad !== "ud" ? ` / ${esc(p.unidad)}` : "";
}

function stockInfo(p) {
  const s = Number(p.stock || 0);
  if (s <= 0) return { cls: "is-out", text: "Agotado temporalmente", dot: "dot--danger" };
  if (p.stock_estado === "ultimas" || s <= 5) {
    return { cls: "is-low", text: `Últimas ${number(s)} ${esc(p.unidad || "ud")}`, dot: "dot--warn" };
  }
  return { cls: "is-ok", text: `En stock · ${number(s)} ${esc(p.unidad || "ud")}`, dot: "" };
}

function remember(products) {
  (products || []).forEach((p) => { if (p && p.id) PRODUCTS.set(p.id, p); });
}

function productCard(p) {
  const info = stockInfo(p);
  const out = Number(p.stock) <= 0;
  return `<article class="product-card">
    <div class="product-media">
      <a href="#/producto/${esc(p.slug)}" aria-label="${esc(p.nombre)}">
        <img src="${esc(imgSrc(p))}" alt="${esc(p.nombre)}" loading="lazy" width="400" height="400">
      </a>
      <div class="product-badges">
        ${p.destacado ? '<span class="badge badge--brand">Destacado</span>' : ""}
        ${out ? '<span class="badge badge--danger">Agotado</span>' : ""}
        ${p.promo && !out ? '<span class="badge badge--warn">Promoción</span>' : ""}
        ${!out && p.stock_estado === "ultimas" ? '<span class="badge badge--warn">Últimas uds</span>' : ""}
      </div>
      <button class="quick-add" type="button" data-add="${esc(p.id)}" ${out ? "disabled" : ""} ${p.tiene_variantes ? `data-ver="${esc(p.slug)}" title="Elegir variante"` : ""}
        aria-label="Añadir ${esc(p.nombre)} al carrito" title="Añadir al carrito">${icon("plus", 18, 2.2)}</button>
    </div>
    <div class="product-body">
      <span class="product-cat">${esc(p.categoria_nombre || "Insumos")}</span>
      <h3 class="product-name"><a href="#/producto/${esc(p.slug)}">${esc(p.nombre)}</a></h3>
      <span class="stock-note ${info.cls}"><span class="dot ${info.dot}"></span>${info.text}</span>
      <div class="product-foot">
        <div class="product-price">${p.promo ? `<s class="muted">${money(p.precio_original)}</s> ` : ""}${money(p.precio)}<small>IVA incl.${unitText(p)}</small></div>
      </div>
    </div>
  </article>`;
}

function productGrid(items) {
  return `<div class="product-grid">${items.map(productCard).join("")}</div>`;
}

function catalogUrl({ q = "", categoria = "", orden = "", pagina = 1, disponibles = false } = {}) {
  const params = new URLSearchParams();
  if (q) params.set("q", q);
  if (categoria) params.set("categoria", categoria);
  if (orden) params.set("orden", orden);
  if (pagina > 1) params.set("pagina", String(pagina));
  if (disponibles) params.set("disponibles", "1");
  const qs = params.toString();
  return `#/tienda${qs ? `?${qs}` : ""}`;
}

function parseHash() {
  const raw = (location.hash || "#/").replace(/^#/, "");
  const [path, qs] = raw.split("?");
  return { path: path || "/", params: new URLSearchParams(qs || "") };
}

/* --------------------------------- Shell --------------------------------- */
function headerHTML(activeCat = "") {
  const t = CONFIG?.tienda || {};
  const cats = (CONFIG?.categorias || []).slice(0, 5);
  return `<div class="announcement">
    Envío a acordar en el chat del pedido · Entrega 24/48 h en península · <span>Stock real verificado</span>
  </div>
  <header class="site-header">
    <div class="container header-inner">
      <a class="logo" href="#/" aria-label="${esc(t.nombre)}, inicio">
        <span class="logo-mark">${esc(initials(t.nombre))}</span>
        <span class="logo-text"><strong>${esc(t.nombre)}</strong>${t.claim ? `<span>${esc(t.claim)}</span>` : ""}</span>
      </a>
      <nav class="main-nav" aria-label="Navegación principal">
        <a href="#/tienda" class="${currentPath === "/tienda" && !activeCat ? "is-active" : ""}">Tienda</a>
        ${cats.map((c) => `<a href="${catalogUrl({ categoria: c.slug })}" class="${activeCat === c.slug ? "is-active" : ""}">${esc(c.nombre)}</a>`).join("")}
      </nav>
      <div class="header-actions">
        <form class="header-search search-box" role="search" id="header-search">
          ${icon("search", 17)}
          <input class="input" type="search" name="q" placeholder="Buscar insumos…" aria-label="Buscar productos" autocomplete="off">
        </form>
        <a class="btn btn-ghost btn-sm" href="#/cuenta" id="account-link" style="padding:0 10px;min-height:40px">${icon("users",16)} ${ME ? "Mi cuenta" : "Entrar"}</a>
        <button class="btn-icon cart-button" type="button" id="cart-btn" aria-label="Abrir carrito">
          ${icon("cart", 20)}
          <span class="cart-count" id="cart-count" data-count="0"></span>
        </button>
        <button class="btn-icon menu-button" type="button" id="menu-btn" aria-label="Abrir menú">
          ${icon("menu", 20)}
        </button>
      </div>
    </div>
  </header>`;
}

function footerHTML() {
  const cats = CONFIG?.categorias || [];
  const t = CONFIG?.tienda || {};
  return `<footer class="site-footer">
    <div class="container">
      <div class="footer-main">
        <div class="footer-brand">
          <a class="logo" href="#/">
            <span class="logo-mark">${esc(initials(t.nombre))}</span>
            <span class="logo-text"><strong>${esc(t.nombre)}</strong>${t.claim ? `<span>${esc(t.claim)}</span>` : ""}</span>
          </a>
          <p>${esc(t.claim || "")}</p>
        </div>
        <div class="footer-col">
          <h3>Tienda</h3>
          <ul>
            <li><a href="#/tienda">Todo el catálogo</a></li>
            ${cats.map((c) => `<li><a href="${catalogUrl({ categoria: c.slug })}">${esc(c.nombre)}</a></li>`).join("")}
          </ul>
        </div>
        <div class="footer-col">
          <h3>Ayuda</h3>
          <ul>
            <li><a href="#/envios">Envíos y entrega</a></li>
            <li><a href="#/devoluciones">Devoluciones</a></li>
            <li><a href="#/faq">Preguntas frecuentes</a></li>
            <li><a href="#/contacto">Contacto</a></li>
            <li><a href="#/nosotros">Quiénes somos</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h3>Contacto</h3>
          <div class="footer-contact">
            <p>${esc(t.direccion || "")}</p>
            <p><strong>${esc(t.telefono || "")}</strong></p>
            <p><a href="mailto:${esc(t.email || "")}">${esc(t.email || "")}</a></p>
            <p>Lun–Vie · 8:00–18:00</p>
          </div>
        </div>
      </div>
      <div class="footer-bottom">
        <span>© ${new Date().getFullYear()} ${esc(t.nombre)}${t.direccion ? ` · ${esc(t.direccion)}` : ""}</span>
        <a href="/admin" class="tiny" style="margin-left:16px">Acceso clientes</a>
        <div class="footer-pay">
          <span class="pay-pill">BIZUM</span>
          <span class="pay-pill">TRANSFERENCIA</span>
          <span class="pay-pill">CONTRAREEMBOLSO</span>
        </div>
      </div>
    </div>
  </footer>`;
}

function cartDrawerHTML() {
  return `<div class="cart-drawer-backdrop" id="cart-backdrop"></div>
  <aside class="cart-drawer" id="cart-drawer" aria-label="Carrito de la compra" aria-hidden="true">
    <div class="cart-head">
      <div>
        <h2>Tu carrito</h2>
        <p id="cart-head-count">0 artículos</p>
      </div>
      <button class="btn-icon" type="button" data-close-cart aria-label="Cerrar carrito">${icon("close", 18)}</button>
    </div>
    <div class="cart-body" id="cart-body"></div>
    <div class="cart-foot" id="cart-foot"></div>
  </aside>`;
}

function mobileNavHTML() {
  const cats = CONFIG?.categorias || [];
  return `<div class="mobile-nav" id="mobile-nav">
    <div class="mobile-nav-panel" role="dialog" aria-label="Menú">
      <div class="mobile-nav-head">
        <span class="logo-text"><strong>Menú</strong></span>
        <button class="btn-icon" type="button" id="mobile-close" aria-label="Cerrar menú">${icon("close", 18)}</button>
      </div>
      <form class="search-box" id="mobile-search" role="search">
        ${icon("search", 17)}
        <input class="input" type="search" name="q" placeholder="Buscar insumos…" aria-label="Buscar productos">
      </form>
      <a href="#/tienda">Todo el catálogo</a>
      ${cats.map((c) => `<a href="${catalogUrl({ categoria: c.slug })}">${esc(c.nombre)}</a>`).join("")}
      <hr class="divider">
      <a href="#/envios">Envíos</a>
      <a href="#/devoluciones">Devoluciones</a>
      <a href="#/contacto">Contacto</a>
      <a href="#/nosotros">Quiénes somos</a>
    </div>
  </div>`;
}

function shell(content, activeCat = "") {
  return `${headerHTML(activeCat)}${content}${footerHTML()}${cartDrawerHTML()}${mobileNavHTML()}`;
}

function renderApp(content, activeCat = "") {
  const app = $("#app");
  app.innerHTML = shell(content, activeCat);
  mountShell();
}

function loadingBlock(text = "Cargando…") {
  return `<div class="container"><div class="loading-block"><span class="spinner"></span>${esc(text)}</div></div>`;
}

/* -------------------------------- Carrito DOM ---------------------------- */
function cartLineHTML(item, { page = false } = {}) {
  const href = item.slug ? `#/producto/${esc(item.slug)}` : "#/tienda";
  return `<div class="cart-line">
    <a href="${href}" aria-hidden="true" tabindex="-1"><img src="${esc(item.imagen || PLACEHOLDER)}" alt=""></a>
    <div>
      <a href="${href}" class="cart-line-name">${esc(item.nombre)}</a>
      <p class="cart-line-meta">${esc(item.sku || "")} · ${money(item.precio)}${item.unidad && item.unidad !== "ud" ? ` / ${esc(item.unidad)}` : ""}</p>
      <div class="cart-line-controls">
        <div class="qty-stepper">
          <button type="button" data-cart-dec="${esc(item.id)}" aria-label="Quitar una unidad">${icon("minus", 13)}</button>
          <input type="text" inputmode="numeric" value="${Number(item.cantidad)}" data-cart-input="${esc(item.id)}" aria-label="Cantidad de ${esc(item.nombre)}">
          <button type="button" data-cart-inc="${esc(item.id)}" aria-label="Añadir una unidad">${icon("plus", 13)}</button>
        </div>
        <button type="button" class="cart-remove" data-cart-remove="${esc(item.id)}">Quitar</button>
      </div>
    </div>
    <span class="cart-line-price">${money(Number(item.precio) * Number(item.cantidad))}</span>
  </div>`;
}

function renderCartDrawer() {
  const body = $("#cart-body");
  const foot = $("#cart-foot");
  const headCount = $("#cart-head-count");
  if (!body || !foot) return;
  const items = cartItems();
  updateCartBadge();
  const units = cartCount();
  if (headCount) headCount.textContent = units === 1 ? "1 unidad" : `${units} unidades`;
  if (!items.length) {
    body.innerHTML = `<div class="cart-empty">
      ${icon("cart", 44, 1.4)}
      <h3>Tu carrito está vacío</h3>
      <p>Añade insumos y los tendrás aquí guardados.</p>
      <a class="btn btn-primary btn-sm" href="#/tienda" data-close-cart-link>Explorar catálogo</a>
    </div>`;
    foot.innerHTML = "";
    return;
  }
  body.innerHTML = items.map((i) => cartLineHTML(i)).join("");
  const ship = cartShipping(CONFIG);
  foot.innerHTML = `
    <div class="cart-total-row"><span>Subtotal (IVA incl.)</span><strong>${money(ship.subtotal)}</strong></div>
    <p class="tiny muted" style="margin:4px 0 10px">El envío se acuerda en el chat del pedido (gratis, con coste o recogida).</p>
    <a class="btn btn-primary btn-block" href="#/checkout" data-close-cart-link>Finalizar compra ${icon("arrowRight", 17)}</a>
    <p class="cart-note"><a href="#/carrito" data-close-cart-link>Ver carrito completo</a></p>`;
}

function updateCartBadge() {
  const n = cartCount();
  $$("[id='cart-count']").forEach((el) => {
    el.textContent = n ? String(n) : "";
    el.dataset.count = String(n);
  });
}

function openCart() {
  const drawer = $("#cart-drawer");
  const backdrop = $("#cart-backdrop");
  if (!drawer || !backdrop) return;
  renderCartDrawer();
  drawer.classList.add("is-open");
  backdrop.classList.add("is-open");
  drawer.setAttribute("aria-hidden", "false");
  document.body.classList.add("no-scroll");
}

function closeCart() {
  const drawer = $("#cart-drawer");
  const backdrop = $("#cart-backdrop");
  if (!drawer || !backdrop) return;
  drawer.classList.remove("is-open");
  backdrop.classList.remove("is-open");
  drawer.setAttribute("aria-hidden", "true");
  document.body.classList.remove("no-scroll");
}

function toggleMobileNav(open) {
  const nav = $("#mobile-nav");
  if (!nav) return;
  nav.classList.toggle("is-open", open);
  document.body.classList.toggle("no-scroll", open);
}

/* -------------------------------- Eventos globales ----------------------- */
function bindCartControls(root) {
  if (!root) return;
  root.addEventListener("click", (e) => {
    const inc = e.target.closest("[data-cart-inc]");
    const dec = e.target.closest("[data-cart-dec]");
    const rem = e.target.closest("[data-cart-remove]");
    if (inc) {
      const item = cartItems().find((i) => i.id === inc.dataset.cartInc);
      if (item) cartSet(item.id, Number(item.cantidad) + 1);
    } else if (dec) {
      const item = cartItems().find((i) => i.id === dec.dataset.cartDec);
      if (item && Number(item.cantidad) > 1) cartSet(item.id, Number(item.cantidad) - 1);
    } else if (rem) {
      cartRemove(rem.dataset.cartRemove);
      toast("Producto quitado del carrito", "success", 2200);
    }
  });
  root.addEventListener("change", (e) => {
    const input = e.target.closest("[data-cart-input]");
    if (!input) return;
    const value = parseInt(input.value.replace(/[^\d]/g, ""), 10);
    cartSet(input.dataset.cartInput, Number.isFinite(value) ? value : 1);
  });
}

function mountShell() {
  updateCartBadge();
  renderCartDrawer();

  $("#cart-btn")?.addEventListener("click", openCart);
  $("#menu-btn")?.addEventListener("click", () => toggleMobileNav(true));
  $("#mobile-close")?.addEventListener("click", () => toggleMobileNav(false));
  $("#mobile-nav")?.addEventListener("click", (e) => {
    if (e.target.id === "mobile-nav") toggleMobileNav(false);
  });
  $$("[data-close-cart]").forEach((b) => b.addEventListener("click", closeCart));
  $("#cart-backdrop")?.addEventListener("click", closeCart);
  $$("[data-close-cart-link]").forEach((a) => a.addEventListener("click", closeCart));

  const search = (form) => {
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const q = (new FormData(form).get("q") || "").toString().trim();
      toggleMobileNav(false);
      closeCart();
      location.hash = catalogUrl({ q });
    });
  };
  const headerSearch = $("#header-search");
  if (headerSearch) search(headerSearch);
  const mobileSearch = $("#mobile-search");
  if (mobileSearch) search(mobileSearch);

  bindCartControls($("#cart-body"));
  bindCartControls($("#cart-foot"));

  document.body.classList.remove("no-scroll");
}

document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") { closeCart(); toggleMobileNav(false); }
});

document.addEventListener("click", (e) => {
  const ver = e.target.closest("[data-ver]");
  if (ver) { location.hash = `#/producto/${encodeURIComponent(ver.dataset.ver)}`; return; }
  const add = e.target.closest("[data-add]");
  if (add && !add.disabled) {
    const product = PRODUCTS.get(add.dataset.add);
    if (!product) return;
    cartAdd(product, 1);
    toast(`«${product.nombre}» añadido al carrito`);
    add.classList.add("is-added");
    setTimeout(() => add.classList.remove("is-added"), 600);
  }
});

/* --------------------------------- Home ---------------------------------- */
function ledgerRows(stock) {
  const s = Math.max(0, Number(stock) || 0);
  const config = s >= 30
    ? { start: s - 30, deltas: [["Compra CMP-0012", 24], ["Venta PED-0031", -6], ["Compra CMP-0019", 12]] }
    : s >= 10
      ? { start: s - 10, deltas: [["Compra CMP-0021", 12], ["Venta PED-0044", -4], ["Ajuste AJU-0007", 2]] }
      : { start: s, deltas: [] };
  let balance = config.start;
  let entradas = config.start;
  let salidas = 0;
  const rows = config.deltas.map(([label, delta]) => {
    balance += delta;
    if (delta > 0) entradas += delta; else salidas += Math.abs(delta);
    return { label, delta, balance };
  });
  return { start: config.start, rows, end: balance, entradas, salidas };
}

function homePage() {
  const t = CONFIG.tienda;
  const destacados = CONFIG.destacados || [];
  remember(destacados);
  const hero = destacados.find((p) => Number(p.stock) > 30) || destacados[0] || null;
  const cats = CONFIG.categorias || [];
  const ledger = ledgerRows(hero ? hero.stock : 46);
  const featured = destacados.slice(0, 4);
  const total = CONFIG.total_productos || 0;

  const content = `
  <section class="hero">
    <div class="container hero-grid">
      <div class="hero-copy">
        <span class="eyebrow">${esc(t.claim || "Tienda online")}</span>
        <h1>${esc(t.nombre)}</h1>
        <p>Explora el catálogo, añade lo que necesitas y confirma tu pedido. Los precios incluyen IVA.</p>
        <div class="hero-actions">
          <a class="btn btn-primary btn-lg" href="#/tienda">Ver catálogo ${icon("arrowRight", 18)}</a>
          <a class="btn btn-outline btn-lg" href="#/nosotros">Cómo trabajamos</a>
        </div>
        <div class="hero-trust">
          <div class="hero-stat"><strong>${number(total)}</strong><span>referencias activas</span></div>
          <div class="hero-stat"><strong>24/48 h</strong><span>entrega península</span></div>
          <div class="hero-stat"><strong>0</strong><span>roturas de stock ocultas</span></div>
        </div>
      </div>
      <div class="hero-art" aria-hidden="true">
        <div class="hero-blob"></div>
        ${hero ? `<div class="hero-product">
          <img src="${esc(imgSrc(hero))}" alt="">
          <div class="hero-product-meta"><strong>${esc(hero.nombre)}</strong><span>${money(hero.precio)}</span></div>
        </div>` : ""}
        <div class="hero-float hero-float--stock">
          <div class="hero-float-head">${icon("package", 14)} Stock en vivo</div>
          <strong>${hero ? number(hero.stock) : 46} ${esc(hero?.unidad || "ud")}</strong>
          <small>${hero && Number(hero.stock) > 5 ? "Disponible para envío hoy" : "Reposición en camino"}</small>
        </div>
        <div class="hero-float hero-float--kardex">
          <div class="hero-float-head">${icon("layers", 14)} Kardex · ${esc(hero?.sku || "LIM-001")}</div>
          <div class="mini-ledger">
            ${ledger.rows.map((r) => `<div class="mini-ledger-row">
              <span>${esc(r.label)}</span>
              <span class="${r.delta > 0 ? "plus" : "minus"}">${r.delta > 0 ? "+" : "−"}${number(Math.abs(r.delta))}</span>
              <span>${number(r.balance)}</span>
            </div>`).join("")}
          </div>
        </div>
        <div class="hero-stamp">Stock<span>real</span>Kardex</div>
      </div>
    </div>
  </section>

  <div class="trust-bar">
    <div class="container trust-bar-inner">
      <div class="trust-item">${icon("truck", 22)}<div><strong>Recogida o envío</strong><span>Tú eliges cómo lo recibes</span></div></div>
      <div class="trust-item">${icon("layers", 22)}<div><strong>Stock verificado</strong><span>Cada movimiento queda en el Kardex</span></div></div>
      <div class="trust-item">${icon("shield", 22)}<div><strong>Pago protegido</strong><span>Transferencia, tarjeta o contra­reembolso</span></div></div>
      <div class="trust-item">${icon("phone", 22)}<div><strong>Atención directa</strong><span>Personas, no chatbots</span></div></div>
    </div>
  </div>

  <section class="section">
    <div class="container">
      <div class="section-head">
        <div>
          <span class="eyebrow">Categorías</span>
          <h2>Lo que necesitas, por familias</h2>
          <p>Seis familias de producto para cubrir el día a día de tu negocio sin perseguir a cinco proveedores.</p>
        </div>
        <a class="section-link" href="#/tienda">Ver todo ${icon("arrowRight", 16)}</a>
      </div>
      <div class="cat-grid">
        ${cats.map((c) => `<a class="cat-card" href="${catalogUrl({ categoria: c.slug })}">
          <span class="cat-icon">${categoryIcon(c.icono)}</span>
          <div><strong>${esc(c.nombre)}</strong><span>${number(c.productos)} productos</span></div>
        </a>`).join("")}
      </div>
    </div>
  </section>

  <section class="section section--tight">
    <div class="container">
      <div class="section-head">
        <div>
          <span class="eyebrow">Selección del equipo</span>
          <h2>Los que más salen del almacén</h2>
          <p>Referencias probadas por nuestros clientes de hostelería, clínicas y oficinas.</p>
        </div>
        <a class="section-link" href="${catalogUrl({ orden: "relevancia" })}">Catálogo completo ${icon("arrowRight", 16)}</a>
      </div>
      ${featured.length ? productGrid(featured) : emptyState({ title: "Catálogo en preparación", text: "Muy pronto tendremos productos disponibles." })}
    </div>
  </section>

  <section class="section">
    <div class="container">
      <div class="values-grid">
        <div class="value-card"><span class="value-num">01</span><div class="value-icon">${icon("tag", 21)}</div>
          <h3>Precio claro</h3><p>Todos los precios llevan el IVA incluido. El envío se calcula antes de pagar, sin sorpresas en el último paso.</p></div>
        <div class="value-card"><span class="value-num">02</span><div class="value-icon">${icon("layers", 21)}</div>
          <h3>Stock que es real</h3><p>Cada venta, compra y ajuste se anota en el Kardex. Lo que ves disponible es lo que hay en el almacén.</p></div>
        <div class="value-card"><span class="value-num">03</span><div class="value-icon">${icon("truck", 21)}</div>
          <h3>Envío sin sorpresas</h3><p>El total de tu pedido no incluye el envío. La tienda te lo confirma antes de enviarlo.</p></div>
        <div class="value-card"><span class="value-num">04</span><div class="value-icon">${icon("phone", 21)}</div>
          <h3>Soporte humano</h3><p>Si algo no cuadra, escribes y te contesta una persona que conoce el catálogo y el almacén.</p></div>
      </div>
    </div>
  </section>

  <section class="section section--tight">
    <div class="container">
      <div class="newsletter">
        <div>
          <span class="eyebrow">Sin spam</span>
          <h2>Reposiciones y novedades, una vez al mes.</h2>
          <p>Te avisamos cuando llega stock de lo que sueles pedir y cuando cambian los precios de tu familia de producto.</p>
        </div>
        <form class="newsletter-form" id="newsletter-form">
          <input class="input" type="email" name="email" placeholder="tu@empresa.es" aria-label="Tu email" required>
          <button class="btn btn-primary" type="submit">Avísame</button>
        </form>
      </div>
    </div>
  </section>`;

  renderApp(content);
  $("#newsletter-form")?.addEventListener("submit", (e) => {
    e.preventDefault();
    e.target.reset();
    toast("Gracias. Te avisaremos de las próximas reposiciones.");
  });
}

/* -------------------------------- Catálogo ------------------------------- */
async function catalogPage(params) {
  const q = (params.get("q") || "").trim();
  const categoria = params.get("categoria") || "";
  const orden = params.get("orden") || "relevancia";
  const pagina = Math.max(1, parseInt(params.get("pagina") || "1", 10) || 1);
  const disponibles = params.get("disponibles") === "1";

  renderApp(`<div class="container">${loadingBlock("Cargando catálogo…")}</div>`, categoria);

  const data = await api("/api/public/productos", {
    query: {
      q, categoria, orden, pagina, por_pagina: 12,
      disponibles: disponibles ? "1" : "",
    },
  });
  remember(data.items);

  const cats = CONFIG.categorias || [];
  const catActual = cats.find((c) => c.slug === categoria);
  document.title = `${catActual ? catActual.nombre : q ? `Resultados: ${q}` : "Catálogo"} · ${CONFIG.tienda.nombre}`;
  const filtrosActivos = [];
  if (q) filtrosActivos.push(`<a class="chip is-active" href="${catalogUrl({ categoria, orden, disponibles })}">«${esc(q)}» ${icon("close", 12)}</a>`);
  if (catActual) filtrosActivos.push(`<a class="chip is-active" href="${catalogUrl({ q, orden, disponibles })}">${esc(catActual.nombre)} ${icon("close", 12)}</a>`);
  if (disponibles) filtrosActivos.push(`<a class="chip is-active" href="${catalogUrl({ q, categoria, orden })}">Solo en stock ${icon("close", 12)}</a>`);

  const content = `
  <section class="page-hero">
    <div class="container">
      <nav class="breadcrumb" aria-label="Migas de pan">
        <a href="#/">Inicio</a><span>/</span>
        ${catActual ? `<a href="#/tienda">Tienda</a><span>/</span><strong>${esc(catActual.nombre)}</strong>` : "<strong>Tienda</strong>"}
      </nav>
      <h1>${catActual ? esc(catActual.nombre) : q ? `Resultados para «${esc(q)}»` : "Catálogo completo"}</h1>
      <p>${catActual?.descripcion ? esc(catActual.descripcion) : "Filtra por familia o busca por nombre, referencia o marca."}</p>
    </div>
  </section>

  <div class="container">
    <div class="catalog-layout">
      <aside class="filters" id="filters" aria-label="Filtros">
        <div class="filter-group">
          <p class="filter-title">Categorías</p>
          <a class="filter-link ${!categoria ? "is-active" : ""}" href="${catalogUrl({ q, orden, disponibles })}">Todas <span class="n">${number(CONFIG.total_productos || 0)}</span></a>
          ${cats.map((c) => `<a class="filter-link ${categoria === c.slug ? "is-active" : ""}" href="${catalogUrl({ q, categoria: c.slug, orden, disponibles })}">
            ${esc(c.nombre)} <span class="n">${number(c.productos)}</span>
          </a>`).join("")}
        </div>
        <div class="filter-group">
          <p class="filter-title">Disponibilidad</p>
          <label class="check">
            <input type="checkbox" id="filter-disponibles" ${disponibles ? "checked" : ""}>
            Solo productos en stock
          </label>
        </div>
        <div class="filter-group">
          <p class="filter-title">Envío</p>
          <div class="notice">${icon("truck", 17)}<span>${esc(CONFIG.envio.aviso || "")}</span></div>
        </div>
        <div class="filter-group">
          <p class="filter-title">¿Necesitas algo más?</p>
          <p class="tiny muted mb-2">Busca por nombre, SKU o marca, o escríbenos y lo conseguimos.</p>
          <a class="btn btn-outline btn-sm btn-block" href="#/contacto">Pedir por encargo</a>
        </div>
      </aside>

      <div class="catalog-main">
        <div class="catalog-toolbar">
          <p class="catalog-count"><strong>${number(data.total)}</strong> ${data.total === 1 ? "producto" : "productos"}${q ? ` para «${esc(q)}»` : ""}</p>
          <div class="catalog-tools">
            <button class="btn btn-outline btn-sm filter-toggle" type="button" id="filter-toggle">${icon("filter", 15)} Filtros</button>
            <select class="select" id="order-select" aria-label="Ordenar productos">
              <option value="relevancia" ${orden === "relevancia" ? "selected" : ""}>Relevancia</option>
              <option value="precio_asc" ${orden === "precio_asc" ? "selected" : ""}>Precio: menor a mayor</option>
              <option value="precio_desc" ${orden === "precio_desc" ? "selected" : ""}>Precio: mayor a menor</option>
              <option value="nombre" ${orden === "nombre" ? "selected" : ""}>Nombre A–Z</option>
              <option value="novedad" ${orden === "novedad" ? "selected" : ""}>Novedades</option>
            </select>
          </div>
        </div>
        ${filtrosActivos.length ? `<div class="active-filters">${filtrosActivos.join("")}</div>` : ""}
        ${data.items.length
          ? productGrid(data.items)
          : emptyState({
              iconName: "search",
              title: "No encontramos nada con esos filtros",
              text: "Prueba con otra palabra o quita algún filtro. También puedes pedirnos el producto por encargo.",
              action: `<a class="btn btn-primary btn-sm" href="#/tienda">Ver todo el catálogo</a>`,
            })}
        ${data.paginas > 1 ? paginationHTML(data.pagina, data.paginas, { q, categoria, orden, disponibles }) : ""}
      </div>
    </div>
  </div>`;

  renderApp(content, categoria);
  const searchInput = $("#header-search")?.q;
  if (searchInput) searchInput.value = q;

  $("#order-select")?.addEventListener("change", (e) => {
    location.hash = catalogUrl({ q, categoria, orden: e.target.value, disponibles });
  });
  $("#filter-disponibles")?.addEventListener("change", (e) => {
    location.hash = catalogUrl({ q, categoria, orden, disponibles: e.target.checked });
  });
  $("#filter-toggle")?.addEventListener("click", () => $("#filters")?.classList.toggle("is-open"));
}

function paginationHTML(actual, total, filtros) {
  const pages = [];
  for (let i = 1; i <= total; i += 1) {
    if (i === 1 || i === total || Math.abs(i - actual) <= 1) pages.push(i);
    else if (pages[pages.length - 1] !== "…") pages.push("…");
  }
  return `<nav class="pagination" aria-label="Paginación">
    <a class="page-btn" href="${catalogUrl({ ...filtros, pagina: actual - 1 })}" ${actual <= 1 ? 'aria-disabled="true" tabindex="-1"' : ""} aria-label="Anterior">${icon("arrowLeft", 15)}</a>
    ${pages.map((p) => p === "…"
      ? `<span class="page-btn" aria-hidden="true">…</span>`
      : `<a class="page-btn ${p === actual ? "is-active" : ""}" href="${catalogUrl({ ...filtros, pagina: p })}" ${p === actual ? 'aria-current="page"' : ""}>${p}</a>`).join("")}
    <a class="page-btn" href="${catalogUrl({ ...filtros, pagina: actual + 1 })}" ${actual >= total ? 'aria-disabled="true" tabindex="-1"' : ""} aria-label="Siguiente">${icon("arrowRight", 15)}</a>
  </nav>`;
}

/* ------------------------------ Ficha producto --------------------------- */
async function productPage(slug) {
  renderApp(`<div class="container">${loadingBlock("Cargando producto…")}</div>`);
  const p = await api(`/api/public/productos/${encodeURIComponent(slug)}`);
  remember([p]);
  remember(p.relacionados || []);
  document.title = `${p.nombre} · ${CONFIG.tienda.nombre}`;
  const variantes = p.variantes || [];
  const info = variantes.length ? { cls: "", dot: "", text: "Elige una opción" } : stockInfo(p);
  const out = variantes.length ? false : Number(p.stock) <= 0;
  const specs = (p.especificaciones || []);
  const related = p.relacionados || [];
  const catUrl = p.categoria_slug ? catalogUrl({ categoria: p.categoria_slug }) : "#/tienda";

  const content = `
  <div class="container">
    <nav class="breadcrumb mt-3" aria-label="Migas de pan">
      <a href="#/">Inicio</a><span>/</span>
      <a href="#/tienda">Tienda</a><span>/</span>
      ${p.categoria_slug ? `<a href="${catUrl}">${esc(p.categoria_nombre || "Categoría")}</a><span>/</span>` : ""}
      <strong>${esc(p.nombre)}</strong>
    </nav>

    <div class="product-detail">
      <div class="product-gallery">
        <div class="gallery-frame">
          <img src="${esc(imgSrc(p))}" alt="${esc(p.nombre)}" width="800" height="800">
          ${p.destacado ? '<span class="badge badge--brand gallery-badge">Destacado</span>' : ""}
        </div>
        <div class="gallery-note">
          <span>${icon("layers", 15)} Trazabilidad Kardex</span>
          <span>${icon("truck", 15)} Envío 24/48 h</span>
          <span>${icon("shield", 15)} Compra protegida</span>
        </div>
      </div>

      <div class="product-info">
        <span class="product-cat">${esc(p.categoria_nombre || "Insumos")}${p.marca ? ` · ${esc(p.marca)}` : ""}</span>
        <h1>${esc(p.nombre)}</h1>
        <p class="product-sku">SKU ${esc(p.sku)}</p>
        ${p.descripcion_corta ? `<p class="product-intro">${esc(p.descripcion_corta)}</p>` : ""}

        <div class="price-block">
          <span class="price-now">${money(p.precio)}</span>
          <span class="price-tax">IVA ${number(p.iva, p.iva % 1 ? 1 : 0)} % incluido · ${money(p.precio / (1 + p.iva / 100))} sin IVA${p.unidad && p.unidad !== "ud" ? ` · ${esc(p.unidad)}` : ""}</span>
        </div>
        <p class="product-stock ${info.cls}"><span class="dot ${info.dot}"></span>${info.text}</p>

        ${variantes.length ? selectorVariantesHTML(variantes) : ""}
        <div class="buy-row">
          <div class="qty-stepper">
            <button type="button" id="qty-minus" aria-label="Menos unidades">${icon("minus", 16)}</button>
            <input type="text" inputmode="numeric" id="qty-input" value="1" aria-label="Cantidad" ${out ? "disabled" : ""}>
            <button type="button" id="qty-plus" aria-label="Más unidades" ${out ? "disabled" : ""}>${icon("plus", 16)}</button>
          </div>
          <button class="btn btn-primary btn-lg" type="button" id="add-to-cart" ${out ? "disabled" : ""}>
            ${icon("cart", 18)} ${out ? "Sin stock" : "Añadir al carrito"}
          </button>
        </div>

        <div class="product-usps">
          <span class="product-usp">${icon("truck", 16)} Recogida o envío · el envío lo confirma la tienda</span>
          <span class="product-usp">${icon("refresh", 16)} Devolución sin coste durante 14 días</span>
          <span class="product-usp">${icon("phone", 16)} Dudas: ${esc(CONFIG.tienda.telefono)} · ${esc(CONFIG.tienda.email)}</span>
        </div>

        <div class="product-accordions">
          <details class="accordion" open>
            <summary>Descripción y modo de uso</summary>
            <div class="accordion-body">
              <p>${esc(p.descripcion_corta || "")}</p>
              <p>${esc(p.descripcion || "Producto profesional de uso habitual en negocios.")}</p>
            </div>
          </details>
          ${specs.length ? `<details class="accordion">
            <summary>Especificaciones</summary>
            <div class="accordion-body">
              <table class="spec-table"><tbody>
                ${specs.map((s) => `<tr><th>${esc(s.clave)}</th><td>${esc(s.valor)}</td></tr>`).join("")}
              </tbody></table>
            </div>
          </details>` : ""}
          <details class="accordion">
            <summary>Envío y devoluciones</summary>
            <div class="accordion-body">
              Preparamos tu pedido el mismo día si lo recibimos antes de las 14:00. Entrega en 24/48 h en península.
              ${esc(CONFIG.envio.aviso || "")} Contra­reembolso con recargo de ${money(CONFIG.envio.recargo_contrareembolso)}.
              Dispones de 14 días para devolver el producto sin usar y en su embalaje original.
            </div>
          </details>
          <details class="accordion">
            <summary>Stock y trazabilidad</summary>
            <div class="accordion-body">
              Cada unidad vendida se descuenta del libro de inventario (Kardex) en el momento del pedido, con su documento y su coste.
              Si un pedido se cancela, la devolución se registra como una entrada al coste original, no como un borrado.
            </div>
          </details>
        </div>
      </div>
    </div>

    ${related.length ? `<section class="related-section">
      <div class="section-head">
        <div><span class="eyebrow">Combina bien con</span><h2>También te puede servir</h2></div>
        <a class="section-link" href="${catUrl}">Ver categoría ${icon("arrowRight", 16)}</a>
      </div>
      ${productGrid(related)}
    </section>` : ""}
  </div>`;

  renderApp(content, p.categoria_slug || "");
  const input = $("#qty-input");
  const clamp = (v) => Math.max(1, Math.min(Number(p.stock) || 1, v));
  $("#qty-minus")?.addEventListener("click", () => { input.value = String(clamp((parseInt(input.value, 10) || 1) - 1)); });
  $("#qty-plus")?.addEventListener("click", () => { input.value = String(clamp((parseInt(input.value, 10) || 1) + 1)); });
  input?.addEventListener("change", () => { input.value = String(clamp(parseInt(input.value, 10) || 1)); });
  if (variantes.length) {
    const { keys } = variantesDe(variantes);
    const sel = {};
    const elegida = () => variantElegida(variantes, sel, keys);
    const pintar = () => {
      $$("[data-var-key]").forEach((b) => {
        const k = b.dataset.varKey, v = b.dataset.varVal;
        b.classList.toggle("is-selected", sel[k] === v);
        const disponible = variantes.some((x) => x.atributos[k] === v && x.stock > 0 && Object.keys(sel).every((sk) => sk === k || x.atributos[sk] === sel[sk]));
        b.disabled = !disponible;
      });
      const v = elegida();
      $("#var-precio").innerHTML = v ? `${money(v.precio)}<small>IVA incl.</small>` : `${money(p.precio)}<small>desde · IVA incl.</small>`;
      $("#var-stock").textContent = !v ? "Elige todas las opciones para ver disponibilidad" : v.stock <= 0 ? "Sin stock" : v.stock <= 5 ? `Últimas ${number(v.stock)} uds` : "Disponible";
      $("#add-to-cart").disabled = !v || v.stock <= 0;
      input.max = String(v ? Math.max(1, Math.min(v.stock, 999)) : 1);
      input.value = String(Math.min(parseInt(input.value, 10) || 1, Math.max(1, v ? v.stock : 1)));
    };
    $$("[data-var-key]").forEach((b) => b.addEventListener("click", () => { sel[b.dataset.varKey] = b.dataset.varVal; pintar(); }));
    $("#add-to-cart")?.addEventListener("click", () => {
      const v = elegida();
      if (!v) return toast("Elige todas las opciones", "error");
      const etiqueta = keys.map((k) => v.atributos[k]).join(" · ");
      const cantidad = Math.max(1, Math.min(v.stock, parseInt(input?.value, 10) || 1));
      cartAdd({ id: v.id, nombre: `${p.nombre} · ${etiqueta}`, slug: p.slug, precio: v.precio, imagen: v.imagen || p.imagen, sku: v.sku, unidad: v.unidad || p.unidad, iva: p.iva, stock: v.stock }, cantidad);
      toast(`«${p.nombre} · ${etiqueta}» añadido al carrito`);
      openCart();
    });
    pintar();
    return;
  }
  $("#add-to-cart")?.addEventListener("click", () => {
    cartAdd(p, clamp(parseInt(input?.value, 10) || 1));
    toast(`«${p.nombre}» añadido al carrito`);
    openCart();
  });
}

function variantesDe(variantes) {
  const keys = [...new Set(variantes.flatMap((v) => Object.keys(v.atributos || {})))];
  const valores = Object.fromEntries(keys.map((k) => [k, [...new Set(variantes.map((v) => v.atributos[k]).filter(Boolean))]]));
  return { keys, valores };
}

function variantElegida(variantes, sel, keys) {
  if (!keys.every((k) => sel[k])) return null;
  return variantes.find((x) => keys.every((k) => x.atributos[k] === sel[k])) || null;
}

function selectorVariantesHTML(variantes) {
  const { keys, valores } = variantesDe(variantes);
  return `<div class="var-selector">${keys.map((k) => `<div class="var-grupo"><span class="var-titulo">${esc(k)}</span>
    <div class="var-opciones">${valores[k].map((v) => `<button type="button" class="var-opt" data-var-key="${esc(k)}" data-var-val="${esc(v)}">${esc(v)}</button>`).join("")}</div></div>`).join("")}
    <div class="var-resumen"><strong id="var-precio"></strong> <span class="tiny muted" id="var-stock"></span></div></div>`;
}

async function activarCuentaPage(token) {
  document.title = `Crea tu contraseña · ${CONFIG.tienda.nombre}`;
  renderApp(`<div class="container info-page" style="max-width:520px">
    <span class="eyebrow">Mi cuenta</span>
    <h1>Crea tu contraseña</h1>
    <p class="lead">Tu cuenta ya está creada. Elige una contraseña para ver tus pedidos.</p>
    <form class="checkout-section" id="act-form" style="margin-top:18px" novalidate>
      <div class="field"><label>Contraseña</label><input class="input" type="password" name="password" autocomplete="new-password" required></div>
      <p class="tiny muted">Mínimo 8 caracteres, con letras y números.</p>
      <button class="btn btn-primary btn-block" type="submit" id="act-btn">Guardar y entrar</button>
    </form>
    <p class="tiny muted" style="margin-top:12px">¿El enlace ha caducado? <a href="#/cuenta/reenviar">Pide uno nuevo</a>.</p>
  </div>`);
  $("#act-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = $("#act-btn");
    setBusy(btn, true, "Guardando…");
    try {
      await api("/api/auth/activar", { method: "POST", body: { token, password: formObject(e.target).password } });
      toast("Contraseña creada. Ya puedes entrar.");
      location.hash = "#/cuenta";
    } catch (err) { setBusy(btn, false); toast(err.message, "error"); }
  });
}

async function reenviarActivacionPage() {
  document.title = `Pedir enlace · ${CONFIG.tienda.nombre}`;
  renderApp(`<div class="container info-page" style="max-width:520px">
    <span class="eyebrow">Mi cuenta</span><h1>Pedir enlace</h1>
    <p class="lead">Escribe el email de tu compra y te enviaremos un enlace para crear tu contraseña.</p>
    <form class="checkout-section" id="reenvio-form" style="margin-top:18px" novalidate>
      <div class="field"><label>Email</label><input class="input" type="email" name="email" required></div>
      <button class="btn btn-primary btn-block" type="submit" id="reenvio-btn">Enviar enlace</button>
    </form></div>`);
  $("#reenvio-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = $("#reenvio-btn");
    setBusy(btn, true, "Enviando…");
    try {
      await api("/api/auth/reenviar-activacion", { method: "POST", body: formObject(e.target) });
      toast("Si hay una cuenta con ese email, te hemos enviado el enlace.");
      e.target.reset();
    } catch (err) { toast(err.message, "error"); }
    finally { setBusy(btn, false); }
  });
}

/* --------------------------------- Carrito -------------------------------- */
function cartPage() {
  const items = cartItems();
  const ship = cartShipping(CONFIG);
  const content = `
  <section class="page-hero">
    <div class="container">
      <nav class="breadcrumb"><a href="#/">Inicio</a><span>/</span><strong>Carrito</strong></nav>
      <h1>Tu carrito</h1>
      <p>Revisa las cantidades y las condiciones antes de pasar por caja.</p>
    </div>
  </section>
  <div class="container">
    ${items.length ? `<div class="cart-page">
      <div>
        <div class="cart-page-list" id="cart-page-body">
          ${items.map((i) => cartLineHTML(i, { page: true })).join("")}
        </div>
        <div class="row-between mt-2">
          <a class="btn btn-ghost btn-sm" href="#/tienda">${icon("arrowLeft", 15)} Seguir comprando</a>
          <button class="btn btn-ghost btn-sm" type="button" id="empty-cart">Vaciar carrito</button>
        </div>
      </div>
      <aside class="summary-card">
        <h2>Resumen</h2>
        <div class="summary-row"><span>Subtotal</span><span>${money(ship.subtotal)}</span></div>
        <div class="summary-row"><span>Envío</span><span id="sum-envio">A confirmar por la tienda</span></div>
        <div class="summary-row summary-row--total"><span>Total</span><span>${money(ship.subtotal)}</span></div>
        <p class="tiny muted mt-1">IVA incluido. El envío se acuerda con nosotros en el chat del pedido.</p>
        <a class="btn btn-primary btn-block" href="#/checkout">Continuar con el pedido ${icon("arrowRight", 17)}</a>
        <div class="summary-trust">
          <span>${icon("truck", 15)} Entrega 24/48 h en península</span>
          <span>${icon("refresh", 15)} 14 días para devoluciones</span>
          <span>${icon("shield", 15)} Pago protegido y datos cifrados</span>
        </div>
      </aside>
    </div>` : `<div class="mt-3">${emptyState({
      iconName: "cart",
      title: "Tu carrito está vacío",
      text: "Todavía no has añadido nada. Explora el catálogo y empieza por los básicos.",
      action: `<a class="btn btn-primary" href="#/tienda">Ver catálogo</a>`,
    })}</div>`}
  </div>`;
  renderApp(content);
  bindCartControls($("#cart-page-body"));
  $("#empty-cart")?.addEventListener("click", () => { cartClear(); toast("Carrito vaciado"); });
}

/* -------------------------------- Checkout ------------------------------- */
// Forma de entrega: con recogida no se pide dirección y el envío es sin coste.
function actualizarEntrega() {
  const tipo = document.querySelector("input[name='tipo_entrega']:checked")?.value || "envio_transportista";
  const recogida = tipo === "recogida";
  const bloque = $("#bloque-direccion");
  if (bloque) bloque.style.display = recogida ? "none" : "";
  ["direccion", "cp", "ciudad"].forEach((n) => { const el = document.querySelector(`[name='${n}']`); if (el) el.required = !recogida; });
  const aviso = $("#entrega-aviso");
  if (aviso) aviso.style.display = recogida ? "none" : "";
  document.querySelectorAll("#sum-envio").forEach((sum) => { sum.textContent = recogida ? "Sin coste (recogida)" : "A confirmar por la tienda"; });
  const bloqueRecogida = $("#bloque-recogida");
  if (bloqueRecogida) bloqueRecogida.style.display = recogida ? "" : "none";
  ["recogida_fecha", "recogida_hora"].forEach((n) => { const el = document.querySelector(`[name='${n}']`); if (el) el.required = recogida; });
}

function actualizarDatosPago() {
  const el = $("#pago-datos");
  if (!el) return;
  const metodo = document.querySelector("input[name='metodo_pago']:checked")?.value;
  const t = CONFIG.tienda;
  const plazo = ["transferencia", "cartera_digital", "tarjeta_web"].includes(metodo) && t.aviso_plazo_pago
    ? `<div class="notice notice--warn" style="margin-top:10px"><span>${esc(t.aviso_plazo_pago)}</span></div>` : "";
  if (metodo === "transferencia") {
    el.innerHTML = `<div class="notice"><span>Haz una transferencia a <strong>${esc(t.pago_iban || "la cuenta que te indicaremos por email")}</strong> por el importe de tu pedido. Indica tu número de pedido en el concepto. Preparamos tu pedido cuando verificamos el ingreso.</span></div>${plazo}`;
  } else if (metodo === "cartera_digital") {
    el.innerHTML = `<div class="notice"><span>Envía el importe de tu pedido a <strong>${esc(t.pago_cartera || "el número que te indicaremos por email")}</strong> e indica tu número de pedido. Preparamos tu pedido cuando verificamos el pago.</span></div>${plazo}`;
  } else if (metodo === "contrareembolso") {
    el.innerHTML = `<div class="notice"><span>Pagarás al recibir el pedido. El transportista confirma el cobro en la entrega.</span></div>`;
  } else if (metodo === "tarjeta_web") {
    el.innerHTML = `<div class="notice"><span>Completa el pago de forma segura al confirmar. Preparamos tu pedido cuando se confirma el cobro.</span></div>${plazo}`;
  } else {
    el.innerHTML = "";
  }
}

// Aviso del estado de pago en la página de seguimiento del pedido.
function avisoPago(pedido) {
  const t = CONFIG.tienda;
  const estado = pedido.pago_estado;
  if ((estado === "pendiente_verificacion" || estado === "pendiente_pago_web") && pedido.pago_vence_at) {
    const limite = new Date(pedido.pago_vence_at).toLocaleString("es-ES", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });
    if (pedido.pago_vencido) {
      return `<div class="notice notice--warn"><span>El plazo para pagar este pedido ha vencido. Si no recibimos el pago, se cancelará y los productos volverán al stock. Si ya has pagado, escríbenos con tu número de pedido.</span></div>`;
    }
    return `<div class="notice notice--warn"><span>Plazo para pagar: <strong>${esc(limite)}</strong>. ${esc(t.aviso_plazo_pago || "")}</span></div>` + (estado === "pendiente_verificacion" ? `<div class="notice"><span>Envía el importe ${pedido.metodo_pago === "cartera_digital" ? `a <strong>${esc(t.pago_cartera || "el número indicado")}</strong>` : `a <strong>${esc(t.pago_iban || "la cuenta indicada")}</strong>`} indicando el número <strong>${esc(pedido.numero)}</strong>. Te avisaremos cuando lo recibamos.</span></div>` : "");
  }
  if (estado === "pendiente_verificacion") {
    const destino = pedido.metodo_pago === "cartera_digital"
      ? `a <strong>${esc(t.pago_cartera || "el número indicado")}</strong> desde tu cartera digital`
      : `a <strong>${esc(t.pago_iban || "la cuenta indicada")}</strong> por transferencia`;
    return `<div class="notice"><span>Estamos esperando la verificación de tu pago. Envía el importe ${destino} indicando el número <strong>${esc(pedido.numero)}</strong>. Te avisaremos cuando lo recibamos.</span></div>`;
  }
  if (estado === "verificado") return `<div class="notice notice--ok"><span>Hemos verificado tu pago. Preparamos tu pedido.</span></div>`;
  if (estado === "pendiente_pago_web") return `<div class="notice"><span>Tu pedido está pendiente de pago. Lo prepararemos cuando confirmemos el cobro.</span></div>`;
  if (estado === "pendiente_cobro") return `<div class="notice"><span>Pagarás <strong>${pedido.a_cobrar != null ? money(pedido.a_cobrar) : "el total más el envío que te confirmaremos"}</strong> al recibir el pedido.</span></div>`;
  if (estado === "cobrado") return `<div class="notice notice--ok"><span>Pedido pagado al recibirlo. ¡Gracias!</span></div>`;
  return "";
}

function checkoutTotals(items, metodo) {
  const productos = items.reduce((acc, i) => acc + Number(i.precio) * Number(i.cantidad), 0);
  let base = items.reduce((acc, i) => acc + (Number(i.precio) * Number(i.cantidad)) / (1 + Number(i.iva || 21) / 100), 0);
  const total = productos;
  return { productos, envio: 0, envioBase: 0, recargo: 0, base, iva: total - base, total };
}

function checkoutPage() {
  const items = cartItems();
  if (!items.length) {
    location.hash = "#/carrito";
    return;
  }
  let totals = checkoutTotals(items, "transferencia");
  const content = `
  <div class="container checkout-head">
    <nav class="breadcrumb"><a href="#/">Inicio</a><span>/</span><a href="#/carrito">Carrito</a><span>/</span><strong>Checkout</strong></nav>
    <h1 class="serif" style="font-size:clamp(34px,4vw,48px);margin-top:8px">Finalizar pedido</h1>
  </div>
  <div class="container">
    <form class="checkout-layout" id="checkout-form" novalidate>
      <div>
        <section class="checkout-section">
          <h2><span class="checkout-step">1</span> Datos de contacto</h2>
          <div class="form-grid">
            <div class="field full"><label for="ck-email">Email</label>
              <input class="input" type="email" id="ck-email" name="email" autocomplete="email" placeholder="tu@empresa.es" required>
            </div>
            <div class="field"><label for="ck-nombre">Nombre y apellidos</label>
              <input class="input" id="ck-nombre" name="nombre" autocomplete="name" placeholder="Nombre completo" required>
            </div>
            <div class="field"><label for="ck-telefono">Teléfono</label>
              <input class="input" id="ck-telefono" name="telefono" autocomplete="tel" placeholder="+34 600 000 000">
            </div>
          </div>
        </section>

        <section class="checkout-section">
          <h2><span class="checkout-step">2</span> Entrega</h2>
          <div class="pay-options" id="entrega-opciones">
            <label class="pay-option">
              <input type="radio" name="tipo_entrega" value="envio_transportista" checked>
              <span><strong>Envío por transportista</strong><span>Correos, DHL u otro transportista. La tienda te confirma el coste y cómo pagarlo.</span></span>
              <span class="pay-icon">${icon("truck", 20)}</span>
            </label>
            <label class="pay-option">
              <input type="radio" name="tipo_entrega" value="envio_propio">
              <span><strong>Envío propio</strong><span>Lo enviamos nosotros. El envío se cobra al recibir el pedido.</span></span>
              <span class="pay-icon">${icon("truck", 20)}</span>
            </label>
            <label class="pay-option">
              <input type="radio" name="tipo_entrega" value="recogida">
              <span><strong>Recogida en tienda</strong><span>Sin coste de envío. ${esc(CONFIG.tienda.direccion || "Te indicamos la dirección de recogida.")}</span></span>
              <span class="pay-icon">${icon("package", 20)}</span>
            </label>
          </div>
          <div id="bloque-recogida" class="form-grid" style="display:none;margin-bottom:14px">
            <div class="field"><label for="ck-recogida-fecha">Fecha aproximada de recogida</label>
              <input class="input" type="date" id="ck-recogida-fecha" name="recogida_fecha" min="${new Date().toISOString().slice(0, 10)}"></div>
            <div class="field"><label for="ck-recogida-hora">Hora aproximada</label>
              <input class="input" type="time" id="ck-recogida-hora" name="recogida_hora"></div>
            <p class="tiny muted full">Indícanos cuándo pasarás y te confirmamos la hora exacta antes de tu visita.</p>
          </div>
          <div id="entrega-aviso" class="notice" style="margin-bottom:14px">${icon("truck", 17)}<span>${esc(CONFIG.envio.aviso || "")}</span></div>
          <div class="form-grid" id="bloque-direccion">
            <div class="field"><label for="ck-empresa">Empresa <span class="muted">(opcional)</span></label>
              <input class="input" id="ck-empresa" name="empresa" autocomplete="organization" placeholder="Nombre de la empresa">
            </div>
            <div class="field"><label for="ck-nif">NIF / CIF <span class="muted">(opcional)</span></label>
              <input class="input" id="ck-nif" name="nif" placeholder="B12345678">
            </div>
            <div class="field full"><label for="ck-direccion">Dirección</label>
              <input class="input" id="ck-direccion" name="direccion" autocomplete="street-address" placeholder="Calle, número, piso" required>
            </div>
            <div class="field"><label for="ck-cp">Código postal</label>
              <input class="input" id="ck-cp" name="cp" autocomplete="postal-code" inputmode="numeric" placeholder="08224" required>
            </div>
            <div class="field"><label for="ck-ciudad">Ciudad</label>
              <input class="input" id="ck-ciudad" name="ciudad" autocomplete="address-level2" placeholder="Terrassa" required>
            </div>
            <div class="field"><label for="ck-provincia">Provincia</label>
              <input class="input" id="ck-provincia" name="provincia" autocomplete="address-level1" placeholder="Barcelona">
            </div>
            <div class="field"><label for="ck-pais">País</label>
              <input class="input" id="ck-pais" name="pais" value="España" autocomplete="country-name">
            </div>
            <div class="field full"><label for="ck-notas">Notas para la entrega <span class="muted">(opcional)</span></label>
              <textarea class="textarea" id="ck-notas" name="notas" placeholder="Horario de recepción, referencia del pedido, etc."></textarea>
            </div>
          </div>
        </section>

        <section class="checkout-section">
          <h2><span class="checkout-step">3</span> Método de pago</h2>
          <div class="pay-options">
<label class="pay-option">
              <input type="radio" name="metodo_pago" value="transferencia" checked>
              <span><strong>Transferencia bancaria</strong><span>Recibirás los datos por email. Preparamos el pedido al confirmar el ingreso.</span></span>
              <span class="pay-icon">${icon("card", 20)}</span>
            </label>
            <label class="pay-option">
              <input type="radio" name="metodo_pago" value="cartera_digital">
              <span><strong>Cartera digital</strong><span>Pagas desde tu app de cartera digital. Verificamos el pago antes de preparar el pedido.</span></span>
              <span class="pay-icon">${icon("phone", 20)}</span>
            </label>
            ${CONFIG.tienda.pago_web_activo ? `<label class="pay-option">
              <input type="radio" name="metodo_pago" value="tarjeta_web">
              <span><strong>Tarjeta</strong><span>Pago seguro en línea. Tu pedido se prepara cuando se confirma el cobro.</span></span>
              <span class="pay-icon">${icon("card", 20)}</span>
            </label>` : ""}
            <label class="pay-option">
              <input type="radio" name="metodo_pago" value="contrareembolso">
              <span><strong>Contrareembolso</strong><span>Pagas al transportista. Recargo de ${money(CONFIG.envio.recargo_contrareembolso)}.</span></span>
              <span class="pay-icon">${icon("truck", 20)}</span>
            </label>
          </div>
          <div id="pago-datos" class="pago-datos" aria-live="polite"></div>
          <p class="checkout-legal">${esc(CONFIG.tienda.aviso_pago || "")} El envío se acuerda en el chat del pedido. Al confirmar aceptas las <a href="#/aviso-legal">condiciones de venta</a> y la <a href="#/privacidad">política de privacidad</a>.</p>
        </section>

        <label class="check full" style="margin:2px 0 18px">
          <input type="checkbox" id="ck-acepta" required>
          <span>He leído y acepto las condiciones de venta y la política de privacidad.</span>
        </label>
        <button class="btn btn-primary btn-lg btn-block" type="submit" id="pay-btn">${icon("lock", 18)} Confirmar pedido · <span id="pay-total">${money(totals.total)}</span></button>
        <p class="tiny muted center mt-1">No se realizará ningún cargo real en este entorno de demostración.</p>
      </div>

      <aside class="summary-card checkout-summary">
        <h2>Tu pedido</h2>
        ${items.map((i) => `<div class="checkout-line">
          <img src="${esc(i.imagen || PLACEHOLDER)}" alt="">
          <div><p class="checkout-line-name">${esc(i.nombre)}</p><p class="checkout-line-qty">${Number(i.cantidad)} × ${money(i.precio)}</p></div>
          <span class="checkout-line-price">${money(Number(i.precio) * Number(i.cantidad))}</span>
        </div>`).join("")}
        <div class="summary-row mt-2"><span>Productos</span><span id="sum-productos">${money(totals.productos)}</span></div>
        <div class="summary-row"><span>Envío</span><span id="sum-envio">A confirmar por la tienda</span></div>
        <div class="summary-row"><span>IVA incluido</span><span id="sum-iva">${money(totals.iva)}</span></div>
        <div class="summary-row summary-row--total"><span>Total</span><span id="sum-total">${money(totals.total)}</span></div>
        <div class="summary-trust">
          <span>${icon("truck", 15)} Envío confirmado por la tienda</span>
          <span>${icon("refresh", 15)} 14 días para devolver</span>
        </div>
        <a class="btn btn-ghost btn-sm btn-block mt-2" href="#/carrito">Editar carrito</a>
      </aside>
    </form>
  </div>`;

  renderApp(content);

  const updateTotals = () => {
    totals = checkoutTotals(items, "transferencia");
    $("#sum-iva").textContent = money(totals.iva);
    $("#sum-total").textContent = money(totals.total);
    $("#pay-total").textContent = money(totals.total);
  };
  $$("input[name='metodo_pago']").forEach((r) => r.addEventListener("change", updateTotals));
  $$("input[name='metodo_pago']").forEach((r) => r.addEventListener("change", actualizarDatosPago));
  actualizarDatosPago();
  $$("input[name='tipo_entrega']").forEach((r) => r.addEventListener("change", actualizarEntrega));
  actualizarEntrega();

  const form = $("#checkout-form");
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(form).entries());
    const problemas = [];
    const check = (name, ok, message) => {
      const field = form.elements[name];
      if (!field) return;
      field.classList.toggle("field-error", !ok);
      if (!ok) problemas.push(message);
    };
    check("email", /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(String(data.email || "").trim()), "Revisa el email de contacto.");
    check("nombre", String(data.nombre || "").trim().length >= 2, "Indica el nombre y los apellidos.");
    if (data.tipo_entrega !== "recogida") {
      check("direccion", String(data.direccion || "").trim().length >= 5, "Indica la dirección de envío.");
      check("cp", String(data.cp || "").trim().length >= 4, "Indica el código postal.");
      check("ciudad", String(data.ciudad || "").trim().length >= 2, "Indica la ciudad.");
    }
    if (!$("#ck-acepta").checked) {
      problemas.push("Debes aceptar las condiciones de venta.");
      $("#ck-acepta").classList.add("field-error");
    } else {
      $("#ck-acepta").classList.remove("field-error");
    }
    if (problemas.length) {
      toast(problemas[0], "error");
      const first = form.querySelector(".field-error") || $("#ck-acepta");
      first?.focus?.();
      return;
    }

    const btn = $("#pay-btn");
    const original = btn.innerHTML;
    checkoutSubmitting = true;
    btn.disabled = true;
    btn.innerHTML = `<span class="spinner" style="width:17px;height:17px;border-color:rgba(255,255,255,.4);border-top-color:#fff"></span> Procesando…`;
    try {
      const pedido = await api("/api/public/pedidos", {
        method: "POST",
        body: {
          cliente: {
            nombre: data.nombre,
            email: data.email,
            telefono: data.telefono,
            empresa: data.empresa,
            nif: data.nif,
            direccion: data.direccion,
            ciudad: data.ciudad,
            cp: data.cp,
            provincia: data.provincia,
            pais: data.pais || "España",
          },
          items: items.map((i) => ({ producto_id: i.id, cantidad: Number(i.cantidad) })),
          metodo_pago: data.metodo_pago || "transferencia",
          tipo_entrega: data.tipo_entrega || "envio_transportista",
          recogida_fecha: data.recogida_fecha || "",
          recogida_hora: data.recogida_hora || "",
          notas: data.notas || "",
        },
      });
      cartClear();
      location.hash = `#/pedido/${encodeURIComponent(pedido.numero)}?t=${encodeURIComponent(pedido.token)}`;
    } catch (err) {
      checkoutSubmitting = false;
      btn.disabled = false;
      btn.innerHTML = original;
      toast(err.message || "No se pudo completar el pedido", "error", 6000);
      if (err.campo && form.elements[err.campo]) {
        form.elements[err.campo].classList.add("field-error");
        form.elements[err.campo].focus();
      }
    }
  });
}

/* ------------------------------ Confirmación ----------------------------- */
async function confirmPage(numero, params) {
  const token = params.get("t") || "";
  renderApp(`<div class="container">${loadingBlock("Recuperando tu pedido…")}</div>`);
  let pedido;
  try {
    pedido = await api(`/api/public/pedidos/${encodeURIComponent(numero)}`, { query: { t: token } });
  } catch (err) {
    renderApp(`<div class="container confirm-wrap">
      ${emptyState({
        iconName: "alert",
        title: "No podemos mostrar este pedido",
        text: err.message || "El enlace no es válido o ha caducado.",
        action: `<a class="btn btn-primary" href="#/tienda">Volver a la tienda</a>`,
      })}
    </div>`);
    return;
  }

  const pasos = ["pendiente", "pagado", "preparando", "enviado", "entregado"];
  const idx = pasos.indexOf(pedido.estado);
  const cancelado = pedido.estado === "cancelado";
  const lineas = pedido.lineas || [];

  const content = `
  <div class="container confirm-wrap">
    <div class="confirm-card">
      <div class="confirm-top">
        <div class="success-mark">${icon(cancelado ? "alert" : "check", 28, 2.4)}</div>
        <div>
          <span class="eyebrow">${cancelado ? "Pedido cancelado" : "Pedido confirmado"}</span>
          <h1>${cancelado ? "Tu pedido se ha cancelado" : "¡Gracias! Ya estamos en ello."}</h1>
          <p>${cancelado
            ? "El stock ha vuelto al inventario y no se realizará ningún cargo."
            : "Hemos recibido tu pedido y hemos reservado el stock. Te escribiremos a " + esc(pedido.cliente_email) + "."}</p>
          <span class="confirm-number">${esc(pedido.numero)}</span>
          <span class="confirm-number">${fmtDate(pedido.created_at)}</span>
        </div>
      </div>

      <div class="confirm-body">
        <div class="confirm-main">
          <div class="confirm-block">
            <h3>Seguimiento</h3>
            ${cancelado
              ? `<div class="notice notice--danger">${icon("alert", 17)}<span>Este pedido fue cancelado. Si necesitas ayuda, escríbenos a ${esc(CONFIG.tienda.email)}.</span></div>`
              : `<div class="timeline">
                  ${pasos.map((paso, i) => `<div class="timeline-step ${i < idx ? "is-done" : ""} ${i === idx ? "is-done is-current" : ""}">
                    <div class="timeline-dot">${icon("check", 11, 3)}</div>
                    <span>${esc(estadoLabel(paso))}</span>
                  </div>`).join("")}
                </div>`}
            <div class="stack mt-2">
              ${(pedido.eventos || []).map((ev) => `<div class="row" style="align-items:flex-start">
                <span class="dot ${ev.estado === "cancelado" ? "dot--danger" : ""}" style="margin-top:7px"></span>
                <div><strong class="small">${esc(ev.estado_label)}</strong>
                  <p class="tiny muted">${fmtDate(ev.created_at)}${ev.nota ? ` · ${esc(ev.nota)}` : ""}${ev.usuario ? ` · ${esc(ev.usuario)}` : ""}</p></div>
              </div>`).join("")}
            </div>
          </div>

          ${avisoPago(pedido)}

          <div class="confirm-block">
            <h3>Productos</h3>
            <table class="table">
              <tbody>
                ${lineas.map((l) => `<tr>
                  <td><strong>${esc(l.nombre)}</strong><br><span class="tiny muted">${esc(l.sku)} · ${Number(l.cantidad)} × ${money(l.precio_unit)}</span></td>
                  <td class="num money">${money(l.total)}</td>
                </tr>`).join("")}
              </tbody>
            </table>
            <div class="confirm-total"><span>${["verificado", "cobrado"].includes(pedido.pago_estado) ? "Total pagado" : "Total a pagar"}</span><strong>${money(pedido.total)}</strong></div>
            <p class="tiny muted">IVA incluido · ${esc(pedido.tipo_entrega_label || "")} · ${esc(pedido.metodo_pago_label)}</p>
            ${pedido.tipo_entrega === "recogida" && pedido.recogida_fecha ? `<p class="small"><strong>Recogida:</strong> ${esc(pedido.recogida_fecha)} sobre las ${esc(pedido.recogida_hora)} (aprox.)</p>` : ""}
            <p class="small"><strong>${pedido.tipo_entrega === "recogida" ? "Recogida en tienda · sin coste de envío" : pedido.envio_pendiente ? "Envío: pendiente de confirmar por la tienda" : `Envío: ${money(pedido.envio)}`}</strong></p>
            ${pedido.tipo_entrega !== "recogida" && pedido.envio_cobro === "anticipado" && !pedido.envio_pagado && !pedido.envio_pendiente ? `<div class="notice"><span>Paga el envío de <strong>${money(pedido.envio)}</strong> por transferencia (${esc(CONFIG.tienda.pago_iban || "cuenta indicada por la tienda")}) o cartera digital (${esc(CONFIG.tienda.pago_cartera || "número indicado por la tienda")}), indicando el número <strong>${esc(pedido.numero)}</strong>.</span></div>` : ""}
            ${pedido.tipo_entrega !== "recogida" && !pedido.envio_pendiente && pedido.envio_cobro === "entrega" ? `<p class="small">El envío de <strong>${money(pedido.envio)}</strong> se cobra al recibir el pedido.</p>` : ""}
            ${pedido.tipo_entrega !== "recogida" ? `<p class="tiny muted">${esc(CONFIG.envio.aviso || "")}</p>` : ""}
          </div>
        </div>

        <aside class="confirm-side">
          <div class="confirm-block">
            <h3>Entrega</h3>
            <p class="small"><strong>${esc(pedido.cliente_nombre)}</strong><br>
            ${esc(pedido.direccion)}<br>
            ${esc(pedido.cp)} ${esc(pedido.ciudad)}${pedido.provincia ? ` (${esc(pedido.provincia)})` : ""}<br>
            ${esc(pedido.pais)}</p>
          </div>
          <div class="confirm-block">
            <h3>Resumen</h3>
            <div class="summary-row"><span>Productos</span><span>${money(Number(pedido.total) - Number(pedido.envio))}</span></div>
            <div class="summary-row"><span>Envío</span><span>${Number(pedido.envio) === 0 ? "Gratis" : money(pedido.envio)}</span></div>
            <div class="summary-row"><span>Base imponible</span><span>${money(pedido.base)}</span></div>
            <div class="summary-row"><span>IVA</span><span>${money(pedido.iva)}</span></div>
            <div class="summary-row summary-row--total"><span>Total</span><span>${money(pedido.total)}</span></div>
          </div>
          <div class="confirm-block">
            <h3>¿Alguna duda?</h3>
            <p class="small">Escríbenos a <a href="mailto:${esc(CONFIG.tienda.email)}"><strong>${esc(CONFIG.tienda.email)}</strong></a> o llama al ${esc(CONFIG.tienda.telefono)} indicando el número de pedido.</p>
          </div>
        </aside>
      </div>

      <div class="confirm-actions no-print">
        <button class="btn btn-outline btn-sm" type="button" id="print-order">${icon("printer", 16)} Imprimir</button>
        <a class="btn btn-primary btn-sm" href="#/tienda">Seguir comprando ${icon("arrowRight", 16)}</a>
      </div>
    </div>
  </div>`;

  renderApp(content);
  $("#print-order")?.addEventListener("click", () => window.print());
}

function estadoLabel(estado) {
  return {
    pendiente: "Pendiente", pagado: "Pagado", preparando: "Preparando",
    enviado: "Enviado", entregado: "Entregado", cancelado: "Cancelado",
  }[estado] || estado;
}

/* ------------------------------ Páginas info ----------------------------- */
const INFO_PAGES = {
  "/nosotros": () => ({
    eyebrow: "Quiénes somos",
    title: "Un almacén pequeño, obsesionado con no fallar.",
    lead: "CC Shop's nació en Terrassa para resolver un problema muy concreto: los negocios pequeños no pueden permitirse quedarse sin guantes un viernes por la tarde.",
    body: `
      <div class="prose">
        <h2>Empezamos contando cajas</h2>
        <p>Comenzamos sirviendo a clínicas dentales, restaurantes y oficinas de nuestra comarca. Cargábamos el maletero con lo que faltaba y aprendimos que el problema casi nunca era el precio: era no saber si había stock de verdad.</p>
        <p>Por eso montamos el negocio sobre un libro de inventario serio, el Kardex. Cada compra, cada venta y cada recuento deja rastro. Si un producto aparece como disponible, está en la estantería. Si no, no lo vendemos.</p>
        <h2>Cómo trabajamos</h2>
        <ul>
          <li>Compramos a proveedores locales y de confianza, con plazos de reposición cortos.</li>
          <li>Valoramos el inventario a coste medio ponderado, para saber de verdad cuánto margen queda.</li>
          <li>Preparamos antes de las 14:00 los pedidos recibidos por la mañana.</li>
          <li>Atendemos por teléfono y email. Sin laberintos de menús.</li>
        </ul>
        <h2>Dónde estamos</h2>
        <p>${esc(CONFIG.tienda.direccion)}. Si vienes a recoger un pedido, avísanos antes y lo tendremos preparado.</p>
        <p>¿Trabajas con nosotros y necesitas condiciones especiales? Escríbenos a <a href="mailto:${esc(CONFIG.tienda.email)}"><strong>${esc(CONFIG.tienda.email)}</strong></a>.</p>
      </div>
      <div class="info-grid">
        <div class="info-card"><h2>Stock real</h2><p>Un Kardex append-only detrás de cada referencia. Nada de cifras inventadas.</p></div>
        <div class="info-card"><h2>Entrega 24/48 h</h2><p>Preparamos el mismo día y trabajamos con agencias con seguimiento.</p></div>
        <div class="info-card"><h2>Trato directo</h2><p>Hablas con quien prepara tu pedido, no con un formulario.</p></div>
      </div>`,
  }),
  "/envios": () => ({
    eyebrow: "Envíos y entrega",
    title: "De nuestro almacén a tu puerta.",
    lead: CONFIG.envio.aviso || "",
    body: `
      <div class="info-grid">
        <div class="info-card"><h2>24/48 h</h2><p>Entrega estándar en península con seguimiento. Baleares y Canarias, consultar plazos.</p></div>
        <div class="info-card"><h2>Recogida o envío</h2><p>Puedes recoger tu pedido en nuestra dirección o pedir envío. El coste del envío te lo confirma la tienda antes de enviarlo.</p></div>
        <div class="info-card"><h2>Recogida</h2><p>Puedes recoger en ${esc(CONFIG.tienda.direccion)} avisando con antelación.</p></div>
      </div>
      <div class="prose">
        <h2>Plazos</h2>
        <p>Los pedidos confirmados antes de las 14:00 de un día laborable salen ese mismo día. La entrega se realiza en 24/48 h laborables en península. Los pedidos de viernes por la tarde o fin de semana salen el siguiente día laborable.</p>
        <h2>Contrareembolso</h2>
        <p>Disponible con un recargo de ${money(CONFIG.envio.recargo_contrareembolso)} que se muestra antes de confirmar. El importe se abona al transportista en el momento de la entrega.</p>
        <h2>Seguimiento</h2>
        <p>Cuando tu pedido salga del almacén recibirás un email con el número de seguimiento. También puedes consultar el estado en el enlace de confirmación de tu pedido.</p>
        <h2>Incidencias</h2>
        <p>Si el paquete llega dañado, hazlo constar al transportista y escríbenos el mismo día a <a href="mailto:${esc(CONFIG.tienda.email)}"><strong>${esc(CONFIG.tienda.email)}</strong></a>. Lo resolvemos con la mayor rapidez posible.</p>
      </div>`,
  }),
  "/devoluciones": () => ({
    eyebrow: "Devoluciones",
    title: "Si no es lo que necesitabas, lo arreglamos.",
    lead: "Dispones de 14 días naturales desde la recepción para devolver un producto sin usar y en su embalaje original.",
    body: `
      <div class="prose">
        <h2>Cómo solicitar una devolución</h2>
        <ul>
          <li>Escríbenos a ${esc(CONFIG.tienda.email)} indicando el número de pedido y el producto.</li>
          <li>Te confirmamos la dirección de devolución y las instrucciones.</li>
          <li>Una vez recibido y revisado el producto, emitimos el reembolso por el mismo método de pago.</li>
        </ul>
        <h2>Productos excluidos</h2>
        <p>Por motivos de higiene no aceptamos devoluciones de productos abiertos o usados, ni de artículos de un solo uso que hayan salido de su embalaje original. Los productos defectuosos o enviados por error quedan siempre cubiertos.</p>
        <h2>Plazo de reembolso</h2>
        <p>El reembolso se realiza en un máximo de 14 días desde la recepción de la devolución. En el caso de entregas parciales o cancelaciones antes del envío, el plazo es de 14 días desde la confirmación.</p>
        <h2>Devoluciones y Kardex</h2>
        <p>Cuando un pedido se cancela antes de la entrega, el stock se devuelve al inventario como una entrada valorada al coste original del producto. Nunca se modifica el movimiento de venta: la historia del inventario queda intacta.</p>
      </div>`,
  }),
  "/faq": () => ({
    eyebrow: "Ayuda",
    title: "Preguntas frecuentes.",
    lead: "Lo que más nos preguntan por teléfono y por email, resuelto en dos líneas.",
    body: `
      <div class="prose">
        <h2>¿Los precios llevan IVA?</h2>
        <p>Sí. Todos los precios de la tienda se muestran con IVA incluido. En el resumen del pedido puedes ver la base imponible y la cuota de IVA desglosadas.</p>
        <h2>¿Puedo comprar sin ser empresa?</h2>
        <p>Sí, no pedimos NIF ni datos de empresa para comprar. El campo de empresa y NIF es opcional y solo se usa para la factura.</p>
        <h2>¿Cómo sé si hay stock?</h2>
        <p>El stock que ves en la ficha es el saldo real del Kardex en ese momento. Al confirmar un pedido, las unidades se reservan y se descuentan del inventario.</p>
        <h2>¿Puedo modificar un pedido?</h2>
        <p>Si aún no ha salido del almacén, escríbenos cuanto antes. Si ya está en reparto, podemos gestionar la devolución una vez recibido.</p>
        <h2>¿Emitís factura?</h2>
        <p>Sí. Indica los datos fiscales en el checkout (empresa y NIF) y la factura se emite con el pedido.</p>
        <h2>¿El pago con tarjeta es real?</h2>
        <p>No. Esta tienda es un entorno de demostración: el pago con tarjeta es simulado y no se realiza ningún cargo.</p>
        <h2>¿Cómo contacto con vosotros?</h2>
        <p>Por email en <a href="mailto:${esc(CONFIG.tienda.email)}"><strong>${esc(CONFIG.tienda.email)}</strong></a> o por teléfono en ${esc(CONFIG.tienda.telefono)}, de lunes a viernes de 8:00 a 18:00.</p>
      </div>`,
  }),
  "/aviso-legal": () => ({
    eyebrow: "Legal",
    title: "Aviso legal y condiciones de venta.",
    lead: "Este sitio es una demostración funcional de CC Shop's. Los pedidos se registran, pero no se realiza ningún cargo real.",
    body: `
      <div class="prose">
        <h2>Titular</h2>
        <p>CC Shop's · ${esc(CONFIG.tienda.direccion)} · ${esc(CONFIG.tienda.email)} · ${esc(CONFIG.tienda.telefono)}.</p>
        <h2>Objeto</h2>
        <p>Este sitio permite consultar un catálogo de insumos profesionales y simular pedidos. Los precios se muestran en euros con IVA incluido y pueden cambiar sin previo aviso.</p>
        <h2>Pedidos</h2>
        <p>Al confirmar un pedido se reserva el stock disponible y se genera un número de pedido con un enlace privado de seguimiento. En este entorno de demostración no se procesa ningún pago real.</p>
        <h2>Responsabilidad</h2>
        <p>La información del catálogo se ofrece con la mayor precisión posible. Las imágenes son ilustrativas. Para condiciones específicas de suministro, contacta con nosotros.</p>
        <h2>Propiedad intelectual</h2>
        <p>Los contenidos, marcas y elementos gráficos de este sitio pertenecen a sus titulares y no pueden reproducirse sin autorización.</p>
      </div>`,
  }),
  "/privacidad": () => ({
    eyebrow: "Privacidad",
    title: "Qué hacemos con tus datos.",
    lead: "Solo usamos los datos necesarios para gestionar tu pedido y atenderte. No los vendemos a terceros.",
    body: `
      <div class="prose">
        <h2>Datos que recogemos</h2>
        <p>Nombre, email, teléfono, dirección de envío y, si lo facilitas, datos de empresa y NIF. También guardamos el detalle de los pedidos y los movimientos de inventario asociados.</p>
        <h2>Para qué los usamos</h2>
        <ul>
          <li>Preparar y entregar tu pedido.</li>
          <li>Enviarte el seguimiento y resolver incidencias.</li>
          <li>Emitir la factura cuando se solicita.</li>
          <li>Cumplir las obligaciones legales y contables.</li>
        </ul>
        <h2>Cuánto tiempo</h2>
        <p>Los datos de pedidos se conservan durante los plazos legales de facturación y contabilidad. Los enlaces de seguimiento son privados y contienen un token aleatorio.</p>
        <h2>Derechos</h2>
        <p>Puedes solicitar acceso, rectificación, supresión o portabilidad escribiendo a <a href="mailto:${esc(CONFIG.tienda.email)}"><strong>${esc(CONFIG.tienda.email)}</strong></a>. Responderemos en el plazo legal establecido.</p>
        <h2>Cookies</h2>
        <p>No usamos cookies publicitarias. El carrito se guarda en tu navegador (almacenamiento local) y la sesión del backoffice usa una cookie técnica.</p>
      </div>`,
  }),
};

function infoPage(path) {
  const page = INFO_PAGES[path]();
  document.title = `${page.title} · ${CONFIG.tienda.nombre}`;
  const content = `<div class="container info-page">
    <nav class="breadcrumb"><a href="#/">Inicio</a><span>/</span><strong>${esc(page.eyebrow)}</strong></nav>
    <span class="eyebrow mt-2" style="margin-top:18px">${esc(page.eyebrow)}</span>
    <h1>${esc(page.title)}</h1>
    <p class="lead">${esc(page.lead)}</p>
    ${page.body}
  </div>`;
  renderApp(content);
}

function contactPage() {
  const t = CONFIG.tienda;
  document.title = `Contacto · ${CONFIG.tienda.nombre}`;
  const content = `<div class="container info-page">
    <nav class="breadcrumb"><a href="#/">Inicio</a><span>/</span><strong>Contacto</strong></nav>
    <span class="eyebrow" style="margin-top:18px">Contacto</span>
    <h1>Hablemos de tu próximo pedido.</h1>
    <p class="lead">¿Necesitas una referencia que no está en el catálogo, un precio por volumen o una entrega concreta? Escríbenos desde este formulario y te respondemos por email.</p>
    <div class="info-grid">
      <div class="info-card"><h2>Teléfono</h2><p>${t.telefono ? `<a href="tel:${esc(t.telefono)}">${esc(t.telefono)}</a><br>` : ""}Lunes a viernes, 8:00–18:00.</p></div>
      <div class="info-card"><h2>Dirección</h2><p>${esc(t.direccion || "")}<br>Recogida con aviso previo.</p></div>
    </div>
    <div class="grid-2 mt-4" style="align-items:start">
      <form class="checkout-section" id="contact-form" style="margin:0" novalidate>
        <h2><span class="checkout-step">?</span> Escríbenos</h2>
        <div class="form-grid">
          <div class="field"><label for="ct-nombre">Nombre</label><input class="input" id="ct-nombre" name="nombre" maxlength="100" required></div>
          <div class="field"><label for="ct-email">Email</label><input class="input" type="email" id="ct-email" name="email" maxlength="160" required></div>
          <div class="field full"><label for="ct-empresa">Empresa <span class="muted">(opcional)</span></label><input class="input" id="ct-empresa" name="empresa" maxlength="100"></div>
          <div class="field full"><label for="ct-mensaje">Mensaje</label><textarea class="textarea" id="ct-mensaje" name="mensaje" maxlength="2000" placeholder="Cuéntanos qué necesitas y para cuándo…" required></textarea></div>
          <div class="field full" style="position:absolute;left:-9999px" aria-hidden="true"><label>No rellenar</label><input name="website" tabindex="-1" autocomplete="off"></div>
        </div>
        <button class="btn btn-primary btn-block mt-2" type="submit" id="ct-enviar">Enviar mensaje ${icon("send", 16)}</button>
      </form>
      <div class="prose" style="margin-top:0">
        <h2>Pedidos por encargo</h2>
        <p>Si necesitas una referencia concreta, un formato especial o una cantidad grande, lo buscamos y te damos precio y plazo.</p>
        <h2>Cuentas de empresa</h2>
        <p>Para compras recurrentes podemos acordar condiciones de pago y entregas programadas. Indícanos el volumen aproximado mensual.</p>
        <h2>Visitas</h2>
        <p>Si quieres ver muestras o recoger un pedido, avísanos con antelación.</p>
      </div>
    </div>
  </div>`;
  renderApp(content);
  $("#contact-form")?.addEventListener("submit", async (e) => {
    e.preventDefault();
    const form = e.target;
    const boton = $("#ct-enviar");
    const data = formObject(form);
    if (!data.nombre || !data.email || !data.mensaje) return toast("Completa nombre, email y mensaje", "error");
    boton.disabled = true;
    try {
      await api("/api/public/contacto", { method: "POST", body: data });
      form.reset();
      toast("Gracias por escribirnos. Te responderemos por email.");
    } catch (err) {
      toast(err.message, "error");
    } finally {
      boton.disabled = false;
    }
  });
}


/* ------------------------------ Cuenta cliente --------------------------- */
async function accountPage() {
  if (ME) {
    const content = `<div class="container info-page">
      <span class="eyebrow">Mi cuenta</span>
      <h1>Hola, ${esc(ME.nombre)}.</h1>
      <p class="lead">Gestiona tus pedidos y datos desde aquí.</p>
      <div class="info-grid">
        <div class="info-card"><h2>Mis pedidos</h2><p>Consulta el estado y el historial de tus pedidos.</p><a class="btn btn-primary btn-sm mt-2" href="#/cuenta/pedidos">Ver pedidos</a></div>
        <div class="info-card"><h2>Datos</h2><p>${esc(ME.email)} · ${esc(ME.rol)}</p></div>
        <div class="info-card"><h2>Ayuda</h2><p>Escríbenos a ${esc(CONFIG.tienda.email)}.</p></div>
      </div>
      <div class="mt-3"><button class="btn btn-outline" id="logout-btn">Cerrar sesión</button></div>
    </div>`;
    renderApp(content);
    $("#logout-btn")?.addEventListener("click", async () => {
      try { await api("/api/auth/logout", { method: "POST" }); } catch {}
      ME = null; toast("Sesión cerrada"); location.hash = "#/";
    });
    return;
  }
  // login/register
  let mode = "login";
  const renderForm = () => {
    const isLogin = mode === "login";
    const content = `<div class="container info-page" style="max-width:520px">
      <span class="eyebrow">Mi cuenta</span>
      <h1>${isLogin ? "Entrar" : "Crear cuenta"}</h1>
      <p class="lead">${isLogin ? "Accede para ver tus pedidos." : "Regístrate para guardar tus pedidos y chatear con nosotros."}</p>
      <form class="checkout-section" id="auth-form" style="margin-top:18px" novalidate>
        ${!isLogin ? `<div class="field"><label>Nombre</label><input class="input" name="nombre" required></div>` : ""}
        <div class="field"><label>Email</label><input class="input" type="email" name="email" required></div>
        <div class="field"><label>Contraseña</label>
          <div class="input-group">
            <input class="input" type="password" name="password" id="acc-pass" required>
            <button class="btn btn-outline" type="button" id="acc-toggle-pass" style="min-height:44px;padding:0 12px" aria-label="Mostrar contraseña">${icon("eye",16)}</button>
          </div></div>
        <button class="btn btn-primary btn-block" type="submit" id="auth-btn">${isLogin ? "Entrar" : "Crear cuenta"}</button>
      </form>
      <p class="tiny muted center mt-2">
        ${isLogin ? "¿No tienes cuenta?" : "¿Ya tienes cuenta?"}
        <a href="#" id="toggle-mode">${isLogin ? "Crear una" : "Entrar"}</a>
      </p>
    </div>`;
    renderApp(content);
    $("#acc-toggle-pass")?.addEventListener("click", () => {
      const inp = $("#acc-pass");
      if (inp) inp.type = inp.type === "password" ? "text" : "password";
    });
    $("#toggle-mode")?.addEventListener("click", (e) => { e.preventDefault(); mode = isLogin ? "register" : "login"; renderForm(); });
    $("#auth-form")?.addEventListener("submit", async (e) => {
      e.preventDefault();
      const data = Object.fromEntries(new FormData(e.target).entries());
      const btn = $("#auth-btn");
      btn.disabled = true;
      try {
        if (isLogin) {
          const r = await api("/api/auth/login", { method: "POST", body: { email: data.email, password: data.password } });
          ME = r.usuario;
          toast("Bienvenido, " + ME.nombre);
        } else {
          const r = await api("/api/auth/register", { method: "POST", body: data });
          ME = r.usuario;
          toast("Cuenta creada");
        }
        location.hash = "#/cuenta";
        route();
      } catch (err) {
        btn.disabled = false;
        toast(err.message || "Error", "error");
      }
    });
  };
  renderForm();
}

async function accountOrdersPage() {
  if (!ME) { location.hash = "#/cuenta"; return; }
  renderApp(`<div class="container">${loadingBlock("Cargando pedidos…")}</div>`);
  const d = await api("/api/cliente/pedidos");
  const content = `<div class="container info-page">
    <nav class="breadcrumb"><a href="#/">Inicio</a><span>/</span><a href="#/cuenta">Mi cuenta</a><span>/</span><strong>Pedidos</strong></nav>
    <span class="eyebrow" style="margin-top:18px">Mis pedidos</span>
    <h1>Tus pedidos</h1>
    ${d.items.length ? `<div class="admin-card" style="padding:0;margin-top:18px"><table class="table">
      <thead><tr><th>Nº</th><th>Fecha</th><th>Estado</th><th class="num">Total</th><th></th></tr></thead>
      <tbody>${d.items.map((p) => `<tr>
        <td><strong>${esc(p.numero)}</strong></td>
        <td class="tiny muted">${fmtDate(p.created_at)}</td>
        <td>${estadoBadge(p.estado, p.estado_label)}</td>
        <td class="num money">${money(p.total)}</td>
        <td class="actions"><a class="btn btn-xs btn-outline" href="#/cuenta/pedido/${encodeURIComponent(p.numero)}">Ver</a></td>
      </tr>`).join("")}</tbody></table></div>` : emptyState({ iconName: "truck", title: "Sin pedidos", text: "Todavía no has hecho ningún pedido.", action: `<a class="btn btn-primary btn-sm" href="#/tienda">Ir al catálogo</a>` })}
  </div>`;
  renderApp(content);
}

// Estado del pedido para el cliente: recorrido, pago, entrega y historial.
function estadoPedidoHTML(p) {
  const recogida = p.tipo_entrega === "recogida";
  const pasos = [["pendiente", "Recibido"], ["preparando", "En preparación"], ["preparado", "Preparado"]]
    .concat(recogida ? [["entregado", "Listo para recoger / entregado"]] : [["enviado", "En reparto"], ["entregado", "Entregado"]]);
  const orden = pasos.map(([k]) => k);
  const idx = orden.indexOf(p.estado) >= 0 ? orden.indexOf(p.estado) : (p.estado === "pagado" ? 0 : -1);
  if (p.estado === "cancelado") {
    return `<div class="notice notice--danger" style="margin-top:14px"><span>Este pedido está cancelado.</span></div>`;
  }
  const stepper = `<ol class="estado-pasos">${pasos.map(([k, t], i) => `<li class="${i <= idx ? "is-done" : ""} ${i === idx ? "is-current" : ""}"><span>${i + 1}</span>${esc(t)}</li>`).join("")}</ol>`;
  const entrega = recogida
    ? `Recogida en tienda${p.recogida_fecha ? ` · ${esc(p.recogida_fecha)} sobre las ${esc(p.recogida_hora)} (aprox.)` : ""}`
    : `${esc(p.tipo_entrega_label || "Envío")}${p.transportista ? ` · ${esc(p.transportista)}` : ""}${p.seguimiento ? ` · seguimiento <strong>${esc(p.seguimiento)}</strong>` : ""}${p.envio_pendiente ? " · el coste del envío te lo confirmamos" : ""}`;
  const eventos = (p.eventos || []).slice().reverse();
  return `<div class="admin-card" style="margin-top:18px">
    <div class="admin-card-head"><h3>Estado del pedido</h3><span class="badge">${esc(p.estado_label)}</span></div>
    ${stepper}
    <p class="small" style="margin-top:12px"><strong>Pago:</strong> ${esc(p.pago_estado_label || "—")}</p>
    <p class="small"><strong>Entrega:</strong> ${entrega}</p>
    ${eventos.length ? `<div class="historial-estado"><h4 class="tiny muted" style="margin:14px 0 6px;text-transform:uppercase;letter-spacing:.08em">Historial</h4>
      ${eventos.map((e) => `<div class="evento-estado"><span class="tiny muted">${fmtDateTime(e.created_at)}</span> · <strong>${esc(e.estado_label)}</strong>${e.nota ? ` <span class="tiny muted">— ${esc(e.nota)}</span>` : ""}</div>`).join("")}</div>` : ""}
  </div>`;
}

async function accountOrderDetailPage(numero, params) {
  if (!ME) { location.hash = "#/cuenta"; return; }
  renderApp(`<div class="container">${loadingBlock("Cargando pedido…")}</div>`);
  try {
    const p = await api(`/api/cliente/pedidos/${encodeURIComponent(numero)}`);
    const content = `<div class="container info-page">
      <nav class="breadcrumb"><a href="#/">Inicio</a><span>/</span><a href="#/cuenta/pedidos">Mis pedidos</a><span>/</span><strong>${esc(p.numero)}</strong></nav>
      <span class="eyebrow" style="margin-top:18px">Pedido</span>
      <h1>${esc(p.numero)}</h1>
      <p class="lead">${fmtDate(p.created_at)} · ${esc(p.estado_label)} · ${esc(p.metodo_pago_label)}</p>
      ${estadoPedidoHTML(p)}
      <div class="confirm-card" style="margin-top:18px">
        <div class="confirm-body" style="grid-template-columns:1fr">
          <div class="confirm-main">
            <table class="table"><tbody>${p.lineas.map((l) => `<tr><td>${esc(l.nombre)}</td><td class="num">${number(l.cantidad)}</td><td class="num money">${money(l.total)}</td></tr>`).join("")}</tbody></table>
            <div class="confirm-total"><span>Total</span><strong>${money(p.total)}</strong></div>
          </div>
        </div>
      </div>
      <div class="admin-card" style="margin-top:18px">
        <div class="admin-card-head"><h3>Chat con el equipo</h3></div>
        <div id="chat-box" style="max-height:320px;overflow:auto;padding:8px 0"></div>
        <form id="chat-form" class="row" style="margin-top:10px;gap:8px">
          <input class="input" name="mensaje" placeholder="Escribe un mensaje…" required style="flex:1">
          <button class="btn btn-primary btn-sm" type="submit">${icon("send",14)} Enviar</button>
        </form>
      </div>
    </div>`;
    renderApp(content);
    const chatBox = $("#chat-box");
    const renderChat = async () => {
      try {
        const d = await api(`/api/cliente/pedidos/${encodeURIComponent(numero)}/chat`);
        chatBox.innerHTML = (d.items || []).map((m) => `<div style="margin:6px 0;padding:8px 10px;border-radius:10px;background:${m.autor_rol === "cliente" ? "var(--brand-mist)" : "var(--paper-2)"};margin-left:${m.autor_rol === "cliente" ? "0" : "24px"};margin-right:${m.autor_rol === "cliente" ? "24px" : "0"}">
          <p class="tiny muted"><strong>${esc(m.autor)}</strong> · ${fmtDate(m.created_at)}</p>
          <p class="small">${esc(m.mensaje)}</p>
        </div>`).join("") || `<p class="tiny muted">Sin mensajes todavía. Escribe para iniciar la conversación.</p>`;
        chatBox.scrollTop = chatBox.scrollHeight;
      } catch (err) { chatBox.innerHTML = `<p class="tiny muted">${esc(err.message)}</p>`; }
    };
    await renderChat();
    $("#chat-form")?.addEventListener("submit", async (e) => {
      e.preventDefault();
      const input = e.target.querySelector("[name='mensaje']");
      const msg = input.value.trim();
      if (!msg) return;
      try {
        await api(`/api/cliente/pedidos/${encodeURIComponent(numero)}/chat`, { method: "POST", body: { mensaje: msg } });
        input.value = "";
        await renderChat();
      } catch (err) { toast(err.message, "error"); }
    });
  } catch (err) {
    renderApp(`<div class="container info-page">${emptyState({ iconName: "alert", title: "No disponible", text: err.message, action: `<a class="btn btn-primary btn-sm" href="#/cuenta/pedidos">Volver</a>` })}</div>`);
  }
}

/* -------------------------------- 404 ------------------------------------ */
function notFoundPage() {
  renderApp(`<div class="container info-page">
    <span class="eyebrow">Error 404</span>
    <h1>Esta página no existe.</h1>
    <p class="lead">Puede que el enlace esté mal escrito o que hayamos movido el producto. Vuelve al catálogo y seguimos.</p>
    <div class="row mt-3">
      <a class="btn btn-primary" href="#/tienda">Ir al catálogo</a>
      <a class="btn btn-outline" href="#/">Volver al inicio</a>
    </div>
  </div>`);
}

/* -------------------------------- Router --------------------------------- */
async function route() {
  const { path, params } = parseHash();
  currentPath = path;
  if (CONFIG) document.title = `${CONFIG.tienda.nombre} · ${CONFIG.tienda.claim}`;
  closeCart();
  toggleMobileNav(false);
  window.scrollTo({ top: 0, behavior: "auto" });

  try {
    if (path === "/" || path === "") return homePage();
    if (path === "/tienda") return await catalogPage(params);
    if (path.startsWith("/producto/")) {
      const slug = decodeURIComponent(path.slice("/producto/".length));
      return await productPage(slug);
    }
    if (path === "/carrito") return cartPage();
    if (path === "/checkout") return checkoutPage();
    if (path.startsWith("/pedido/")) {
      const numero = decodeURIComponent(path.slice("/pedido/".length));
      return await confirmPage(numero, params);
    }
    if (path === "/cuenta") return accountPage();
    if (path === "/cuenta/activar") return activarCuentaPage(params.get("token") || "");
    if (path === "/cuenta/reenviar") return reenviarActivacionPage();
    if (path === "/cuenta/pedidos") return accountOrdersPage();
    if (path.startsWith("/cuenta/pedido/")) return accountOrderDetailPage(decodeURIComponent(path.slice("/cuenta/pedido/".length)), params);
    if (path === "/contacto") return contactPage();
    if (INFO_PAGES[path]) return infoPage(path);
    return notFoundPage();
  } catch (err) {
    renderApp(`<div class="container info-page">
      <span class="eyebrow">Algo ha ido mal</span>
      <h1>No hemos podido cargar la página.</h1>
      <p class="lead">${esc(err.message || "Error inesperado")}</p>
      <div class="row mt-3">
        <button class="btn btn-primary" type="button" id="retry-btn">Reintentar</button>
        <a class="btn btn-outline" href="#/tienda">Ir al catálogo</a>
      </div>
    </div>`);
    $("#retry-btn")?.addEventListener("click", () => location.reload());
  }
}

/* ------------------------------- Arranque -------------------------------- */
async function boot() {
  const app = $("#app");
  app.innerHTML = shell(`<div class="container">${loadingBlock("Preparando la tienda…")}</div>`);
  try {
    const me = await api("/api/auth/me");
    ME = me.usuario;
  } catch { ME = null; }
  try {
    CONFIG = await api("/api/public/config");
    aplicarTema(CONFIG?.tienda?.tema);
  } catch (err) {
    app.innerHTML = `<div class="container info-page">
      <span class="eyebrow">Sin conexión</span>
      <h1>No podemos cargar la tienda.</h1>
      <p class="lead">${esc(err.message || "Revisa tu conexión e inténtalo de nuevo.")}</p>
      <button class="btn btn-primary mt-3" type="button" id="retry-btn">Reintentar</button>
    </div>`;
    $("#retry-btn")?.addEventListener("click", () => location.reload());
    return;
  }
  document.title = `${CONFIG.tienda.nombre} · ${CONFIG.tienda.claim}`;
  onCart(() => {
    updateCartBadge();
    renderCartDrawer();
    if (currentPath === "/carrito") cartPage();
    else if (currentPath === "/checkout" && !checkoutSubmitting && !cartItems().length) {
      location.hash = "#/carrito";
    }
  });
  window.addEventListener("hashchange", route);
  await route();
}

boot();
