/* ==========================================================================
   CC Shop's · backoffice
   ========================================================================== */
import {
  $, $$, esc, money, number, fmtDate, fmtDateTime, icon, toast, emptyState,
  api, formObject, compressImage, downloadCSV, estadoBadge, stockBadge, parseMoney,
  openModal, closeModal, confirmDialog, setBusy, categoryIcon, iconoCategoria, aplicarTema,
} from "./lib.js?v=6";
import { ICONOS_CATEGORIA } from "./iconos.js";

let ME = null;
let CONFIG = null;
let TIENDA_SLUG = "";
let NOTIS = { items: [], no_leidas: 0 };
let PAGOS_PENDIENTES = 0;
let NOTIS_TIMER = null;
const PUEDE_VERIFICAR = () => ME?.rol === "admin";
const PUEDE_OPERAR = () => ME?.rol === "admin";
const ES_ADMIN = () => ME?.rol === "admin";
// Pantallas a las que puede entrar cada rol (el resto redirige a su inicio).
const PANTALLAS_POR_ROL = {
  domiciliario: { re: /^\/ruta(\/|$)|^\/logout$/, inicio: "#/ruta" },
  preparador: { re: /^\/(pedidos|inventario|movimientos|productos)(\/|$)|^\/logout$/, inicio: "#/pedidos" },
  superadmin: { re: /^\/superadmin(\/|$)|^\/logout$/, inicio: "#/superadmin" },
};
const TRANSICIONES_PEDIDO = {
  pendiente: ["pagado", "preparando", "cancelado"],
  pagado: ["preparando", "preparado", "cancelado"],
  preparando: ["preparado", "cancelado"],
  preparado: ["enviado", "entregado", "cancelado"],
  enviado: ["entregado", "cancelado"],
  entregado: [], cancelado: [],
};
const ESTADOS_POR_ROL = { preparador: ["preparando", "preparado"], domiciliario: ["enviado", "entregado"] };
function transicionesPara(estado) {
  const todas = TRANSICIONES_PEDIDO[estado] || [];
  const permitidos = ESTADOS_POR_ROL[ME?.rol];
  return permitidos ? todas.filter((e) => permitidos.includes(e)) : todas;
}

// Tema visual del backoffice: «clasico» (por defecto) o «tech». Se aplica con data-theme en <html>.

// Carga los ajustes de la tienda (tema incluido). Requiere sesión; el backoffice no usa la API pública.
async function cargarAjustesAdmin() {
  try {
    const a = await api("/api/admin/ajustes");
    CONFIG = { tienda: { nombre: a.ajustes.tienda_nombre, tema: a.ajustes.tema_tienda } };
    TIENDA_SLUG = a.tienda_slug || "";
    aplicarTema(a.ajustes.tema_backoffice);
  } catch {
    CONFIG = null;
  }
}

const TEMAS_OPCIONES = [
  ["clasico", "Clásico elegante"], ["tech", "Tech"], ["moda", "Moda · campaña editorial"], ["belleza", "Belleza y cuidado"],
  ["mascotas", "Mascotas"], ["hogar", "Hogar y decoración"], ["deporte", "Deporte y outdoor"], ["gourmet", "Alimentación gourmet"],
];

function opcionesTema(valor) {
  return TEMAS_OPCIONES
    .map(([v, t]) => `<option value="${v}" ${valor === v ? "selected" : ""}>${t}</option>`).join("");
}
let CATEGORIAS = [];
let currentPath = "/";

const ESTADOS_PEDIDO = {
  pendiente: "Pendiente", pagado: "Pagado", preparando: "En preparación", preparado: "Preparado",
  enviado: "Enviado", entregado: "Entregado", cancelado: "Cancelado",
};

/* ------------------------------ Utilidades ------------------------------- */
function navPorRol() {
  const path = currentPath;
  const nav = (href, label, ic) => `<a href="#${href}" class="${path === href || (href !== "/" && path.startsWith(href)) ? "is-active" : ""}">${icon(ic, 17)} ${esc(label)}</a>`;
  if (ME?.rol === "superadmin") {
    return `<nav class="admin-nav"><div class="admin-nav-group"><div class="admin-nav-label">Plataforma</div>${nav("/superadmin", "Panel", "grid")}${nav("/superadmin/soporte", "Soporte", "help")}${nav("/superadmin/ajustes", "Ajustes", "settings")}</div></nav>`;
  }
  if (ME?.rol === "domiciliario") {
    return `<nav class="admin-nav"><div class="admin-nav-group"><div class="admin-nav-label">Reparto</div>${nav("/ruta", "Hoja de ruta", "truck")}</div></nav>`;
  }
  if (ME?.rol === "preparador") {
    return `<nav class="admin-nav">
      <div class="admin-nav-group"><div class="admin-nav-label">Preparación</div>${nav("/pedidos?estado=por_preparar", "Pedidos por preparar", "box")}${nav("/pedidos", "Pedidos", "truck")}</div>
      <div class="admin-nav-group"><div class="admin-nav-label">Inventario</div>${nav("/inventario", "Inventario", "layers")}${nav("/movimientos", "Movimientos", "list")}</div>
    </nav>`;
  }
  return `<nav class="admin-nav">
    <div class="admin-nav-group">
      <div class="admin-nav-label">General</div>
      ${nav("/", "Dashboard", "grid")}
      ${nav("/metricas", "Métricas", "chart")}
    </div>
    <div class="admin-nav-group">
      <div class="admin-nav-label">Catálogo</div>
      ${nav("/productos", "Productos", "package")}
      ${nav("/categorias", "Categorías", "tag")}
    </div>
    <div class="admin-nav-group">
      <div class="admin-nav-label">Inventario</div>
      ${nav("/inventario", "Inventario", "layers")}
      ${nav("/movimientos", "Movimientos", "list")}
    </div>
    <div class="admin-nav-group">
      <div class="admin-nav-label">Comercial</div>
      ${nav("/pedidos", "Pedidos", "truck")}
      ${nav("/pedidos?estado=por_preparar", "Pedidos por preparar", "box")}
      ${nav("/pagos", `Pagos${PAGOS_PENDIENTES ? ` (${PAGOS_PENDIENTES})` : ""}`, "card")}
      ${nav("/ruta", "Hoja de ruta", "truck")}
      ${nav("/clientes", "Clientes", "users")}
      ${nav("/compras", "Compras", "box")}
      ${nav("/proveedores", "Proveedores", "users")}
    </div>
    <div class="admin-nav-group">
      <div class="admin-nav-label">Sistema</div>
      ${nav("/equipo", "Equipo", "users")}
      ${nav("/soporte", "Soporte", "help")}
      ${nav("/ajustes", "Ajustes", "settings")}
    </div>
  </nav>`;
}

function shell(content, title = "Backoffice") {
  const path = currentPath;
  const nav = (href, label, ic) => `<a href="#${href}" class="${path === href || (href !== "/" && path.startsWith(href)) ? "is-active" : ""}">${icon(ic, 17)} ${esc(label)}</a>`;
  document.title = `${title} · CC Shop's Admin`;
  return `<div class="admin-shell">
    <aside class="admin-sidebar" id="admin-sidebar">
      <div class="admin-brand">
        <span class="admin-brand-mark">CC</span>
        <span class="admin-brand-text"><strong>CC Shop's</strong><span>Backoffice</span></span>
      </div>
      ${navPorRol()}
      <div class="admin-sidebar-foot">
        ${ME?.rol === "superadmin" ? "" : `<a href="${TIENDA_SLUG ? `/?tienda=${encodeURIComponent(TIENDA_SLUG)}` : "/"}" target="_blank" rel="noopener">${icon("external", 15)} Ver tienda</a>`}
        <a href="#/logout" id="logout-link">${icon("logout", 15)} Cerrar sesión</a>
      </div>
    </aside>
    <div class="admin-sidebar-backdrop" id="sidebar-backdrop"></div>
    <div class="admin-main">
      <header class="admin-topbar">
        <button class="btn-icon admin-mobile-toggle" type="button" id="sidebar-toggle" aria-label="Menú">${icon("menu", 18)}</button>
        <h1>${esc(title)}</h1>
        <div class="notif-wrap">
          <button class="btn-icon notif-btn" type="button" id="notif-btn" aria-label="Notificaciones" aria-expanded="false">${icon("bell", 18)}${NOTIS.no_leidas ? `<span class="notif-dot" id="notif-dot">${NOTIS.no_leidas}</span>` : `<span class="notif-dot" id="notif-dot" hidden></span>`}</button>
          <div class="notif-panel" id="notif-panel" hidden>${panelNotificaciones()}</div>
        </div>
        <div class="admin-user-chip">
          <span class="avatar">${esc((ME?.nombre || "?").split(" ").map((x) => x[0]).join("").slice(0, 2).toUpperCase())}</span>
          <span>${esc(ME?.nombre || "")}</span>
        </div>
      </header>
      <main class="admin-content" id="admin-content">${content}</main>
    </div>
  </div>`;
}

function render(content, title = "Backoffice") {
  $("#admin").innerHTML = shell(content, title);
  bindShell();
}

function panelNotificaciones() {
  if (!NOTIS.items.length) return `<p class="tiny muted" style="padding:10px">No tienes notificaciones.</p>`;
  return `<div class="notif-head"><strong>Notificaciones</strong></div>` + NOTIS.items.slice(0, 10).map((n) => `
    <a class="notif-item ${n.leida ? "" : "is-new"}" href="#/pagos">
      <span>${esc(n.texto)}</span>
      <time class="tiny muted">${fmtDateTime(n.created_at)}</time>
    </a>`).join("");
}

function actualizarBadges() {
  const dot = $("#notif-dot");
  if (dot) { dot.hidden = !NOTIS.no_leidas; dot.textContent = NOTIS.no_leidas || ""; }
  const panel = $("#notif-panel");
  if (panel) panel.innerHTML = panelNotificaciones();
  $$(".admin-nav a[href='#/pagos']").forEach((a) => {
    a.lastChild.textContent = ` Pagos${PAGOS_PENDIENTES ? ` (${PAGOS_PENDIENTES})` : ""}`;
  });
}

async function sondearNotificaciones(avisar) {
  if (!ME || !PUEDE_OPERAR()) return;
  try {
    const [n, p] = await Promise.all([api("/api/admin/notificaciones"), api("/api/admin/pagos")]);
    const antes = NOTIS.no_leidas;
    NOTIS = n;
    PAGOS_PENDIENTES = p.por_verificar.length + p.contrareembolso.length;
    if (avisar && n.no_leidas > antes) toast("Nuevo pedido pendiente de verificar el pago", "info");
    actualizarBadges();
  } catch { /* sin conexión: se reintenta en el siguiente ciclo */ }
}

function iniciarNotificaciones() {
  if (NOTIS_TIMER) clearInterval(NOTIS_TIMER);
  sondearNotificaciones(false);
  NOTIS_TIMER = setInterval(() => sondearNotificaciones(true), 30000);
}

function bindNotificaciones() {
  const btn = $("#notif-btn"), panel = $("#notif-panel");
  if (!btn || !panel) return;
  btn.addEventListener("click", async (e) => {
    e.stopPropagation();
    const abrir = panel.hidden;
    panel.hidden = !abrir;
    btn.setAttribute("aria-expanded", String(abrir));
    if (abrir && NOTIS.no_leidas) {
      try { await api("/api/admin/notificaciones/leidas", { method: "POST" }); NOTIS.no_leidas = 0; NOTIS.items = NOTIS.items.map((n) => ({ ...n, leida: 1 })); actualizarBadges(); } catch { /* ignorar */ }
    }
  });
  document.addEventListener("click", (e) => {
    if (!panel.hidden && !panel.contains(e.target) && e.target !== btn) { panel.hidden = true; btn.setAttribute("aria-expanded", "false"); }
  });
}

function bindShell() {
  bindNotificaciones();
  $("#sidebar-toggle")?.addEventListener("click", () => {
    $("#admin-sidebar")?.classList.toggle("is-open");
    $("#sidebar-backdrop")?.classList.toggle("is-open");
  });
  $("#sidebar-backdrop")?.addEventListener("click", () => {
    $("#admin-sidebar")?.classList.remove("is-open");
    $("#sidebar-backdrop")?.classList.remove("is-open");
  });
  $("#logout-link")?.addEventListener("click", async (e) => {
    e.preventDefault();
    try { await api("/api/auth/logout", { method: "POST" }); } catch {}
    ME = null;
    location.hash = "#/login";
  });
}

function loadingBlock(text = "Cargando…") {
  return `<div class="admin-empty"><span class="spinner"></span><p style="margin-top:10px">${esc(text)}</p></div>`;
}

function pageHead(title, subtitle, actions = "") {
  return `<div class="admin-page-head">
    <div><h2>${esc(title)}</h2>${subtitle ? `<p>${esc(subtitle)}</p>` : ""}</div>
    <div class="row">${actions}</div>
  </div>`;
}

function paginationHTML(pagina, paginas, buildHref) {
  if (paginas <= 1) return "";
  const items = [];
  for (let i = 1; i <= paginas; i += 1) {
    if (i === 1 || i === paginas || Math.abs(i - pagina) <= 1) items.push(i);
    else if (items[items.length - 1] !== "…") items.push("…");
  }
  return `<nav class="admin-pagination">
    ${items.map((p) => p === "…"
      ? `<span class="page-btn" aria-hidden="true">…</span>`
      : `<a class="page-btn ${p === pagina ? "is-active" : ""}" href="${buildHref(p)}">${p}</a>`).join("")}
  </nav>`;
}

/* ------------------------------ Login ------------------------------------ */
function slugDesdeNombre(texto) {
  return String(texto || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase()
    .replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 40);
}

function registroTiendaPage() {
  $("#admin").innerHTML = `<div class="admin-login">
    <div class="admin-login-card" style="width:min(480px,100%)">
      <div class="admin-login-mark">CC</div>
      <h1>Crea tu tienda</h1>
      <p>Tendrás tu panel, tu catálogo y tu tienda online en un momento.</p>
      <form id="registro-form" style="margin-top:22px" novalidate>
        <div class="field"><label for="rg-negocio">Nombre de tu tienda</label>
          <input class="input" id="rg-negocio" name="nombre_negocio" maxlength="80" required placeholder="Ej.: Estética Luna"></div>
        <div class="field" style="margin-top:12px"><label for="rg-slug">Dirección de tu tienda</label>
          <input class="input" id="rg-slug" name="slug" maxlength="40" placeholder="estetica-luna">
          <p class="tiny muted" style="margin-top:4px">Tu tienda estará en <strong id="rg-preview">/?tienda=…</strong></p></div>
        <div class="field" style="margin-top:12px"><label for="rg-nombre">Tu nombre</label>
          <input class="input" id="rg-nombre" name="nombre" maxlength="120" required autocomplete="name"></div>
        <div class="field" style="margin-top:12px"><label for="rg-email">Email</label>
          <input class="input" type="email" id="rg-email" name="email" maxlength="160" required autocomplete="username"></div>
        <div class="field" style="margin-top:12px"><label for="rg-pass">Contraseña</label>
          <input class="input" type="password" id="rg-pass" name="password" required autocomplete="new-password" placeholder="Mín. 8 caracteres, con letras y números">
        </div>
        <button class="btn btn-primary btn-block" type="submit" style="margin-top:18px" id="rg-btn">Crear mi tienda</button>
      </form>
      <p class="tiny muted center mt-2">¿Ya tienes cuenta? <a href="#/login">Entrar</a></p>
    </div>
  </div>`;
  const negocio = $("#rg-negocio"), slug = $("#rg-slug"), preview = $("#rg-preview");
  let slugManual = false;
  const actualizarPreview = () => { preview.textContent = `/?tienda=${slug.value || "…"}`; };
  negocio.addEventListener("input", () => { if (!slugManual) slug.value = slugDesdeNombre(negocio.value); actualizarPreview(); });
  slug.addEventListener("input", () => { slugManual = slug.value.length > 0; slug.value = slugDesdeNombre(slug.value); actualizarPreview(); });
  $("#registro-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = $("#rg-btn");
    const data = formObject(e.target);
    setBusy(btn, true, "Creando tu tienda…");
    try {
      const r = await api("/api/auth/registrar-tienda", { method: "POST", body: data });
      ME = r.usuario;
      await cargarAjustesAdmin();
      toast("Tu tienda está lista");
      location.hash = "#/";
    } catch (err) {
      setBusy(btn, false);
      toast(err.message, "error");
    }
  });
}

function loginPage() {
  $("#admin").innerHTML = `<div class="admin-login">
    <div class="admin-login-card">
      <div class="admin-login-mark">CC</div>
      <h1>Backoffice</h1>
      <p>Acceso para el equipo de CC Shop's.</p>
      <form id="login-form" style="margin-top:22px" novalidate>
        <div class="field"><label for="lg-email">Email</label>
          <input class="input" type="email" id="lg-email" name="email" autocomplete="username" placeholder="admin@ccshops.es" required></div>
        <div class="field" style="margin-top:12px"><label for="lg-pass">Contraseña</label>
          <div class="input-group">
            <input class="input" type="password" id="lg-pass" name="password" autocomplete="current-password" required>
            <button class="btn btn-outline" type="button" id="lg-toggle-pass" style="min-height:44px;padding:0 12px" aria-label="Mostrar contraseña">${icon("eye",16)}</button>
          </div></div>
        <button class="btn btn-primary btn-block" type="submit" style="margin-top:18px" id="lg-btn">Entrar</button>
      </form>
      <p class="tiny muted center mt-2">¿Aún no tienes tienda? <a href="#/registro">Crear mi tienda</a></p>
    </div>
  </div>`;
  $("#lg-toggle-pass")?.addEventListener("click", () => {
    const inp = $("#lg-pass");
    if (!inp) return;
    inp.type = inp.type === "password" ? "text" : "password";
  });
  $("#login-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const data = formObject(e.target);
    const btn = $("#lg-btn");
    btn.disabled = true; btn.textContent = "Entrando…";
    try {
      const res = await api("/api/auth/login", { method: "POST", body: data });
      ME = res.usuario;
      toast("Bienvenido, " + (ME.nombre || ""));
      location.hash = "#/";
    } catch (err) {
      btn.disabled = false; btn.textContent = "Entrar";
      toast(err.message || "Credenciales incorrectas", "error");
    }
  });
}

/* ------------------------------ Dashboard -------------------------------- */
async function dashboardPage() {
  render(loadingBlock("Cargando dashboard…"), "Dashboard");
  const d = await api("/api/admin/dashboard?dias=14");
  const k = d.kpis;
  const inv = d.inventario;
  const content = `
  ${pageHead("Dashboard", "Resumen de negocio de los últimos 14 días.", `<a class="btn btn-outline btn-sm" href="#/metricas">${icon("chart", 15)} Ver métricas</a>`)}
  <div class="kpi-grid" style="margin-bottom:14px">
    <div class="admin-kpi is-brand">
      <div class="kpi-label">Ventas hoy</div>
      <div class="kpi-value">${money(k.ventas_hoy)}</div>
      <div class="kpi-sub">${number(k.pedidos_hoy)} pedidos</div>
    </div>
    <div class="admin-kpi">
      <div class="kpi-label">Ventas del mes</div>
      <div class="kpi-value">${money(k.ventas_mes)}</div>
      <div class="kpi-sub">${k.variacion_mes === null ? "—" : `${k.variacion_mes > 0 ? "+" : ""}${k.variacion_mes}%`} vs mes anterior</div>
    </div>
    <div class="admin-kpi">
      <div class="kpi-label">Ticket medio</div>
      <div class="kpi-value">${money(k.ticket_medio)}</div>
      <div class="kpi-sub">Margen ${money(k.margen_mes)} (${k.margen_pct}%)</div>
    </div>
    <div class="admin-kpi">
      <div class="kpi-label">Pedidos pendientes</div>
      <div class="kpi-value">${number(k.pendientes)}</div>
      <div class="kpi-sub">${money(k.pendiente_importe)} por cobrar</div>
    </div>
  </div>
  <div class="kpi-grid" style="margin-bottom:18px">
    <div class="admin-kpi"><div class="kpi-label">Inventario (coste)</div><div class="kpi-value">${money(k.inventario_valor)}</div><div class="kpi-sub">${number(k.inventario_unidades)} unidades · ${number(k.inventario_referencias)} refs</div></div>
    <div class="admin-kpi"><div class="kpi-label">Valor a venta</div><div class="kpi-value">${money(k.inventario_venta)}</div><div class="kpi-sub">Margen potencial ${money(parseMoney(k.inventario_venta) - parseMoney(k.inventario_valor))}</div></div>
    <div class="admin-kpi"><div class="kpi-label">Bajo mínimo</div><div class="kpi-value">${number(k.bajo_stock)}</div><div class="kpi-sub">${number(k.agotados)} agotados</div></div>
    <div class="admin-kpi"><div class="kpi-label">Clientes</div><div class="kpi-value">${number(k.clientes)}</div><div class="kpi-sub">${number(k.recurrentes)} recurrentes</div></div>
  </div>

  <div class="admin-card" style="margin-bottom:14px">
    <div class="admin-card-head"><h3>Ventas de los últimos ${d.rango.dias} días</h3><span class="meta">${fmtDate(d.rango.desde)} — ${fmtDate(d.rango.hasta)}</span></div>
    <div class="chart">
      ${d.serie.map((s) => {
        const v = parseMoney(s.ventas);
        const max = Math.max(...d.serie.map((x) => parseMoney(x.ventas)), 1);
        const h = Math.max(2, (v / max) * 170);
        return `<div class="bar" style="height:${h}px" title="${esc(s.etiqueta)}: ${money(v)}">
          <span class="label">${esc(s.etiqueta.slice(0,5))}</span>
          ${v > 0 ? `<span class="value">${money(v).replace(" €","")}</span>` : ""}
        </div>`;
      }).join("")}
    </div>
  </div>

  <div class="grid-2" style="gap:14px;margin-bottom:14px">
    <div class="admin-card">
      <div class="admin-card-head"><h3>Top productos</h3><span class="meta">por unidades</span></div>
      ${d.top_productos.length ? `<table class="table admin-table"><thead><tr><th>Producto</th><th class="num">Uds</th><th class="num">Importe</th></tr></thead><tbody>
        ${d.top_productos.map((p) => `<tr>
          <td><strong>${esc(p.nombre)}</strong><br><span class="tiny muted">${esc(p.sku)}</span></td>
          <td class="num">${number(p.unidades)}</td>
          <td class="num money">${money(p.importe)}</td>
        </tr>`).join("")}
      </tbody></table>` : `<div class="admin-empty">${icon("package", 24)} Sin ventas en el periodo</div>`}
    </div>
    <div class="admin-card">
      <div class="admin-card-head"><h3>Ventas por categoría</h3></div>
      ${d.categorias.length ? `<div class="stack">
        ${d.categorias.map((c) => {
          const total = d.categorias.reduce((a, x) => a + parseMoney(x.importe), 0) || 1;
          const pct = Math.round(parseMoney(c.importe) / total * 100);
          return `<div>
            <div class="row-between" style="font-size:12.5px"><strong>${esc(c.nombre)}</strong><span class="muted">${money(c.importe)} · ${pct}%</span></div>
            <div class="progress" style="margin-top:5px"><span style="width:${pct}%"></span></div>
          </div>`;
        }).join("")}
      </div>` : `<div class="admin-empty">${icon("tag", 24)} Sin datos</div>`}
    </div>
  </div>

  <div class="grid-2" style="gap:14px">
    <div class="admin-card">
      <div class="admin-card-head"><h3>Pedidos recientes</h3><a class="btn btn-ghost btn-xs" href="#/pedidos">Ver todos</a></div>
      ${d.pedidos_recientes.length ? `<table class="table admin-table"><thead><tr><th>Nº</th><th>Cliente</th><th>Estado</th><th class="num">Total</th></tr></thead><tbody>
        ${d.pedidos_recientes.map((p) => `<tr style="cursor:pointer" data-pedido="${esc(p.id)}">
          <td><strong>${esc(p.numero)}</strong><br><span class="tiny muted">${fmtDate(p.created_at)}</span></td>
          <td>${esc(p.cliente_nombre)}</td>
          <td>${estadoBadge(p.estado, p.estado_label)}</td>
          <td class="num money">${money(p.total)}</td>
        </tr>`).join("")}
      </tbody></table>` : `<div class="admin-empty">${icon("truck", 24)} Sin pedidos</div>`}
    </div>
    <div class="admin-card">
      <div class="admin-card-head"><h3>Últimos movimientos</h3><a class="btn btn-ghost btn-xs" href="#/movimientos">Ver todos</a></div>
      ${d.movimientos.length ? `<table class="table admin-table"><thead><tr><th>Fecha</th><th>Producto</th><th>Mov.</th><th class="num">Saldo</th></tr></thead><tbody>
        ${d.movimientos.map((m) => `<tr>
          <td class="tiny muted">${fmtDateTime(m.fecha)}</td>
          <td>${esc(m.producto_nombre)}<br><span class="tiny muted">${esc(m.producto_sku)}</span></td>
          <td class="${m.cantidad > 0 ? "in" : "out"}">${m.cantidad > 0 ? "+" : "−"}${number(Math.abs(m.cantidad))}</td>
          <td class="num">${number(m.saldo_cantidad)}</td>
        </tr>`).join("")}
      </tbody></table>` : `<div class="admin-empty">${icon("layers", 24)} Sin movimientos</div>`}
    </div>
  </div>

  ${d.bajo_stock.length ? `<div class="admin-card" style="margin-top:14px">
    <div class="admin-card-head"><h3>Productos bajo mínimo</h3><a class="btn btn-ghost btn-xs" href="#/inventario">Ver inventario</a></div>
    <table class="table admin-table"><thead><tr><th>Producto</th><th>Categoría</th><th class="num">Stock</th><th class="num">Mínimo</th><th></th></tr></thead><tbody>
      ${d.bajo_stock.map((p) => `<tr>
        <td><strong>${esc(p.nombre)}</strong><br><span class="tiny muted">${esc(p.sku)}</span></td>
        <td>${esc(p.categoria || "—")}</td>
        <td class="num ${Number(p.stock) <= 0 ? "out" : ""}">${number(p.stock)} ${esc(p.unidad)}</td>
        <td class="num">${number(p.stock_minimo)}</td>
        <td class="actions"><a class="btn btn-xs btn-outline" href="#/productos/${esc(p.id)}">Ajustar</a></td>
      </tr>`).join("")}
    </tbody></table>
  </div>` : ""}`;
  render(content, "Dashboard");
  $$("[data-pedido]").forEach((r) => r.addEventListener("click", () => { location.hash = `#/pedidos/${r.dataset.pedido}`; }));
}

/* ------------------------------ Productos -------------------------------- */
let PRODUCTOS_CACHE = new Map();

// ------------------------------ Variantes de producto ------------------------------

async function openVariantesModal(productoId) {
  const pr = (await api(`/api/admin/productos/${encodeURIComponent(productoId)}`)).producto;
  const variantes = pr.variantes || [];
  const pintarLista = () => variantes.length
    ? `<div class="table-wrap"><table class="table admin-table"><thead><tr><th>Variante</th><th>SKU</th><th class="num">Precio</th><th class="num">Stock</th><th>Activa</th></tr></thead>
       <tbody>${variantes.map((v) => `<tr>
         <td><strong>${esc(Object.values(v.atributos || {}).join(" · "))}</strong><br><span class="tiny muted">${esc(Object.entries(v.atributos || {}).map(([k, x]) => `${k}: ${x}`).join(" · "))}</span></td>
         <td class="tiny muted">${esc(v.sku)}</td><td class="num money">${money(v.precio)}</td>
         <td class="num ${Number(v.stock) <= 0 ? "out" : ""}">${number(v.stock)} ${esc(v.unidad || "ud")}</td>
         <td><input type="checkbox" data-var-activa="${esc(v.id)}" ${v.activo ? "checked" : ""}></td></tr>`).join("")}</tbody></table></div>`
    : `<p class="tiny muted">Este producto todavía no tiene variantes. Añade la primera abajo.</p>`;
  const body = `
    <p class="tiny muted" style="margin-bottom:10px">El stock del producto es la suma de sus variantes. Los clientes ven las variantes activas dentro de la ficha.</p>
    <div id="var-lista">${pintarLista()}</div>
    <div class="admin-card" style="margin-top:14px;padding:14px">
      <div class="admin-card-head"><h3>Nueva variante</h3></div>
      <form id="var-form" class="admin-form-grid" novalidate>
        <div class="field"><label>Atributo 1 (nombre)</label><input class="input" name="a1k" placeholder="Talla" value="Talla"></div>
        <div class="field"><label>Valor</label><input class="input" name="a1v" placeholder="M" required></div>
        <div class="field"><label>Atributo 2 (nombre)</label><input class="input" name="a2k" placeholder="Color" value="Color"></div>
        <div class="field"><label>Valor</label><input class="input" name="a2v" placeholder="Rojo"></div>
        <div class="field"><label>SKU <span class="muted">(opcional)</span></label><input class="input" name="sku" placeholder="Se genera"></div>
        <div class="field"><label>Precio <span class="muted">(vacío = el del producto)</span></label><input class="input" type="number" step="0.01" min="0" name="precio"></div>
        <div class="field"><label>Stock inicial</label><input class="input" type="number" step="0.01" min="0" name="stock_inicial" value="0"></div>
        <div class="field"><label>Coste unitario</label><input class="input" type="number" step="0.01" min="0" name="coste" value="${esc(pr.coste_medio || 0)}"></div>
        <div class="field full"><button class="btn btn-primary btn-sm" type="submit" id="var-btn">${icon("plus", 14)} Añadir variante</button></div>
      </form>
    </div>`;
  openModal({
    title: `Variantes de «${pr.nombre}»`,
    body,
    xl: true,
    footer: `<button class="btn btn-outline btn-sm" data-cancel>Cerrar</button>`,
    onMount: (el, close) => {
      el.querySelector("[data-cancel]").addEventListener("click", close);
      const enlazar = () => {
        el.querySelectorAll("[data-var-activa]").forEach((chk) => chk.addEventListener("change", async () => {
          try { await api(`/api/admin/productos/${productoId}/variantes/${chk.dataset.varActiva}`, { method: "PUT", body: { activa: chk.checked } }); toast("Variante actualizada"); }
          catch (err) { chk.checked = !chk.checked; toast(err.message, "error"); }
        }));
      };
      enlazar();
      el.querySelector("#var-form").addEventListener("submit", async (e) => {
        e.preventDefault();
        const f = formObject(e.target);
        const atributos = {};
        if (f.a1k && f.a1v) atributos[f.a1k] = f.a1v;
        if (f.a2k && f.a2v) atributos[f.a2k] = f.a2v;
        const btn = el.querySelector("#var-btn");
        setBusy(btn, true, "Añadiendo…");
        try {
          await api(`/api/admin/productos/${productoId}/variantes`, { method: "POST", body: {
            atributos, sku: f.sku || "", precio: f.precio === "" ? null : parseMoney(f.precio),
            stock_inicial: Number(f.stock_inicial || 0), coste: parseMoney(f.coste || "0") } });
          toast("Variante añadida");
          close();
          openVariantesModal(productoId);
          productsPage(new URLSearchParams());
        } catch (err) { setBusy(btn, false); toast(err.message, "error"); }
      });
    },
  });
}

// ------------------------------ Clientes ------------------------------

async function clientesPage() {
  render(loadingBlock("Cargando clientes…"), "Clientes");
  const d = await api("/api/admin/clientes");
  const total = d.items.reduce((t, c) => t + Number(c.gastado || 0), 0);
  render(`${pageHead("Clientes", `${number(d.items.length)} clientes · ${money(total)} en ventas no canceladas.`)}
  <div class="admin-card" style="padding:0">
    <div class="table-wrap"><table class="table admin-table">
      <thead><tr><th>Cliente</th><th>Teléfono</th><th class="num">Pedidos</th><th class="num">Gastado</th><th>Último pedido</th><th>Cuenta</th></tr></thead>
      <tbody>${d.items.map((c) => `<tr class="is-clickable" data-href="#/clientes/${encodeURIComponent(c.email)}">
        <td><strong>${esc(c.nombre || "—")}</strong><br><span class="tiny muted">${esc(c.email)}</span></td>
        <td>${esc(c.telefono || "—")}</td>
        <td class="num">${number(c.pedidos)}</td>
        <td class="num money">${money(c.gastado)}</td>
        <td class="tiny muted">${c.ultimo_pedido ? fmtDateTime(c.ultimo_pedido) : "—"}</td>
        <td>${c.cuenta ? '<span class="badge badge--ok">Con cuenta</span>' : '<span class="badge">Sin cuenta</span>'}</td>
      </tr>`).join("") || `<tr><td colspan="6" class="admin-empty">Todavía no hay clientes. Aparecerán cuando hagan su primer pedido.</td></tr>`}</tbody>
    </table></div>
  </div>`, "Clientes");
  $$("tr[data-href]").forEach((tr) => tr.addEventListener("click", () => { location.hash = tr.dataset.href; }));
}

async function clienteDetallePage(email) {
  render(loadingBlock("Cargando cliente…"), "Cliente");
  const c = await api(`/api/admin/clientes/${encodeURIComponent(email)}`);
  const dir = c.direccion || {};
  render(`${pageHead(c.nombre || c.email, c.email, `<a class="btn btn-outline btn-sm" href="#/clientes">${icon("arrowLeft", 14)} Volver</a>`)}
  <div class="kpi-grid" style="margin-bottom:14px">
    ${kpi("Pedidos", number(c.resumen.pedidos), `${number(c.resumen.activos)} activos`)}
    ${kpi("Gastado", money(c.resumen.gastado), "sin cancelados")}
    ${kpi("Ticket medio", money(c.resumen.ticket_medio))}
    ${kpi("Cuenta", c.cuenta.existe ? "Sí" : "No", c.cuenta.existe && c.cuenta.ultimo_acceso ? `último acceso ${fmtDateTime(c.cuenta.ultimo_acceso)}` : "")}
  </div>
  <div class="grid-2" style="gap:14px;align-items:start;margin-bottom:14px">
    <div class="admin-card"><div class="admin-card-head"><h3>Datos de contacto</h3></div>
      <p><strong>${esc(c.nombre || "—")}</strong>${c.nif ? ` · ${esc(c.nif)}` : ""}</p>
      <p class="small">${c.telefono ? `<a href="tel:${esc(c.telefono)}">${esc(c.telefono)}</a> · ` : ""}<a href="mailto:${esc(c.email)}">${esc(c.email)}</a></p>
    </div>
    <div class="admin-card"><div class="admin-card-head"><h3>Última dirección</h3></div>
      <p class="small">${esc(dir.direccion || "—")}<br>${esc([dir.cp, dir.ciudad, dir.provincia].filter(Boolean).join(" · "))}</p>
    </div>
  </div>
  <div class="admin-card" style="padding:0"><div class="admin-card-head" style="padding:14px 18px"><h3>Historial de pedidos</h3></div>
    <div class="table-wrap"><table class="table admin-table">
      <thead><tr><th>Pedido</th><th>Fecha</th><th>Estado</th><th>Pago</th><th>Entrega</th><th class="num">Total</th></tr></thead>
      <tbody>${c.pedidos.map((p) => `<tr class="is-clickable" data-href="#/pedidos/${encodeURIComponent(p.id)}">
        <td><strong>${esc(p.numero)}</strong></td><td class="tiny muted">${fmtDateTime(p.fecha)}</td>
        <td>${estadoBadge(p.estado, p.estado_label)}</td><td class="tiny">${esc(p.pago_estado)}</td>
        <td class="tiny">${esc(p.tipo_entrega)}</td><td class="num money">${money(p.total)}</td></tr>`).join("")}</tbody>
    </table></div></div>`, "Cliente");
  $$("tr[data-href]").forEach((tr) => tr.addEventListener("click", () => { location.hash = tr.dataset.href; }));
}

async function productsPage(params) {
  const q = params.get("q") || "";
  const categoria = params.get("categoria") || "";
  const estado = params.get("estado") || "";
  const pagina = Math.max(1, parseInt(params.get("pagina") || "1", 10) || 1);

  render(loadingBlock("Cargando productos…"), "Productos");
  const [data, cats] = await Promise.all([
    api("/api/admin/productos", { query: { q, categoria, estado, pagina, por_pagina: 25 } }),
    api("/api/admin/categorias"),
  ]);
  CATEGORIAS = cats.items || [];
  data.items.forEach((p) => PRODUCTOS_CACHE.set(p.id, p));

  const content = `
  ${pageHead("Productos", `${data.resumen.referencias} referencias · ${number(data.resumen.unidades)} unidades · ${money(data.resumen.valor)} en stock.`, `
    <button class="btn btn-primary btn-sm" id="new-product-btn">${icon("plus", 15)} Nuevo producto</button>
  `)}
  <div class="admin-toolbar">
    <div class="search-box"><input class="input" id="prod-search" type="search" placeholder="Buscar por nombre, SKU o marca…" value="${esc(q)}"></div>
    <select class="select" id="prod-cat">
      <option value="">Todas las categorías</option>
      ${CATEGORIAS.map((c) => `<option value="${esc(c.id)}" ${categoria === c.id ? "selected" : ""}>${esc(c.nombre)}</option>`).join("")}
    </select>
    <select class="select" id="prod-estado">
      <option value="" ${estado === "" ? "selected" : ""}>Todos los estados</option>
      <option value="activo" ${estado === "activo" ? "selected" : ""}>Activos</option>
      <option value="inactivo" ${estado === "inactivo" ? "selected" : ""}>Inactivos</option>
      <option value="bajo" ${estado === "bajo" ? "selected" : ""}>Bajo mínimo</option>
      <option value="agotado" ${estado === "agotado" ? "selected" : ""}>Agotados</option>
    </select>
  </div>
  ${data.items.length ? `<div class="admin-card" style="padding:0"><div class="table-wrap"><table class="table admin-table">
    <thead><tr><th></th><th>SKU</th><th>Producto</th><th>Categoría</th><th class="num">Precio</th><th class="num">Stock</th><th class="num">Mín.</th><th>Estado</th><th class="actions">Acciones</th></tr></thead>
    <tbody>
      ${data.items.map((p) => `<tr>
        <td><img class="thumb" src="${esc(imgSrc(p))}" alt=""></td>
        <td class="tiny muted">${esc(p.sku)}</td>
        <td><strong>${esc(p.nombre)}</strong>${p.destacado ? ' <span class="badge badge--brand">Destacado</span>' : ""}${p.es_pack ? ' <span class="badge">Pack</span>' : ""}${p.promo_vigente ? ` <span class="badge badge--warn">Promo · ${number(p.promo_stock_restante)} ud</span>` : ""}<br><span class="tiny muted">${esc(p.marca || "")}</span></td>
        <td>${esc(p.categoria_nombre || "—")}</td>
        <td class="num money">${money(p.precio)}</td>
        <td class="num ${Number(p.stock) <= 0 ? "out" : Number(p.stock) <= Number(p.stock_minimo) ? "warn" : ""}">${number(p.stock)} ${esc(p.unidad)}</td>
        <td class="num">${number(p.stock_minimo)}</td>
        <td>${p.activo ? (Number(p.stock) <= 0 ? '<span class="badge badge--danger">Agotado</span>' : Number(p.stock) <= Number(p.stock_minimo) ? '<span class="badge badge--warn">Bajo</span>' : '<span class="badge badge--ok">OK</span>') : '<span class="badge">Inactivo</span>'}</td>
        <td class="actions">
          <button class="btn btn-xs btn-outline" data-edit="${esc(p.id)}">${icon("edit", 13)}</button>
          <button class="btn btn-xs btn-outline" data-kardex="${esc(p.id)}">${icon("layers", 13)}</button>
          ${p.es_pack ? "" : `<button class="btn btn-xs btn-outline" data-variantes="${esc(p.id)}" title="Variantes (talla, color…)">${icon("grid", 13)}${p.variantes?.length ? ` ${p.variantes.length}` : ""}</button>`}
          <button class="btn btn-xs btn-outline" data-ajuste="${esc(p.id)}">${icon("ruler", 13)}</button>
          <button class="btn btn-xs btn-danger" data-deactivate="${esc(p.id)}" title="Desactivar">${icon("trash", 13)}</button>
        </td>
      </tr>`).join("")}
    </tbody></table></div>
    ${paginationHTML(data.pagina, data.paginas, (pg) => `#/productos?${new URLSearchParams({ q, categoria, estado, pagina: pg }).toString()}`)}
  </div>` : emptyState({ iconName: "package", title: "Sin productos", text: "No hay productos que coincidan con los filtros.", action: `<button class="btn btn-primary btn-sm" id="new-product-btn2">Nuevo producto</button>` })}`;

  render(content, "Productos");
  $("#new-product-btn")?.addEventListener("click", () => openProductModal());
  $("#new-product-btn2")?.addEventListener("click", () => openProductModal());

  const debounce = (fn, ms = 350) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
  const update = () => {
    const params = new URLSearchParams();
    const qv = $("#prod-search").value.trim();
    const cv = $("#prod-cat").value;
    const ev = $("#prod-estado").value;
    if (qv) params.set("q", qv);
    if (cv) params.set("categoria", cv);
    if (ev) params.set("estado", ev);
    location.hash = `#/productos${params.toString() ? "?" + params.toString() : ""}`;
  };
  $("#prod-search")?.addEventListener("input", debounce(update));
  $("#prod-cat")?.addEventListener("change", update);
  $("#prod-estado")?.addEventListener("change", update);

  $$("[data-edit]").forEach((b) => b.addEventListener("click", () => openProductModal(PRODUCTOS_CACHE.get(b.dataset.edit))));
  $$("[data-kardex]").forEach((b) => b.addEventListener("click", () => openKardexModal(b.dataset.kardex)));
  $$("[data-variantes]").forEach((b) => b.addEventListener("click", () => openVariantesModal(b.dataset.variantes)));
  $$("[data-ajuste]").forEach((b) => b.addEventListener("click", () => openAjusteModal(b.dataset.ajuste)));
  $$("[data-deactivate]").forEach((b) => b.addEventListener("click", async () => {
    const p = PRODUCTOS_CACHE.get(b.dataset.deactivate);
    const ok = await confirmDialog({ title: "Desactivar producto", message: `¿Desactivar «${p?.nombre || ""}»? No se borra, solo deja de venderse.`, danger: true, confirmText: "Desactivar" });
    if (!ok) return;
    try {
      await api(`/api/admin/productos/${b.dataset.deactivate}`, { method: "DELETE" });
      toast("Producto desactivado");
      route();
    } catch (err) { toast(err.message, "error"); }
  }));
}

function imgSrc(p) { return p && p.imagen ? p.imagen : PLACEHOLDER; }
const PLACEHOLDER = "data:image/svg+xml;charset=utf-8," + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400"><rect width="400" height="400" fill="#f1ece0"/><g fill="none" stroke="#c9bfa9" stroke-width="7"><path d="M118 152h164v148H118z"/></g></svg>');

async function openProductModal(product = null) {
  const isEdit = !!product;
  const cats = await api("/api/admin/categorias").then((r) => r.items || []).catch(() => []);
  const marcas = await api("/api/admin/marcas").then((r) => r.items || []).catch(() => []);
  const productosPack = await api("/api/admin/productos", { query: { por_pagina: 500 } }).then((r) => (r.items || []).filter((x) => !x.es_pack && x.id !== product?.id)).catch(() => []);
  const specs = Array.isArray(product?.especificaciones) ? product.especificaciones : [];
  const body = `
  <form id="product-form" class="admin-form-grid" novalidate>
    <div class="field"><label>Nombre *</label><input class="input" name="nombre" value="${esc(product?.nombre || "")}" required></div>
    <div class="field"><label>SKU</label><input class="input" name="sku" value="${esc(product?.sku || "")}" placeholder="Se genera si se deja vacío"></div>
    <div class="field"><label>Categoría principal</label>
      <select class="select" name="categoria_id" id="pm-cat">
        <option value="">Sin categoría</option>
        ${cats.filter((c) => !c.padre_id).map((c) => `<option value="${esc(c.id)}" ${product?.categoria_id === c.id ? "selected" : ""}>${esc(c.nombre)}</option>`).join("")}
      </select>
      <div class="row" style="gap:8px;margin-top:6px"><input class="input" id="pm-nueva-cat" placeholder="Nueva categoría…" style="flex:1"><button type="button" class="btn btn-outline btn-sm" id="pm-crear-cat">Crear</button></div>
    </div>
    <div class="field full"><label>Subcategorías <span class="tiny muted">(máximo 2, dentro de la categoría principal)</span></label>
      <div id="pm-subs" class="chip-row"></div>
      <div class="row" style="gap:8px;margin-top:6px"><input class="input" id="pm-nueva-sub" placeholder="Nueva subcategoría de la categoría elegida…" style="flex:1"><button type="button" class="btn btn-outline btn-sm" id="pm-crear-sub">Crear</button></div>
    </div>
    <div class="field"><label>Marca</label><input class="input" name="marca" list="pm-marcas" value="${esc(product?.marca || "")}" autocomplete="off" placeholder="Elige una marca usada o escribe una nueva"><datalist id="pm-marcas">${marcas.map((x) => `<option value="${esc(x)}"></option>`).join("")}</datalist></div>
    <div class="field"><label>Precio con IVA *</label><input class="input" name="precio" type="number" step="0.01" min="0" value="${esc(product?.precio ?? "")}" required></div>
    <div class="field"><label>IVA</label>
      <select class="select" name="iva">
        ${[0,4,10,21].map((v) => `<option value="${v}" ${Number(product?.iva ?? 21) === v ? "selected" : ""}>${v} %</option>`).join("")}
      </select></div>
    <div class="field"><label>Unidad</label>
      <select class="select" name="unidad">
        ${["ud","caja","pack","rollo","kg","l","m"].map((v) => `<option value="${v}" ${product?.unidad === v ? "selected" : ""}>${v}</option>`).join("")}
      </select></div>
    <div class="field"><label>Stock mínimo</label><input class="input" name="stock_minimo" type="number" step="0.01" min="0" value="${esc(product?.stock_minimo ?? 0)}"></div>
    ${!isEdit ? `
    <div class="field"><label>Stock inicial</label><input class="input" name="stock_inicial" type="number" step="0.01" min="0" value="0"></div>
    <div class="field"><label>Coste unitario *</label><input class="input" name="coste" type="number" step="0.01" min="0" value="${esc(product?.coste_medio ?? "")}" placeholder="Obligatorio si hay stock"></div>
    ` : `<input type="hidden" name="stock_inicial" value="0">`}
    <div class="field"><label>Activo</label>
      <select class="select" name="activo">
        <option value="true" ${product?.activo !== false ? "selected" : ""}>Sí</option>
        <option value="false" ${product?.activo === false ? "selected" : ""}>No</option>
      </select></div>
    <div class="field"><label>Destacado</label>
      <select class="select" name="destacado">
        <option value="false" ${!product?.destacado ? "selected" : ""}>No</option>
        <option value="true" ${product?.destacado ? "selected" : ""}>Sí</option>
      </select></div>
    <div class="field full"><label>Descripción corta</label><textarea class="textarea" name="descripcion_corta" rows="2">${esc(product?.descripcion_corta || "")}</textarea></div>
    <div class="field full"><label>Descripción</label><textarea class="textarea" name="descripcion" rows="4">${esc(product?.descripcion || "")}</textarea></div>
    <div class="field full">
      <label>Imagen</label>
      <div class="row" style="gap:8px;flex-wrap:wrap">
        <button type="button" class="btn btn-outline btn-sm" id="product-image-pick">${icon("image", 14)} Subir foto</button>
        <button type="button" class="btn btn-outline btn-sm" id="product-image-cam">${icon("camera", 14)} Hacer foto</button>
      </div>
      <input type="file" id="product-image-file" accept="image/jpeg,image/png,image/webp" class="hidden-file" tabindex="-1">
      <input type="file" id="product-image-camera" accept="image/*" capture="environment" class="hidden-file" tabindex="-1">
      <input type="hidden" name="imagen" id="product-image-value" value="${esc(product?.imagen || "")}">
      <div id="product-image-preview" style="margin-top:8px">${product?.imagen ? `<img src="${esc(product.imagen)}" style="max-height:120px;border-radius:10px;border:1px solid var(--line)">` : ""}</div>
      <p class="hint">JPEG, PNG o WebP. Se comprime automáticamente.</p>
    </div>
    <div class="field full">
      <label>Tipo</label>
      <select class="select" name="es_pack" id="pm-es-pack" ${isEdit ? "disabled" : ""} style="max-width:320px">
        <option value="false" ${!product?.es_pack ? "selected" : ""}>Producto</option>
        <option value="true" ${product?.es_pack ? "selected" : ""}>Pack (2 o más productos)</option>
      </select>
      ${isEdit ? `<p class="hint">El tipo no se puede cambiar después de crear el producto.</p>` : ""}
    </div>
    <div class="field full" id="pm-pack-bloque" style="display:none">
      <label>Productos del pack <span class="muted">· el stock del pack es el que permita formar más packs completos</span></label>
      <div id="pm-componentes" class="stack"></div>
      <button type="button" class="btn btn-ghost btn-xs" id="pm-add-comp" style="margin-top:6px">${icon("plus", 13)} Añadir producto al pack</button>
    </div>
    <div class="field full" id="pm-promo-bloque">
      <label>Promoción</label>
      <label class="check"><input type="checkbox" id="pm-promo-activa" name="promo_activa" value="true" ${product?.promo_activa ? "checked" : ""}> Activar promoción</label>
      <div class="admin-form-grid" id="pm-promo-campos" style="margin-top:8px">
        <div class="field"><label>Precio en promoción (€)</label><input class="input" type="number" step="0.01" min="0" name="promo_precio" value="${esc(product?.promo_precio || "")}"></div>
        <div class="field"><label>Unidades en promoción</label><input class="input" type="number" step="0.01" min="0" name="promo_stock" value="${esc(product?.promo_stock_inicial || "")}"></div>
        <div class="field"><label>Válida hasta</label><input class="input" type="datetime-local" name="promo_fin" value="${esc((product?.promo_fin || "").slice(0, 16))}"></div>
      </div>
      <p class="hint">Se muestra en la categoría Promociones mientras queden unidades y no haya pasado la fecha. Al agotarse o vencer, pierde la etiqueta sola.</p>
    </div>
    <div class="field full">
      <label>Especificaciones</label>
      <div id="specs-container" class="stack"></div>
      <button type="button" class="btn btn-ghost btn-xs" id="add-spec-btn" style="margin-top:6px">${icon("plus", 13)} Añadir especificación</button>
    </div>
  </form>`;

  const close = openModal({
    title: isEdit ? "Editar producto" : "Nuevo producto",
    subtitle: isEdit ? product.sku : "Crea una nueva referencia en el catálogo",
    body, wide: true,
    footer: `<button class="btn btn-outline btn-sm" data-cancel>Cancelar</button>
             <button class="btn btn-primary btn-sm" id="save-product-btn">${isEdit ? "Guardar cambios" : "Crear producto"}</button>`,
    onMount: (el, closeFn) => {
      const specsContainer = el.querySelector("#specs-container");
      const renderSpec = (spec = {}) => {
        const row = document.createElement("div");
        row.className = "row";
        row.style.gap = "8px";
        row.innerHTML = `<input class="input" placeholder="Clave" value="${esc(spec.clave || "")}" style="flex:1">
                         <input class="input" placeholder="Valor" value="${esc(spec.valor || "")}" style="flex:2">
                         <button type="button" class="btn-icon is-danger" style="width:34px;height:34px">${icon("trash", 14)}</button>`;
        row.querySelector("button").addEventListener("click", () => row.remove());
        specsContainer.appendChild(row);
      };
      specs.forEach(renderSpec);
      // packs: componentes y visibilidad de campos de stock
      const tipoSel = el.querySelector("#pm-es-pack");
      const packBloque = el.querySelector("#pm-pack-bloque");
      const compBox = el.querySelector("#pm-componentes");
      const opcionesProd = (sel = "") => productosPack.map((x) => `<option value="${esc(x.id)}" ${x.id === sel ? "selected" : ""}>${esc(x.nombre)} (${esc(x.sku)})</option>`).join("");
      const addComp = (pid = "", cant = 1) => {
        const fila = document.createElement("div");
        fila.className = "row";
        fila.style.gap = "8px";
        fila.innerHTML = `<select class="select" data-comp-id style="flex:2"><option value="">Elige un producto…</option>${opcionesProd(pid)}</select>
          <input class="input" type="number" min="0.0001" step="0.0001" data-comp-cant value="${esc(cant)}" style="flex:0 0 90px" title="Cantidad por pack">
          <button type="button" class="btn-icon is-danger" style="width:34px;height:34px">${icon("trash", 14)}</button>`;
        fila.querySelector("button").addEventListener("click", () => fila.remove());
        compBox.appendChild(fila);
      };
      (product?.componentes || []).forEach((c) => addComp(c.producto_id, c.cantidad));
      el.querySelector("#pm-add-comp").addEventListener("click", () => addComp());
      const aplicarTipo = () => {
        const pack = tipoSel.value === "true";
        packBloque.style.display = pack ? "" : "none";
        el.querySelectorAll("input[name=stock_inicial], input[name=coste]").forEach((inp) => {
          const campo = inp.closest(".field");
          if (campo) campo.style.display = pack ? "none" : "";
        });
        if (pack && !compBox.children.length) { addComp(); addComp(); }
      };
      tipoSel.addEventListener("change", aplicarTipo);
      aplicarTipo();
      const promoCheck = el.querySelector("#pm-promo-activa");
      const promoCampos = el.querySelector("#pm-promo-campos");
      const aplicarPromo = () => { promoCampos.style.opacity = promoCheck.checked ? "1" : "0.5"; };
      promoCheck.addEventListener("change", aplicarPromo);
      aplicarPromo();
      // categoría principal, subcategorías (máximo 2) y creación al momento
      const catSel = el.querySelector("#pm-cat");
      const subsBox = el.querySelector("#pm-subs");
      const seleccion = new Set((product?.subcategorias || []).map((x) => x.id));
      const pintarSubs = () => {
        const padre = catSel.value;
        const hijos = cats.filter((c) => c.padre_id && c.padre_id === padre);
        for (const id of [...seleccion]) if (!hijos.some((h) => h.id === id)) seleccion.delete(id);
        subsBox.innerHTML = !padre
          ? `<span class="tiny muted">Elige primero una categoría principal.</span>`
          : hijos.length
            ? hijos.map((h) => `<label class="chip"><input type="checkbox" value="${esc(h.id)}" ${seleccion.has(h.id) ? "checked" : ""}> ${esc(h.nombre)}</label>`).join("")
            : `<span class="tiny muted">Esta categoría todavía no tiene subcategorías.</span>`;
        subsBox.querySelectorAll("input[type=checkbox]").forEach((chk) => chk.addEventListener("change", () => {
          if (chk.checked) {
            if (seleccion.size >= 2) { chk.checked = false; toast("Un producto puede tener como máximo 2 subcategorías", "error"); return; }
            seleccion.add(chk.value);
          } else seleccion.delete(chk.value);
        }));
      };
      catSel.addEventListener("change", pintarSubs);
      pintarSubs();
      el.querySelector("#pm-crear-cat").addEventListener("click", async () => {
        const input = el.querySelector("#pm-nueva-cat");
        const nombre = input.value.trim();
        if (!nombre) return toast("Escribe el nombre de la categoría", "error");
        try {
          const c = (await api("/api/admin/categorias", { method: "POST", body: { nombre } })).categoria;
          cats.push(c);
          catSel.add(new Option(c.nombre, c.id, true, true));
          catSel.value = c.id; input.value = "";
          pintarSubs(); toast("Categoría creada");
        } catch (err) { toast(err.message, "error"); }
      });
      el.querySelector("#pm-crear-sub").addEventListener("click", async () => {
        const input = el.querySelector("#pm-nueva-sub");
        const nombre = input.value.trim();
        if (!catSel.value) return toast("Elige primero una categoría principal", "error");
        if (!nombre) return toast("Escribe el nombre de la subcategoría", "error");
        try {
          const c = (await api("/api/admin/categorias", { method: "POST", body: { nombre, padre_id: catSel.value } })).categoria;
          cats.push(c); input.value = "";
          if (seleccion.size < 2) seleccion.add(c.id);
          pintarSubs(); toast("Subcategoría creada");
        } catch (err) { toast(err.message, "error"); }
      });
      el.querySelector("#add-spec-btn").addEventListener("click", () => renderSpec());
      // image
      const cargarFoto = async (e) => {
        const file = e.target.files?.[0];
        e.target.value = "";
        if (!file) return;
        try {
          const data = await compressImage(file);
          el.querySelector("#product-image-value").value = data;
          el.querySelector("#product-image-preview").innerHTML = `<img src="${data}" style="max-height:120px;border-radius:10px;border:1px solid var(--line)">`;
          toast("Imagen cargada");
        } catch (err) { toast(err.message, "error"); }
      };
      el.querySelector("#product-image-file").addEventListener("change", cargarFoto);
      el.querySelector("#product-image-camera").addEventListener("change", cargarFoto);
      el.querySelector("#product-image-pick").addEventListener("click", () => el.querySelector("#product-image-file").click());
      el.querySelector("#product-image-cam").addEventListener("click", () => el.querySelector("#product-image-camera").click());
      el.querySelector("[data-cancel]").addEventListener("click", closeFn);
      el.querySelector("#save-product-btn").addEventListener("click", async () => {
        const btn = el.querySelector("#save-product-btn");
        const form = el.querySelector("#product-form");
        const fd = new FormData(form);
        const especificaciones = [...specsContainer.querySelectorAll(".row")].map((row) => {
          const inputs = row.querySelectorAll("input");
          return { clave: inputs[0].value.trim(), valor: inputs[1].value.trim() };
        }).filter((x) => x.clave && x.valor);
        const bodyData = {
          nombre: fd.get("nombre"),
          sku: fd.get("sku"),
          categoria_id: fd.get("categoria_id"),
          subcategoria_ids: [...seleccion],
          es_pack: el.querySelector("#pm-es-pack").value === "true",
          componentes: el.querySelector("#pm-es-pack").value === "true"
            ? [...el.querySelectorAll("#pm-componentes > .row")].map((fila) => ({
                producto_id: fila.querySelector("[data-comp-id]").value,
                cantidad: Number(fila.querySelector("[data-comp-cant]").value || 1),
              })).filter((c) => c.producto_id)
            : undefined,
          promo_activa: el.querySelector("#pm-promo-activa").checked,
          promo_precio: fd.get("promo_precio") || 0,
          promo_stock: fd.get("promo_stock") || 0,
          promo_fin: fd.get("promo_fin") || "",
          marca: fd.get("marca"),
          precio: parseMoney(fd.get("precio")),
          iva: Number(fd.get("iva")),
          unidad: fd.get("unidad"),
          stock_minimo: Number(fd.get("stock_minimo") || 0),
          activo: fd.get("activo") === "true",
          destacado: fd.get("destacado") === "true",
          descripcion_corta: fd.get("descripcion_corta"),
          descripcion: fd.get("descripcion"),
          imagen: fd.get("imagen"),
          especificaciones,
        };
        if (!isEdit) {
          bodyData.stock_inicial = Number(fd.get("stock_inicial") || 0);
          bodyData.coste = fd.get("coste") === "" ? undefined : parseMoney(fd.get("coste"));
        }
        setBusy(btn, true, "Guardando…");
        try {
          if (isEdit) {
            await api(`/api/admin/productos/${product.id}`, { method: "PUT", body: bodyData });
            toast("Producto actualizado");
          } else {
            await api("/api/admin/productos", { method: "POST", body: bodyData });
            toast("Producto creado");
          }
          closeFn();
          route();
        } catch (err) {
          setBusy(btn, false);
          toast(err.message || "Error al guardar", "error");
          if (err.campo) {
            const f = form.querySelector(`[name="${err.campo}"]`);
            f?.classList.add("field-error"); f?.focus();
          }
        }
      });
    },
  });
}

/* ------------------------------ Kardex modal ----------------------------- */
async function openKardexModal(productId) {
  const close = openModal({ title: "Kardex del producto", subtitle: "Cargando…", body: loadingBlock("Cargando Kardex…"), wide: true, xl: true });
  try {
    const d = await api(`/api/admin/productos/${productId}/kardex?limite=2000`);
    const p = d.producto;
    const r = d.resumen;
    const v = d.verificacion;
    const movs = d.movimientos || [];
    const body = `
    <div class="row-between" style="margin-bottom:14px;flex-wrap:wrap">
      <div>
        <strong style="font-size:16px">${esc(p.nombre)}</strong>
        <p class="tiny muted">${esc(p.sku)} · ${esc(p.categoria_nombre || "Sin categoría")} · ${esc(p.unidad)}</p>
      </div>
      <div class="row">
        ${v.correcto ? `<span class="badge badge--ok">Cuadra con la ficha</span>` : `<span class="badge badge--danger">Inconsistencia</span>`}
        <button class="btn btn-primary btn-sm" id="kdx-ajuste">${icon("ruler", 14)} Ajustar stock</button>
      </div>
    </div>
    <div class="kpi-grid kpi-grid--6" style="margin-bottom:14px">
      <div class="admin-kpi"><div class="kpi-label">Stock</div><div class="kpi-value">${number(r.stock)} ${esc(r.unidad)}</div></div>
      <div class="admin-kpi"><div class="kpi-label">Coste medio</div><div class="kpi-value">${money(r.coste_medio)}</div></div>
      <div class="admin-kpi"><div class="kpi-label">Valor stock</div><div class="kpi-value">${money(r.valor_stock)}</div></div>
      <div class="admin-kpi"><div class="kpi-label">Entradas</div><div class="kpi-value">${number(r.entradas_unidades)}</div><div class="kpi-sub">${money(r.entradas_importe)}</div></div>
      <div class="admin-kpi"><div class="kpi-label">Salidas</div><div class="kpi-value">${number(r.salidas_unidades)}</div><div class="kpi-sub">${money(r.salidas_importe)}</div></div>
      <div class="admin-kpi"><div class="kpi-label">Movimientos</div><div class="kpi-value">${number(r.movimientos)}</div></div>
    </div>
    ${!v.correcto ? `<div class="notice notice--danger" style="margin-bottom:12px">${icon("alert", 16)}<span>${esc(v.diferencias.join(" · "))}</span></div>` : ""}
    <div class="table-wrap" style="max-height:420px;overflow:auto">
      <table class="table admin-kardex-table">
        <thead><tr><th>Fecha</th><th>Documento</th><th>Tipo</th><th class="num">Cantidad</th><th class="num">Coste u.</th><th class="num">Total</th><th class="num">Saldo uds</th><th class="num">Coste medio</th><th class="num">Saldo valor</th><th>Motivo</th></tr></thead>
        <tbody>
          ${movs.map((m) => `<tr>
            <td class="tiny">${fmtDateTime(m.fecha)}</td>
            <td class="tiny">${esc(m.documento_numero || m.documento_tipo || "—")}</td>
            <td>${esc(m.tipo_label || m.tipo)}</td>
            <td class="num ${m.cantidad > 0 ? "in" : "out"}">${m.cantidad > 0 ? "+" : "−"}${number(Math.abs(m.cantidad))}</td>
            <td class="num">${money(m.coste_unit)}</td>
            <td class="num">${money(Math.abs(m.coste_total))}</td>
            <td class="num">${number(m.saldo_cantidad)}</td>
            <td class="num">${money(m.saldo_coste_medio)}</td>
            <td class="num">${money(m.saldo_valor)}</td>
            <td class="tiny muted">${esc(m.motivo || "")}</td>
          </tr>`).join("")}
        </tbody>
      </table>
    </div>
    <p class="tiny muted mt-2">Libro: ${number(v.libro_unidades)} uds · ${money(v.libro_valor)} · Ficha: ${number(v.ficha_unidades)} uds · ${money(v.ficha_valor)}</p>`;
    // reopen modal with content
    close();
    const close2 = openModal({ title: "Kardex del producto", subtitle: `${p.nombre} · ${p.sku}`, body, wide: true, xl: true,
      onMount: (el) => {
        el.querySelector("#kdx-ajuste")?.addEventListener("click", () => { close2(); openAjusteModal(productId); });
      },
    });
  } catch (err) {
    close();
    toast(err.message || "Error al cargar el Kardex", "error");
  }
}

async function openAjusteModal(productId) {
  const p = PRODUCTOS_CACHE.get(productId);
  const nombre = p?.nombre || productId;
  const body = `
  <form id="ajuste-form" class="admin-form-grid" novalidate>
    <div class="field full"><label>Motivo del ajuste *</label>
      <textarea class="textarea" name="motivo" rows="2" placeholder="Inventario físico, rotura, merma, corrección…" required></textarea></div>
    <div class="field full">
      <label>Tipo de ajuste</label>
      <div class="row" style="gap:14px">
        <label class="check"><input type="radio" name="modo" value="recuento" checked> Recuento físico (nuevo stock)</label>
        <label class="check"><input type="radio" name="modo" value="delta"> Ajuste por diferencia (+/-)</label>
      </div>
    </div>
    <div class="field" id="campo-nuevo"><label>Nuevo stock contado</label><input class="input" name="nuevo_stock" type="number" step="0.01" min="0" value="${esc(p?.stock ?? 0)}"></div>
    <div class="field" id="campo-delta" style="display:none"><label>Cantidad a ajustar (+/-)</label><input class="input" name="cantidad" type="number" step="0.01" value="0"></div>
    <div class="field" id="campo-coste"><label>Coste unitario (solo si es entrada)</label><input class="input" name="coste" type="number" step="0.01" min="0" value="${esc(p?.coste_medio ?? "")}"></div>
  </form>`;
  const close = openModal({
    title: "Ajuste de stock", subtitle: nombre,
    body,
    footer: `<button class="btn btn-outline btn-sm" data-cancel>Cancelar</button>
             <button class="btn btn-primary btn-sm" id="ajuste-btn">Aplicar ajuste</button>`,
    onMount: (el, closeFn) => {
      const radios = el.querySelectorAll("input[name='modo']");
      const nuevo = el.querySelector("#campo-nuevo");
      const delta = el.querySelector("#campo-delta");
      radios.forEach((r) => r.addEventListener("change", () => {
        const recuento = el.querySelector("input[name='modo']:checked").value === "recuento";
        nuevo.style.display = recuento ? "" : "none";
        delta.style.display = recuento ? "none" : "";
      }));
      el.querySelector("[data-cancel]").addEventListener("click", closeFn);
      el.querySelector("#ajuste-btn").addEventListener("click", async () => {
        const btn = el.querySelector("#ajuste-btn");
        const form = el.querySelector("#ajuste-form");
        const data = formObject(form);
        const bodyData = { motivo: data.motivo };
        if (data.modo === "recuento") bodyData.nuevo_stock = Number(data.nuevo_stock);
        else bodyData.cantidad = Number(data.cantidad);
        if (data.coste !== "") bodyData.coste = parseMoney(data.coste);
        setBusy(btn, true, "Aplicando…");
        try {
          const res = await api(`/api/admin/productos/${productId}/ajuste`, { method: "POST", body: bodyData });
          toast(`Ajuste aplicado · ${res.numero}`);
          closeFn();
          route();
        } catch (err) {
          setBusy(btn, false);
          toast(err.message || "Error", "error");
        }
      });
    },
  });
}

/* ------------------------------ Categorías ------------------------------- */
async function categoriesPage() {
  render(loadingBlock("Cargando categorías…"), "Categorías");
  const data = await api("/api/admin/categorias");
  CATEGORIAS = data.items || [];
  const principales = CATEGORIAS.filter((c) => !c.padre_id);
  const hijos = (id) => CATEGORIAS.filter((c) => c.padre_id === id);
  const fila = (c, sub = false) => `<tr class="${sub ? "is-sub" : ""}">
    <td>${sub ? `<span class="muted" style="margin-left:18px">↳</span> ` : `<span class="cat-icon-sm">${categoryIcon(c.icono, 18)}</span> `}<strong>${esc(c.nombre)}</strong>${sub ? "" : `<br><span class="tiny muted">${esc(c.descripcion || "")}</span>`}</td>
    <td class="tiny muted">${esc(c.slug)}</td>
    <td class="num">${number(c.productos)}</td>
    <td class="num">${number(c.orden)}</td>
    <td>${c.activo ? '<span class="badge badge--ok">Sí</span>' : '<span class="badge">No</span>'}</td>
    <td class="actions">
      ${sub ? "" : `<button class="btn btn-xs btn-outline" data-add-sub="${esc(c.id)}" title="Añadir subcategoría">${icon("plus", 13)} Subcategoría</button>`}
      <button class="btn btn-xs btn-outline" data-edit-cat="${esc(c.id)}">${icon("edit", 13)}</button>
      <button class="btn btn-xs btn-danger" data-del-cat="${esc(c.id)}">${icon("trash", 13)}</button>
    </td>
  </tr>`;
  const content = `
  ${pageHead("Categorías", `${principales.length} categorías y ${CATEGORIAS.length - principales.length} subcategorías.`, `
    <button class="btn btn-primary btn-sm" id="new-cat-btn">${icon("plus", 15)} Nueva categoría</button>
  `)}
  <div class="admin-card" style="padding:0">
    <table class="table admin-table">
      <thead><tr><th>Nombre</th><th>Slug</th><th class="num">Productos</th><th class="num">Orden</th><th>Activa</th><th class="actions">Acciones</th></tr></thead>
      <tbody>
        ${principales.map((c) => fila(c) + hijos(c.id).map((h) => fila(h, true)).join("")).join("")}
        ${principales.length ? "" : `<tr><td colspan="6" class="admin-empty">Todavía no hay categorías. Crea la primera.</td></tr>`}
      </tbody>
    </table>
  </div>`;
  render(content, "Categorías");
  $("#new-cat-btn")?.addEventListener("click", () => openCategoryModal());
  $$("[data-add-sub]").forEach((b) => b.addEventListener("click", () => openCategoryModal(null, b.dataset.addSub)));
  $$("[data-edit-cat]").forEach((b) => b.addEventListener("click", () => {
    const c = (CATEGORIAS.find((x) => x.id === b.dataset.editCat));
    openCategoryModal(c);
  }));
  $$("[data-del-cat]").forEach((b) => b.addEventListener("click", async () => {
    const ok = await confirmDialog({ title: "Borrar categoría", message: "Solo se puede borrar si no tiene productos ni subcategorías. ¿Continuar?", danger: true, confirmText: "Borrar" });
    if (!ok) return;
    try {
      await api(`/api/admin/categorias/${b.dataset.delCat}`, { method: "DELETE" });
      toast("Categoría borrada"); route();
    } catch (err) { toast(err.message, "error"); }
  }));
}

// ---------------------------- Selector de iconos de categoría ----------------------------

function iconPickerHTML(valor) {
  const actual = iconoCategoria(valor);
  return `<div class="icon-picker" id="icon-picker">
    <input type="hidden" name="icono" id="ip-val" value="${esc(actual.id)}">
    <div class="icon-preview">
      <span class="icon-preview-svg" id="ip-preview">${categoryIcon(actual.id, 40)}</span>
      <div><strong id="ip-nombre">${esc(actual.nombre)}</strong><div class="tiny muted" id="ip-id">${esc(actual.id)}</div></div>
    </div>
    <input class="input" type="search" id="ip-q" placeholder="Buscar: limpieza, pestañas, caja, papel…" autocomplete="off" style="margin-top:10px">
    <div class="icon-grid" id="ip-grid" role="listbox" aria-label="Iconos de categoría"></div>
    <p class="tiny muted" id="ip-count" style="margin-top:6px"></p>
  </div>`;
}

function bindIconPicker(el) {
  const root = el.querySelector("#icon-picker");
  if (!root) return;
  const norm = (t) => String(t).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
  const pintarGrid = () => {
    const q = norm(root.querySelector("#ip-q").value.trim());
    const val = root.querySelector("#ip-val").value;
    const lista = ICONOS_CATEGORIA.filter((i) => !q || norm(`${i.nombre} ${i.palabras} ${i.id}`).includes(q));
    root.querySelector("#ip-grid").innerHTML = lista.map((i) => `<button type="button" class="icon-opt ${i.id === val ? "is-selected" : ""}" role="option" aria-selected="${i.id === val}" data-icon="${esc(i.id)}" title="${esc(i.nombre)}">${categoryIcon(i.id, 22)}</button>`).join("")
      || `<p class="tiny muted">Ningún icono coincide. Prueba con otra palabra.</p>`;
    root.querySelector("#ip-count").textContent = `${lista.length} de ${ICONOS_CATEGORIA.length} iconos`;
    root.querySelectorAll("[data-icon]").forEach((b) => b.addEventListener("click", () => {
      const i = iconoCategoria(b.dataset.icon);
      root.querySelector("#ip-val").value = i.id;
      root.querySelector("#ip-preview").innerHTML = categoryIcon(i.id, 40);
      root.querySelector("#ip-nombre").textContent = i.nombre;
      root.querySelector("#ip-id").textContent = i.id;
      root.querySelectorAll(".icon-opt").forEach((o) => { const sel = o.dataset.icon === i.id; o.classList.toggle("is-selected", sel); o.setAttribute("aria-selected", String(sel)); });
    }));
  };
  root.querySelector("#ip-q").addEventListener("input", pintarGrid);
  pintarGrid();
}

async function openCategoryModal(cat = null, padreId = null) {
  const isEdit = !!cat;
  const padre = isEdit ? (cat.padre_id ? CATEGORIAS.find((c) => c.id === cat.padre_id) : null) : (padreId ? CATEGORIAS.find((c) => c.id === padreId) : null);
  const esSub = isEdit ? !!cat.padre_id : !!padreId;
  const body = `
  <form id="cat-form" class="admin-form-grid">
    ${esSub ? `<div class="field full"><label>Categoría principal</label><input class="input" value="${esc(padre?.nombre || "")}" disabled></div>` : ""}
    <div class="field full"><label>Nombre *</label><input class="input" name="nombre" value="${esc(cat?.nombre || "")}" required></div>
    ${esSub ? "" : `<div class="field full"><label>Descripción</label><textarea class="textarea" name="descripcion" rows="2">${esc(cat?.descripcion || "")}</textarea></div>
    <div class="field full"><label>Icono</label>${iconPickerHTML(cat?.icono || "box")}</div>`}
    <div class="field"><label>Orden</label><input class="input" name="orden" type="number" value="${esc(cat?.orden ?? 0)}"></div>
    <div class="field"><label>Activa</label>
      <select class="select" name="activo">
        <option value="true" ${cat?.activo !== 0 ? "selected" : ""}>Sí</option>
        <option value="false" ${cat?.activo === 0 ? "selected" : ""}>No</option>
      </select></div>
  </form>`;
  const titulo = isEdit ? (esSub ? "Editar subcategoría" : "Editar categoría") : (esSub ? "Nueva subcategoría" : "Nueva categoría");
  const close = openModal({
    title: titulo,
    body,
    footer: `<button class="btn btn-outline btn-sm" data-cancel>Cancelar</button><button class="btn btn-primary btn-sm" id="save-cat-btn">Guardar</button>`,
    onMount: (el, closeFn) => {
      el.querySelector("[data-cancel]").addEventListener("click", closeFn);
      bindIconPicker(el);
      el.querySelector("#save-cat-btn").addEventListener("click", async () => {
        const btn = el.querySelector("#save-cat-btn");
        const data = formObject(el.querySelector("#cat-form"));
        data.activo = data.activo === "true";
        data.orden = Number(data.orden || 0);
        if (!isEdit && padreId) data.padre_id = padreId;
        setBusy(btn, true, "Guardando…");
        try {
          if (isEdit) await api(`/api/admin/categorias/${cat.id}`, { method: "PUT", body: data });
          else await api("/api/admin/categorias", { method: "POST", body: data });
          toast(isEdit ? "Guardado" : (esSub ? "Subcategoría creada" : "Categoría creada"));
          closeFn(); route();
        } catch (err) { setBusy(btn, false); toast(err.message, "error"); }
      });
    },
  });
}

/* ------------------------------ Inventario ------------------------------- */
async function inventoryPage() {
  render(loadingBlock("Cargando inventario…"), "Inventario");
  const d = await api("/api/admin/inventario");
  const inv = d.resumen;
  const content = `
  ${pageHead("Inventario", "Fotografía actual del stock y movimientos recientes.")}
  <div class="kpi-grid" style="margin-bottom:14px">
    <div class="admin-kpi"><div class="kpi-label">Referencias activas</div><div class="kpi-value">${number(inv.referencias)}</div></div>
    <div class="admin-kpi"><div class="kpi-label">Unidades</div><div class="kpi-value">${number(inv.unidades)}</div></div>
    <div class="admin-kpi"><div class="kpi-label">Valor a coste</div><div class="kpi-value">${money(inv.valor)}</div></div>
    <div class="admin-kpi"><div class="kpi-label">Valor a venta</div><div class="kpi-value">${money(inv.valor_venta)}</div><div class="kpi-sub">Margen potencial ${money(inv.margen_potencial)}</div></div>
    <div class="admin-kpi"><div class="kpi-label">Bajo mínimo</div><div class="kpi-value">${number(inv.bajo)}</div></div>
    <div class="admin-kpi"><div class="kpi-label">Agotados</div><div class="kpi-value">${number(inv.agotados)}</div></div>
  </div>
  <div class="grid-2" style="gap:14px">
    <div class="admin-card">
      <div class="admin-card-head"><h3>Bajo mínimo</h3></div>
      ${d.bajo_stock.length ? `<table class="table admin-table"><thead><tr><th>Producto</th><th class="num">Stock</th><th class="num">Mín.</th><th></th></tr></thead><tbody>
        ${d.bajo_stock.map((p) => `<tr>
          <td><strong>${esc(p.nombre)}</strong><br><span class="tiny muted">${esc(p.sku)}</span></td>
          <td class="num ${Number(p.stock) <= 0 ? "out" : ""}">${number(p.stock)} ${esc(p.unidad)}</td>
          <td class="num">${number(p.stock_minimo)}</td>
          <td class="actions"><button class="btn btn-xs btn-outline" data-ajuste="${esc(p.id)}">${icon("ruler", 13)}</button></td>
        </tr>`).join("")}
      </tbody></table>` : `<div class="admin-empty">${icon("checkCircle", 24)} Todo por encima del mínimo</div>`}
    </div>
    <div class="admin-card">
      <div class="admin-card-head"><h3>Últimos movimientos</h3><a class="btn btn-ghost btn-xs" href="#/movimientos">Ver todos</a></div>
      ${d.ultimos.length ? `<table class="table admin-table"><thead><tr><th>Fecha</th><th>Producto</th><th>Mov.</th><th class="num">Saldo</th></tr></thead><tbody>
        ${d.ultimos.map((m) => `<tr>
          <td class="tiny muted">${fmtDateTime(m.fecha)}</td>
          <td>${esc(m.producto_nombre)}</td>
          <td class="${m.cantidad > 0 ? "in" : "out"}">${m.cantidad > 0 ? "+" : "−"}${number(Math.abs(m.cantidad))}</td>
          <td class="num">${number(m.saldo_cantidad)}</td>
        </tr>`).join("")}
      </tbody></table>` : `<div class="admin-empty">${icon("layers", 24)} Sin movimientos</div>`}
    </div>
  </div>`;
  render(content, "Inventario");
  $$("[data-ajuste]").forEach((b) => b.addEventListener("click", () => openAjusteModal(b.dataset.ajuste)));
}

/* ------------------------------ Movimientos ------------------------------ */
async function movementsPage(params) {
  const producto_id = params.get("producto_id") || "";
  const tipo = params.get("tipo") || "";
  const desde = params.get("desde") || "";
  const hasta = params.get("hasta") || "";
  const pagina = Math.max(1, parseInt(params.get("pagina") || "1", 10) || 1);

  render(loadingBlock("Cargando movimientos…"), "Movimientos");
  const [data, productos] = await Promise.all([
    api("/api/admin/movimientos", { query: { producto_id, tipo, desde, hasta, pagina, por_pagina: 50 } }),
    api("/api/admin/productos?por_pagina=200"),
  ]);
  const prods = productos.items || [];
  const content = `
  ${pageHead("Movimientos del Kardex", `${data.total} movimientos registrados. Libro inmutable: las correcciones son movimientos contrarios.`)}
  <div class="admin-toolbar">
    <select class="select" id="mv-producto" style="min-width:220px">
      <option value="">Todos los productos</option>
      ${prods.map((p) => `<option value="${esc(p.id)}" ${producto_id === p.id ? "selected" : ""}>${esc(p.sku)} · ${esc(p.nombre)}</option>`).join("")}
    </select>
    <select class="select" id="mv-tipo">
      <option value="">Todos los tipos</option>
      ${["entrada_compra","entrada_devolucion","entrada_ajuste","salida_venta","salida_ajuste","salida_compra_anulada"].map((t) => `<option value="${t}" ${tipo === t ? "selected" : ""}>${esc(t.replace(/_/g," "))}</option>`).join("")}
    </select>
    <input class="input" type="date" id="mv-desde" value="${esc(desde)}" style="min-width:140px;min-height:38px">
    <input class="input" type="date" id="mv-hasta" value="${esc(hasta)}" style="min-width:140px;min-height:38px">
    <button class="btn btn-outline btn-sm" id="mv-export">${icon("download", 14)} Exportar CSV</button>
  </div>
  ${data.items.length ? `<div class="admin-card" style="padding:0"><div class="table-wrap"><table class="table admin-table">
    <thead><tr><th>Fecha</th><th>Producto</th><th>Tipo</th><th class="num">Cantidad</th><th class="num">Coste u.</th><th class="num">Total</th><th class="num">Saldo</th><th>Motivo</th></tr></thead>
    <tbody>
      ${data.items.map((m) => `<tr>
        <td class="tiny">${fmtDateTime(m.fecha)}</td>
        <td>${esc(m.producto_nombre)}<br><span class="tiny muted">${esc(m.producto_sku)}</span></td>
        <td><span class="badge ${m.cantidad > 0 ? "badge--ok" : "badge--danger"} badge--plain">${esc(m.tipo_label)}</span></td>
        <td class="num ${m.cantidad > 0 ? "in" : "out"}">${m.cantidad > 0 ? "+" : "−"}${number(Math.abs(m.cantidad))}</td>
        <td class="num">${money(m.coste_unit)}</td>
        <td class="num">${money(Math.abs(m.coste_total))}</td>
        <td class="num">${number(m.saldo_cantidad)}</td>
        <td class="tiny muted">${esc(m.motivo || "")}</td>
      </tr>`).join("")}
    </tbody></table></div>
    ${paginationHTML(data.pagina || pagina, Math.ceil(data.total / 50), (pg) => `#/movimientos?${new URLSearchParams({ producto_id, tipo, desde, hasta, pagina: pg }).toString()}`)}
  </div>` : emptyState({ iconName: "layers", title: "Sin movimientos", text: "No hay movimientos con esos filtros." })}`;
  render(content, "Movimientos");
  const update = () => {
    const params = new URLSearchParams();
    const pv = $("#mv-producto").value; const tv = $("#mv-tipo").value; const dv = $("#mv-desde").value; const hv = $("#mv-hasta").value;
    if (pv) params.set("producto_id", pv); if (tv) params.set("tipo", tv); if (dv) params.set("desde", dv); if (hv) params.set("hasta", hv);
    location.hash = `#/movimientos${params.toString() ? "?" + params.toString() : ""}`;
  };
  $("#mv-producto")?.addEventListener("change", update);
  $("#mv-tipo")?.addEventListener("change", update);
  $("#mv-desde")?.addEventListener("change", update);
  $("#mv-hasta")?.addEventListener("change", update);
  $("#mv-export")?.addEventListener("click", () => {
    const rows = [["Fecha","Producto","SKU","Tipo","Cantidad","Coste unit","Total","Saldo","Motivo"]];
    data.items.forEach((m) => rows.push([m.fecha, m.producto_nombre, m.producto_sku, m.tipo_label, m.cantidad, m.coste_unit, m.coste_total, m.saldo_cantidad, m.motivo]));
    downloadCSV(`movimientos-${new Date().toISOString().slice(0,10)}.csv`, rows);
  });
}

/* ------------------------------ Pedidos ---------------------------------- */
async function ordersPage(params) {
  const estado = params.get("estado") || "";
  const q = params.get("q") || "";
  const desde = params.get("desde") || "";
  const hasta = params.get("hasta") || "";
  const pagina = Math.max(1, parseInt(params.get("pagina") || "1", 10) || 1);

  render(loadingBlock("Cargando pedidos…"), "Pedidos");
  const data = await api("/api/admin/pedidos", { query: { estado, q, desde, hasta, pagina, por_pagina: 20 } });
  const conteos = data.conteos || {};
  const content = `
  ${pageHead("Pedidos", `${data.resumen.pedidos} pedidos · ${money(data.resumen.ventas)} en ventas confirmadas.`, "")}
  <div class="chip-row" style="margin-bottom:12px">
    ${["", "por_preparar", "pendiente", "pagado", "preparando", "preparado", "enviado", "entregado", "cancelado"].map((e) => {
      const label = e === "por_preparar" ? "Por preparar" : e ? ESTADOS_PEDIDO[e] : "Todos";
      const n = e === "por_preparar" ? ["pendiente", "pagado", "preparando"].reduce((t, k) => t + (conteos[k] || 0), 0) : e ? (conteos[e] || 0) : data.total;
      return `<a class="status-chip ${estado === e ? "is-active" : ""}" href="#/pedidos?${new URLSearchParams({ ...(e ? { estado: e } : {}), q, desde, hasta }).toString()}">${esc(label)} <span class="n">${number(n)}</span></a>`;
    }).join("")}
  </div>
  <div class="admin-toolbar">
    <div class="search-box"><input class="input" id="ord-search" type="search" placeholder="Nº, cliente, email o empresa…" value="${esc(q)}"></div>
    <input class="input" type="date" id="ord-desde" value="${esc(desde)}" style="min-width:140px;min-height:38px">
    <input class="input" type="date" id="ord-hasta" value="${esc(hasta)}" style="min-width:140px;min-height:38px">
  </div>
  ${data.items.length ? `<div class="admin-card" style="padding:0"><div class="table-wrap"><table class="table admin-table">
    <thead><tr><th>Nº</th><th>Fecha</th><th>Cliente</th><th>Método</th><th>Estado</th><th class="num">Total</th><th class="num">Uds</th><th></th></tr></thead>
    <tbody>
      ${data.items.map((p) => `<tr>
        <td><strong>${esc(p.numero)}</strong></td>
        <td class="tiny muted">${fmtDate(p.created_at)}</td>
        <td>${esc(p.cliente_nombre)}<br><span class="tiny muted">${esc(p.cliente_email)}</span></td>
        <td class="tiny">${esc(p.metodo_pago_label)}</td>
        <td>${estadoBadge(p.estado, p.estado_label)}</td>
        <td class="num money">${money(p.total)}</td>
        <td class="num">${number(p.unidades)}</td>
        <td class="actions"><a class="btn btn-xs btn-outline" href="#/pedidos/${esc(p.id)}">${icon("eye", 13)}</a></td>
      </tr>`).join("")}
    </tbody></table></div>
    ${paginationHTML(data.pagina, data.paginas, (pg) => `#/pedidos?${new URLSearchParams({ estado, q, desde, hasta, pagina: pg }).toString()}`)}
  </div>` : emptyState({ iconName: "truck", title: "Sin pedidos", text: "No hay pedidos con esos filtros." })}`;
  render(content, "Pedidos");
  const update = () => {
    const params = new URLSearchParams();
    const qv = $("#ord-search").value.trim();
    const dv = $("#ord-desde").value; const hv = $("#ord-hasta").value;
    if (estado) params.set("estado", estado); if (qv) params.set("q", qv); if (dv) params.set("desde", dv); if (hv) params.set("hasta", hv);
    location.hash = `#/pedidos${params.toString() ? "?" + params.toString() : ""}`;
  };
  $("#ord-search")?.addEventListener("input", debounce(update));
  $("#ord-desde")?.addEventListener("change", update);
  $("#ord-hasta")?.addEventListener("change", update);
}

function debounce(fn, ms = 350) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }

// ------------------------------ Hoja de ruta (domiciliario) ------------------------------

function direccionCompleta(p) {
  return `${p.direccion}, ${p.cp || ""} ${p.ciudad || ""}`.replace(/\s+,/g, ",").trim();
}

function enlaceNavegar(direccion) {
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(direccion)}`;
}

function textoCobro(importe, envioPagado) {
  if (importe > 0) return `<span class="badge badge--warn">Cobrar ${money(importe)}</span>`;
  return `<span class="badge badge--ok">Sin cobro${envioPagado ? " · envío pagado" : ""}</span>`;
}

async function rutaPage() {
  render(loadingBlock("Cargando hoja de ruta…"), "Hoja de ruta");
  const d = await api("/api/admin/ruta");
  const items = d.items || [];
  const direcciones = items.map(direccionCompleta);
  const ruta = direcciones.length
    ? `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(direcciones[direcciones.length - 1])}`
      + (direcciones.length > 1 ? `&waypoints=${encodeURIComponent(direcciones.slice(0, -1).slice(0, 8).join("|"))}` : "")
      + "&travelmode=driving"
    : "";
  const content = `
    ${pageHead("Hoja de ruta", `${items.length} ${items.length === 1 ? "entrega" : "entregas"} listas para salir`, ruta ? `<a class="btn btn-primary btn-sm" href="${esc(ruta)}" target="_blank" rel="noopener">${icon("external", 14)} Abrir ruta completa</a>` : "")}
    ${items.length ? `<div class="grid-2" style="gap:14px">${items.map((i) => `
      <article class="admin-card">
        <div class="admin-card-head"><h3>${esc(i.numero)}</h3>${estadoBadge(i.estado, i.estado_label)}</div>
        <p><strong>${esc(i.cliente_nombre)}</strong></p>
        <p class="small">${esc(direccionCompleta(i))}</p>
        ${i.cliente_telefono ? `<p class="small"><a href="tel:${esc(i.cliente_telefono)}">${icon("phone", 13)} ${esc(i.cliente_telefono)}</a></p>` : ""}
        <p style="margin:8px 0">${textoCobro(i.importe_cobrar, i.envio_ya_pagado)}</p>
        <div class="row" style="gap:8px;flex-wrap:wrap">
          <a class="btn btn-outline btn-sm" href="${esc(enlaceNavegar(direccionCompleta(i)))}" target="_blank" rel="noopener">${icon("external", 14)} Navegar</a>
          <a class="btn btn-primary btn-sm" href="#/ruta/${encodeURIComponent(i.id)}">Ver entrega</a>
        </div>
      </article>`).join("")}</div>` : emptyState({ iconName: "truck", title: "Nada que repartir", text: "Aquí aparecerán los pedidos preparados con el pago listo." })}`;
  render(content, "Hoja de ruta");
}

async function rutaDetallePage(id) {
  render(loadingBlock("Cargando entrega…"), "Entrega");
  const d = await api(`/api/admin/pedidos/${id}`);
  const p = d.pedido;
  const cobro = p.a_cobrar || 0;
  const envioPagado = p.envio_cobro === "anticipado" && p.envio_pagado;
  const direccion = direccionCompleta(p);
  const content = `
    ${pageHead(p.numero, p.estado_label, `<a class="btn btn-outline btn-sm" href="#/ruta">${icon("arrowLeft", 14)} Volver</a>`)}
    <div class="grid-2" style="gap:14px;align-items:start">
      <div class="admin-card">
        <div class="admin-card-head"><h3>Cliente y entrega</h3></div>
        <p><strong>${esc(p.cliente_nombre)}</strong></p>
        <p class="small">${esc(direccion)}</p>
        ${p.cliente_telefono ? `<p class="small"><a class="btn btn-outline btn-sm" href="tel:${esc(p.cliente_telefono)}">${icon("phone", 13)} Llamar ${esc(p.cliente_telefono)}</a></p>` : ""}
        ${p.notas ? `<p class="small"><strong>Notas:</strong> ${esc(p.notas)}</p>` : ""}
        <p style="margin-top:12px"><a class="btn btn-primary btn-sm" href="${esc(enlaceNavegar(direccion))}" target="_blank" rel="noopener">${icon("external", 14)} Navegar</a></p>
      </div>
      <div class="admin-card">
        <div class="admin-card-head"><h3>Cobro</h3></div>
        ${cobro > 0
          ? `<p class="kpi-value" style="font-size:28px">${money(cobro)}</p><p class="small muted">Cobrar al entregar (${esc(p.metodo_pago_label)}${p.envio_cobro === "entrega" && !p.envio_cobrado ? ", incluye envío" : ""}).</p>`
          : `<p class="small">No hay nada que cobrar${envioPagado ? ". El envío ya está pagado." : "."}</p>`}
        <div class="stack" style="margin-top:14px">
          ${p.estado === "preparado" ? `<button class="btn btn-primary btn-block" id="btn-salir">${icon("truck", 15)} Salir a reparto</button>` : ""}
          ${p.estado === "enviado" && cobro > 0 ? `<button class="btn btn-primary btn-block" id="btn-cobrar">${icon("check", 15)} Entregado y cobrado · ${money(cobro)}</button>` : ""}
          ${p.estado === "enviado" && !(cobro > 0) ? `<button class="btn btn-primary btn-block" id="btn-entregar">${icon("check", 15)} Marcar entregado</button>` : ""}
        </div>
      </div>
    </div>
    <div class="admin-card" style="margin-top:14px">
      <div class="admin-card-head"><h3>Productos</h3></div>
      <table class="table admin-table"><tbody>${p.lineas.map((l) => `<tr><td><strong>${esc(l.nombre)}</strong><br><span class="tiny muted">${esc(l.sku)}</span></td><td class="num">${number(l.cantidad)}</td></tr>`).join("")}</tbody></table>
    </div>`;
  render(content, "Entrega");
  const accion = async (boton, url, mensaje) => {
    setBusy(boton, true, "Guardando…");
    try { await api(url, { method: "POST", body: url.endsWith("/estado") ? { estado: boton.dataset.estado } : undefined }); toast(mensaje); rutaDetallePage(id); }
    catch (err) { setBusy(boton, false); toast(err.message, "error"); }
  };
  $("#btn-salir")?.addEventListener("click", (e) => { e.currentTarget.dataset.estado = "enviado"; accion(e.currentTarget, `/api/admin/pedidos/${id}/estado`, "Pedido en reparto"); });
  $("#btn-cobrar")?.addEventListener("click", (e) => accion(e.currentTarget, `/api/admin/pedidos/${id}/confirmar-cobro`, "Entrega y cobro registrados"));
  $("#btn-entregar")?.addEventListener("click", (e) => { e.currentTarget.dataset.estado = "entregado"; accion(e.currentTarget, `/api/admin/pedidos/${id}/estado`, "Entrega registrada"); });
}

// ------------------------------ Equipo ------------------------------

const ROLES_EQUIPO_OPCIONES = [["admin", "Administrador"], ["preparador", "Preparación"], ["domiciliario", "Domiciliario"]];

async function equipoPage() {
  render(loadingBlock("Cargando equipo…"), "Equipo");
  const d = await api("/api/admin/equipo");
  const opciones = (rol) => ROLES_EQUIPO_OPCIONES.map(([v, t]) => `<option value="${v}" ${rol === v ? "selected" : ""}>${t}</option>`).join("");
  const content = `
    ${pageHead("Equipo", `Administradores: ${d.admins_activos} de ${d.max_admins}. Preparación y domiciliarios no tienen límite.`)}
    <div class="admin-card">
      <div class="admin-card-head"><h3>Miembros</h3></div>
      <div class="table-wrap"><table class="table admin-table">
        <thead><tr><th>Persona</th><th>Rol</th><th>Activo</th><th>Último acceso</th></tr></thead>
        <tbody>${d.items.map((u) => `<tr>
          <td><strong>${esc(u.nombre)}</strong><br><span class="tiny muted">${esc(u.email)}</span></td>
          <td><select class="select" data-rol="${esc(u.id)}" ${u.id === ME?.id ? "disabled" : ""}>${opciones(u.rol)}</select></td>
          <td><input type="checkbox" data-activo="${esc(u.id)}" ${u.activo ? "checked" : ""} ${u.id === ME?.id ? "disabled" : ""}></td>
          <td class="tiny muted">${u.ultimo_acceso ? fmtDateTime(u.ultimo_acceso) : "—"}</td>
        </tr>`).join("")}</tbody>
      </table></div>
    </div>
    <div class="admin-card" style="margin-top:14px">
      <div class="admin-card-head"><h3>Añadir miembro</h3></div>
      <form id="equipo-form" class="admin-form-grid" novalidate>
        <div class="field"><label>Nombre</label><input class="input" name="nombre" required></div>
        <div class="field"><label>Email</label><input class="input" type="email" name="email" required></div>
        <div class="field"><label>Rol</label><select class="select" name="rol">${opciones("preparador")}</select></div>
        <div class="field"><label>Contraseña inicial</label><input class="input" type="password" name="password" required placeholder="Mín. 8 caracteres, con letras y números"></div>
        <div class="field full"><button class="btn btn-primary btn-sm" type="submit" id="equipo-btn">${icon("plus", 14)} Añadir al equipo</button></div>
      </form>
    </div>`;
  render(content, "Equipo");
  $$("[data-rol]").forEach((sel) => sel.addEventListener("change", async () => {
    try { await api(`/api/admin/equipo/${sel.dataset.rol}`, { method: "PUT", body: { rol: sel.value } }); toast("Rol actualizado"); equipoPage(); }
    catch (err) { toast(err.message, "error"); equipoPage(); }
  }));
  $$("[data-activo]").forEach((chk) => chk.addEventListener("change", async () => {
    try { await api(`/api/admin/equipo/${chk.dataset.activo}`, { method: "PUT", body: { activo: chk.checked } }); toast(chk.checked ? "Miembro activado" : "Miembro desactivado"); equipoPage(); }
    catch (err) { toast(err.message, "error"); equipoPage(); }
  }));
  $("#equipo-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = $("#equipo-btn");
    setBusy(btn, true, "Añadiendo…");
    try { await api("/api/admin/equipo", { method: "POST", body: formObject(e.target) }); toast("Miembro añadido"); equipoPage(); }
    catch (err) { setBusy(btn, false); toast(err.message, "error"); }
  });
}

async function pagosPage() {
  render(loadingBlock("Cargando pagos…"), "Pagos");
  const d = await api("/api/admin/pagos");
  const fila = (p, acciones, importe = p.total) => `<tr>
    <td><a href="#/pedidos/${encodeURIComponent(p.id)}"><strong>${esc(p.numero)}</strong></a></td>
    <td>${esc(p.cliente_nombre)}<br><span class="tiny muted">${esc(p.cliente_email)}</span></td>
    <td class="num money">${importe}</td>
    <td>${esc(p.metodo_pago_label)}</td>
    <td class="tiny muted">${fmtDateTime(p.created_at)}${p.pago_cancela_at ? `<br><span class="${p.pago_vencido ? "badge badge--warn" : ""}">${p.pago_vencido ? "Vencido · " : ""}cancelación ${fmtDateTime(p.pago_cancela_at)}</span>` : ""}</td>
    <td>${acciones}</td>
  </tr>`;
  const verificar = (p) => PUEDE_VERIFICAR()
    ? `<button class="btn btn-primary btn-sm" data-verificar="${esc(p.id)}">${icon("check", 14)} Pago recibido</button>`
    : `<span class="tiny muted">Lo verifica el administrador</span>`;
  const cobrar = (p) => p.estado === "enviado"
    ? `<button class="btn btn-primary btn-sm" data-cobro="${esc(p.id)}">${icon("check", 14)} Entregado y cobrado</button>`
    : `<span class="tiny muted">Pendiente de envío</span>`;
  const verificarEnvio = (p) => PUEDE_VERIFICAR()
    ? `<button class="btn btn-primary btn-sm" data-verificar-envio-lista="${esc(p.id)}">${icon("check", 14)} Envío recibido</button>`
    : `<span class="tiny muted">Lo verifica el administrador</span>`;
  const content = `
    ${pageHead("Pagos", "Pedidos pendientes de verificar y cobros en la entrega.")}
    ${d.envios_por_verificar.length ? `<div class="admin-card" style="margin-bottom:14px">
      <div class="admin-card-head"><h3>Envíos pagados por adelantado</h3><span class="tiny muted">Pendiente de verificar</span></div>
      <div class="table-wrap"><table class="table admin-table"><thead><tr><th>Pedido</th><th>Cliente</th><th class="num">Envío</th><th>Transportista</th><th>Asignado</th><th></th></tr></thead>
        <tbody>${d.envios_por_verificar.map((p) => `<tr>
          <td><a href="#/pedidos/${encodeURIComponent(p.id)}"><strong>${esc(p.numero)}</strong></a></td>
          <td>${esc(p.cliente_nombre)}</td>
          <td class="num money">${money(p.envio)}</td>
          <td>${esc(p.transportista || "—")}</td>
          <td class="tiny muted">${fmtDateTime(p.updated_at)}</td>
          <td>${verificarEnvio(p)}</td>
        </tr>`).join("")}</tbody></table></div>
    </div>` : ""}
    <div class="admin-card">
      <div class="admin-card-head"><h3>Pagos por verificar</h3><span class="tiny muted">Transferencia y cartera digital</span></div>
      ${d.por_verificar.length ? `<div class="table-wrap"><table class="table admin-table"><thead><tr><th>Pedido</th><th>Cliente</th><th class="num">Total</th><th>Método</th><th>Recibido</th><th></th></tr></thead>
        <tbody>${d.por_verificar.map((p) => fila(p, verificar(p))).join("")}</tbody></table></div>`
        : emptyState({ iconName: "check", title: "Sin pagos pendientes", text: "Cuando llegue un pago por transferencia o cartera digital aparecerá aquí." })}
    </div>
    <div class="admin-card" style="margin-top:14px">
      <div class="admin-card-head"><h3>Cobros en la entrega</h3><span class="tiny muted">Contrareembolso y envíos que se pagan al recibir</span></div>
      ${d.contrareembolso.length ? `<div class="table-wrap"><table class="table admin-table"><thead><tr><th>Pedido</th><th>Cliente</th><th class="num">Total</th><th>Método</th><th>Recibido</th><th></th></tr></thead>
        <tbody>${d.contrareembolso.map((p) => fila(p, cobrar(p), p.envio_pendiente ? `${money(p.total)} <span class="tiny muted">+ envío pendiente</span>` : `${money(p.a_cobrar)}${p.envio_cobro === "entrega" && p.envio_cobrado === false && p.envio > 0 ? ` <span class="tiny muted">(incluye envío ${money(p.envio)})</span>` : ""}`)).join("")}</tbody></table></div>`
        : emptyState({ iconName: "truck", title: "Sin cobros pendientes", text: "Los pedidos a contrareembolso aparecen aquí hasta que el repartidor confirma la entrega." })}
    </div>`;
  render(content, "Pagos");
  $$("[data-verificar]").forEach((b) => b.addEventListener("click", async () => {
    setBusy(b, true, "Verificando…");
    try { await api(`/api/admin/pedidos/${b.dataset.verificar}/verificar-pago`, { method: "POST" }); toast("Pago verificado · pedido pagado"); await sondearNotificaciones(false); pagosPage(); }
    catch (err) { setBusy(b, false); toast(err.message, "error"); }
  }));
  $$("[data-verificar-envio-lista]").forEach((b) => b.addEventListener("click", async () => {
    setBusy(b, true, "Verificando…");
    try { await api(`/api/admin/pedidos/${b.dataset.verificarEnvioLista}/verificar-envio`, { method: "POST" }); toast("Pago del envío verificado"); await sondearNotificaciones(false); pagosPage(); }
    catch (err) { setBusy(b, false); toast(err.message, "error"); }
  }));
  $$("[data-cobro]").forEach((b) => b.addEventListener("click", async () => {
    setBusy(b, true, "Confirmando…");
    try { await api(`/api/admin/pedidos/${b.dataset.cobro}/confirmar-cobro`, { method: "POST" }); toast("Entrega y cobro confirmados"); await sondearNotificaciones(false); pagosPage(); }
    catch (err) { setBusy(b, false); toast(err.message, "error"); }
  }));
}

async function orderDetailPage(orderId) {
  render(loadingBlock("Cargando pedido…"), "Pedido");
  const d = await api(`/api/admin/pedidos/${orderId}`);
  const p = d.pedido;
  const transiciones = transicionesPara(p.estado);
  const content = `
  ${pageHead(p.numero, `${fmtDate(p.created_at)} · ${p.estado_label} · ${p.metodo_pago_label}`, `
    <a class="btn btn-outline btn-sm" href="#/pedidos">${icon("arrowLeft", 14)} Volver</a>
  `)}
  <div class="grid-2" style="gap:14px;align-items:start">
    <div class="admin-card">
      <div class="admin-card-head"><h3>Productos</h3></div>
      <table class="table admin-table"><thead><tr><th>Producto</th><th class="num">Cant.</th><th class="num">P. unit.</th><th class="num">Total</th><th class="num">Coste</th></tr></thead><tbody>
        ${p.lineas.map((l) => `<tr>
          <td><strong>${esc(l.nombre)}</strong><br><span class="tiny muted">${esc(l.sku)}</span></td>
          <td class="num">${number(l.cantidad)}</td>
          <td class="num">${money(l.precio_unit)}</td>
          <td class="num money">${money(l.total)}</td>
          <td class="num muted">${money(l.coste_unit)}</td>
        </tr>`).join("")}
      </tbody></table>
      <div class="row-between mt-2" style="font-size:13px"><span class="muted">Base imponible</span><strong>${money(p.base)}</strong></div>
      <div class="row-between" style="font-size:13px"><span class="muted">IVA</span><strong>${money(p.iva)}</strong></div>
      <div class="row-between" style="font-size:13px"><span class="muted">Envío</span><strong>${money(p.envio)}</strong></div>
      <div class="row-between" style="font-size:15px;font-weight:700;border-top:1px solid var(--line);padding-top:8px;margin-top:6px"><span>Total</span><strong>${money(p.total)}</strong></div>
    </div>
    <div class="stack">
      <div class="admin-card">
        <div class="admin-card-head"><h3>Cliente y envío</h3></div>
        <p class="small"><strong>${esc(p.cliente.nombre)}</strong><br>
        ${esc(p.cliente.email)}${p.cliente.telefono ? ` · ${esc(p.cliente.telefono)}` : ""}<br>
        ${p.cliente.empresa ? `${esc(p.cliente.empresa)}${p.cliente.nif ? ` · ${esc(p.cliente.nif)}` : ""}<br>` : ""}
        ${esc(p.cliente.direccion)}<br>
        ${esc(p.cliente.cp)} ${esc(p.cliente.ciudad)}${p.cliente.provincia ? ` (${esc(p.cliente.provincia)})` : ""}<br>
        ${esc(p.cliente.pais)}</p>
        ${p.notas ? `<p class="small muted mt-1"><strong>Notas:</strong> ${esc(p.notas)}</p>` : ""}
      </div>
      <div class="admin-card">
        <div class="admin-card-head"><h3>Chat con el cliente</h3></div>
        <div id="admin-chat-box" style="max-height:260px;overflow:auto;padding:8px 0"></div>
        <form id="admin-chat-form" class="row" style="margin-top:10px;gap:8px">
          <input class="input" name="mensaje" placeholder="Responder al cliente…" required style="flex:1">
          <button class="btn btn-primary btn-sm" type="submit">${icon("send",14)} Enviar</button>
        </form>
      </div>
      <div class="admin-card">
        <div class="admin-card-head"><h3>Estado</h3>${estadoBadge(p.estado, p.estado_label)}</div>
        ${p.pago_estado_label ? `<p class="small">Pago: <strong>${esc(p.pago_estado_label)}</strong></p>` : ""}
        ${p.pago_cancela_at && ["pendiente_verificacion", "pendiente_pago_web"].includes(p.pago_estado) ? `<p class="small">${p.pago_vencido ? `<span class="badge badge--warn">Plazo de pago vencido</span> ` : ""}Plazo del cliente: ${fmtDateTime(p.pago_vence_at)} · cancelación automática: ${fmtDateTime(p.pago_cancela_at)}</p>` : ""}
        <p class="small">Entrega: <strong>${esc(p.tipo_entrega_label || "")}</strong></p>
        ${p.tipo_entrega === "recogida" && p.recogida_fecha ? `<p class="small">Recogida: <strong>${esc(p.recogida_fecha)}</strong> sobre las <strong>${esc(p.recogida_hora)}</strong> (aprox.)</p>` : ""}
        ${p.tipo_entrega !== "recogida" ? `<p class="small">Envío: ${p.envio_pendiente ? `<span class="tiny muted">pendiente de asignar</span>` : `<strong>${money(p.envio)}</strong> · ${esc(p.envio_cobro_label || "")}${p.transportista ? ` · ${esc(p.transportista)}` : ""}${p.seguimiento ? ` · ${esc(p.seguimiento)}` : ""}`}</p>` : ""}
        ${p.tipo_entrega !== "recogida" && !p.envio_pendiente && p.envio_cobro === "anticipado" && !p.envio_pagado && PUEDE_VERIFICAR() && !["cancelado"].includes(p.estado) ? `<p><button class="btn btn-primary btn-sm" data-verificar-envio="${esc(p.id)}">${icon("check", 14)} Pago del envío recibido</button></p>` : ""}
        ${ES_ADMIN() && p.tipo_entrega !== "recogida" && !["enviado", "entregado", "cancelado"].includes(p.estado) ? `<form id="envio-form" class="stack" style="margin:8px 0">
          <div class="field"><label>Coste de envío (€)</label><input class="input" type="number" step="0.01" min="0" name="importe" value="${p.envio_pendiente ? "" : esc(p.envio)}" required></div>
          ${p.tipo_entrega === "envio_propio" ? `<p class="tiny muted">Envío propio: se cobra al recibir el pedido.</p>` : `<div class="field"><label>Cómo se paga el envío</label>
            <select class="select" name="cobro">
              <option value="entrega" ${p.envio_cobro === "entrega" || !p.envio_cobro ? "selected" : ""}>Se cobra al recibir el pedido (a cargo del destinatario)</option>
              <option value="anticipado" ${p.envio_cobro === "anticipado" ? "selected" : ""}>Pagado por adelantado (transferencia o cartera digital)</option>
            </select></div>`}
          <div class="field"><label>Transportista <span class="muted">(opcional)</span></label><input class="input" name="transportista" value="${esc(p.transportista || "")}" placeholder="Correos, DHL, reparto propio…"></div>
          <div class="field"><label>Número de seguimiento <span class="muted">(opcional)</span></label><input class="input" name="seguimiento" value="${esc(p.seguimiento || "")}"></div>
          <button class="btn btn-primary btn-sm" type="submit" id="save-envio-btn">${icon("check", 14)} ${p.envio_pendiente ? "Asignar envío" : "Actualizar envío"}</button>
        </form>` : ""}
        ${p.pago_estado === "pendiente_verificacion" && ["pendiente", "pagado", "preparando"].includes(p.estado) ? `<div class="notice notice--warn" style="margin:8px 0"><span>El pago no está verificado. Puedes preparar el pedido, pero no saldrá a reparto hasta verificarlo (salvo contrareembolso).</span></div>` : ""}
        ${p.pago_estado === "pendiente_verificacion" && PUEDE_VERIFICAR() ? `<p><button class="btn btn-primary btn-sm" data-verificar="${esc(p.id)}">${icon("check", 14)} Verificar pago recibido</button></p>` : ""}
        ${(p.pago_estado === "pendiente_cobro" || (p.envio_cobro === "entrega" && !p.envio_cobrado && !p.envio_pendiente && p.tipo_entrega !== "recogida")) && p.estado === "enviado" ? `<p><button class="btn btn-primary btn-sm" data-cobro="${esc(p.id)}">${icon("check", 14)} Entregado y cobrado</button></p>` : ""}
        ${transiciones.length ? `<div class="row" style="flex-wrap:wrap;gap:8px">
          ${transiciones.map((e) => `<button class="btn btn-sm ${e === "cancelado" ? "btn-danger" : "btn-primary"}" data-estado="${e}">${e === "cancelado" ? icon("trash", 14) : icon("check", 14)} ${esc(ESTADOS_PEDIDO[e])}</button>`).join("")}
        </div>` : `<p class="tiny muted">No hay transiciones disponibles para este estado.</p>`}
        <div class="admin-section-title">Historial</div>
        <div class="stack">
          ${(p.eventos || []).map((ev) => `<div class="row" style="align-items:flex-start;gap:8px">
            <span class="dot ${ev.estado === "cancelado" ? "dot--danger" : "dot--ok"}" style="margin-top:6px"></span>
            <div><strong class="small">${esc(ev.estado_label)}</strong>
              <p class="tiny muted">${fmtDateTime(ev.created_at)}${ev.nota ? ` · ${esc(ev.nota)}` : ""}${ev.usuario ? ` · ${esc(ev.usuario)}` : ""}</p></div>
          </div>`).join("")}
        </div>
      </div>
    </div>
  </div>`;
  render(content, p.numero);
  const changeEstado = async (nuevo, nota = "") => {
    try {
      if (nuevo === "cancelado") {
        const motivo = prompt("Motivo de la cancelación (opcional):") || "";
        await api(`/api/admin/pedidos/${orderId}/cancelar`, { method: "POST", body: { motivo } });
      } else {
        await api(`/api/admin/pedidos/${orderId}/estado`, { method: "POST", body: { estado: nuevo, nota } });
      }
      toast("Pedido actualizado");
      route();
    } catch (err) { toast(err.message, "error"); }
  };
  const chatBox = $("#admin-chat-box");
  const renderAdminChat = async () => {
    try {
      const d = await api(`/api/admin/pedidos/${orderId}/chat`);
      chatBox.innerHTML = (d.items || []).map((m) => `<div style="margin:6px 0;padding:8px 10px;border-radius:10px;background:${m.autor_rol === "admin" ? "var(--brand-mist)" : "var(--paper-2)"};margin-left:${m.autor_rol === "admin" ? "24px" : "0"};margin-right:${m.autor_rol === "admin" ? "0" : "24px"}">
        <p class="tiny muted"><strong>${esc(m.autor)}</strong> · ${fmtDateTime(m.created_at)}</p>
        <p class="small">${esc(m.mensaje)}</p>
      </div>`).join("") || `<p class="tiny muted">Sin mensajes todavía.</p>`;
      chatBox.scrollTop = chatBox.scrollHeight;
    } catch (err) { chatBox.innerHTML = `<p class="tiny muted">${esc(err.message)}</p>`; }
  };
  await renderAdminChat();
  $("#admin-chat-form")?.addEventListener("submit", async (e) => {
    e.preventDefault();
    const input = e.target.querySelector("[name='mensaje']");
    const msg = input.value.trim();
    if (!msg) return;
    try {
      await api(`/api/admin/pedidos/${orderId}/chat`, { method: "POST", body: { mensaje: msg } });
      input.value = "";
      await renderAdminChat();
    } catch (err) { toast(err.message, "error"); }
  });
  $$("[data-estado]").forEach((b) => b.addEventListener("click", () => changeEstado(b.dataset.estado)));
  $("#envio-form")?.addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = $("#save-envio-btn");
    const data = formObject(e.target);
    setBusy(btn, true, "Guardando…");
    try {
      await api(`/api/admin/pedidos/${orderId}/envio`, { method: "POST", body: data });
      toast("Envío asignado");
      await sondearNotificaciones(false);
      orderDetailPage(orderId);
    } catch (err) { setBusy(btn, false); toast(err.message, "error"); }
  });
  $$("[data-verificar-envio]").forEach((b) => b.addEventListener("click", async () => {
    try { await api(`/api/admin/pedidos/${orderId}/verificar-envio`, { method: "POST" }); toast("Pago del envío verificado"); await sondearNotificaciones(false); orderDetailPage(orderId); }
    catch (err) { toast(err.message, "error"); }
  }));
  $$("[data-verificar]").forEach((b) => b.addEventListener("click", async () => {
    try { await api(`/api/admin/pedidos/${orderId}/verificar-pago`, { method: "POST" }); toast("Pago verificado · pedido pagado"); await sondearNotificaciones(false); orderDetailPage(orderId); }
    catch (err) { toast(err.message, "error"); }
  }));
  $$("[data-cobro]").forEach((b) => b.addEventListener("click", async () => {
    try { await api(`/api/admin/pedidos/${orderId}/confirmar-cobro`, { method: "POST" }); toast("Entrega y cobro confirmados"); await sondearNotificaciones(false); orderDetailPage(orderId); }
    catch (err) { toast(err.message, "error"); }
  }));
}

/* ------------------------------ Compras ---------------------------------- */
async function purchasesPage(params) {
  const estado = params.get("estado") || "";
  const q = params.get("q") || "";
  const pagina = Math.max(1, parseInt(params.get("pagina") || "1", 10) || 1);

  render(loadingBlock("Cargando compras…"), "Compras");
  const data = await api("/api/admin/compras", { query: { estado, q, pagina, por_pagina: 20 } });
  const content = `
  ${pageHead("Compras", `${data.resumen.total} compras · ${money(data.resumen.importe)} recibidas.`, `
    <a class="btn btn-primary btn-sm" href="#/compras/nueva">${icon("plus", 15)} Nueva compra</a>
  `)}
  <div class="chip-row" style="margin-bottom:12px">
    ${["", "borrador", "recibida", "anulada"].map((e) => {
      const label = e ? (e === "borrador" ? "Borradores" : e === "recibida" ? "Recibidas" : "Anuladas") : "Todas";
      return `<a class="status-chip ${estado === e ? "is-active" : ""}" href="#/compras?${new URLSearchParams({ ...(e ? { estado: e } : {}), q }).toString()}">${esc(label)}</a>`;
    }).join("")}
  </div>
  <div class="admin-toolbar">
    <div class="search-box"><input class="input" id="cmp-search" type="search" placeholder="Nº o proveedor…" value="${esc(q)}"></div>
  </div>
  ${data.items.length ? `<div class="admin-card" style="padding:0"><div class="table-wrap"><table class="table admin-table">
    <thead><tr><th>Nº</th><th>Fecha</th><th>Proveedor</th><th>Estado</th><th class="num">Total</th><th class="num">Uds</th><th></th></tr></thead>
    <tbody>
      ${data.items.map((c) => `<tr>
        <td><strong>${esc(c.numero)}</strong></td>
        <td class="tiny muted">${fmtDate(c.fecha)}</td>
        <td>${esc(c.proveedor_nombre || "—")}</td>
        <td>${estadoBadge(c.estado, c.estado === "borrador" ? "Borrador" : c.estado === "recibida" ? "Recibida" : "Anulada")}</td>
        <td class="num money">${money(c.total)}</td>
        <td class="num">${number(c.unidades)}</td>
        <td class="actions"><a class="btn btn-xs btn-outline" href="#/compras/${esc(c.id)}">${icon("eye", 13)}</a></td>
      </tr>`).join("")}
    </tbody></table></div>
    ${paginationHTML(data.pagina, data.paginas, (pg) => `#/compras?${new URLSearchParams({ estado, q, pagina: pg }).toString()}`)}
  </div>` : emptyState({ iconName: "box", title: "Sin compras", text: "Crea una compra para registrar entradas de stock." })}`;
  render(content, "Compras");
  $("#cmp-search")?.addEventListener("input", debounce(() => {
    const params = new URLSearchParams(); const qv = $("#cmp-search").value.trim();
    if (estado) params.set("estado", estado); if (qv) params.set("q", qv);
    location.hash = `#/compras${params.toString() ? "?" + params.toString() : ""}`;
  }));
}

async function purchaseDetailPage(purchaseId) {
  render(loadingBlock("Cargando compra…"), "Compra");
  const d = await api(`/api/admin/compras/${purchaseId}`);
  const c = d.compra;
  const content = `
  ${pageHead(c.numero, `${fmtDate(c.fecha)} · ${c.estado} · ${c.proveedor?.nombre || "Sin proveedor"}`, `
    <a class="btn btn-outline btn-sm" href="#/compras">${icon("arrowLeft", 14)} Volver</a>
    ${c.estado === "borrador" ? `<button class="btn btn-primary btn-sm" id="receive-btn">${icon("check", 14)} Recibir</button>
      <button class="btn btn-danger btn-sm" id="delete-btn">${icon("trash", 14)} Borrar</button>` : ""}
    ${c.estado === "recibida" ? `<button class="btn btn-danger btn-sm" id="cancel-purchase-btn">${icon("trash", 14)} Anular</button>` : ""}
  `)}
  <div class="admin-card">
    <table class="table admin-table"><thead><tr><th>Producto</th><th class="num">Cant.</th><th class="num">Coste u.</th><th class="num">Total</th></tr></thead><tbody>
      ${c.lineas.map((l) => `<tr>
        <td><strong>${esc(l.nombre)}</strong><br><span class="tiny muted">${esc(l.sku)}</span></td>
        <td class="num">${number(l.cantidad)}</td>
        <td class="num">${money(l.coste_unit)}</td>
        <td class="num money">${money(l.total)}</td>
      </tr>`).join("")}
    </tbody></table>
    <div class="row-between mt-2" style="font-size:13px"><span class="muted">Base</span><strong>${money(c.base)}</strong></div>
    <div class="row-between" style="font-size:13px"><span class="muted">IVA</span><strong>${money(c.iva)}</strong></div>
    <div class="row-between" style="font-size:15px;font-weight:700;border-top:1px solid var(--line);padding-top:8px;margin-top:6px"><span>Total</span><strong>${money(c.total)}</strong></div>
    ${c.notas ? `<p class="small muted mt-2">${esc(c.notas)}</p>` : ""}
  </div>`;
  render(content, c.numero);
  $("#receive-btn")?.addEventListener("click", async () => {
    try { await api(`/api/admin/compras/${purchaseId}/recibir`, { method: "POST" }); toast("Compra recibida · stock actualizado"); route(); }
    catch (err) { toast(err.message, "error"); }
  });
  $("#delete-btn")?.addEventListener("click", async () => {
    const ok = await confirmDialog({ title: "Borrar compra", message: "Solo borradores. ¿Continuar?", danger: true, confirmText: "Borrar" });
    if (!ok) return;
    try { await api(`/api/admin/compras/${purchaseId}`, { method: "DELETE" }); toast("Compra borrada"); location.hash = "#/compras"; }
    catch (err) { toast(err.message, "error"); }
  });
  $("#cancel-purchase-btn")?.addEventListener("click", async () => {
    const ok = await confirmDialog({ title: "Anular compra", message: "Se revertirá el stock a coste original. ¿Continuar?", danger: true, confirmText: "Anular" });
    if (!ok) return;
    try { await api(`/api/admin/compras/${purchaseId}/anular`, { method: "POST" }); toast("Compra anulada"); route(); }
    catch (err) { toast(err.message, "error"); }
  });
}

async function newPurchasePage() {
  // reuse modal via a temporary container
  render(`<div class="admin-card">${loadingBlock("Preparando formulario…")}</div>`, "Nueva compra");
  const [prods, provs] = await Promise.all([
    api("/api/admin/productos?por_pagina=200"),
    api("/api/admin/proveedores"),
  ]);
  const productos = prods.items || [];
  const proveedores = provs.items || [];
  const lines = [{ producto_id: "", cantidad: 1, coste_unit: "" }];
  const renderLines = () => lines.map((l, i) => `
    <div class="row" style="gap:8px;margin-bottom:6px" data-line="${i}">
      <select class="select" data-field="producto_id" style="flex:2">
        <option value="">Selecciona producto…</option>
        ${productos.map((p) => `<option value="${esc(p.id)}" ${l.producto_id === p.id ? "selected" : ""}>${esc(p.sku)} · ${esc(p.nombre)}</option>`).join("")}
      </select>
      <input class="input" type="number" step="0.01" min="0.0001" data-field="cantidad" value="${esc(l.cantidad)}" placeholder="Cant." style="width:90px">
      <input class="input" type="number" step="0.01" min="0" data-field="coste_unit" value="${esc(l.coste_unit)}" placeholder="Coste" style="width:110px">
      <button type="button" class="btn-icon is-danger" data-remove-line="${i}" style="width:34px;height:34px">${icon("trash", 14)}</button>
    </div>`).join("");
  const body = `
  <form id="purchase-form" class="admin-form-grid">
    <div class="field"><label>Proveedor</label>
      <select class="select" name="proveedor_id">
        <option value="">Sin proveedor</option>
        ${proveedores.map((p) => `<option value="${esc(p.id)}">${esc(p.nombre)}</option>`).join("")}
      </select></div>
    <div class="field"><label>Fecha</label><input class="input" type="date" name="fecha" value="${new Date().toISOString().slice(0,10)}"></div>
    <div class="field full"><label>Notas</label><textarea class="textarea" name="notas" rows="2"></textarea></div>
    <div class="field full">
      <label>Líneas de compra</label>
      <div id="purchase-lines">${renderLines()}</div>
      <button type="button" class="btn btn-ghost btn-xs" id="add-purchase-line" style="margin-top:6px">${icon("plus", 13)} Añadir línea</button>
    </div>
    <div class="field full">
      <label class="check"><input type="checkbox" name="recibir" value="true"> Recibir la compra automáticamente (entrada al Kardex)</label>
    </div>
  </form>`;
  const close = openModal({
    title: "Nueva compra", subtitle: "Registra una entrada de stock desde un proveedor",
    body, wide: true,
    footer: `<button class="btn btn-outline btn-sm" data-cancel>Cancelar</button>
             <button class="btn btn-primary btn-sm" id="save-purchase-btn">Guardar compra</button>`,
    onMount: (el, closeFn) => {
      const container = el.querySelector("#purchase-lines");
      const sync = () => {
        lines.forEach((l, i) => {
          const row = container.querySelector(`[data-line="${i}"]`);
          if (!row) return;
          l.producto_id = row.querySelector('[data-field="producto_id"]').value;
          l.cantidad = row.querySelector('[data-field="cantidad"]').value;
          l.coste_unit = row.querySelector('[data-field="coste_unit"]').value;
        });
      };
      const rerender = () => {
        sync();
        container.innerHTML = renderLines();
        bindLines();
      };
      function bindLines() {
        container.querySelectorAll("[data-remove-line]").forEach((b) => {
          b.addEventListener("click", () => { lines.splice(Number(b.dataset.removeLine), 1); if (!lines.length) lines.push({ producto_id: "", cantidad: 1, coste_unit: "" }); rerender(); });
        });
        container.querySelectorAll("select[data-field='producto_id']").forEach((s) => {
          s.addEventListener("change", () => {
            const row = s.closest("[data-line]"); const idx = Number(row.dataset.line);
            const prod = productos.find((p) => p.id === s.value);
            if (prod && !lines[idx].coste_unit) {
              lines[idx].coste_unit = prod.coste_medio || "";
              row.querySelector("[data-field='coste_unit']").value = lines[idx].coste_unit;
            }
          });
        });
      }
      bindLines();
      el.querySelector("#add-purchase-line").addEventListener("click", () => {
        sync();
        lines.push({ producto_id: "", cantidad: 1, coste_unit: "" });
        rerender();
      });
      el.querySelector("[data-cancel]").addEventListener("click", () => { closeFn(); location.hash = "#/compras"; });
      el.querySelector("#save-purchase-btn").addEventListener("click", async () => {
        sync();
        const btn = el.querySelector("#save-purchase-btn");
        const form = el.querySelector("#purchase-form");
        const fd = new FormData(form);
        const lineas = lines.map((l) => ({
          producto_id: l.producto_id,
          cantidad: Number(l.cantidad),
          coste_unit: l.coste_unit === "" ? undefined : parseMoney(l.coste_unit),
        })).filter((l) => l.producto_id);
        if (!lineas.length) { toast("Añade al menos una línea", "error"); return; }
        const bodyData = {
          proveedor_id: fd.get("proveedor_id"),
          fecha: fd.get("fecha"),
          notas: fd.get("notas"),
          lineas,
          recibir: fd.get("recibir") === "true",
        };
        setBusy(btn, true, "Guardando…");
        try {
          const res = await api("/api/admin/compras", { method: "POST", body: bodyData });
          toast("Compra creada");
          closeFn();
          location.hash = `#/compras/${res.compra.id}`;
        } catch (err) {
          setBusy(btn, false);
          toast(err.message || "Error", "error");
        }
      });
    },
  });
  // keep modal open
}

/* ------------------------------ Proveedores ------------------------------ */
async function suppliersPage() {
  render(loadingBlock("Cargando proveedores…"), "Proveedores");
  const data = await api("/api/admin/proveedores");
  const content = `
  ${pageHead("Proveedores", `${data.items.length} proveedores.`, `
    <button class="btn btn-primary btn-sm" id="new-sup-btn">${icon("plus", 15)} Nuevo proveedor</button>
  `)}
  <div class="admin-card" style="padding:0">
    <table class="table admin-table">
      <thead><tr><th>Nombre</th><th>Contacto</th><th>Email</th><th>Teléfono</th><th class="num">Compras</th><th class="num">Importe</th><th class="actions">Acciones</th></tr></thead>
      <tbody>
        ${data.items.map((p) => `<tr>
          <td><strong>${esc(p.nombre)}</strong><br><span class="tiny muted">${esc(p.notas || "")}</span></td>
          <td>${esc(p.contacto || "—")}</td>
          <td class="tiny">${p.email ? `<a href="mailto:${esc(p.email)}">${esc(p.email)}</a>` : "—"}</td>
          <td class="tiny">${esc(p.telefono || "—")}</td>
          <td class="num">${number(p.compras)}</td>
          <td class="num money">${money(p.importe)}</td>
          <td class="actions">
            <button class="btn btn-xs btn-outline" data-edit-sup="${esc(p.id)}">${icon("edit", 13)}</button>
            <button class="btn btn-xs btn-danger" data-del-sup="${esc(p.id)}">${icon("trash", 13)}</button>
          </td>
        </tr>`).join("")}
      </tbody>
    </table>
  </div>`;
  render(content, "Proveedores");
  $("#new-sup-btn")?.addEventListener("click", () => openSupplierModal());
  $$("[data-edit-sup]").forEach((b) => b.addEventListener("click", () => {
    const p = data.items.find((x) => x.id === b.dataset.editSup);
    openSupplierModal(p);
  }));
  $$("[data-del-sup]").forEach((b) => b.addEventListener("click", async () => {
    const ok = await confirmDialog({ title: "Borrar proveedor", message: "Solo si no tiene compras. ¿Continuar?", danger: true, confirmText: "Borrar" });
    if (!ok) return;
    try { await api(`/api/admin/proveedores/${b.dataset.delSup}`, { method: "DELETE" }); toast("Proveedor borrado"); route(); }
    catch (err) { toast(err.message, "error"); }
  }));
}

async function openSupplierModal(sup = null) {
  const isEdit = !!sup;
  const body = `
  <form id="sup-form" class="admin-form-grid">
    <div class="field full"><label>Nombre *</label><input class="input" name="nombre" value="${esc(sup?.nombre || "")}" required></div>
    <div class="field"><label>Contacto</label><input class="input" name="contacto" value="${esc(sup?.contacto || "")}"></div>
    <div class="field"><label>Email</label><input class="input" type="email" name="email" value="${esc(sup?.email || "")}"></div>
    <div class="field"><label>Teléfono</label><input class="input" name="telefono" value="${esc(sup?.telefono || "")}"></div>
    <div class="field full"><label>Notas</label><textarea class="textarea" name="notas" rows="2">${esc(sup?.notas || "")}</textarea></div>
    <div class="field"><label>Activo</label>
      <select class="select" name="activo">
        <option value="true" ${sup?.activo !== 0 ? "selected" : ""}>Sí</option>
        <option value="false" ${sup?.activo === 0 ? "selected" : ""}>No</option>
      </select></div>
  </form>`;
  const close = openModal({
    title: isEdit ? "Editar proveedor" : "Nuevo proveedor",
    body,
    footer: `<button class="btn btn-outline btn-sm" data-cancel>Cancelar</button><button class="btn btn-primary btn-sm" id="save-sup-btn">Guardar</button>`,
    onMount: (el, closeFn) => {
      el.querySelector("[data-cancel]").addEventListener("click", closeFn);
      el.querySelector("#save-sup-btn").addEventListener("click", async () => {
        const btn = el.querySelector("#save-sup-btn");
        const data = formObject(el.querySelector("#sup-form"));
        data.activo = data.activo === "true";
        setBusy(btn, true, "Guardando…");
        try {
          if (isEdit) await api(`/api/admin/proveedores/${sup.id}`, { method: "PUT", body: data });
          else await api("/api/admin/proveedores", { method: "POST", body: data });
          toast(isEdit ? "Proveedor actualizado" : "Proveedor creado");
          closeFn(); route();
        } catch (err) { setBusy(btn, false); toast(err.message, "error"); }
      });
    },
  });
}

/* ------------------------------ Métricas --------------------------------- */
async function metricsPage(params) {
  const desde = params.get("desde") || "";
  const hasta = params.get("hasta") || "";
  const dias = params.get("dias") || "30";

  render(loadingBlock("Cargando métricas…"), "Métricas");
  const d = await api("/api/admin/metricas", { query: { desde, hasta, dias } });
  const k = d.kpis;
  const content = `
  ${pageHead("Métricas de negocio", `${fmtDate(d.rango.desde)} — ${fmtDate(d.rango.hasta)} (${d.rango.dias} días).`)}
  <div class="admin-toolbar">
    <input class="input" type="date" id="m-desde" value="${esc(d.rango.desde)}" style="min-width:140px;min-height:38px">
    <input class="input" type="date" id="m-hasta" value="${esc(d.rango.hasta)}" style="min-width:140px;min-height:38px">
    <select class="select" id="m-dias" style="min-width:120px;min-height:38px">
      ${[7,14,30,60,90,365].map((v) => `<option value="${v}" ${Number(dias) === v ? "selected" : ""}>${v} días</option>`).join("")}
    </select>
    <button class="btn btn-outline btn-sm" id="m-apply">Aplicar</button>
  </div>
  <div class="kpi-grid" style="margin-bottom:14px">
    <div class="admin-kpi is-brand"><div class="kpi-label">Ventas</div><div class="kpi-value">${money(k.ventas)}</div><div class="kpi-sub">${k.variacion_ventas === null ? "—" : `${k.variacion_ventas > 0 ? "+" : ""}${k.variacion_ventas}%`} vs periodo anterior</div></div>
    <div class="admin-kpi"><div class="kpi-label">Pedidos</div><div class="kpi-value">${number(k.pedidos)}</div><div class="kpi-sub">${k.variacion_pedidos === null ? "—" : `${k.variacion_pedidos > 0 ? "+" : ""}${k.variacion_pedidos}%`}</div></div>
    <div class="admin-kpi"><div class="kpi-label">Ticket medio</div><div class="kpi-value">${money(k.ticket_medio)}</div><div class="kpi-sub">${k.variacion_ticket === null ? "—" : `${k.variacion_ticket > 0 ? "+" : ""}${k.variacion_ticket}%`}</div></div>
    <div class="admin-kpi"><div class="kpi-label">Margen</div><div class="kpi-value">${money(k.margen)}</div><div class="kpi-sub">${k.margen_pct}% sobre base</div></div>
    <div class="admin-kpi"><div class="kpi-label">Unidades</div><div class="kpi-value">${number(k.unidades)}</div></div>
    <div class="admin-kpi"><div class="kpi-label">Clientes</div><div class="kpi-value">${number(k.clientes)}</div><div class="kpi-sub">${number(k.devoluciones)} devoluciones</div></div>
  </div>
  <div class="admin-card" style="margin-bottom:14px">
    <div class="admin-card-head"><h3>Ventas diarias</h3></div>
    <div class="chart">
      ${d.serie.map((s) => {
        const v = parseMoney(s.ventas);
        const max = Math.max(...d.serie.map((x) => parseMoney(x.ventas)), 1);
        const h = Math.max(2, (v / max) * 170);
        return `<div class="bar" style="height:${h}px" title="${esc(s.etiqueta)}: ${money(v)}"><span class="label">${esc(s.etiqueta.slice(0,5))}</span></div>`;
      }).join("")}
    </div>
  </div>
  <div class="grid-2" style="gap:14px;margin-bottom:14px">
    <div class="admin-card">
      <div class="admin-card-head"><h3>Top productos</h3></div>
      ${d.top_productos.length ? `<table class="table admin-table"><thead><tr><th>Producto</th><th class="num">Uds</th><th class="num">Importe</th><th class="num">Margen</th></tr></thead><tbody>
        ${d.top_productos.map((p) => `<tr>
          <td><strong>${esc(p.nombre)}</strong><br><span class="tiny muted">${esc(p.sku)}</span></td>
          <td class="num">${number(p.unidades)}</td>
          <td class="num money">${money(p.importe)}</td>
          <td class="num">${money(p.margen)}</td>
        </tr>`).join("")}
      </tbody></table>` : `<div class="admin-empty">${icon("package", 24)} Sin ventas</div>`}
    </div>
    <div class="admin-card">
      <div class="admin-card-head"><h3>Por categoría</h3></div>
      ${d.categorias.length ? `<div class="stack">
        ${d.categorias.map((c) => {
          const total = d.categorias.reduce((a, x) => a + parseMoney(x.importe), 0) || 1;
          const pct = Math.round(parseMoney(c.importe) / total * 100);
          return `<div>
            <div class="row-between" style="font-size:12.5px"><strong>${esc(c.nombre)}</strong><span class="muted">${money(c.importe)} · ${number(c.unidades)} uds · ${pct}%</span></div>
            <div class="progress" style="margin-top:5px"><span style="width:${pct}%"></span></div>
          </div>`;
        }).join("")}
      </div>` : `<div class="admin-empty">${icon("tag", 24)} Sin datos</div>`}
    </div>
  </div>
  <div class="grid-2" style="gap:14px">
    <div class="admin-card">
      <div class="admin-card-head"><h3>Métodos de pago</h3></div>
      ${d.metodos_pago.length ? `<table class="table admin-table"><thead><tr><th>Método</th><th class="num">Pedidos</th><th class="num">Importe</th></tr></thead><tbody>
        ${d.metodos_pago.map((m) => `<tr><td>${esc(m.etiqueta)}</td><td class="num">${number(m.pedidos)}</td><td class="num money">${money(m.importe)}</td></tr>`).join("")}
      </tbody></table>` : `<div class="admin-empty">${icon("card", 24)} Sin datos</div>`}
    </div>
    <div class="admin-card">
      <div class="admin-card-head"><h3>Estados de pedidos</h3></div>
      <div class="stack">
        ${Object.entries(d.estados).map(([k, v]) => `<div class="row-between" style="font-size:13px"><span>${esc(ESTADOS_PEDIDO[k] || k)}</span><strong>${number(v)}</strong></div>`).join("")}
      </div>
    </div>
  </div>`;
  render(content, "Métricas");
  $("#m-apply")?.addEventListener("click", () => {
    const params = new URLSearchParams();
    const dv = $("#m-desde").value; const hv = $("#m-hasta").value;
    if (dv) params.set("desde", dv); if (hv) params.set("hasta", hv);
    location.hash = `#/metricas${params.toString() ? "?" + params.toString() : ""}`;
  });
}

/* ------------------------------ Ajustes ---------------------------------- */
// ------------------------------ Dominio propio (tienda) ------------------------------

const PASOS_DOMINIO = [
  ["Elegir el dominio", ["pendiente_dns", "pendiente_pago_dominio", "pendiente_registro", "dns_ok", "activo"]],
  ["Apuntarlo a CC Shops", ["dns_ok", "activo"]],
  ["Activar el complemento", ["activo"]],
];

async function dominioPage() {
  render(loadingBlock("Cargando dominio…"), "Dominio propio");
  const d = await api("/api/admin/dominio");
  const sinDominio = !d.dominio;
  const badge = (d.estado === "activo") ? "badge--ok" : "badge--warn";
  const pasos = `<ol class="dominio-pasos">${PASOS_DOMINIO.map(([txt, hechoEn], i) => {
    const hecho = hechoEn.includes(d.estado);
    return `<li class="${hecho ? "is-done" : ""}"><span>${i + 1}</span> ${esc(txt)}</li>`;
  }).join("")}</ol>`;
  let cuerpo = "";
  if (sinDominio) {
    cuerpo = `<form id="dom-form" class="stack" novalidate>
      <div class="dominio-opciones">
        <label class="dominio-opcion"><input type="radio" name="modo" value="propio" checked><strong>Ya tengo un dominio</strong><span class="tiny muted">Lo registré yo en el proveedor que quiera (por ejemplo, Ionos, GoDaddy o Namecheap).</span></label>
        <label class="dominio-opcion"><input type="radio" name="modo" value="compra"><strong>Quiero comprarlo</strong><span class="tiny muted">CC Shops lo registra por ti. Precio: ${money(d.precios.compra_anual)} al año, pagados íntegros por ti.</span></label>
      </div>
      <div class="field"><label>Dominio</label><input class="input" name="dominio" placeholder="midominio.com" autocomplete="off" required></div>
      <p class="tiny muted">Complemento mensual: ${money(d.precios.mensual)} al mes. Sin el complemento activo, el dominio no se muestra.</p>
      <button class="btn btn-primary btn-sm" type="submit" id="dom-btn">Continuar</button>
    </form>`;
  } else if (d.estado === "pendiente_dns") {
    cuerpo = `<p>Crea estos dos registros en el panel DNS de tu dominio. Después pulsa «Comprobar ahora».</p>
    <table class="table dns-tabla"><thead><tr><th>Tipo</th><th>Nombre</th><th>Valor</th></tr></thead><tbody>
      <tr><td>A</td><td>@ (la raíz)</td><td><code>${esc(d.dns.ip)}</code></td></tr>
      <tr><td>CNAME</td><td>www</td><td><code>${esc(d.dns.host)}</code></td></tr>
    </tbody></table>
    <p class="tiny muted">Los cambios de DNS pueden tardar hasta 24 horas en verse.</p>
    <div class="row" style="gap:8px"><button class="btn btn-primary btn-sm" id="dom-verificar">Comprobar ahora</button></div>`;
  } else if (d.estado === "pendiente_pago_dominio") {
    cuerpo = `<p>Para registrar <strong>${esc(d.dominio)}</strong> envía <strong>${money(d.precios.compra_anual)}</strong> con esta referencia:</p>
    <p><code>${esc(d.pago.referencia)}</code></p>
    <p class="small">${d.pago.iban ? `Transferencia a <strong>${esc(d.pago.iban)}</strong>` : ""}${d.pago.cartera ? ` · Cartera digital: <strong>${esc(d.pago.cartera)}</strong>` : ""}</p>
    <p class="tiny muted">${esc(d.nota)} CC Shops lo registra cuando verifica el pago.</p>`;
  } else if (d.estado === "pendiente_registro") {
    cuerpo = `<p>CC Shops está registrando <strong>${esc(d.dominio)}</strong>. Te avisaremos cuando esté listo y tengas que configurar el DNS.</p>`;
  } else if (d.estado === "dns_ok") {
    cuerpo = `<p>Tu dominio <strong>${esc(d.dominio)}</strong> está verificado.</p>
    <p>Para mostrarlo, activa el complemento mensual de ${money(d.precios.mensual)}. Paga por transferencia o cartera digital con la referencia <code>${esc(d.pago.referencia)}</code>. CC Shops lo activa cuando verifica el pago.</p>
    <p class="small">${d.pago.iban ? `Transferencia a <strong>${esc(d.pago.iban)}</strong>` : ""}${d.pago.cartera ? ` · Cartera digital: <strong>${esc(d.pago.cartera)}</strong>` : ""}</p>`;
  } else if (d.estado === "activo") {
    cuerpo = `<div class="notice"><span>Tu tienda está en <strong><a href="https://${esc(d.dominio)}" target="_blank" rel="noopener">${esc(d.dominio)}</a></strong>.</span></div>`;
  }
  // Igual que el servidor: un dominio comprado y registrado a nombre de la tienda solo lo cambia CC Shops.
  const cancelable = !(d.modo === "compra" && ["pendiente_registro", "dns_ok", "activo"].includes(d.estado));
  const acciones = !sinDominio && cancelable ? `<button class="btn btn-outline btn-sm" id="dom-cancelar">Cambiar o quitar dominio</button>` : "";
  render(`${pageHead("Dominio propio", "Tu tienda en tu propio dominio.", `<a class="btn btn-outline btn-sm" href="#/ajustes">${icon("arrowLeft", 14)} Volver</a>`)}
  <div class="admin-card">
    <div class="admin-card-head"><h3>${sinDominio ? "Configurar" : esc(d.dominio)}</h3><span class="badge ${badge}">${esc(d.estado_texto)}</span></div>
    ${sinDominio ? "" : pasos}
    ${cuerpo}
    ${acciones ? `<div style="margin-top:14px">${acciones}</div>` : ""}
  </div>`, "Dominio propio");

  $("#dom-form")?.addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = $("#dom-btn");
    const data = formObject(e.target);
    setBusy(btn, true, "Guardando…");
    try { await api("/api/admin/dominio/configurar", { method: "POST", body: data }); toast("Dominio guardado"); dominioPage(); }
    catch (err) { setBusy(btn, false); toast(err.message, "error"); }
  });
  $("#dom-verificar")?.addEventListener("click", async (e) => {
    const btn = e.currentTarget;
    setBusy(btn, true, "Comprobando…");
    try { await api("/api/admin/dominio/verificar", { method: "POST" }); toast("DNS verificado"); dominioPage(); }
    catch (err) { setBusy(btn, false); toast(err.message, "error"); }
  });
  $("#dom-cancelar")?.addEventListener("click", async () => {
    const ok = await confirmDialog({ title: "Cambiar o quitar dominio", message: "Se quitará el dominio que has configurado. Podrás elegir otro.", danger: true, confirmText: "Quitar" });
    if (!ok) return;
    try { await api("/api/admin/dominio/cancelar", { method: "POST" }); toast("Dominio quitado"); dominioPage(); }
    catch (err) { toast(err.message, "error"); }
  });
}

async function settingsPage() {
  render(loadingBlock("Cargando ajustes…"), "Ajustes");
  const d = await api("/api/admin/ajustes");
  const a = d.ajustes;
  const content = `
  ${pageHead("Ajustes de la tienda", "Configuración general, envío y datos de contacto.")}
  <div class="admin-card" style="margin-bottom:14px">
    <div class="admin-card-head"><h3>Dominio propio</h3><a class="btn btn-outline btn-sm" href="#/ajustes/dominio">${icon("settings", 14)} Configurar</a></div>
    <p class="tiny muted">Usa tu propio dominio, por ejemplo midominio.com, en lugar de la dirección de CC Shops. Es un complemento de pago mensual.</p>
  </div>
  <div class="grid-2" style="gap:14px;align-items:start">
    <div class="admin-card">
      <div class="admin-card-head"><h3>Datos de la tienda</h3></div>
      <form id="settings-form" class="admin-form-grid">
        <div class="field full"><label>Nombre de la tienda</label><input class="input" name="tienda_nombre" value="${esc(a.tienda_nombre)}"></div>
        <div class="field full"><label>Claim</label><input class="input" name="tienda_claim" value="${esc(a.tienda_claim)}"></div>
        <div class="field"><label>Email de contacto</label><input class="input" type="email" value="${esc(a.tienda_email || "")}" disabled><p class="tiny muted" style="margin-top:4px">Es el correo de tu cuenta. Los mensajes del formulario de contacto llegan ahí.</p></div>
        <div class="field"><label>Teléfono</label><input class="input" name="tienda_telefono" value="${esc(a.tienda_telefono)}"></div>
        <div class="field full"><label>Dirección</label><textarea class="textarea" name="tienda_direccion" rows="2">${esc(a.tienda_direccion)}</textarea></div>
        <div class="field"><label>Horas para pagar (cliente)</label><input class="input" type="number" min="1" max="72" name="pago_plazo_horas" value="${esc(a.pago_plazo_horas)}"></div>
        <div class="field"><label>Horas extra para el administrador</label><input class="input" type="number" min="1" max="168" name="pago_gracia_admin_horas" value="${esc(a.pago_gracia_admin_horas)}"></div>
        <div class="field full"><label>Aviso de plazo de pago para el cliente</label><textarea class="textarea" name="aviso_plazo_pago" rows="2">${esc(a.aviso_plazo_pago)}</textarea>
          <p class="tiny muted" style="margin-top:4px">Usa <strong>{horas}</strong> para el número de horas. Tras el plazo del cliente, el administrador tiene las horas extra antes de que el pedido se cancele y el stock vuelva a la venta.</p></div>
        <div class="field full"><label>Nota de envío para el cliente</label><textarea class="textarea" name="aviso_envio" rows="2">${esc(a.aviso_envio)}</textarea>
          <p class="tiny muted" style="margin-top:4px">Usa <strong>{tienda}</strong> para el nombre de la tienda. El coste del envío lo asignas tú en cada pedido.</p></div>
        <div class="field"><label>Recargo contra­reembolso (€)</label><input class="input" type="number" step="0.01" name="recargo_contrareembolso" value="${esc(a.recargo_contrareembolso)}"></div>
        <div class="field full"><label>Aviso de pago</label><textarea class="textarea" name="aviso_pago" rows="2">${esc(a.aviso_pago)}</textarea></div>
        <div class="field full"><label>Cuenta para transferencias (IBAN)</label><input class="input" name="pago_iban" value="${esc(a.pago_iban)}" placeholder="ES00 0000 0000 0000 0000 0000"></div>
        <div class="field full"><label>Número de cartera digital</label><input class="input" name="pago_cartera" value="${esc(a.pago_cartera)}" placeholder="600 000 000"></div>
        <div class="field full"><label>Pago online con tarjeta</label>
          <select class="select" name="pago_web_activo">
            <option value="0" ${a.pago_web_activo === "1" ? "" : "selected"}>Desactivado</option>
            <option value="1" ${a.pago_web_activo === "1" ? "selected" : ""}>Activado</option>
          </select>
          <p class="tiny muted" style="margin-top:4px">Los cobros los gestiona la pasarela conectada a tu cuenta. Indica la cuenta conectada antes de activarlo.</p></div>
        <div class="field full"><label>Cuenta conectada del pago online</label><input class="input" name="pago_web_cuenta" value="${esc(a.pago_web_cuenta)}" placeholder="acct_…"></div>
        <div class="field full"><button class="btn btn-primary btn-sm" type="submit" id="save-settings-btn">${icon("check", 14)} Guardar cambios</button></div>
      </form>
    </div>
    <div class="stack">
      <div class="admin-card">
        <div class="admin-card-head"><h3>Estadísticas</h3></div>
        <div class="row-between" style="font-size:13px"><span class="muted">Productos activos</span><strong>${number(d.stats.productos)}</strong></div>
        <div class="row-between" style="font-size:13px"><span class="muted">Pedidos</span><strong>${number(d.stats.pedidos)}</strong></div>
        <div class="row-between" style="font-size:13px"><span class="muted">Movimientos</span><strong>${number(d.stats.movimientos)}</strong></div>
        <div class="row-between" style="font-size:13px"><span class="muted">Eventos</span><strong>${number(d.stats.eventos)}</strong></div>
        <div class="row-between" style="font-size:13px"><span class="muted">Base de datos</span><strong class="tiny">${esc(d.db)}</strong></div>
        <div class="row-between" style="font-size:13px"><span class="muted">URL pública</span><strong class="tiny">${esc(d.public_url)}</strong></div>
      </div>
      <div class="admin-card">
        <div class="admin-card-head"><h3>Apariencia</h3></div>
        <form id="theme-form" class="stack">
          <div class="field"><label>Tema del backoffice</label>
            <select class="input" name="tema_backoffice" ${ME?.rol === "admin" ? "" : "disabled"}>${opcionesTema(a.tema_backoffice)}</select></div>
          <div class="field"><label>Tema de la tienda</label>
            <select class="input" name="tema_tienda" ${ME?.rol === "admin" ? "" : "disabled"}>${opcionesTema(a.tema_tienda)}</select></div>
          <p class="tiny muted">Clásico: diseño actual. Tech: oscuro con acentos neón. El tema de la tienda lo ven tus clientes.</p>
          ${ME?.rol === "admin" ? `<button class="btn btn-primary btn-sm" type="submit" id="save-theme-btn">${icon("check", 14)} Guardar apariencia</button>` : `<p class="tiny muted">Solo el administrador puede cambiar el tema.</p>`}
        </form>
      </div>
      <div class="admin-card">
        <div class="admin-card-head"><h3>Cambiar contraseña</h3></div>
        <form id="password-form" class="stack">
          <div class="field"><label>Contraseña actual</label><input class="input" type="password" name="actual" required></div>
          <div class="field"><label>Nueva contraseña</label><input class="input" type="password" name="nueva" required placeholder="Mín. 8 caracteres, con letras y números"></div>
          <button class="btn btn-primary btn-sm" type="submit" id="save-password-btn">${icon("lock", 14)} Cambiar contraseña</button>
        </form>
      </div>
      <div class="admin-card">
        <div class="admin-card-head"><h3>Sesión</h3></div>
        <p class="small">${esc(ME?.nombre || "")} · ${esc(ME?.email || "")} · ${esc(ME?.rol || "")}</p>
        <p class="tiny muted">Último acceso: ${fmtDateTime(ME?.ultimo_acceso)}</p>
      </div>
    </div>
  </div>`;
  render(content, "Ajustes");
  $("#settings-form")?.addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = $("#save-settings-btn");
    const data = formObject(e.target);
    setBusy(btn, true, "Guardando…");
    try {
      await api("/api/admin/ajustes", { method: "PUT", body: data });
      toast("Ajustes guardados");
      await cargarAjustesAdmin();
    } catch (err) { toast(err.message, "error"); }
    finally { setBusy(btn, false); }
  });
  $("#theme-form")?.addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = $("#save-theme-btn");
    const data = formObject(e.target);
    setBusy(btn, true, "Guardando…");
    try {
      await api("/api/admin/ajustes", { method: "PUT", body: data });
      toast("Apariencia guardada");
      await cargarAjustesAdmin();
    } catch (err) { toast(err.message, "error"); }
    finally { setBusy(btn, false); }
  });
  $("#password-form")?.addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = $("#save-password-btn");
    const data = formObject(e.target);
    setBusy(btn, true, "Cambiando…");
    try {
      await api("/api/auth/password", { method: "POST", body: data });
      toast("Contraseña actualizada");
      e.target.reset();
    } catch (err) { toast(err.message, "error"); }
    finally { setBusy(btn, false); }
  });
}


// ============================== SUPERADMIN ==============================

let CHAT_TIMER = null;
const ESTADOS_TICKET = { abierto: "Abierto", en_curso: "En curso", resuelto: "Resuelto", cerrado: "Cerrado" };

function chatHTML(mensajes, yo) {
  return mensajes.map((m) => `<div class="chat-msg ${m.autor_tipo === yo ? "is-mine" : ""}">
    <div class="chat-meta tiny muted">${m.autor_tipo === "plataforma" ? "CC Shops" : "Tienda"} · ${fmtDateTime(m.created_at)}</div>
    <div class="chat-text">${esc(m.texto)}</div>
  </div>`).join("") || `<p class="tiny muted">Todavía no hay mensajes.</p>`;
}

function kpi(label, valor, sub = "") {
  return `<div class="admin-kpi"><div class="kpi-label">${esc(label)}</div><div class="kpi-value">${valor}</div>${sub ? `<div class="kpi-sub">${sub}</div>` : ""}</div>`;
}

async function superadminPage() {
  render(loadingBlock("Cargando panel…"), "Panel");
  const m = await api("/api/superadmin/metricas");
  const content = `
  ${pageHead("Panel de la plataforma", "Tiendas, clientes, ventas y uso de almacenamiento.")}
  <div class="kpi-grid" style="margin-bottom:14px">
    ${kpi("Tiendas", number(m.tiendas), `${number(m.tiendas_activas)} activas`)}
    ${kpi("Productos", number(m.productos))}
    ${kpi("Clientes", number(m.clientes_total), "cuentas y compradores")}
    ${kpi("Pedidos", number(m.pedidos_total))}
    ${kpi("Ventas", money(m.ventas_total), "pedidos no cancelados")}
    ${kpi("Almacenamiento", `${number(m.almacenamiento_bd_mb)} MB`, `base de datos · imágenes ${number(m.almacenamiento_imagenes_kb)} KB`)}
  </div>
  <div class="admin-card" style="padding:0">
    <div class="admin-card-head" style="padding:14px 18px"><h3>Por tienda</h3></div>
    <div class="table-wrap"><table class="table admin-table">
      <thead><tr><th>Tienda</th><th>Estado</th><th class="num">Productos</th><th class="num">Pedidos</th><th class="num">Ventas</th><th class="num">Clientes</th><th class="num">Clientes/día (media)</th><th class="num">Imágenes KB</th></tr></thead>
      <tbody>${m.por_tienda.map((t) => `<tr>
        <td><strong>${esc(t.nombre)}</strong><br><span class="tiny muted">${esc(t.slug)}</span></td>
        <td><span class="badge ${t.estado === "activa" ? "badge--ok" : "badge--warn"}">${esc(t.estado)}</span></td>
        <td class="num">${number(t.productos)}</td><td class="num">${number(t.pedidos)}</td>
        <td class="num money">${money(t.ventas)}</td><td class="num">${number(t.clientes)}</td>
        <td class="num">${number(t.clientes_medios_dia)}</td><td class="num">${number(t.almacenamiento_kb)}</td>
      </tr>`).join("") || `<tr><td colspan="8" class="admin-empty">Sin tiendas todavía</td></tr>`}</tbody>
    </table></div>
  </div>`;
  render(content, "Panel");
}

const TABS_AJUSTES_SA = [["correo", "Correo"], ["landing", "Landing"], ["seo", "SEO"], ["dominios", "Dominios"], ["contrasena", "Mi contraseña"], ["usuarios", "Usuarios"], ["planes", "Planes"], ["suscripciones", "Suscripciones"], ["tiendas", "Tiendas"]];

async function superadminAjustesPage(tab = "correo") {
  render(loadingBlock("Cargando ajustes…"), "Ajustes");
  const tabs = `<div class="chip-row" style="margin-bottom:14px">${TABS_AJUSTES_SA.map(([k, t]) => `<a class="chip ${tab === k ? "is-active" : ""}" href="#/superadmin/ajustes?tab=${k}">${t}</a>`).join("")}</div>`;
  let cuerpo = "";
  if (tab === "correo") {
    const correo = await api("/api/superadmin/correo");
    cuerpo = `<div class="admin-card">
      <div class="admin-card-head"><h3>Correo de la plataforma</h3><span class="badge ${correo.configurado ? "badge--ok" : "badge--warn"}">${correo.configurado ? "Configurado" : "Sin servidor"}</span></div>
      <p class="tiny muted" style="margin-bottom:10px">Desde aquí salen los mensajes de contacto de todas las tiendas. Llegan al correo de la cuenta de cada propietario.</p>
      <form id="correo-form" class="admin-form-grid" novalidate>
        <div class="field full"><label>Remitente (cómo aparece el correo)</label><input class="input" name="correo_remitente" value="${esc(correo.correo_remitente)}" placeholder="CC Shops <no-reply@tudominio.es>" required></div>
        <div class="field"><label>Servidor SMTP</label><input class="input" name="smtp_host" value="${esc(correo.smtp_host)}" placeholder="smtp.tudominio.es"></div>
        <div class="field"><label>Puerto</label><input class="input" type="number" min="1" max="65535" name="smtp_port" value="${esc(correo.smtp_port)}"></div>
        <div class="field"><label>Usuario</label><input class="input" name="smtp_usuario" value="${esc(correo.smtp_usuario)}" autocomplete="off"></div>
        <div class="field"><label>Contraseña</label><input class="input" type="password" name="smtp_password" placeholder="${correo.smtp_password_configurada ? "•••••••• (guardada; escribe para cambiarla)" : "Contraseña del servidor"}" autocomplete="new-password"></div>
        <div class="field"><label>Cifrado</label><select class="select" name="smtp_tls"><option value="1" ${correo.smtp_tls ? "selected" : ""}>STARTTLS (recomendado)</option><option value="0" ${!correo.smtp_tls ? "selected" : ""}>Sin cifrado</option></select></div>
        <div class="field full row" style="gap:8px">
          <button class="btn btn-primary btn-sm" type="submit" id="correo-btn">${icon("check", 14)} Guardar correo</button>
          <button class="btn btn-outline btn-sm" type="button" id="correo-prueba">Enviar prueba a mi correo</button>
        </div>
      </form>
    </div>`;
  } else if (tab === "landing" || tab === "seo") {
    const cfg = await api("/api/superadmin/landing");
    const campos = tab === "landing"
      ? `<div class="field full"><label>Titular de la landing</label><input class="input" name="landing_titulo" value="${esc(cfg.landing_titulo)}" maxlength="120" required></div>
         <div class="field full"><label>Texto de presentación</label><textarea class="textarea" name="landing_subtitulo" rows="3" maxlength="300" required>${esc(cfg.landing_subtitulo)}</textarea></div>`
      : `<div class="field full"><label>Título de la página (pestaña y buscadores)</label><input class="input" name="seo_titulo" value="${esc(cfg.seo_titulo)}" maxlength="120" required></div>
         <div class="field full"><label>Descripción para buscadores</label><textarea class="textarea" name="seo_descripcion" rows="3" maxlength="300" required>${esc(cfg.seo_descripcion)}</textarea><p class="tiny muted">Se muestra en Google y al compartir el enlace. Recomendado: 150–160 caracteres.</p></div>`;
    cuerpo = `<div class="admin-card">
      <div class="admin-card-head"><h3>${tab === "landing" ? "Landing page" : "SEO de la landing"}</h3></div>
      <p class="tiny muted" style="margin-bottom:10px">${tab === "landing" ? "Textos principales de la página pública de CC Shops." : "Datos que leen los buscadores y las redes sociales. Las tiendas tienen su propio nombre y descripción."}</p>
      <form id="web-form" class="admin-form-grid" novalidate>${campos}
        <div class="field full"><button class="btn btn-primary btn-sm" type="submit" id="web-btn">${icon("check", 14)} Guardar</button></div>
      </form></div>`;
  } else if (tab === "contrasena") {
    cuerpo = `<div class="admin-card" style="max-width:520px">
      <div class="admin-card-head"><h3>Cambiar mi contraseña</h3></div>
      <form id="sa-password-form" class="stack" novalidate>
        <div class="field"><label>Contraseña actual</label><input class="input" type="password" name="actual" autocomplete="current-password" required></div>
        <div class="field"><label>Nueva contraseña</label><input class="input" type="password" name="nueva" autocomplete="new-password" required placeholder="Mín. 8 caracteres, con letras y números"></div>
        <button class="btn btn-primary btn-sm" type="submit" id="sa-password-btn">${icon("lock", 14)} Cambiar contraseña</button>
      </form></div>`;
  } else if (tab === "dominios") {
    const d = await api("/api/superadmin/dominios");
    const c = d.configuracion;
    const etiquetas = { pendiente_pago_dominio: "Pendiente de pago del dominio", pendiente_registro: "Registrar dominio", pendiente_dns: "Esperando DNS", dns_ok: "DNS verificado", activo: "Activo" };
    cuerpo = `<div class="admin-card" style="margin-bottom:14px">
      <div class="admin-card-head"><h3>Precios y datos de DNS</h3></div>
      <form id="dom-config" class="admin-form-grid" novalidate>
        <div class="field"><label>Complemento mensual (€)</label><input class="input" type="number" step="0.01" min="0" name="dominio_mensual" value="${esc(c.mensual)}"></div>
        <div class="field"><label>Dominio: precio anual (€, lo paga el propietario)</label><input class="input" type="number" step="0.01" min="0" name="dominio_compra_anual" value="${esc(c.compra_anual)}"></div>
        <div class="field"><label>IP del servidor (registro A)</label><input class="input" name="dominio_dns_ip" value="${esc(c.dns_ip)}" placeholder="203.0.113.10"></div>
        <div class="field"><label>Destino para «www» (CNAME)</label><input class="input" name="dominio_dns_host" value="${esc(c.dns_host)}"></div>
        <div class="field"><label>IBAN para cobros</label><input class="input" name="plataforma_iban" value="${esc(c.iban)}"></div>
        <div class="field"><label>Cartera digital para cobros</label><input class="input" name="plataforma_cartera" value="${esc(c.cartera)}"></div>
        <div class="field full"><button class="btn btn-primary btn-sm" type="submit" id="dom-config-btn">${icon("check", 14)} Guardar</button></div>
      </form></div>
      <div class="admin-card" style="padding:0"><div class="table-wrap"><table class="table admin-table">
        <thead><tr><th>Tienda</th><th>Dominio</th><th>Camino</th><th>Estado</th><th>Complemento</th><th></th></tr></thead>
        <tbody>${d.items.map((t) => {
          const botones = [];
          if (t.dominio_estado === "pendiente_pago_dominio") botones.push(["pago_dominio_ok", "Pago del dominio recibido"]);
          if (t.dominio_estado === "pendiente_registro") botones.push(["registrado", "Dominio registrado"]);
          if (t.dominio_estado === "dns_ok") botones.push([t.complemento_activo ? "add_on_off" : "add_on_on", t.complemento_activo ? "Desactivar complemento" : "Activar complemento"]);
          return `<tr>
            <td><strong>${esc(t.nombre)}</strong><br><span class="tiny muted">${esc(t.slug)}</span></td>
            <td>${esc(t.dominio_propio)}</td>
            <td>${t.dominio_modo === "compra" ? "Compra" : "Propio"}</td>
            <td><span class="badge">${esc(etiquetas[t.dominio_estado] || t.dominio_estado)}</span></td>
            <td>${t.complemento_activo ? '<span class="badge badge--ok">Activo</span>' : "No"}</td>
            <td>${botones.map(([a, txt]) => `<button class="btn btn-xs btn-outline" data-dom-accion="${esc(t.id)}" data-accion="${a}">${esc(txt)}</button>`).join(" ")}</td>
          </tr>`;
        }).join("") || `<tr><td colspan="6" class="admin-empty">Ninguna tienda ha pedido dominio propio.</td></tr>`}</tbody></table></div></div>`;
  } else if (tab === "usuarios") {
    const usuarios = (await api("/api/superadmin/usuarios")).items;
    cuerpo = `<div class="admin-card" style="padding:0"><div class="table-wrap"><table class="table admin-table">
      <thead><tr><th>Persona</th><th>Rol</th><th>Tienda</th><th>Último acceso</th><th>Activo</th></tr></thead>
      <tbody>${usuarios.map((u) => `<tr>
        <td><strong>${esc(u.nombre)}</strong><br><span class="tiny muted">${esc(u.email)}</span></td>
        <td>${esc(u.rol)}</td><td>${esc(u.tienda_nombre || "—")}</td>
        <td class="tiny muted">${u.ultimo_acceso ? fmtDateTime(u.ultimo_acceso) : "—"}</td>
        <td><input type="checkbox" data-usuario="${esc(u.id)}" ${u.activo ? "checked" : ""} ${u.rol === "superadmin" ? "disabled" : ""}></td>
      </tr>`).join("")}</tbody></table></div></div>`;
  } else if (tab === "planes") {
    const planes = (await api("/api/superadmin/planes")).items;
    window.__PLANES = planes;
    cuerpo = `<div class="admin-card" style="padding:0;margin-bottom:14px"><div class="table-wrap"><table class="table admin-table">
      <thead><tr><th>Plan</th><th class="num">Precio</th><th class="num">Productos</th><th class="num">Usuarios</th><th class="num">Almacenamiento MB</th><th>Activo</th><th></th></tr></thead>
      <tbody>${planes.map((p) => `<tr>
        <td><strong>${esc(p.nombre)}</strong><br><span class="tiny muted">${esc(p.descripcion || "")}</span></td>
        <td class="num money">${money(p.precio)}</td><td class="num">${number(p.max_productos)}</td><td class="num">${number(p.max_usuarios)}</td><td class="num">${number(p.max_storage_mb)}</td>
        <td>${p.activo ? "Sí" : "No"}</td><td><button class="btn btn-xs btn-outline" data-editar-plan="${esc(p.id)}">${icon("edit", 13)} Editar</button></td>
      </tr>`).join("")}</tbody></table></div></div>
      <div class="admin-card"><div class="admin-card-head"><h3>Nuevo plan</h3></div>
      <form id="plan-form" class="admin-form-grid" novalidate>
        <div class="field"><label>Nombre</label><input class="input" name="nombre" required></div>
        <div class="field"><label>Precio mensual (€)</label><input class="input" type="number" step="0.01" min="0" name="precio" required></div>
        <div class="field full"><label>Descripción</label><input class="input" name="descripcion" maxlength="240"></div>
        <div class="field"><label>Máx. productos</label><input class="input" type="number" min="1" name="max_productos" value="100" required></div>
        <div class="field"><label>Máx. usuarios</label><input class="input" type="number" min="1" name="max_usuarios" value="5" required></div>
        <div class="field"><label>Almacenamiento (MB)</label><input class="input" type="number" min="1" name="max_storage_mb" value="500" required></div>
        <div class="field"><label>Activo</label><select class="select" name="activo"><option value="true">Sí</option><option value="false">No</option></select></div>
        <div class="field full"><input type="hidden" name="plan_id" value=""><button class="btn btn-primary btn-sm" type="submit" id="plan-btn">${icon("plus", 14)} Guardar plan</button></div>
      </form></div>`;
  } else if (tab === "suscripciones") {
    const [subs, tiendas, planes] = await Promise.all([api("/api/superadmin/suscripciones"), api("/api/superadmin/tiendas"), api("/api/superadmin/planes")]);
    const hoy = new Date().toISOString().slice(0, 10);
    const fin = new Date(Date.now() + 30 * 864e5).toISOString().slice(0, 10);
    cuerpo = `<div class="admin-card" style="padding:0;margin-bottom:14px"><div class="table-wrap"><table class="table admin-table">
      <thead><tr><th>Tienda</th><th>Plan</th><th>Estado</th><th>Inicio</th><th>Fin</th><th></th></tr></thead>
      <tbody>${subs.items.map((s) => `<tr>
        <td>${esc(s.tienda_nombre)}</td><td>${esc(s.plan_nombre)}</td>
        <td><span class="badge ${s.estado === "activa" ? "badge--ok" : "badge--warn"}">${esc(s.estado)}</span></td>
        <td class="tiny muted">${fmtDate(s.fecha_inicio)}</td><td class="tiny muted">${fmtDate(s.fecha_fin)}</td>
        <td><button class="btn btn-xs btn-outline" data-editar-sus="${esc(s.id)}" data-plan="${esc(s.plan_id)}" data-estado="${esc(s.estado)}" data-fin="${esc(s.fecha_fin)}">${icon("edit", 13)}</button></td>
      </tr>`).join("") || `<tr><td colspan="6" class="admin-empty">Sin suscripciones</td></tr>`}</tbody></table></div></div>
      <div class="admin-card"><div class="admin-card-head"><h3>Asignar plan a una tienda</h3></div>
      <form id="sus-form" class="admin-form-grid" novalidate>
        <div class="field full"><label>Tienda</label><select class="select" name="tienda_id">${tiendas.items.map((t) => `<option value="${esc(t.id)}">${esc(t.nombre)} (${esc(t.slug)})</option>`).join("")}</select></div>
        <div class="field"><label>Plan</label><select class="select" name="plan_id">${planes.items.map((p) => `<option value="${esc(p.id)}">${esc(p.nombre)} · ${money(p.precio)}</option>`).join("")}</select></div>
        <div class="field"><label>Estado</label><select class="select" name="estado"><option value="activa">Activa</option><option value="pendiente">Pendiente</option><option value="vencida">Vencida</option><option value="cancelada">Cancelada</option></select></div>
        <div class="field"><label>Inicio</label><input class="input" type="date" name="fecha_inicio" value="${hoy}"></div>
        <div class="field"><label>Fin</label><input class="input" type="date" name="fecha_fin" value="${fin}"></div>
        <div class="field full"><input type="hidden" name="suscripcion_id" value=""><button class="btn btn-primary btn-sm" type="submit" id="sus-btn">${icon("check", 14)} Guardar suscripción</button></div>
      </form></div>`;
  } else if (tab === "tiendas") {
    const tiendas = (await api("/api/superadmin/tiendas")).items;
    cuerpo = `<div class="admin-card" style="padding:0;margin-bottom:14px"><div class="table-wrap"><table class="table admin-table">
      <thead><tr><th>Tienda</th><th>Propietario</th><th>Plan</th><th class="num">Productos</th><th>Estado</th><th></th></tr></thead>
      <tbody>${tiendas.map((t) => `<tr>
        <td><strong>${esc(t.nombre)}</strong><br><span class="tiny muted">${esc(t.slug)}</span></td>
        <td>${esc(t.propietario_nombre || "—")}<br><span class="tiny muted">${esc(t.propietario_email || "")}</span></td>
        <td>${esc(t.plan_nombre || "Sin plan")}</td><td class="num">${number(t.productos)}</td>
        <td><span class="badge ${t.estado === "activa" ? "badge--ok" : "badge--warn"}">${esc(t.estado)}</span></td>
        <td><button class="btn btn-xs ${t.estado === "activa" ? "btn-danger" : "btn-outline"}" data-estado-tienda="${esc(t.id)}" data-nuevo="${t.estado === "activa" ? "suspendida" : "activa"}">${t.estado === "activa" ? "Suspender" : "Activar"}</button></td>
      </tr>`).join("")}</tbody></table></div></div>
    <div class="admin-card"><div class="admin-card-head"><h3>Administradores por tienda</h3><span class="tiny muted">Límite por defecto: 3</span></div>
      <form id="limite-form" class="admin-form-grid" novalidate>
        <div class="field"><label>Tienda</label><select class="select" name="tienda_id">${tiendas.map((t) => `<option value="${esc(t.id)}">${esc(t.nombre)} (${esc(t.slug)})</option>`).join("")}</select></div>
        <div class="field"><label>Máximo de administradores</label><input class="input" type="number" name="max_admins" min="1" max="20" value="3" required></div>
        <div class="field full"><button class="btn btn-primary btn-sm" type="submit" id="limite-btn">${icon("check", 14)} Guardar límite</button></div>
      </form></div>`;
  }
  render(`${pageHead("Ajustes de la plataforma", "Correo, landing, usuarios, planes, suscripciones y tiendas.")}${tabs}${cuerpo}`, "Ajustes");
  bindAjustesSuperadmin(tab);
}

function bindAjustesSuperadmin(tab) {
  $("#sa-password-form")?.addEventListener("submit", async (e) => {
    e.preventDefault(); const btn = $("#sa-password-btn");
    setBusy(btn, true, "Cambiando…");
    try { await api("/api/auth/password", { method: "POST", body: formObject(e.target) }); toast("Contraseña actualizada"); e.target.reset(); }
    catch (err) { toast(err.message, "error"); }
    finally { setBusy(btn, false); }
  });
  $("#correo-form")?.addEventListener("submit", async (e) => {
    e.preventDefault(); const btn = $("#correo-btn"); const data = formObject(e.target);
    setBusy(btn, true, "Guardando…");
    try { await api("/api/superadmin/correo", { method: "PUT", body: data }); toast("Configuración de correo guardada"); superadminAjustesPage("correo"); }
    catch (err) { setBusy(btn, false); toast(err.message, "error"); }
  });
  $("#correo-prueba")?.addEventListener("click", async (e) => {
    const btn = e.currentTarget; setBusy(btn, true, "Enviando…");
    try {
      const r = await api("/api/superadmin/correo/prueba", { method: "POST" });
      toast(r.estado === "enviado" ? `Prueba enviada a ${r.destino}` : "Sin servidor configurado: el mensaje se registró sin enviarse", r.estado === "enviado" ? "info" : "error");
    } catch (err) { toast(err.message, "error"); }
    finally { setBusy(btn, false); }
  });
  $("#web-form")?.addEventListener("submit", async (e) => {
    e.preventDefault(); const btn = $("#web-btn"); const data = formObject(e.target);
    setBusy(btn, true, "Guardando…");
    try { await api("/api/superadmin/landing", { method: "PUT", body: data }); toast("Guardado. La landing ya muestra los cambios."); superadminAjustesPage(tab); }
    catch (err) { setBusy(btn, false); toast(err.message, "error"); }
  });
  $("#dom-config")?.addEventListener("submit", async (e) => {
    e.preventDefault(); const btn = $("#dom-config-btn"); const data = formObject(e.target);
    setBusy(btn, true, "Guardando…");
    try { await api("/api/superadmin/dominios/config", { method: "PUT", body: data }); toast("Guardado"); superadminAjustesPage("dominios"); }
    catch (err) { setBusy(btn, false); toast(err.message, "error"); }
  });
  $$("[data-dom-accion]").forEach((b) => b.addEventListener("click", async () => {
    try { await api(`/api/superadmin/dominios/${b.dataset.domAccion}/accion`, { method: "POST", body: { accion: b.dataset.accion } }); toast("Hecho"); superadminAjustesPage("dominios"); }
    catch (err) { toast(err.message, "error"); }
  }));
  $$("[data-usuario]").forEach((chk) => chk.addEventListener("change", async () => {
    try { await api(`/api/superadmin/usuarios/${chk.dataset.usuario}`, { method: "PUT", body: { activo: chk.checked } }); toast(chk.checked ? "Usuario activado" : "Usuario desactivado"); }
    catch (err) { chk.checked = !chk.checked; toast(err.message, "error"); }
  }));
  $$("[data-editar-plan]").forEach((b) => b.addEventListener("click", () => {
    const p = (window.__PLANES || []).find((x) => x.id === b.dataset.editarPlan);
    const f = $("#plan-form"); if (!f || !p) return;
    f.nombre.value = p.nombre; f.precio.value = p.precio; f.descripcion.value = p.descripcion || ""; f.max_productos.value = p.max_productos;
    f.max_usuarios.value = p.max_usuarios; f.max_storage_mb.value = p.max_storage_mb; f.activo.value = p.activo ? "true" : "false"; f.plan_id.value = p.id;
    f.scrollIntoView({ behavior: "smooth" });
  }));
  $("#plan-form")?.addEventListener("submit", async (e) => {
    e.preventDefault(); const btn = $("#plan-btn"); const data = formObject(e.target);
    const id = data.plan_id; delete data.plan_id; data.activo = data.activo === "true";
    setBusy(btn, true, "Guardando…");
    try {
      if (id) await api(`/api/superadmin/planes/${id}`, { method: "PUT", body: data });
      else await api("/api/superadmin/planes", { method: "POST", body: data });
      toast("Plan guardado"); superadminAjustesPage("planes");
    } catch (err) { setBusy(btn, false); toast(err.message, "error"); }
  });
  $$("[data-editar-sus]").forEach((b) => b.addEventListener("click", () => {
    const f = $("#sus-form"); if (!f) return;
    f.plan_id.value = b.dataset.plan; f.estado.value = b.dataset.estado; f.fecha_fin.value = b.dataset.fin;
    f.suscripcion_id.value = b.dataset.editarSus; f.tienda_id.disabled = true; f.scrollIntoView({ behavior: "smooth" });
  }));
  $("#sus-form")?.addEventListener("submit", async (e) => {
    e.preventDefault(); const btn = $("#sus-btn"); const f = e.target; const data = formObject(f);
    const id = data.suscripcion_id; delete data.suscripcion_id; data.tienda_id = f.tienda_id.value;
    setBusy(btn, true, "Guardando…");
    try {
      if (id) await api(`/api/superadmin/suscripciones/${id}`, { method: "PUT", body: data });
      else await api("/api/superadmin/suscripciones", { method: "POST", body: data });
      toast("Suscripción guardada"); superadminAjustesPage("suscripciones");
    } catch (err) { setBusy(btn, false); toast(err.message, "error"); }
  });
  $("#limite-form")?.addEventListener("submit", async (e) => {
    e.preventDefault(); const btn = $("#limite-btn"); const data = formObject(e.target);
    setBusy(btn, true, "Guardando…");
    try { await api(`/api/superadmin/tiendas/${data.tienda_id}/limite-admins`, { method: "PUT", body: { max_admins: Number(data.max_admins) } }); toast("Límite guardado"); superadminAjustesPage("tiendas"); }
    catch (err) { setBusy(btn, false); toast(err.message, "error"); }
  });
  $$("[data-estado-tienda]").forEach((b) => b.addEventListener("click", async () => {
    const ok = await confirmDialog({ title: b.dataset.nuevo === "suspendida" ? "Suspender tienda" : "Activar tienda", message: b.dataset.nuevo === "suspendida" ? "La tienda dejará de estar disponible para sus clientes y su equipo no podrá entrar al panel." : "La tienda volverá a estar disponible.", danger: b.dataset.nuevo === "suspendida", confirmText: "Confirmar" });
    if (!ok) return;
    try { await api(`/api/superadmin/tiendas/${b.dataset.estadoTienda}/estado`, { method: "PUT", body: { estado: b.dataset.nuevo } }); toast("Estado actualizado"); superadminAjustesPage("tiendas"); }
    catch (err) { toast(err.message, "error"); }
  }));
}

// ============================== SOPORTE (CC) ==============================
// Mismo modelo que CC Pro: conversaciones (chat) y tickets (incidencia, mejora o feedback).
// Lado tienda: admin de la tienda. Lado plataforma: superadmin. Una sola pantalla de hilo.

const TIPOS_TICKET = [["incidencia", "Incidencia"], ["mejora", "Mejora"], ["feedback", "Feedback"]];
const ESTADOS_TICKET_UI = [["recibido", "Recibido"], ["en_proceso", "En proceso"], ["resuelto", "Resuelto"]];
const SONDEO_MS = 5000;

function soporteEtiquetaTicket(e) { return ({ recibido: "Recibido", en_proceso: "En proceso", resuelto: "Resuelto" })[e] || e; }

function burbujasHilo(mensajes, rol) {
  // rol: "tienda" o "plataforma". Los mensajes de tickets usan «centro/ccpro»; los de chat «tienda/plataforma».
  const propio = (m) => rol === "tienda" ? ["centro", "tienda"].includes(m.autor_rol) : ["ccpro", "plataforma"].includes(m.autor_rol);
  const quien = (m) => propio(m) ? "Tú" : (rol === "tienda" ? "CC" : "Tienda");
  const cuerpo = (m) => m.texto ?? m.cuerpo ?? "";
  return mensajes.map((m) => `<div class="chat-msg ${propio(m) ? "is-mine" : ""}">
    <div class="chat-meta tiny muted">${quien(m)} · ${fmtDateTime(m.created_at)}</div>
    <div class="chat-text">${esc(cuerpo(m))}</div>
  </div>`).join("") || `<p class="tiny muted">Todavía no hay mensajes.</p>`;
}

function filaLista(href, principal, detalle, badges = "") {
  return `<div class="soporte-fila is-clickable" data-href="${href}"><div class="soporte-fila-main"><strong>${esc(principal)}</strong><div class="tiny muted">${detalle}</div></div><div class="soporte-fila-badges">${badges}</div></div>`;
}

async function soportePage(historial = false) {
  SONDEO_FIRMA = "";
  render(loadingBlock("Cargando soporte…"), "Soporte");
  const [tickets, convs, cats] = await Promise.all([
    api("/api/admin/soporte/tickets", { query: historial ? { historial: 1 } : {} }),
    api("/api/admin/soporte/conversaciones", { query: historial ? { historial: 1 } : {} }),
    api("/api/admin/soporte/categorias"),
  ]);
  const cats_ = cats.items || [];
  const lista_t = tickets.items.map((t) => filaLista(
    `#/soporte/ticket/${encodeURIComponent(t.id)}`, t.asunto,
    `${esc(t.categoria_nombre || "")} · ${TIPOS_TICKET.find(([k]) => k === t.tipo)?.[1] || t.tipo} · ${fmtDateTime(t.updated_at)}`,
    `${t.sin_leer_tienda ? '<span class="badge badge--warn">Respuesta nueva</span>' : ""}<span class="badge">${esc(soporteEtiquetaTicket(t.estado))}</span>`)).join("")
    || `<p class="tiny muted">${historial ? "Sin tickets en el historial." : "No tienes tickets abiertos."}</p>`;
  const lista_c = convs.items.map((c) => filaLista(
    `#/soporte/conv/${encodeURIComponent(c.id)}`, c.asunto, `${number(c.mensajes)} mensajes · ${fmtDateTime(c.updated_at)}`,
    `<span class="badge ${c.estado === "cerrada" ? "" : "badge--ok"}">${c.estado === "cerrada" ? "Cerrada" : "Abierta"}</span>`)).join("")
    || `<p class="tiny muted">${historial ? "Sin conversaciones en el historial." : "No tienes conversaciones abiertas."}</p>`;
  render(`${pageHead("Soporte", "Tickets para incidencias, mejoras y feedback. Conversaciones para dudas rápidas.")}
  <div class="chip-row" style="margin-bottom:12px">
    <a class="chip ${historial ? "" : "is-active"}" href="#/soporte">Activos</a>
    <a class="chip ${historial ? "is-active" : ""}" href="#/soporte?historial=1">Historial</a>
  </div>
  <div class="grid-2" style="gap:14px;align-items:start">
    <div class="admin-card">
      <div class="admin-card-head"><h3>Incidencias y tickets</h3><button class="btn btn-primary btn-sm" id="btn-reportar">${icon("plus", 14)} Reportar</button></div>
      <div class="soporte-lista">${lista_t}</div>
    </div>
    <div class="admin-card">
      <div class="admin-card-head"><h3>Conversaciones</h3><button class="btn btn-primary btn-sm" id="btn-conv">${icon("plus", 14)} Nueva conversación</button></div>
      <div class="soporte-lista">${lista_c}</div>
    </div>
  </div>`, "Soporte");
  $$("[data-href]").forEach((el) => el.addEventListener("click", () => { location.hash = el.dataset.href; }));
  $("#btn-reportar").addEventListener("click", () => abrirReportar(cats_));
  $("#btn-conv").addEventListener("click", abrirNuevaConversacion);
  if (!historial) iniciarSondeoSoporte("tienda");
}

function abrirReportar(cats) {
  openModal({
    title: "Reportar",
    body: `<form id="rep-form" class="admin-form-grid" novalidate>
      <div class="field"><label>Tipo</label><select class="select" name="tipo">${TIPOS_TICKET.map(([k, v]) => `<option value="${k}">${v}</option>`).join("")}</select></div>
      <div class="field"><label>Categoría</label><select class="select" name="categoria_id">${cats.map((c) => `<option value="${esc(c.id)}">${esc(c.nombre)}</option>`).join("")}</select></div>
      <div class="field full"><label>Asunto</label><input class="input" name="asunto" maxlength="160" required></div>
      <div class="field full"><label>Descripción</label><textarea class="textarea" name="descripcion" rows="5" maxlength="4000" required></textarea></div>
    </form>`,
    footer: `<button class="btn btn-outline btn-sm" data-cancel>Cancelar</button><button class="btn btn-primary btn-sm" id="rep-btn">Enviar</button>`,
    onMount: (el, close) => {
      el.querySelector("[data-cancel]").addEventListener("click", close);
      el.querySelector("#rep-btn").addEventListener("click", async () => {
        const btn = el.querySelector("#rep-btn");
        setBusy(btn, true, "Enviando…");
        try {
          const r = await api("/api/admin/soporte/tickets", { method: "POST", body: formObject(el.querySelector("#rep-form")) });
          close(); toast("Ticket enviado"); location.hash = `#/soporte/ticket/${encodeURIComponent(r.id)}`;
        } catch (err) { setBusy(btn, false); toast(err.message, "error"); }
      });
    },
  });
}

function abrirNuevaConversacion() {
  openModal({
    title: "Nueva conversación",
    body: `<form id="conv-form" class="admin-form-grid" novalidate>
      <div class="field full"><label>Asunto</label><input class="input" name="asunto" maxlength="160" required></div>
      <div class="field full"><label>Primer mensaje <span class="muted">(opcional)</span></label><textarea class="textarea" name="mensaje" rows="4" maxlength="2000"></textarea></div>
    </form>`,
    footer: `<button class="btn btn-outline btn-sm" data-cancel>Cancelar</button><button class="btn btn-primary btn-sm" id="conv-btn">Crear</button>`,
    onMount: (el, close) => {
      el.querySelector("[data-cancel]").addEventListener("click", close);
      el.querySelector("#conv-btn").addEventListener("click", async () => {
        const btn = el.querySelector("#conv-btn");
        setBusy(btn, true, "Creando…");
        try {
          const r = await api("/api/admin/soporte/conversaciones", { method: "POST", body: formObject(el.querySelector("#conv-form")) });
          close(); location.hash = `#/soporte/conv/${encodeURIComponent(r.id)}`;
        } catch (err) { setBusy(btn, false); toast(err.message, "error"); }
      });
    },
  });
}

async function soporteHilo(rol, tipo, id) {
  // rol: "tienda" | "plataforma"; tipo: "ticket" | "conv"
  const base = rol === "tienda" ? "/api/admin/soporte" : "/api/superadmin/soporte";
  const volver = rol === "tienda" ? "#/soporte" : "#/superadmin/soporte";
  const url = tipo === "ticket" ? `${base}/tickets/${encodeURIComponent(id)}` : `${base}/conversaciones/${encodeURIComponent(id)}`;
  const d = await api(url);
  const cabecera = tipo === "ticket" ? d : d.conversacion;
  const mensajes = d.mensajes;
  const cerrado = tipo === "conv" ? cabecera.estado === "cerrada" : false;
  const oculto = tipo === "ticket" ? !!cabecera.oculto_tienda : !!cabecera.oculta_tienda;
  const controles = rol === "plataforma" && tipo === "ticket"
    ? `<select class="select" id="estado-sel" style="max-width:200px">${ESTADOS_TICKET_UI.map(([k, v]) => `<option value="${k}" ${cabecera.estado === k ? "selected" : ""}>${v}</option>`).join("")}</select>`
    : rol === "plataforma"
      ? `<select class="select" id="estado-sel" style="max-width:200px"><option value="abierta" ${cabecera.estado === "abierta" ? "selected" : ""}>Abierta</option><option value="cerrada" ${cabecera.estado === "cerrada" ? "selected" : ""}>Cerrada</option></select>`
      : `<button class="btn btn-outline btn-sm" id="oculto-btn">${oculto ? "Mostrar en activas" : "Ocultar (mover al historial)"}</button>`;
  const meta = tipo === "ticket"
    ? `${esc(TIPOS_TICKET.find(([k]) => k === cabecera.tipo)?.[1] || cabecera.tipo)} · ${esc(cabecera.categoria_nombre || "")}${rol === "plataforma" ? ` · Tienda: ${esc(cabecera.tienda_nombre || "")}` : ""}`
    : rol === "plataforma" ? `Tienda: ${esc(cabecera.tienda_nombre || "")}` : "";
  const avisos = rol === "plataforma" && tipo === "ticket" && cabecera.sin_leer_tienda ? `<p class="tiny muted">Pendiente de lectura por el centro</p>` : "";
  render(`${pageHead(cabecera.asunto, meta, `<a class="btn btn-outline btn-sm" href="${volver}">${icon("arrowLeft", 14)} Volver</a>`)}
  ${avisos}
  <div class="admin-card">
    <div class="admin-card-head"><h3>Conversación</h3>${controles}</div>
    <div class="chat" id="chat-box">${burbujasHilo(mensajes, rol)}</div>
    ${cerrado && rol === "tienda" ? `<p class="tiny muted">Esta conversación está cerrada. Si escribes, se reabre.</p>` : ""}
    <form id="chat-form" class="chat-form"><textarea class="textarea" name="texto" rows="2" maxlength="2000" placeholder="Escribe tu mensaje…" required></textarea>
      <button class="btn btn-primary btn-sm" type="submit" id="chat-btn">${icon("send", 14)} Enviar</button></form>
  </div>`, "Soporte");

  $("#estado-sel")?.addEventListener("change", async (e) => {
    try {
      const body = { estado: e.target.value };
      await api(tipo === "ticket" ? `${base}/tickets/${encodeURIComponent(id)}` : `${base}/conversaciones/${encodeURIComponent(id)}`, { method: "PUT", body });
      toast("Estado actualizado");
    } catch (err) { toast(err.message, "error"); }
  });
  $("#oculto-btn")?.addEventListener("click", async () => {
    try {
      const body = tipo === "ticket" ? { oculto: !oculto } : { oculta: !oculto };
      await api(url, { method: "PUT", body });
      location.hash = volver;
    } catch (err) { toast(err.message, "error"); }
  });
  $("#chat-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const texto = e.target.texto.value.trim();
    if (!texto) return;
    const btn = $("#chat-btn");
    setBusy(btn, true, "Enviando…");
    try {
      const cuerpo = tipo === "ticket" ? { texto } : { cuerpo: texto };
      await api(`${url}/mensajes`, { method: "POST", body: cuerpo });
      e.target.reset();
      await refrescarHilo(url, rol);
    } catch (err) { toast(err.message, "error"); }
    finally { setBusy(btn, false); }
  });
  iniciarSondeoHilo(base, tipo, id, url, rol);
}

async function refrescarHilo(url, rol) {
  const d = await api(url);
  const mensajes = d.mensajes;
  const caja = $("#chat-box");
  if (caja) caja.innerHTML = burbujasHilo(mensajes, rol);
  return d;
}

// Sondeo ligero: solo se vuelve a pedir algo cuando la huella cambia; se pausa con la pestaña oculta.
let SONDEO_FIRMA = "";
function iniciarSondeoSoporte(rol) {
  if (CHAT_TIMER) clearInterval(CHAT_TIMER);
  const base = rol === "tienda" ? "/api/admin/soporte" : "/api/superadmin/soporte";
  const seccion = rol === "tienda" ? "#/soporte" : "#/superadmin/soporte";
  CHAT_TIMER = setInterval(async () => {
    if (document.hidden) return;
    if (!location.hash.startsWith(seccion) || /\/(conv|ticket)\//.test(location.hash)) return clearInterval(CHAT_TIMER);
    try {
      const v = await api(`${base}/estado`);
      if (SONDEO_FIRMA && v.listas !== SONDEO_FIRMA) { SONDEO_FIRMA = v.listas; return route(); }
      SONDEO_FIRMA = v.listas;
    } catch { /* reintenta en el siguiente ciclo */ }
  }, SONDEO_MS);
}

function iniciarSondeoHilo(base, tipo, id, url, rol) {
  if (CHAT_TIMER) clearInterval(CHAT_TIMER);
  let firma = null;
  CHAT_TIMER = setInterval(async () => {
    if (document.hidden) return;
    if (!$("#chat-box")) return clearInterval(CHAT_TIMER);
    try {
      const q = tipo === "ticket" ? { ticket: id } : { conv: id };
      const v = await api(`${base}/estado`, { query: q });
      if (firma !== null && v.hilo !== firma) await refrescarHilo(url, rol);
      firma = v.hilo;
    } catch { /* reintenta */ }
  }, SONDEO_MS);
}

async function superadminSoportePage(tab = "conversaciones", historial = false, estado = "") {
  SONDEO_FIRMA = "";
  render(loadingBlock("Cargando soporte…"), "Soporte");
  const tabs = [["conversaciones", "Conversaciones"], ["tickets", "Tickets"], ["categorias", "Categorías"]];
  const cabeceraTabs = `<div class="chip-row" style="margin-bottom:12px">${tabs.map(([k, t]) => `<a class="chip ${tab === k ? "is-active" : ""}" href="#/superadmin/soporte?tab=${k}">${t}</a>`).join("")}</div>`;
  if (tab === "categorias") {
    const cats = (await api("/api/superadmin/soporte/categorias", { query: { todas: 1 } })).items;
    render(`${pageHead("Soporte", "Categorías de tickets. Una categoría desactivada deja de admitir tickets nuevos.")}${cabeceraTabs}
    <div class="admin-card" style="padding:0;margin-bottom:14px"><div class="table-wrap"><table class="table admin-table">
      <thead><tr><th>Categoría</th><th>Activa</th></tr></thead>
      <tbody>${cats.map((c) => `<tr><td>${esc(c.nombre)}</td><td><input type="checkbox" data-cat="${esc(c.id)}" ${c.activo ? "checked" : ""}></td></tr>`).join("")}</tbody>
    </table></div></div>
    <div class="admin-card"><div class="admin-card-head"><h3>Nueva categoría</h3></div>
      <form id="cat-nueva" class="row" style="gap:8px"><input class="input" name="nombre" maxlength="160" placeholder="Nombre" required><button class="btn btn-primary btn-sm" type="submit">${icon("plus", 14)} Añadir</button></form></div>`, "Soporte");
    $$("[data-cat]").forEach((chk) => chk.addEventListener("change", async () => {
      try { await api(`/api/superadmin/soporte/categorias/${chk.dataset.cat}`, { method: "PUT", body: { activa: chk.checked } }); toast("Categoría actualizada"); }
      catch (err) { chk.checked = !chk.checked; toast(err.message, "error"); }
    }));
    $("#cat-nueva").addEventListener("submit", async (e) => {
      e.preventDefault();
      try { await api("/api/superadmin/soporte/categorias", { method: "POST", body: formObject(e.target) }); toast("Categoría creada"); superadminSoportePage("categorias"); }
      catch (err) { toast(err.message, "error"); }
    });
    return;
  }
  if (tab === "tickets") {
    const d = await api("/api/superadmin/soporte/tickets", { query: { ...(historial ? { historial: 1 } : {}), ...(estado ? { estado } : {}) } });
    const filtros = `<div class="chip-row" style="margin-bottom:10px">
      <a class="chip ${!historial && !estado ? "is-active" : ""}" href="#/superadmin/soporte?tab=tickets">Activos</a>
      ${ESTADOS_TICKET_UI.map(([k, v]) => `<a class="chip ${estado === k ? "is-active" : ""}" href="#/superadmin/soporte?tab=tickets&estado=${k}">${v}</a>`).join("")}
      <a class="chip ${historial ? "is-active" : ""}" href="#/superadmin/soporte?tab=tickets&historial=1">Historial</a></div>`;
    const lista = d.items.map((t) => filaLista(
      `#/superadmin/soporte/ticket/${encodeURIComponent(t.id)}`, t.asunto,
      `${esc(t.tienda_nombre)} · ${esc(t.categoria_nombre || "")} · ${fmtDateTime(t.updated_at)}`,
      `${t.sin_leer_plataforma ? '<span class="badge badge--warn">Nuevo mensaje</span>' : ""}${t.sin_leer_tienda ? '<span class="badge">Pendiente de lectura</span>' : ""}<span class="badge">${esc(soporteEtiquetaTicket(t.estado))}</span>`)).join("")
      || `<p class="tiny muted">Sin tickets.</p>`;
    render(`${pageHead("Soporte", "Tickets de las tiendas y conversaciones de soporte.")}${cabeceraTabs}${filtros}<div class="admin-card"><div class="soporte-lista">${lista}</div></div>`, "Soporte");
  } else {
    const d = await api("/api/superadmin/soporte/conversaciones", { query: historial ? { historial: 1 } : {} });
    const chips = `<div class="chip-row" style="margin-bottom:10px">
      <a class="chip ${!historial ? "is-active" : ""}" href="#/superadmin/soporte?tab=conversaciones">Activas</a>
      <a class="chip ${historial ? "is-active" : ""}" href="#/superadmin/soporte?tab=conversaciones&historial=1">Historial</a></div>`;
    const lista = d.items.map((c) => filaLista(
      `#/superadmin/soporte/conv/${encodeURIComponent(c.id)}`, c.asunto, `${esc(c.tienda_nombre)} · ${number(c.mensajes)} mensajes · ${fmtDateTime(c.updated_at)}`,
      `<span class="badge ${c.estado === "cerrada" ? "" : "badge--ok"}">${c.estado === "cerrada" ? "Cerrada" : "Abierta"}</span>`)).join("")
      || `<p class="tiny muted">Sin conversaciones.</p>`;
    render(`${pageHead("Soporte", "Conversaciones con las tiendas.")}${cabeceraTabs}${chips}<div class="admin-card"><div class="soporte-lista">${lista}</div></div>`, "Soporte");
  }
  $$("[data-href]").forEach((el) => el.addEventListener("click", () => { location.hash = el.dataset.href; }));
  iniciarSondeoSoporte("plataforma");
}

function parseHash() { const raw = (location.hash || "#/").replace(/^#/, ""); const [path, qs] = raw.split("?"); return { path: path || "/", params: new URLSearchParams(qs || "") }; }

async function route() {
  const { path, params } = parseHash();
  if (CHAT_TIMER) { clearInterval(CHAT_TIMER); CHAT_TIMER = null; }
  currentPath = path;
  if (path === "/registro") {
    if (ME) { location.hash = "#/"; return; }
    registroTiendaPage(); return;
  }
  // auth guard
  if (ME && PANTALLAS_POR_ROL[ME.rol] && !PANTALLAS_POR_ROL[ME.rol].re.test(path)) {
    location.hash = PANTALLAS_POR_ROL[ME.rol].inicio; return;
  }
  if (path === "/login") {
    if (ME) { location.hash = "#/"; return; }
    loginPage(); return;
  }
  if (!ME) {
    // try restore
    try { const r = await api("/api/auth/me"); ME = r.usuario; } catch { ME = null; }
    if (!ME) { location.hash = "#/login"; return; }
  }
  if (path === "/" || path === "") return dashboardPage();
  if (path === "/metricas") return metricsPage(params);
  if (path === "/productos") return productsPage(params);
  if (path.startsWith("/productos/")) {
    const id = decodeURIComponent(path.slice("/productos/".length));
    if (id === "nuevo") return newPurchasePage(); // placeholder, not used
    return openKardexModal(id);
  }
  if (path === "/categorias") return categoriesPage();
  if (path === "/inventario") return inventoryPage();
  if (path === "/movimientos") return movementsPage(params);
  if (path === "/ruta") return rutaPage();
  if (path === "/clientes") return clientesPage();
  if (path.startsWith("/clientes/")) return clienteDetallePage(decodeURIComponent(path.slice("/clientes/".length)));
  if (path.startsWith("/ruta/")) return rutaDetallePage(decodeURIComponent(path.slice("/ruta/".length)));
  if (path === "/equipo") return equipoPage();
  if (path === "/pedidos") return ordersPage(params);
  if (path === "/pagos") return pagosPage();
  if (path.startsWith("/pedidos/")) {
    const id = decodeURIComponent(path.slice("/pedidos/".length));
    return orderDetailPage(id);
  }
  if (path === "/compras") return purchasesPage(params);
  if (path === "/compras/nueva") return newPurchasePage();
  if (path.startsWith("/compras/")) {
    const id = decodeURIComponent(path.slice("/compras/".length));
    return purchaseDetailPage(id);
  }
  if (path === "/proveedores") return suppliersPage();
  if (path === "/ajustes") return settingsPage();
  if (path === "/ajustes/dominio") return dominioPage();
  if (path === "/superadmin") return superadminPage();
  if (path === "/superadmin/soporte") return superadminSoportePage(params.get("tab") || "conversaciones", params.get("historial") === "1", params.get("estado") || "");
  if (path.startsWith("/superadmin/soporte/conv/")) return soporteHilo("plataforma", "conv", decodeURIComponent(path.slice("/superadmin/soporte/conv/".length)));
  if (path.startsWith("/superadmin/soporte/ticket/")) return soporteHilo("plataforma", "ticket", decodeURIComponent(path.slice("/superadmin/soporte/ticket/".length)));
  if (path === "/superadmin/ajustes") return superadminAjustesPage(params.get("tab") || "correo");
  if (path === "/soporte") return soportePage(params.get("historial") === "1");
  if (path.startsWith("/soporte/conv/")) return soporteHilo("tienda", "conv", decodeURIComponent(path.slice("/soporte/conv/".length)));
  if (path.startsWith("/soporte/ticket/")) return soporteHilo("tienda", "ticket", decodeURIComponent(path.slice("/soporte/ticket/".length)));
  if (path === "/logout") { try { await api("/api/auth/logout", { method: "POST" }); } catch {} ME = null; location.hash = "#/login"; return; }
  // default
  dashboardPage();
}

async function boot() {
  try { const r = await api("/api/auth/me"); ME = r.usuario; } catch { ME = null; }
  if (ME) { await cargarAjustesAdmin(); iniciarNotificaciones(); }
  try { const c = await api("/api/admin/categorias"); CATEGORIAS = c.items || []; } catch { CATEGORIAS = []; }
  window.addEventListener("hashchange", route);
  if (!location.hash) location.hash = !ME ? "#/login" : ME.rol === "superadmin" ? "#/superadmin" : "#/";
  await route();
}

boot();
