import { ICONOS_CATEGORIA } from "./iconos.js";
/* CC-Shops · utilidades compartidas de la tienda y el backoffice */
export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

const ESCAPES = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };
export function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, (c) => ESCAPES[c]);
}

export function money(value, { decimals = true } = {}) {
  const n = Number(value || 0);
  return new Intl.NumberFormat("es-ES", {
    style: "currency", currency: "EUR",
    minimumFractionDigits: decimals ? 2 : 0,
    maximumFractionDigits: decimals ? 2 : 0,
  }).format(Number.isFinite(n) ? n : 0);
}

export function number(value, decimals = 0) {
  return new Intl.NumberFormat("es-ES", {
    minimumFractionDigits: decimals, maximumFractionDigits: decimals,
  }).format(Number(value || 0));
}

export function fmtDate(iso) {
  if (!iso) return "—";
  const d = new Date(String(iso).length <= 10 ? `${iso}T12:00:00` : iso);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleDateString("es-ES", { day: "2-digit", month: "2-digit", year: "numeric" });
}

export function fmtDateTime(iso) {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  return `${d.toLocaleDateString("es-ES", { day: "2-digit", month: "2-digit", year: "numeric" })} · ${d.toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" })}`;
}

export function fmtRelative(iso) {
  if (!iso) return "—";
  const d = new Date(iso);
  const min = Math.floor((Date.now() - d.getTime()) / 60000);
  if (min < 1) return "ahora";
  if (min < 60) return `hace ${min} min`;
  const h = Math.floor(min / 60);
  if (h < 24) return `hace ${h} h`;
  const dias = Math.floor(h / 24);
  if (dias === 1) return "ayer";
  if (dias < 30) return `hace ${dias} días`;
  return fmtDate(iso);
}

export function parseMoney(value) {
  // Con coma decimal (formato español): los puntos son miles y la coma es el decimal.
  // Sin coma: el punto es el decimal (así lo envían los campos numéricos, p. ej. «24.5»).
  let limpio = String(value ?? "").replace(/[\s€]/g, "");
  if (limpio.includes(",")) limpio = limpio.replace(/\./g, "").replace(",", ".");
  const n = Number(limpio);
  return Number.isFinite(n) ? n : 0;
}

export function initials(name) {
  return String(name || "?").trim().split(/\s+/).slice(0, 2).map((p) => p[0]).join("").toUpperCase();
}

export function debounce(fn, ms = 280) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
}

/* --------------------------------- API ---------------------------------- */
export async function api(path, { method = "GET", body, query } = {}) {
  let url = path;
  if (query) {
    const params = new URLSearchParams();
    Object.entries(query).forEach(([k, v]) => { if (v !== undefined && v !== null && v !== "") params.set(k, v); });
    const qs = params.toString();
    if (qs) url += `${url.includes("?") ? "&" : "?"}${qs}`;
  }
  const headers = { "X-CC-Request": "1" };
  const tienda = new URLSearchParams(location.search).get("tienda");
  if (tienda && !/^\/api\/(admin|auth|superadmin)\//.test(path)) headers["X-Tienda"] = tienda;
  if (body !== undefined) headers["Content-Type"] = "application/json";
  let res;
  try {
    res = await fetch(url, {
      method, headers, credentials: "same-origin",
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new Error("No hay conexión con el servidor. Revisa tu red e inténtalo de nuevo.");
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(data.error || `Error ${res.status}`);
    err.status = res.status;
    err.campo = data.campo;
    throw err;
  }
  return data;
}

/* --------------------------------- Iconos -------------------------------- */
const ICONS = {
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.2-3.2"/>',
  cart: '<circle cx="9" cy="20" r="1.4"/><circle cx="18" cy="20" r="1.4"/><path d="M3 4h2l2.2 11.2a2 2 0 0 0 2 1.6h7.7a2 2 0 0 0 2-1.6L21 8H6"/>',
  menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
  close: '<path d="m6 6 12 12M18 6 6 18"/>',
  arrowRight: '<path d="M4 12h16m-6-6 6 6-6 6"/>',
  arrowLeft: '<path d="M20 12H4m6-6-6 6 6 6"/>',
  chevronDown: '<path d="m6 9 6 6 6-6"/>',
  chevronRight: '<path d="m9 6 6 6-6 6"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  minus: '<path d="M5 12h14"/>',
  trash: '<path d="M4 7h16M9 7V4h6v3m-8 0 1 13h8l1-13M10 11v5M14 11v5"/>',
  edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/>',
  check: '<path d="m4 12 5 5L20 6"/>',
  checkCircle: '<circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/>',
  truck: '<path d="M3 6h11v11H3zM14 9h4l3 3v5h-7z"/><circle cx="7" cy="18" r="1.8"/><circle cx="18" cy="18" r="1.8"/>',
  shield: '<path d="M12 3 4 6v5c0 5 3.4 8.4 8 10 4.6-1.6 8-5 8-10V6Z"/><path d="m9 12 2 2 4-4"/>',
  card: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 10h18"/>',
  lock: '<rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
  package: '<path d="m12 3 8 4.5v9L12 21l-8-4.5v-9Z"/><path d="m4 7.5 8 4.5 8-4.5M12 12v9"/>',
  layers: '<path d="m12 3 9 5-9 5-9-5Z"/><path d="m3 12 9 5 9-5M3 16l9 5 9-5"/>',
  box: '<path d="M4 8h16v12H4z"/><path d="M4 8l2-4h12l2 4M9 8v3h6V8"/>',
  tag: '<path d="M20 13 13 20 3 10V3h7l10 10Z"/><circle cx="7.2" cy="7.2" r="1.2"/>',
  droplet: '<path d="M12 3s6 6.3 6 10.5A6 6 0 0 1 6 13.5C6 9.3 12 3 12 3Z"/>',
  spray: '<path d="M9 8h7v13H9zM12 8V5h4M16 3h1M19 5h1M18 8h1"/><path d="M9 12h7"/>',
  glove: '<path d="M7 12V6a2 2 0 0 1 4 0v5M11 11V4a2 2 0 0 1 4 0v7M15 11V6a2 2 0 0 1 4 0v8c0 4-3 7-7 7h-1c-3 0-5-2-5-5l-1-4a2 2 0 0 1 4-1"/>',
  sparkles: '<path d="m12 3 1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8ZM19 16l.8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8Z"/>',
  chart: '<path d="M4 20V10M10 20V4M16 20v-7M22 20V7"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.5V21h-4v-.1a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.5-1H3v-4h.1a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1a1.7 1.7 0 0 0 1.9.3 1.7 1.7 0 0 0 1-1.5V3h4v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.5 1h.1v4h-.1a1.7 1.7 0 0 0-1.5 1Z"/>',
  logout: '<path d="M10 4H5v16h5M14 8l4 4-4 4M8 12h10"/>',
  users: '<circle cx="9" cy="8" r="3"/><path d="M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6M16 5a3 3 0 0 1 0 6M18 14c2.3.6 4 2.8 4 6"/>',
  file: '<path d="M6 3h8l4 4v14H6z"/><path d="M14 3v5h5M9 13h6M9 17h6"/>',
  download: '<path d="M12 3v12m-4-4 4 4 4-4M4 20h16"/>',
  alert: '<path d="M12 3 2.5 20h19Z"/><path d="M12 9v5M12 17h.01"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  filter: '<path d="M3 5h18l-7 8v6l-4 2v-8Z"/>',
  printer: '<path d="M6 9V3h12v6M6 18H4v-7h16v7h-2"/><path d="M6 14h12v7H6z"/>',
  refresh: '<path d="M20 11a8 8 0 1 0-2.3 5.7M20 4v7h-7"/>',
  external: '<path d="M14 4h6v6M20 4 11 13M10 5H5v14h14v-5"/>',
  mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
  phone: '<path d="M5 3h4l2 5-2 2a14 14 0 0 0 5 5l2-2 5 2v4a2 2 0 0 1-2 2A18 18 0 0 1 3 5a2 2 0 0 1 2-2Z"/>',
  pin: '<path d="M12 21s7-6.2 7-11a7 7 0 1 0-14 0c0 4.8 7 11 7 11Z"/><circle cx="12" cy="10" r="2.5"/>',
  grid: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
  list: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
  eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
  copy: '<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1"/>',
  database: '<ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v14c0 1.7 3.6 3 8 3s8-1.3 8-3V5M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/>',
  calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  home: '<path d="m3 11 9-8 9 8M5 10v10h14V10M9 20v-6h6v6"/>',
  help: '<circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 1 1 3.4 2.3c-.6.3-.9.9-.9 1.6v1M12 17h.01"/>',
  more: '<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>',
  send: '<path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/>',
  credit: '<rect x="2" y="5" width="20" height="14" rx="3"/><path d="M2 10h20M6 15h4"/>',
  bell: '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/>',
  ruler: '<path d="M3 17 17 3l4 4L7 21Z"/><path d="m7 13 2 2M10 10l2 2M13 7l2 2"/>',
  archive: '<rect x="3" y="4" width="18" height="5" rx="1"/><path d="M5 9v11h14V9M10 13h4"/>',
  image: '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="M21 16l-5-5-8 8"/>',
  camera: '<path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>',
  upload: '<path d="M12 16V4M7 9l5-5 5 5"/><path d="M4 16v3a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-3"/>',
};

export function icon(name, size = 20, stroke = 1.8) {
  const path = ICONS[name] || ICONS.help;
  return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="${stroke}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${path}</svg>`;
}

const ALIAS_ICONO = { drop: "droplet" }; // valores antiguos de categorías
const MAPA_ICONOS = new Map(ICONOS_CATEGORIA.map((i) => [i.id, i]));

// Temas visuales válidos (los mismos que config.TEMAS del servidor).
export const TEMAS_VALIDOS = ["clasico", "tech", "moda", "belleza", "mascotas", "hogar", "deporte", "gourmet"];
export function aplicarTema(tema) {
  document.documentElement.dataset.theme = TEMAS_VALIDOS.includes(tema) ? tema : "clasico";
}

export function iconoCategoria(id) {
  return MAPA_ICONOS.get(ALIAS_ICONO[id] || id) || MAPA_ICONOS.get("box");
}

export function categoryIcon(name, size = 20) {
  const i = iconoCategoria(name);
  return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${i.svg}</svg>`;
}

/* --------------------------------- Toasts -------------------------------- */
export function toast(message, type = "success", timeout = 3800) {
  const root = $("#toasts");
  if (!root) return;
  const el = document.createElement("div");
  el.className = `toast toast--${type}`;
  el.innerHTML = `${icon(type === "error" ? "alert" : type === "warn" ? "alert" : "checkCircle", 18)}<div>${esc(message)}</div>`;
  root.appendChild(el);
  setTimeout(() => {
    el.classList.add("is-out");
    setTimeout(() => el.remove(), 220);
  }, timeout);
}

/* --------------------------------- Modal --------------------------------- */
let modalCloseHandler = null;

export function openModal({ title = "", subtitle = "", body = "", footer = "", wide = false, xl = false, onMount } = {}) {
  closeModal();
  const root = $("#modal-root");
  const backdrop = document.createElement("div");
  backdrop.className = "modal-backdrop";
  backdrop.innerHTML = `
    <div class="modal ${xl ? "modal--xl" : wide ? "modal--wide" : ""}" role="dialog" aria-modal="true" aria-label="${esc(title)}">
      <div class="modal-head">
        <h2>${esc(title)}</h2>
        ${subtitle ? `<p>${esc(subtitle)}</p>` : ""}
        <button class="modal-close" type="button" aria-label="Cerrar">${icon("close", 18)}</button>
      </div>
      <div class="modal-body">${body}</div>
      ${footer ? `<div class="modal-foot">${footer}</div>` : ""}
    </div>`;
  root.appendChild(backdrop);
  document.body.classList.add("no-scroll");
  const close = () => closeModal();
  backdrop.addEventListener("mousedown", (e) => { if (e.target === backdrop) close(); });
  backdrop.querySelector(".modal-close").addEventListener("click", close);
  const onKey = (e) => { if (e.key === "Escape") close(); };
  document.addEventListener("keydown", onKey);
  modalCloseHandler = () => {
    document.removeEventListener("keydown", onKey);
    backdrop.remove();
    document.body.classList.remove("no-scroll");
    modalCloseHandler = null;
  };
  if (onMount) onMount(backdrop, close);
  const focusable = backdrop.querySelector("input, select, textarea, button");
  if (focusable) setTimeout(() => focusable.focus(), 50);
  return close;
}

export function closeModal() {
  if (modalCloseHandler) modalCloseHandler();
}

export function confirmDialog({ title = "¿Seguro?", message = "", confirmText = "Confirmar", cancelText = "Cancelar", danger = false } = {}) {
  return new Promise((resolve) => {
    const close = openModal({
      title,
      body: `<p style="font-size:14px;color:var(--ink-2);line-height:1.7">${esc(message)}</p>`,
      footer: `<button class="btn btn-outline btn-sm" data-cancel>${esc(cancelText)}</button>
               <button class="btn ${danger ? "btn-danger" : "btn-primary"} btn-sm" data-confirm>${esc(confirmText)}</button>`,
      onMount(el) {
        el.querySelector("[data-cancel]").addEventListener("click", () => { close(); resolve(false); });
        el.querySelector("[data-confirm]").addEventListener("click", () => { close(); resolve(true); });
      },
    });
  });
}

export function emptyState({ iconName = "package", title = "Nada por aquí", text = "", action = "" } = {}) {
  return `<div class="empty">
    <div class="empty-icon">${icon(iconName, 26)}</div>
    <h3>${esc(title)}</h3>
    ${text ? `<p>${esc(text)}</p>` : ""}
    ${action}
  </div>`;
}

export function setBusy(button, busy, label = "Guardando…") {
  if (!button) return;
  if (busy) {
    button.dataset.label = button.innerHTML;
    button.disabled = true;
    button.classList.add("is-loading");
    button.innerHTML = `<span class="spinner" style="width:16px;height:16px;border-color:rgba(255,255,255,.4);border-top-color:#fff"></span>${esc(label)}`;
  } else {
    button.disabled = false;
    button.classList.remove("is-loading");
    if (button.dataset.label) button.innerHTML = button.dataset.label;
  }
}

export function formObject(form) {
  return Object.fromEntries(new FormData(form).entries());
}

/* --------------------------------- Imágenes ------------------------------ */
export function compressImage(file, maxSide = 900, quality = 0.82) {
  return new Promise((resolve, reject) => {
    if (!file) return reject(new Error("No hay archivo"));
    if (!/^image\/(jpeg|png|webp)$/.test(file.type)) {
      return reject(new Error("La imagen debe ser JPEG, PNG o WebP"));
    }
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        let { width, height } = img;
        if (width > maxSide || height > maxSide) {
          const ratio = Math.min(maxSide / width, maxSide / height);
          width = Math.round(width * ratio);
          height = Math.round(height * ratio);
        }
        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        ctx.fillStyle = "#fffdf8";
        ctx.fillRect(0, 0, width, height);
        ctx.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL("image/jpeg", quality));
      };
      img.onerror = () => reject(new Error("No se pudo leer la imagen"));
      img.src = reader.result;
    };
    reader.onerror = () => reject(new Error("No se pudo leer el archivo"));
    reader.readAsDataURL(file);
  });
}

/* --------------------------------- CSV ----------------------------------- */
export function downloadCSV(filename, rows) {
  const csv = rows.map((row) => row.map((cell) => {
    const value = String(cell ?? "");
    return /[";\n]/.test(value) ? `"${value.replace(/"/g, '""')}"` : value;
  }).join(";")).join("\r\n");
  const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/* --------------------------------- Carrito ------------------------------- */
const CART_KEY = "cc_shops_cart_v1";
let cartListeners = [];

function readCart() {
  try {
    const data = JSON.parse(localStorage.getItem(CART_KEY) || "[]");
    return Array.isArray(data) ? data.filter((x) => x && x.id && Number(x.cantidad) > 0) : [];
  } catch {
    return [];
  }
}

function writeCart(items) {
  localStorage.setItem(CART_KEY, JSON.stringify(items));
  cartListeners.forEach((fn) => fn(items));
}

export function cartItems() { return readCart(); }
export function cartCount() { return readCart().reduce((acc, x) => acc + Number(x.cantidad || 0), 0); }
export function cartSubtotal() { return readCart().reduce((acc, x) => acc + Number(x.precio || 0) * Number(x.cantidad || 0), 0); }

export function cartAdd(product, cantidad = 1) {
  const items = readCart();
  const existing = items.find((x) => x.id === product.id);
  const stock = Number(product.stock ?? 9999);
  if (existing) {
    existing.cantidad = Math.min(stock, Number(existing.cantidad) + Number(cantidad));
    existing.precio = Number(product.precio);
    existing.stock = stock;
  } else {
    items.push({
      id: product.id, nombre: product.nombre, slug: product.slug || "",
      precio: Number(product.precio), imagen: product.imagen, sku: product.sku,
      unidad: product.unidad || "ud", iva: Number(product.iva || 21),
      stock, cantidad: Math.min(stock, Number(cantidad)),
    });
  }
  writeCart(items);
  return existing || items[items.length - 1];
}

export function cartSet(id, cantidad) {
  const items = readCart();
  const item = items.find((x) => x.id === id);
  if (!item) return;
  const qty = Math.max(1, Math.min(Number(item.stock || 9999), Number(cantidad) || 1));
  item.cantidad = qty;
  writeCart(items);
}

export function cartRemove(id) {
  writeCart(readCart().filter((x) => x.id !== id));
}

export function cartClear() { writeCart([]); }

export function onCart(fn) {
  cartListeners.push(fn);
  return () => { cartListeners = cartListeners.filter((x) => x !== fn); };
}

export function cartShipping(config) {
  const subtotal = cartSubtotal();
  const gratis = Number(config?.envio?.gratis_desde || 0);
  const coste = Number(config?.envio?.coste || 0);
  return { subtotal, envio: gratis > 0 && subtotal >= gratis ? 0 : coste, gratis, coste };
}

export function estadoBadge(estado, label = "") {
  const map = {
    pendiente: "warn", pagado: "info", preparando: "info", enviado: "brand",
    entregado: "ok", cancelado: "danger", borrador: "neutral", recibida: "ok", anulada: "danger",
  };
  const clase = map[estado] || "neutral";
  return `<span class="badge ${clase !== "neutral" ? `badge--${clase}` : ""}">${esc(label || estado)}</span>`;
}

export function stockBadge(p) {
  if (Number(p.stock) <= 0) return '<span class="badge badge--danger">Agotado</span>';
  if (Number(p.stock) <= Math.max(1, Number(p.stock_minimo || 0)) || Number(p.stock) <= 5) {
    return `<span class="badge badge--warn">Últimas ${number(p.stock)} uds</span>`;
  }
  return '<span class="badge badge--ok">En stock</span>';
}

export function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }
