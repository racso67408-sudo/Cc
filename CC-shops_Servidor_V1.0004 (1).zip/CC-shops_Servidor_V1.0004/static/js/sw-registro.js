// Registro del service worker (PWA). Va en fichero propio por la política CSP (script-src 'self').
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/sw.js").catch(() => {});
  });
}
