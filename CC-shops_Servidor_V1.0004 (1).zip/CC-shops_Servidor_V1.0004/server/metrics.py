"""Métricas de negocio e inventario para el dashboard y los informes."""
from __future__ import annotations

import calendar
from datetime import date, timedelta
from typing import Any

from . import kardex, orders
from .db import all_rows, one
from .util import biz_today, date_range, money, qty

ESTADOS_VENTA = ("pagado", "preparando", "enviado", "entregado")
IN_ESTADOS = "('pagado','preparando','enviado','entregado')"


def _ventas(conn, ini: date, fin: date, tid: str) -> dict:
    fila = one(
        conn,
        f"""SELECT COUNT(*) AS pedidos, COALESCE(SUM(total),0) AS total,
                   COALESCE(SUM(base),0) AS base, COALESCE(SUM(iva),0) AS iva
            FROM pedidos
            WHERE tienda_id=? AND estado IN {IN_ESTADOS} AND substr(created_at,1,10) BETWEEN ? AND ?""",
        (tid, ini.isoformat(), fin.isoformat()),
    )
    unidades = one(
        conn,
        f"""SELECT COALESCE(SUM(l.cantidad),0) AS uds
            FROM pedido_lineas l JOIN pedidos p ON p.id=l.pedido_id
            WHERE p.tienda_id=? AND p.estado IN {IN_ESTADOS} AND substr(p.created_at,1,10) BETWEEN ? AND ?""",
        (tid, ini.isoformat(), fin.isoformat()),
    )
    margen = _margen(conn, ini, fin, tid)
    pedidos_n = int(fila["pedidos"])
    total = money(fila["total"])
    return {
        "pedidos": pedidos_n,
        "ventas": total,
        "base": money(fila["base"]),
        "iva": money(fila["iva"]),
        "unidades": qty(unidades["uds"]),
        "ticket_medio": money(total / pedidos_n) if pedidos_n else 0.0,
        "margen": margen["margen"],
        "margen_pct": margen["margen_pct"],
        "coste_ventas": margen["coste"],
    }


def _margen(conn, ini: date, fin: date, tid: str) -> dict:
    fila = one(
        conn,
        f"""SELECT COALESCE(SUM(l.total/(1+l.iva/100.0)),0) AS base,
                   COALESCE(SUM(l.cantidad*l.coste_unit),0) AS coste
            FROM pedido_lineas l JOIN pedidos p ON p.id=l.pedido_id
            WHERE p.tienda_id=? AND p.estado IN {IN_ESTADOS} AND substr(p.created_at,1,10) BETWEEN ? AND ?""",
        (tid, ini.isoformat(), fin.isoformat()),
    )
    base = money(fila["base"])
    coste = money(fila["coste"])
    margen = money(base - coste)
    return {
        "base": base,
        "coste": coste,
        "margen": margen,
        "margen_pct": round(margen / base * 100, 1) if base > 0 else 0.0,
    }


def _serie(conn, ini: date, fin: date, tid: str) -> list[dict]:
    filas = all_rows(
        conn,
        f"""SELECT substr(created_at,1,10) AS dia, COUNT(*) AS pedidos, COALESCE(SUM(total),0) AS ventas
            FROM pedidos WHERE tienda_id=? AND estado IN {IN_ESTADOS} AND substr(created_at,1,10) BETWEEN ? AND ?
            GROUP BY dia ORDER BY dia""",
        (tid, ini.isoformat(), fin.isoformat()),
    )
    datos = {f["dia"]: f for f in filas}
    salida = []
    dia = ini
    dias_semana = ["lun", "mar", "mié", "jue", "vie", "sáb", "dom"]
    while dia <= fin:
        f = datos.get(dia.isoformat())
        salida.append(
            {
                "fecha": dia.isoformat(),
                "etiqueta": dia.strftime("%d/%m"),
                "dia_semana": dias_semana[dia.weekday()],
                "ventas": money(f["ventas"]) if f else 0.0,
                "pedidos": int(f["pedidos"]) if f else 0,
            }
        )
        dia += timedelta(days=1)
    return salida


def _top_productos(conn, ini: date, fin: date, tid: str, limite: int = 6) -> list[dict]:
    filas = all_rows(
        conn,
        f"""SELECT l.producto_id, l.nombre, l.sku, SUM(l.cantidad) AS unidades,
                   COALESCE(SUM(l.total),0) AS importe,
                   COALESCE(SUM(l.total/(1+l.iva/100.0)-l.cantidad*l.coste_unit),0) AS margen,
                   MAX(p.imagen) AS imagen
            FROM pedido_lineas l
            JOIN pedidos pe ON pe.id=l.pedido_id
            LEFT JOIN productos p ON p.id=l.producto_id
            WHERE pe.tienda_id=? AND pe.estado IN {IN_ESTADOS} AND substr(pe.created_at,1,10) BETWEEN ? AND ?
            GROUP BY l.producto_id, l.nombre, l.sku
            ORDER BY unidades DESC, importe DESC LIMIT ?""",
        (tid, ini.isoformat(), fin.isoformat(), limite),
    )
    out = []
    for f in filas:
        d = dict(f)
        d["unidades"] = qty(d["unidades"])
        d["importe"] = money(d["importe"])
        d["margen"] = money(d["margen"])
        out.append(d)
    return out


def _categorias(conn, ini: date, fin: date, tid: str) -> list[dict]:
    filas = all_rows(
        conn,
        f"""SELECT COALESCE(c.nombre,'Sin categoría') AS categoria, COALESCE(SUM(l.total),0) AS importe,
                   COALESCE(SUM(l.cantidad),0) AS unidades
            FROM pedido_lineas l
            JOIN pedidos pe ON pe.id=l.pedido_id
            LEFT JOIN productos p ON p.id=l.producto_id
            LEFT JOIN categorias c ON c.id=p.categoria_id
            WHERE pe.tienda_id=? AND pe.estado IN {IN_ESTADOS} AND substr(pe.created_at,1,10) BETWEEN ? AND ?
            GROUP BY categoria ORDER BY importe DESC""",
        (tid, ini.isoformat(), fin.isoformat()),
    )
    total = sum(float(f["importe"]) for f in filas) or 1
    out = []
    for f in filas:
        d = dict(f)
        d["nombre"] = d.pop("categoria")
        d["importe"] = money(d["importe"])
        d["unidades"] = qty(d["unidades"])
        d["pct"] = round(d["importe"] / total * 100, 1)
        out.append(d)
    return out


def inventario(conn, tid: str) -> dict:
    return _inventario(conn, tid)


def _inventario(conn, tid: str) -> dict:
    fila = one(
        conn,
        """SELECT COUNT(*) AS referencias, COALESCE(SUM(stock),0) AS unidades,
                  COALESCE(SUM(valor_stock),0) AS valor,
                  COALESCE(SUM(stock*precio/(1+iva/100.0)),0) AS valor_venta,
                  SUM(CASE WHEN stock<=stock_minimo THEN 1 ELSE 0 END) AS bajo,
                  SUM(CASE WHEN stock<=0 THEN 1 ELSE 0 END) AS agotados
           FROM productos WHERE tienda_id=? AND activo=1""",
        (tid,),
    )
    valor = money(fila["valor"])
    valor_venta = money(fila["valor_venta"])
    return {
        "referencias": int(fila["referencias"]),
        "unidades": qty(fila["unidades"]),
        "valor": valor,
        "valor_venta": valor_venta,
        "margen_potencial": money(valor_venta - valor),
        "bajo": int(fila["bajo"] or 0),
        "agotados": int(fila["agotados"] or 0),
    }


def _pedidos_pendientes(conn, tid: str) -> dict:
    fila = one(
        conn,
        "SELECT COUNT(*) AS n, COALESCE(SUM(total),0) AS importe FROM pedidos WHERE tienda_id=? AND estado='pendiente'",
        (tid,),
    )
    return {"pedidos": int(fila["n"]), "importe": money(fila["importe"])}


def _variacion(actual: float, anterior: float) -> float | None:
    if anterior <= 0:
        return None
    return round((actual - anterior) / anterior * 100, 1)


def dashboard(conn, dias: int = 14, *, tid: str) -> dict:
    hoy = biz_today()
    dias = max(7, min(90, int(dias)))
    inicio = hoy - timedelta(days=dias - 1)
    mes_ini = hoy.replace(day=1)
    if mes_ini.month == 1:
        prev_ini = date(hoy.year - 1, 12, 1)
    else:
        prev_ini = date(hoy.year, mes_ini.month - 1, 1)
    prev_fin_mes = prev_ini.replace(day=calendar.monthrange(prev_ini.year, prev_ini.month)[1])
    prev_fin = min(prev_fin_mes, prev_ini + timedelta(days=(hoy - mes_ini).days))

    ventas_hoy = _ventas(conn, hoy, hoy, tid)
    ventas_mes = _ventas(conn, mes_ini, hoy, tid)
    ventas_prev = _ventas(conn, prev_ini, prev_fin, tid)
    inventario = _inventario(conn, tid)
    pendientes = _pedidos_pendientes(conn, tid)
    clientes = one(
        conn,
        f"""SELECT COUNT(DISTINCT cliente_email) AS clientes,
                   COUNT(DISTINCT CASE WHEN visitas>1 THEN cliente_email END) AS recurrentes
            FROM (SELECT cliente_email, COUNT(*) AS visitas FROM pedidos
                  WHERE tienda_id=? AND estado IN {IN_ESTADOS} GROUP BY cliente_email)""",
        (tid,),
    )
    return {
        "fecha": hoy.isoformat(),
        "rango": {"desde": inicio.isoformat(), "hasta": hoy.isoformat(), "dias": dias},
        "kpis": {
            "ventas_hoy": ventas_hoy["ventas"],
            "pedidos_hoy": ventas_hoy["pedidos"],
            "ventas_mes": ventas_mes["ventas"],
            "ventas_mes_anterior": ventas_prev["ventas"],
            "variacion_mes": _variacion(ventas_mes["ventas"], ventas_prev["ventas"]),
            "pedidos_mes": ventas_mes["pedidos"],
            "pedidos_mes_anterior": ventas_prev["pedidos"],
            "ticket_medio": ventas_mes["ticket_medio"],
            "ticket_anterior": ventas_prev["ticket_medio"],
            "unidades_mes": ventas_mes["unidades"],
            "margen_mes": ventas_mes["margen"],
            "margen_pct": ventas_mes["margen_pct"],
            "pendientes": pendientes["pedidos"],
            "pendiente_importe": pendientes["importe"],
            "inventario_valor": inventario["valor"],
            "inventario_unidades": inventario["unidades"],
            "inventario_referencias": inventario["referencias"],
            "inventario_venta": inventario["valor_venta"],
            "bajo_stock": inventario["bajo"],
            "agotados": inventario["agotados"],
            "clientes": int(clientes["clientes"] or 0),
            "recurrentes": int(clientes["recurrentes"] or 0),
        },
        "serie": _serie(conn, inicio, hoy, tid),
        "top_productos": _top_productos(conn, inicio, hoy, tid),
        "categorias": _categorias(conn, inicio, hoy, tid),
        "bajo_stock": kardex.bajo_minimo(conn, 8, tienda_id=tid),
        "pedidos_recientes": orders.ultimos(conn, 6, tienda_id=tid),
        "movimientos": kardex.ultimos(conn, 7, tienda_id=tid),
        "inventario": inventario,
    }


def metricas(conn, desde: str | None = None, hasta: str | None = None, dias: int = 30, *, tid: str) -> dict:
    ini, fin = date_range(desde, hasta, dias)
    largo = (fin - ini).days + 1
    prev_fin = ini - timedelta(days=1)
    prev_ini = prev_fin - timedelta(days=largo - 1)
    actual = _ventas(conn, ini, fin, tid)
    anterior = _ventas(conn, prev_ini, prev_fin, tid)
    metodos = all_rows(
        conn,
        f"""SELECT metodo_pago, COUNT(*) AS pedidos, COALESCE(SUM(total),0) AS importe
            FROM pedidos WHERE tienda_id=? AND estado IN {IN_ESTADOS} AND substr(created_at,1,10) BETWEEN ? AND ?
            GROUP BY metodo_pago ORDER BY importe DESC""",
        (tid, ini.isoformat(), fin.isoformat()),
    )
    estados = all_rows(
        conn,
        "SELECT estado, COUNT(*) AS n FROM pedidos WHERE tienda_id=? AND substr(created_at,1,10) BETWEEN ? AND ? GROUP BY estado",
        (tid, ini.isoformat(), fin.isoformat()),
    )
    clientes = one(
        conn,
        f"""SELECT COUNT(DISTINCT cliente_email) AS clientes FROM pedidos
            WHERE tienda_id=? AND estado IN {IN_ESTADOS} AND substr(created_at,1,10) BETWEEN ? AND ?""",
        (tid, ini.isoformat(), fin.isoformat()),
    )
    devoluciones = one(
        conn,
        """SELECT COUNT(*) AS n, COALESCE(-SUM(coste_total),0) AS importe FROM movimientos
           WHERE tienda_id=? AND tipo='entrada_devolucion' AND substr(fecha,1,10) BETWEEN ? AND ?""",
        (tid, ini.isoformat(), fin.isoformat()),
    )
    return {
        "rango": {
            "desde": ini.isoformat(),
            "hasta": fin.isoformat(),
            "dias": largo,
            "anterior_desde": prev_ini.isoformat(),
            "anterior_hasta": prev_fin.isoformat(),
        },
        "kpis": {
            **actual,
            "variacion_ventas": _variacion(actual["ventas"], anterior["ventas"]),
            "variacion_pedidos": _variacion(actual["pedidos"], anterior["pedidos"]),
            "variacion_ticket": _variacion(actual["ticket_medio"], anterior["ticket_medio"]),
            "anterior": anterior,
            "clientes": int(clientes["clientes"] or 0),
            "devoluciones": int(devoluciones["n"] or 0),
            "devoluciones_importe": money(devoluciones["importe"]),
        },
        "serie": _serie(conn, ini, fin, tid),
        "top_productos": _top_productos(conn, ini, fin, tid, 10),
        "categorias": _categorias(conn, ini, fin, tid),
        "metodos_pago": [
            {
                "metodo": f["metodo_pago"],
                "etiqueta": orders.METODOS.get(f["metodo_pago"], f["metodo_pago"]),
                "pedidos": int(f["pedidos"]),
                "importe": money(f["importe"]),
            }
            for f in metodos
        ],
        "estados": {f["estado"]: int(f["n"]) for f in estados},
        "inventario": _inventario(conn, tid),
        "bajo_stock": kardex.bajo_minimo(conn, 12, tienda_id=tid),
    }
