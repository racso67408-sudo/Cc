-- CC-Shops · esquema SQLite
-- El inventario es un libro (Kardex) de solo inserción: nunca se borra un movimiento.
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS usuarios (
    id              TEXT PRIMARY KEY,
    nombre          TEXT NOT NULL,
    email           TEXT NOT NULL UNIQUE,
    password_hash   TEXT NOT NULL,
    rol             TEXT NOT NULL DEFAULT 'admin',
    tienda_id       TEXT REFERENCES tiendas(id),
    activo          INTEGER NOT NULL DEFAULT 1,
    session_version INTEGER NOT NULL DEFAULT 0,
    ultimo_acceso   TEXT NOT NULL DEFAULT '',
    created_at      TEXT NOT NULL,
    two_factor_secret TEXT NOT NULL DEFAULT '',
    two_factor_enabled INTEGER NOT NULL DEFAULT 0,
    recovery_codes TEXT NOT NULL DEFAULT '[]'
);

CREATE TABLE IF NOT EXISTS categorias (
    id          TEXT PRIMARY KEY,
    tienda_id   TEXT REFERENCES tiendas(id),
    nombre      TEXT NOT NULL,
    slug        TEXT NOT NULL UNIQUE,
    descripcion TEXT NOT NULL DEFAULT '',
    icono       TEXT NOT NULL DEFAULT '',
    orden       INTEGER NOT NULL DEFAULT 0,
    activo      INTEGER NOT NULL DEFAULT 1,
    padre_id    TEXT REFERENCES categorias(id)
);
-- Un producto tiene una categoría principal (productos.categoria_id) y hasta dos subcategorías.
CREATE TABLE IF NOT EXISTS producto_subcategorias (
    producto_id  TEXT NOT NULL REFERENCES productos(id) ON DELETE CASCADE,
    categoria_id TEXT NOT NULL REFERENCES categorias(id),
    PRIMARY KEY (producto_id, categoria_id)
);

CREATE TABLE IF NOT EXISTS productos (
    id              TEXT PRIMARY KEY,
    tienda_id       TEXT REFERENCES tiendas(id),
    sku             TEXT NOT NULL UNIQUE,
    nombre          TEXT NOT NULL,
    slug            TEXT NOT NULL UNIQUE,
    descripcion     TEXT NOT NULL DEFAULT '',
    descripcion_corta TEXT NOT NULL DEFAULT '',
    especificaciones TEXT NOT NULL DEFAULT '[]',
    categoria_id    TEXT REFERENCES categorias(id),
    marca           TEXT NOT NULL DEFAULT '',
    unidad          TEXT NOT NULL DEFAULT 'ud',
    precio          REAL NOT NULL DEFAULT 0,      -- PVP con IVA
    iva             REAL NOT NULL DEFAULT 21,
    stock           REAL NOT NULL DEFAULT 0,
    stock_minimo    REAL NOT NULL DEFAULT 0,
    coste_medio     REAL NOT NULL DEFAULT 0,      -- coste unitario sin IVA (Kardex)
    valor_stock     REAL NOT NULL DEFAULT 0,      -- saldo valorado del Kardex
    imagen          TEXT NOT NULL DEFAULT '',
    activo          INTEGER NOT NULL DEFAULT 1,
    destacado       INTEGER NOT NULL DEFAULT 0,
    created_at      TEXT NOT NULL,
    updated_at      TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_productos_categoria ON productos(categoria_id);
CREATE INDEX IF NOT EXISTS idx_productos_activo ON productos(activo, nombre);
CREATE INDEX IF NOT EXISTS idx_productos_stock ON productos(stock, stock_minimo);

CREATE TABLE IF NOT EXISTS proveedores (
    id          TEXT PRIMARY KEY,
    tienda_id   TEXT REFERENCES tiendas(id),
    nombre      TEXT NOT NULL,
    contacto    TEXT NOT NULL DEFAULT '',
    email       TEXT NOT NULL DEFAULT '',
    telefono    TEXT NOT NULL DEFAULT '',
    notas       TEXT NOT NULL DEFAULT '',
    activo      INTEGER NOT NULL DEFAULT 1,
    created_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS compras (
    id            TEXT PRIMARY KEY,
    tienda_id     TEXT REFERENCES tiendas(id),
    numero        TEXT NOT NULL UNIQUE,
    proveedor_id  TEXT REFERENCES proveedores(id),
    fecha         TEXT NOT NULL,
    estado        TEXT NOT NULL DEFAULT 'borrador' CHECK (estado IN ('borrador', 'recibida', 'anulada')),
    base          REAL NOT NULL DEFAULT 0,   -- suma de líneas sin IVA
    iva           REAL NOT NULL DEFAULT 0,
    total         REAL NOT NULL DEFAULT 0,
    notas         TEXT NOT NULL DEFAULT '',
    recibida_at   TEXT NOT NULL DEFAULT '',
    anulada_at    TEXT NOT NULL DEFAULT '',
    creado_por    TEXT REFERENCES usuarios(id),
    created_at    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_compras_estado ON compras(estado, fecha);

CREATE TABLE IF NOT EXISTS compra_lineas (
    id          TEXT PRIMARY KEY,
    compra_id   TEXT NOT NULL REFERENCES compras(id) ON DELETE CASCADE,
    producto_id TEXT NOT NULL REFERENCES productos(id),
    nombre      TEXT NOT NULL,
    sku         TEXT NOT NULL DEFAULT '',
    cantidad    REAL NOT NULL,
    coste_unit  REAL NOT NULL,   -- sin IVA
    iva         REAL NOT NULL DEFAULT 21,
    total       REAL NOT NULL    -- cantidad * coste_unit (sin IVA)
);

CREATE TABLE IF NOT EXISTS pedidos (
    id              TEXT PRIMARY KEY,
    tienda_id       TEXT REFERENCES tiendas(id),
    numero          TEXT NOT NULL UNIQUE,
    token           TEXT NOT NULL,
    cliente_nombre  TEXT NOT NULL,
    cliente_email   TEXT NOT NULL,
    cliente_telefono TEXT NOT NULL DEFAULT '',
    empresa         TEXT NOT NULL DEFAULT '',
    nif             TEXT NOT NULL DEFAULT '',
    direccion       TEXT NOT NULL,
    ciudad          TEXT NOT NULL,
    cp              TEXT NOT NULL,
    provincia       TEXT NOT NULL DEFAULT '',
    pais            TEXT NOT NULL DEFAULT 'España',
    cliente_id      TEXT REFERENCES usuarios(id),
    metodo_pago     TEXT NOT NULL DEFAULT 'transferencia',
    estado          TEXT NOT NULL DEFAULT 'pendiente'
                    ,
    base            REAL NOT NULL DEFAULT 0,   -- base imponible (productos + envío)
    iva             REAL NOT NULL DEFAULT 0,
    envio           REAL NOT NULL DEFAULT 0,   -- con IVA
    total           REAL NOT NULL DEFAULT 0,   -- con IVA
    notas           TEXT NOT NULL DEFAULT '',
    stock_descontado INTEGER NOT NULL DEFAULT 1,
    stock_devuelto  INTEGER NOT NULL DEFAULT 0,
    created_at      TEXT NOT NULL,
    updated_at      TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_pedidos_estado ON pedidos(estado, created_at);
CREATE INDEX IF NOT EXISTS idx_pedidos_fecha ON pedidos(created_at);
CREATE INDEX IF NOT EXISTS idx_pedidos_email ON pedidos(cliente_email);

-- Packs: un producto virtual formado por 2 o más productos (cantidad por componente).
CREATE TABLE IF NOT EXISTS pack_componentes (
    pack_id     TEXT NOT NULL REFERENCES productos(id) ON DELETE CASCADE,
    producto_id TEXT NOT NULL REFERENCES productos(id),
    cantidad    REAL NOT NULL DEFAULT 1,
    PRIMARY KEY (pack_id, producto_id)
);
CREATE TABLE IF NOT EXISTS pedido_lineas (
    id          TEXT PRIMARY KEY,
    pedido_id   TEXT NOT NULL REFERENCES pedidos(id) ON DELETE CASCADE,
    producto_id TEXT REFERENCES productos(id),
    nombre      TEXT NOT NULL,
    sku         TEXT NOT NULL DEFAULT '',
    cantidad    REAL NOT NULL,
    precio_unit REAL NOT NULL,   -- con IVA
    iva         REAL NOT NULL DEFAULT 21,
    total       REAL NOT NULL,   -- con IVA
    coste_unit  REAL NOT NULL DEFAULT 0  -- coste medio en el momento de la venta
);

CREATE TABLE IF NOT EXISTS pedido_eventos (
    id          TEXT PRIMARY KEY,
    pedido_id   TEXT NOT NULL REFERENCES pedidos(id) ON DELETE CASCADE,
    estado      TEXT NOT NULL,
    nota        TEXT NOT NULL DEFAULT '',
    usuario_id  TEXT REFERENCES usuarios(id),
    created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_pedido_eventos ON pedido_eventos(pedido_id, created_at);

CREATE TABLE IF NOT EXISTS movimientos (
    id                TEXT PRIMARY KEY,
    tienda_id         TEXT REFERENCES tiendas(id),
    producto_id       TEXT NOT NULL REFERENCES productos(id),
    fecha             TEXT NOT NULL,
    tipo              TEXT NOT NULL CHECK (tipo IN (
                          'entrada_compra', 'entrada_devolucion', 'entrada_ajuste',
                          'salida_venta', 'salida_ajuste', 'salida_compra_anulada')),
    documento_tipo    TEXT NOT NULL DEFAULT '',
    documento_id      TEXT NOT NULL DEFAULT '',
    documento_numero  TEXT NOT NULL DEFAULT '',
    cantidad          REAL NOT NULL,        -- + entrada / - salida
    coste_unit        REAL NOT NULL,
    coste_total       REAL NOT NULL,        -- con signo
    saldo_cantidad    REAL NOT NULL,
    saldo_coste_medio REAL NOT NULL,
    saldo_valor       REAL NOT NULL,
    motivo            TEXT NOT NULL DEFAULT '',
    usuario_id        TEXT REFERENCES usuarios(id),
    created_at        TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_mov_producto ON movimientos(producto_id, created_at);
CREATE INDEX IF NOT EXISTS idx_mov_fecha ON movimientos(created_at);
CREATE INDEX IF NOT EXISTS idx_mov_tipo ON movimientos(tipo, created_at);
CREATE INDEX IF NOT EXISTS idx_mov_documento ON movimientos(documento_tipo, documento_id);

CREATE TABLE IF NOT EXISTS configuracion (
    clave     TEXT PRIMARY KEY,
    valor     TEXT NOT NULL,
    tienda_id TEXT REFERENCES tiendas(id)
);

CREATE TABLE IF NOT EXISTS secuencias (
    nombre TEXT PRIMARY KEY,
    valor  INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS eventos (
    id          TEXT PRIMARY KEY,
    tienda_id   TEXT REFERENCES tiendas(id),
    usuario_id  TEXT,
    accion      TEXT NOT NULL,
    entidad     TEXT NOT NULL DEFAULT '',
    entidad_id  TEXT NOT NULL DEFAULT '',
    detalle     TEXT NOT NULL DEFAULT '',
    ip          TEXT NOT NULL DEFAULT '',
    created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_eventos_fecha ON eventos(created_at);

CREATE TABLE IF NOT EXISTS pedido_chat (
    id          TEXT PRIMARY KEY,
    tienda_id   TEXT REFERENCES tiendas(id),
    pedido_id   TEXT NOT NULL REFERENCES pedidos(id) ON DELETE CASCADE,
    usuario_id  TEXT REFERENCES usuarios(id),
    autor_rol   TEXT NOT NULL DEFAULT 'cliente',
    autor_nombre TEXT NOT NULL DEFAULT '',
    mensaje     TEXT NOT NULL,
    created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_pedido_chat ON pedido_chat(pedido_id, created_at);


-- ----------------------------------------------------------------------
-- Multitienda: tiendas, planes, suscripciones
CREATE TABLE IF NOT EXISTS tiendas (
    id                TEXT PRIMARY KEY,
    slug              TEXT NOT NULL UNIQUE,
    nombre            TEXT NOT NULL,
    propietario_id    TEXT REFERENCES usuarios(id),
    plan_id           TEXT REFERENCES planes(id),
    estado            TEXT NOT NULL DEFAULT 'activa' CHECK (estado IN ('activa', 'suspendida', 'cancelada')),
    dominio_provisional TEXT NOT NULL DEFAULT '',
    dominio_propio    TEXT NOT NULL DEFAULT '',
    max_admins        INTEGER NOT NULL DEFAULT 3,
    tema_id           TEXT REFERENCES temas(id),
    config            TEXT NOT NULL DEFAULT '{}',
    created_at        TEXT NOT NULL,
    updated_at        TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_tiendas_slug ON tiendas(slug);
CREATE INDEX IF NOT EXISTS idx_tiendas_propietario ON tiendas(propietario_id);

CREATE TABLE IF NOT EXISTS planes (
    id            TEXT PRIMARY KEY,
    nombre        TEXT NOT NULL,
    descripcion   TEXT NOT NULL DEFAULT '',
    precio        REAL NOT NULL DEFAULT 0,
    periodicidad  TEXT NOT NULL DEFAULT 'mensual',
    max_productos INTEGER NOT NULL DEFAULT 100,
    max_usuarios  INTEGER NOT NULL DEFAULT 5,
    max_storage_mb INTEGER NOT NULL DEFAULT 500,
    activo        INTEGER NOT NULL DEFAULT 1,
    created_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS suscripciones (
    id                TEXT PRIMARY KEY,
    tienda_id         TEXT REFERENCES tiendas(id),
    plan_id           TEXT NOT NULL REFERENCES planes(id),
    estado            TEXT NOT NULL DEFAULT 'activa' CHECK (estado IN ('activa', 'pendiente', 'vencida', 'cancelada')),
    fecha_inicio      TEXT NOT NULL,
    fecha_fin         TEXT NOT NULL,
    renovacion_auto   INTEGER NOT NULL DEFAULT 1,
    metodo_pago       TEXT NOT NULL DEFAULT '',
    created_at        TEXT NOT NULL,
    updated_at        TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_suscripciones_tienda ON suscripciones(tienda_id, estado);

CREATE TABLE IF NOT EXISTS dominios (
    id          TEXT PRIMARY KEY,
    tienda_id   TEXT REFERENCES tiendas(id),
    dominio     TEXT NOT NULL UNIQUE,
    verificado  INTEGER NOT NULL DEFAULT 0,
    created_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS temas (
    id          TEXT PRIMARY KEY,
    nombre      TEXT NOT NULL,
    descripcion TEXT NOT NULL DEFAULT '',
    config      TEXT NOT NULL DEFAULT '{}',
    activo      INTEGER NOT NULL DEFAULT 1,
    created_at  TEXT NOT NULL
);

-- Verificación de pagos manuales
CREATE TABLE IF NOT EXISTS verificaciones_pago (
    id            TEXT PRIMARY KEY,
    tienda_id     TEXT REFERENCES tiendas(id),
    pedido_id     TEXT NOT NULL REFERENCES pedidos(id),
    importe       REAL NOT NULL,
    medio_pago    TEXT NOT NULL,
    resultado     TEXT NOT NULL DEFAULT 'pendiente' CHECK (resultado IN ('pendiente', 'aprobado', 'rechazado')),
    verificado_por TEXT REFERENCES usuarios(id),
    observaciones TEXT NOT NULL DEFAULT '',
    created_at    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_verif_tienda ON verificaciones_pago(tienda_id, resultado);

-- Tickets de soporte (SuperAdmin <-> propietario)
-- Roles y permisos personalizados
CREATE TABLE IF NOT EXISTS roles_personalizados (
    id          TEXT PRIMARY KEY,
    tienda_id   TEXT REFERENCES tiendas(id),
    nombre      TEXT NOT NULL,
    created_at  TEXT NOT NULL,
    UNIQUE (tienda_id, nombre)
);
CREATE TABLE IF NOT EXISTS rol_permisos (
    rol_id      TEXT NOT NULL REFERENCES roles_personalizados(id) ON DELETE CASCADE,
    modulo      TEXT NOT NULL,
    accion      TEXT NOT NULL,
    PRIMARY KEY (rol_id, modulo, accion)
);

-- 2FA
-- (campos añadidos por migración en usuarios: two_factor_secret, two_factor_enabled, recovery_codes)

CREATE TABLE IF NOT EXISTS notificaciones (
    id          TEXT PRIMARY KEY,
    tienda_id   TEXT REFERENCES tiendas(id),
    tipo        TEXT NOT NULL,
    referencia  TEXT NOT NULL DEFAULT '',
    texto       TEXT NOT NULL,
    leida       INTEGER NOT NULL DEFAULT 0,
    created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_notificaciones_tienda ON notificaciones(tienda_id, leida, created_at);

CREATE TABLE IF NOT EXISTS mensajes_contacto (
    id          TEXT PRIMARY KEY,
    tienda_id   TEXT NOT NULL REFERENCES tiendas(id),
    nombre      TEXT NOT NULL,
    email       TEXT NOT NULL,
    empresa     TEXT NOT NULL DEFAULT '',
    mensaje     TEXT NOT NULL,
    destinatario TEXT NOT NULL DEFAULT '',
    estado      TEXT NOT NULL DEFAULT 'pendiente',
    created_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS plataforma_config (
    clave       TEXT PRIMARY KEY,
    valor       TEXT NOT NULL DEFAULT '',
    updated_at  TEXT NOT NULL DEFAULT ''
);

