"""Kardex: libro inmutable de entradas y salidas con saldo valorado a coste medio ponderado.

Reglas de oro:
- Un movimiento nunca se edita ni se borra. Las correcciones son movimientos contrarios.
- Toda variación de stock pasa por aquí; `productos.stock` y `productos.valor_stock` son la
  fotografía del último saldo del Kardex.
- Las salidas se valoran siempre al coste medio vigente en ese instante.
- No se permite stock negativo.
"""
from __future__ import annotations

from datetime import datetime
from typing import Any

from .db import all_rows, one
from math import floor
from .util import ApiError, iso_at, iso_now, money, new_id, qty, txt

TIPOS = {
    "entrada_compra": "Entrada · compra",
    "entrada_devolucion": "Entrada · devolución",
    "entrada_ajuste": "Entrada · ajuste",
    "salida_venta": "Salida · venta",
    "salida_ajuste": "Salida · ajuste",
    "salida_compra_anulada": "Salida · compra anulada",
}
ENTRADAS = {"entrada_compra", "entrada_devolucion", "entrada_ajuste"}
SALIDAS = {"salida_venta", "salida_ajuste", "salida_compra_anulada"}


def etiqueta(tipo: str) -> str:
    return TIPOS.get(tipo, tipo)


def stock_disponible_pack(conn, pack_id: str) -> float:
    """Packs completos que se pueden formar con el componente que tenga menos stock."""
    comps = all_rows(
        conn,
        "SELECT c.cantidad, p.stock FROM pack_componentes c JOIN productos p ON p.id=c.producto_id WHERE c.pack_id=?",
        (pack_id,),
    )
    if not comps:
        return 0.0
    return float(min(floor(float(c["stock"]) / float(c["cantidad"]) + 1e-9) for c in comps if float(c["cantidad"]) > 0))


def recalcular_pack(conn, pack_id: str) -> None:
    stock = stock_disponible_pack(conn, pack_id)
    coste = one(
        conn,
        "SELECT COALESCE(SUM(c.cantidad * p.coste_medio), 0) AS coste FROM pack_componentes c JOIN productos p ON p.id=c.producto_id WHERE c.pack_id=?",
        (pack_id,),
    )["coste"]
    conn.execute(
        "UPDATE productos SET stock=?, coste_medio=?, valor_stock=0 WHERE id=?",
        (stock, round(float(coste), 4), pack_id),
    )


def recalcular_padre(conn, producto_id: str) -> None:
    """Si el producto es una variante, el stock del padre es la suma de todas sus variantes."""
    fila = one(conn, "SELECT padre_id FROM productos WHERE id=?", (producto_id,))
    if not fila or not fila["padre_id"]:
        return
    total = one(conn, "SELECT COALESCE(SUM(stock),0) AS s FROM productos WHERE padre_id=?", (fila["padre_id"],))["s"]
    conn.execute("UPDATE productos SET stock=? WHERE id=?", (float(total), fila["padre_id"]))


def recalcular_packs(conn, producto_id: str) -> None:
    for fila in all_rows(conn, "SELECT DISTINCT pack_id FROM pack_componentes WHERE producto_id=?", (producto_id,)):
        recalcular_pack(conn, fila["pack_id"])


def producto(conn, producto_id: str) -> dict:
    fila = one(conn, "SELECT * FROM productos WHERE id=?", (producto_id,))
    if not fila:
        raise ApiError("Producto no encontrado", 404)
    return dict(fila)


def _registrar(
    conn,
    producto_id: str,
    cantidad: float,
    coste_unit: float | None,
    *,
    tipo: str,
    documento_tipo: str = "",
    documento_id: str = "",
    documento_numero: str = "",
    motivo: str = "",
    usuario_id: str | None = None,
    fecha: str | None = None,
) -> dict:
    if tipo not in TIPOS:
        raise ApiError("Tipo de movimiento no válido")
    cantidad = qty(abs(cantidad))
    if cantidad <= 0:
        raise ApiError("La cantidad debe ser mayor que cero")

    p = producto(conn, producto_id)
    if p.get("es_pack"):
        raise ApiError("Los packs no tienen stock propio: se calcula con sus productos")
    stock_actual = float(p["stock"])
    valor_actual = float(p["valor_stock"])
    coste_actual = float(p["coste_medio"])

    if tipo in ENTRADAS:
        if coste_unit is None or coste_unit == "":
            if coste_actual <= 0:
                raise ApiError("Indica el coste unitario de la entrada")
            unitario = coste_actual
        else:
            unitario = float(coste_unit)
        if unitario < 0:
            raise ApiError("El coste unitario no puede ser negativo")
        nuevo_stock = stock_actual + cantidad
        nuevo_valor = money(valor_actual + cantidad * unitario)
        nuevo_coste = round(nuevo_valor / nuevo_stock, 4) if nuevo_stock > 0 else 0.0
        firmada = cantidad
        total = money(cantidad * unitario)
    else:
        if cantidad > stock_actual + 0.000001:
            raise ApiError(
                f"Stock insuficiente de «{p['nombre']}»: quedan {stock_actual:g} {p['unidad']}", 409
            )
        unitario = coste_actual if coste_unit in (None, "") else float(coste_unit)
        if unitario < 0:
            raise ApiError("El coste unitario no puede ser negativo")
        nuevo_stock = stock_actual - cantidad
        if nuevo_stock <= 0.000001:
            nuevo_stock = 0.0
            nuevo_valor = 0.0
            nuevo_coste = unitario if unitario > 0 else coste_actual
        else:
            nuevo_valor = money(max(0.0, valor_actual - cantidad * unitario))
            nuevo_coste = round(nuevo_valor / nuevo_stock, 4)
        firmada = -cantidad
        total = money(-cantidad * unitario)

    nuevo_stock = qty(nuevo_stock)
    sello = fecha or iso_now()
    mov_id = new_id("MOV")
    conn.execute(
        """INSERT INTO movimientos (id, tienda_id, producto_id, fecha, tipo, documento_tipo, documento_id,
            documento_numero, cantidad, coste_unit, coste_total, saldo_cantidad, saldo_coste_medio,
            saldo_valor, motivo, usuario_id, created_at)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (
            mov_id,
            p["tienda_id"],
            producto_id,
            sello,
            tipo,
            txt(documento_tipo, 20),
            txt(documento_id, 40),
            txt(documento_numero, 40),
            firmada,
            round(unitario, 4),
            total,
            nuevo_stock,
            nuevo_coste,
            nuevo_valor,
            txt(motivo, 240),
            usuario_id,
            iso_now(),
        ),
    )
    conn.execute(
        """UPDATE productos SET stock=?, coste_medio=?, valor_stock=?, updated_at=? WHERE id=?""",
        (nuevo_stock, nuevo_coste, nuevo_valor, iso_now(), producto_id),
    )
    recalcular_packs(conn, producto_id)
    recalcular_padre(conn, producto_id)
    return {
        "id": mov_id,
        "producto_id": producto_id,
        "tipo": tipo,
        "cantidad": firmada,
        "coste_unit": round(unitario, 4),
        "coste_total": total,
        "saldo_cantidad": nuevo_stock,
        "saldo_coste_medio": nuevo_coste,
        "saldo_valor": nuevo_valor,
        "stock_anterior": stock_actual,
        "valor_anterior": valor_actual,
    }


def entrada(conn, producto_id: str, cantidad: float, coste_unit: float | None = None, **kwargs) -> dict:
    return _registrar(conn, producto_id, cantidad, coste_unit, **kwargs)


def salida(conn, producto_id: str, cantidad: float, coste_unit: float | None = None, **kwargs) -> dict:
    return _registrar(conn, producto_id, cantidad, coste_unit, **kwargs)


def listar(
    conn,
    producto_id: str,
    *,
    desde: str = "",
    hasta: str = "",
    limite: int = 500,
    tienda_id: str | None = None,
) -> list[dict]:
    producto(conn, producto_id)
    sql = "SELECT * FROM movimientos WHERE producto_id=?"
    params: list[Any] = [producto_id]
    if tienda_id:
        sql += " AND tienda_id=?"
        params.append(tienda_id)
    if desde:
        sql += " AND substr(fecha,1,10)>=?"
        params.append(desde[:10])
    if hasta:
        sql += " AND substr(fecha,1,10)<=?"
        params.append(hasta[:10])
    sql += " ORDER BY fecha ASC, created_at ASC, rowid ASC LIMIT ?"
    params.append(int(limite))
    return [dict(f) for f in all_rows(conn, sql, params)]


def listar_global(
    conn,
    *,
    producto_id: str = "",
    tipo: str = "",
    desde: str = "",
    hasta: str = "",
    pagina: int = 1,
    por_pagina: int = 50,
    tienda_id: str | None,
) -> tuple[list[dict], int]:
    where = ["m.tienda_id=?"]
    params: list[Any] = [tienda_id]
    if producto_id:
        where.append("m.producto_id=?")
        params.append(producto_id)
    if tipo:
        where.append("m.tipo=?")
        params.append(tipo)
    if desde:
        where.append("substr(m.fecha,1,10)>=?")
        params.append(desde[:10])
    if hasta:
        where.append("substr(m.fecha,1,10)<=?")
        params.append(hasta[:10])
    filtro = " AND ".join(where)
    total = one(conn, f"SELECT COUNT(*) AS n FROM movimientos m WHERE {filtro}", params)["n"]
    pagina = max(1, int(pagina))
    por_pagina = min(200, max(1, int(por_pagina)))
    filas = all_rows(
        conn,
        f"""SELECT m.*, p.nombre AS producto_nombre, p.sku AS producto_sku, p.unidad AS producto_unidad,
                   p.imagen AS producto_imagen, c.nombre AS categoria
            FROM movimientos m
            JOIN productos p ON p.id=m.producto_id
            LEFT JOIN categorias c ON c.id=p.categoria_id
            WHERE {filtro}
            ORDER BY m.fecha DESC, m.created_at DESC, m.rowid DESC
            LIMIT ? OFFSET ?""",
        params + [por_pagina, (pagina - 1) * por_pagina],
    )
    return [dict(f) for f in filas], int(total)


def resumen(conn, producto_id: str) -> dict:
    p = producto(conn, producto_id)
    ultimo = one(
        conn,
        "SELECT * FROM movimientos WHERE producto_id=? ORDER BY fecha DESC, created_at DESC, rowid DESC LIMIT 1",
        (producto_id,),
    )
    entradas = one(
        conn,
        "SELECT COALESCE(SUM(cantidad),0) AS uds, COALESCE(SUM(coste_total),0) AS importe "
        "FROM movimientos WHERE producto_id=? AND cantidad>0",
        (producto_id,),
    )
    salidas = one(
        conn,
        "SELECT COALESCE(SUM(-cantidad),0) AS uds, COALESCE(SUM(-coste_total),0) AS importe "
        "FROM movimientos WHERE producto_id=? AND cantidad<0",
        (producto_id,),
    )
    return {
        "producto_id": producto_id,
        "stock": float(p["stock"]),
        "stock_minimo": float(p["stock_minimo"]),
        "coste_medio": float(p["coste_medio"]),
        "valor_stock": float(p["valor_stock"]),
        "unidad": p["unidad"],
        "bajo_minimo": float(p["stock"]) <= float(p["stock_minimo"]),
        "movimientos": one(conn, "SELECT COUNT(*) AS n FROM movimientos WHERE producto_id=?", (producto_id,))["n"],
        "entradas_unidades": float(entradas["uds"]),
        "entradas_importe": money(entradas["importe"]),
        "salidas_unidades": float(salidas["uds"]),
        "salidas_importe": money(salidas["importe"]),
        "ultimo_movimiento": dict(ultimo) if ultimo else None,
    }


def verificar(conn, producto_id: str) -> dict:
    """Comprueba que la fotografía del producto coincide con el saldo del libro."""
    p = producto(conn, producto_id)
    movs = all_rows(
        conn,
        "SELECT cantidad, coste_total, saldo_cantidad, saldo_valor FROM movimientos "
        "WHERE producto_id=? ORDER BY fecha ASC, created_at ASC, rowid ASC",
        (producto_id,),
    )
    suma_uds = qty(sum(float(m["cantidad"]) for m in movs))
    suma_valor = money(sum(float(m["coste_total"]) for m in movs))
    ultimo = movs[-1] if movs else None
    diferencias = []
    if abs(suma_uds - float(p["stock"])) > 0.0001:
        diferencias.append(f"Unidades: libro {suma_uds:g} vs ficha {float(p['stock']):g}")
    if abs(suma_valor - float(p["valor_stock"])) > 0.02:
        diferencias.append(f"Valor: libro {suma_valor:.2f} vs ficha {float(p['valor_stock']):.2f}")
    if ultimo and (abs(float(ultimo["saldo_cantidad"]) - float(p["stock"])) > 0.0001):
        diferencias.append("El último saldo del Kardex no coincide con la ficha")
    return {
        "correcto": not diferencias,
        "diferencias": diferencias,
        "libro_unidades": suma_uds,
        "libro_valor": suma_valor,
        "ficha_unidades": float(p["stock"]),
        "ficha_valor": float(p["valor_stock"]),
        "movimientos": len(movs),
    }


def bajo_minimo(conn, limite: int = 50, *, tienda_id: str | None) -> list[dict]:
    filas = all_rows(
        conn,
        """SELECT p.id, p.sku, p.nombre, p.stock, p.stock_minimo, p.unidad, p.imagen,
                  p.coste_medio, p.valor_stock, c.nombre AS categoria
           FROM productos p LEFT JOIN categorias c ON c.id=p.categoria_id
           WHERE p.activo=1 AND p.tienda_id=? AND p.stock <= p.stock_minimo
           ORDER BY (p.stock_minimo - p.stock) DESC, p.nombre LIMIT ?""",
        (tienda_id, limite),
    )
    return [dict(f) for f in filas]


def ultimos(conn, limite: int = 8, *, tienda_id: str | None) -> list[dict]:
    filas = all_rows(
        conn,
        """SELECT m.*, p.nombre AS producto_nombre, p.sku AS producto_sku, p.unidad AS producto_unidad,
                  p.imagen AS producto_imagen
           FROM movimientos m JOIN productos p ON p.id=m.producto_id
           WHERE m.tienda_id=?
           ORDER BY m.fecha DESC, m.created_at DESC, m.rowid DESC LIMIT ?""",
        (tienda_id, limite),
    )
    return [dict(f) for f in filas]
