"""Configuración global de CC-Shops."""
from __future__ import annotations

import os
import secrets
import threading
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.environ.get("CC_DATA_DIR", ROOT / "data"))
DB_PATH = Path(os.environ.get("CC_DB_PATH", DATA_DIR / "cc_shops.db"))
STATIC_DIR = Path(os.environ.get("CC_STATIC_DIR", ROOT / "static"))
SECRET_PATH = DATA_DIR / ".secret"

HOST = os.environ.get("CC_HOST", "127.0.0.1")
PORT = int(os.environ.get("CC_PORT", os.environ.get("PORT", "8100")))
IS_PROD = os.environ.get("CC_ENV", "dev").lower() in {"prod", "production"}
PUBLIC_URL = os.environ.get("CC_PUBLIC_URL", f"http://{HOST}:{PORT}")
# En producción no se crean datos de demostración (se puede forzar con CC_SEED_DEMO=1).
SEED_DEMO = os.environ.get("CC_SEED_DEMO", "0" if IS_PROD else "1") == "1"

# Base de datos: SQLite por defecto. Con CC_DATABASE_URL=postgresql://... se usa PostgreSQL.
DATABASE_URL = os.environ.get("CC_DATABASE_URL", "").strip()
ES_POSTGRES = DATABASE_URL.lower().startswith(("postgres://", "postgresql://"))

SESSION_COOKIE = "cc_shops_session"
SESSION_DAYS = 7
PBKDF2_ITERATIONS = 600_000
MAX_BODY = 4 * 1024 * 1024
MAX_IMAGE_CHARS = 450_000

TIENDA_DEFAULTS = {
    "tienda_nombre": "CC Shop's",
    "tienda_claim": "Tu tienda online por suscripción",
    "tienda_email": "hola@ccshops.es",
    "tienda_telefono": "+34 900 123 456",
    "tienda_direccion": "Polígono Can Font, nave 12 · 08224 Terrassa (Barcelona)",
    "recargo_contrareembolso": "2.50",
    "aviso_pago": "Entorno de demostración: los pedidos se registran sin realizar ningún cargo real.",
    "moneda": "EUR",
    "pago_plazo_horas": "8",
    "pago_gracia_admin_horas": "24",
    "aviso_plazo_pago": "Tienes {horas} horas para completar el pago. Si no recibimos el pago en ese plazo, el pedido se cancelará y los productos volverán al stock.",
    "aviso_envio": "El total no incluye el envío. El administrador de {tienda} se comunicará contigo para gestionar el envío.",
    "pago_iban": "",
    "pago_cartera": "",
    "pago_web_activo": "0",
    "pago_web_cuenta": "",
    "tema_backoffice": "clasico",
    "tema_tienda": "clasico",
}

# Temas disponibles: «clasico» (diseño original) y «tech» (oscuro con acentos neón).
TEMAS = ("clasico", "tech", "moda", "belleza", "mascotas", "hogar", "deporte", "gourmet")

_secret_lock = threading.Lock()


def ensure_dirs() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)


def get_secret() -> str:
    """Secreto de firma de sesiones. Se crea una sola vez con permisos 0600."""
    env = os.environ.get("CC_SECRET", "").strip()
    if env:
        return env
    with _secret_lock:
        ensure_dirs()
        if SECRET_PATH.exists():
            value = SECRET_PATH.read_text(encoding="utf-8").strip()
            if value:
                return value
        value = secrets.token_hex(48)
        SECRET_PATH.write_text(value, encoding="utf-8")
        try:
            SECRET_PATH.chmod(0o600)
        except OSError:
            pass
        return value
