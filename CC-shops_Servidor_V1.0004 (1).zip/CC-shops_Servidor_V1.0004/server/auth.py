"""Autenticación: contraseñas PBKDF2 y sesión firmada en cookie HttpOnly."""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import secrets
import time
from http.cookies import SimpleCookie

from . import config
from .util import txt


def hash_password(password: str) -> str:
    if not password or len(password) < 8:
        raise ValueError("La contraseña debe tener al menos 8 caracteres")
    salt = secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), salt.encode("utf-8"), config.PBKDF2_ITERATIONS
    )
    return f"pbkdf2_sha256${config.PBKDF2_ITERATIONS}${salt}${digest.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        algorithm, iterations, salt, expected = str(stored).split("$")
        if algorithm != "pbkdf2_sha256":
            return False
        digest = hashlib.pbkdf2_hmac(
            "sha256", (password or "").encode("utf-8"), salt.encode("utf-8"), int(iterations)
        )
        return hmac.compare_digest(digest.hex(), expected)
    except Exception:
        return False


def password_problem(password: str) -> str | None:
    if len(password or "") < 8:
        return "La contraseña debe tener al menos 8 caracteres"
    if not any(c.isalpha() for c in password) or not any(c.isdigit() for c in password):
        return "La contraseña debe incluir letras y números"
    if password.lower() in {"admin1234", "12345678", "password", "ccshops"}:
        return "Elige una contraseña menos predecible"
    return None


def _sign(raw: bytes) -> str:
    return hmac.new(config.get_secret().encode("utf-8"), raw, hashlib.sha256).hexdigest()


def create_session_token(user_id: str, version: int = 0) -> str:
    payload = json.dumps(
        {"u": user_id, "x": int(time.time()) + config.SESSION_DAYS * 86400, "v": int(version or 0)},
        separators=(",", ":"),
    ).encode("utf-8")
    body = base64.urlsafe_b64encode(payload).decode("ascii").rstrip("=")
    return f"{body}.{_sign(payload)}"


def read_session_token(token: str | None) -> tuple[str | None, int]:
    if not token or "." not in token:
        return None, 0
    body, signature = token.rsplit(".", 1)
    try:
        raw = base64.urlsafe_b64decode(body + "=" * (-len(body) % 4))
    except Exception:
        return None, 0
    if not hmac.compare_digest(_sign(raw), signature):
        return None, 0
    try:
        data = json.loads(raw)
    except Exception:
        return None, 0
    if int(data.get("x", 0) or 0) < time.time():
        return None, 0
    user_id = txt(data.get("u"), 80)
    return (user_id or None), int(data.get("v", 0) or 0)


def session_cookie(user_id: str, version: int = 0) -> str:
    token = create_session_token(user_id, version)
    parts = [
        f"{config.SESSION_COOKIE}={token}",
        "Path=/",
        "HttpOnly",
        "SameSite=Lax",
        f"Max-Age={config.SESSION_DAYS * 86400}",
    ]
    if config.IS_PROD:
        parts.append("Secure")
    return "; ".join(parts)


def clear_cookie() -> str:
    parts = [f"{config.SESSION_COOKIE}=", "Path=/", "HttpOnly", "SameSite=Lax", "Max-Age=0"]
    if config.IS_PROD:
        parts.append("Secure")
    return "; ".join(parts)


def _cookie_value(headers) -> str | None:
    cookie = SimpleCookie()
    try:
        raw = (headers.get("Cookie") or headers.get("cookie") or "") if headers else ""
        cookie.load(raw)
    except Exception:
        return None
    morsel = cookie.get(config.SESSION_COOKIE)
    return morsel.value if morsel else None


def current_user(headers) -> dict | None:
    """Devuelve el usuario de la sesión, validando versión y estado en cada petición."""
    from .db import one, session

    user_id, version = read_session_token(_cookie_value(headers))
    if not user_id:
        return None
    with session() as conn:
        row = one(
            conn,
            "SELECT id, nombre, email, rol, tienda_id, activo, session_version, ultimo_acceso FROM usuarios WHERE id=?",
            (user_id,),
        )
    if not row or not int(row["activo"]) or int(row["session_version"]) != version:
        return None
    from .roles import normalizar

    usuario = dict(row)
    usuario["rol"] = normalizar(usuario.get("rol") or "")
    return usuario
