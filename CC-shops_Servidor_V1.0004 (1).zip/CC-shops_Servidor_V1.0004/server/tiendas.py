"""Alta de tiendas por el propio cliente.

Crea la tienda, su usuario propietario y una configuración inicial neutra
(sin datos de demostración). Las direcciones (slugs) son únicas y se validan.
"""
from __future__ import annotations

import re
import unicodedata

from . import auth, db
from .db import one
from .util import ApiError, iso_now, new_id, txt

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
SLUG_RE = re.compile(r"^[a-z0-9](?:[a-z0-9-]{1,38}[a-z0-9])$")
# Direcciones que no pueden usarse porque tienen un significado propio en la plataforma.
RESERVADOS = {"www", "api", "app", "admin", "static", "mail", "soporte", "ayuda", "cuenta", "superadmin", "login", "registro"}

# Ajustes iniciales: neutros. El propietario los completa en Ajustes.
AJUSTES_INICIALES = {
    "tienda_claim": "",
    "tienda_telefono": "",
    "tienda_direccion": "",
    "aviso_pago": "",
    "recargo_contrareembolso": "0",
}


def email_de_contacto(conn, tienda_id: str) -> str:
    """Correo registrado en la cuenta del propietario de la tienda."""
    from .db import one

    fila = one(
        conn,
        "SELECT u.email FROM tiendas t JOIN usuarios u ON u.id=t.propietario_id WHERE t.id=?",
        (tienda_id,),
    )
    if fila:
        return fila["email"]
    # Tiendas sin propietario asignado (p. ej. la demostración): primer administrador activo.
    fila = one(
        conn,
        "SELECT email FROM usuarios WHERE tienda_id=? AND rol='admin' AND activo=1 ORDER BY created_at LIMIT 1",
        (tienda_id,),
    )
    return fila["email"] if fila else ""


def normalizar_slug(valor: str) -> str:
    """Convierte un nombre en una dirección: minúsculas, sin acentos, guiones entre palabras."""
    texto = unicodedata.normalize("NFKD", str(valor or "")).encode("ascii", "ignore").decode("ascii")
    texto = re.sub(r"[^a-z0-9]+", "-", texto.lower())
    return texto.strip("-")


def registrar_tienda(conn, datos: dict, ip: str = "") -> dict:
    nombre_negocio = txt(datos.get("nombre_negocio"), 80)
    if len(nombre_negocio) < 2:
        raise ApiError("El nombre de tu tienda es obligatorio", 400, "nombre_negocio")

    slug = normalizar_slug(datos.get("slug") or nombre_negocio)
    if not SLUG_RE.match(slug):
        raise ApiError("La dirección de la tienda debe tener entre 3 y 40 letras, números o guiones", 400, "slug")
    if slug in RESERVADOS:
        raise ApiError("Esa dirección no está disponible. Elige otra", 400, "slug")
    if one(conn, "SELECT id FROM tiendas WHERE slug=?", (slug,)):
        raise ApiError("Esa dirección ya está en uso. Elige otra", 409, "slug")

    nombre = txt(datos.get("nombre"), 120)
    if len(nombre) < 2:
        raise ApiError("Tu nombre es obligatorio", 400, "nombre")
    email = txt(datos.get("email"), 160).lower()
    if not EMAIL_RE.match(email):
        raise ApiError("El email no es válido", 400, "email")
    if one(conn, "SELECT id FROM usuarios WHERE email=?", (email,)):
        raise ApiError("Ya existe una cuenta con ese email", 409, "email")
    password = str(datos.get("password") or "")
    problema = auth.password_problem(password)
    if problema:
        raise ApiError(problema, 400, "password")

    tid = new_id("TND")
    sello = iso_now()
    conn.execute(
        "INSERT INTO tiendas (id, slug, nombre, estado, dominio_provisional, dominio_propio, config, created_at, updated_at) "
        "VALUES (?,?,?,?,?,?,?,?,?)",
        (tid, slug, nombre_negocio, "activa", "", "", "{}", sello, sello),
    )
    uid = new_id("USR")
    conn.execute(
        "INSERT INTO usuarios (id, nombre, email, password_hash, rol, tienda_id, activo, session_version, ultimo_acceso, created_at) "
        "VALUES (?,?,?,?,'admin',?,1,0,?,?)",
        (uid, nombre, email, auth.hash_password(password), tid, sello, sello),
    )
    db.save_settings(conn, {"tienda_nombre": nombre_negocio, "tienda_email": email, **AJUSTES_INICIALES}, tid)
    conn.execute("UPDATE tiendas SET propietario_id=? WHERE id=?", (uid, tid))
    db.audit(conn, uid, "tienda.registrada", "tienda", tid, {"slug": slug}, ip)
    return {
        "tienda": {"id": tid, "slug": slug, "nombre": nombre_negocio},
        "usuario": {"id": uid, "nombre": nombre, "email": email, "rol": "admin", "tienda_id": tid, "ultimo_acceso": sello},
    }
