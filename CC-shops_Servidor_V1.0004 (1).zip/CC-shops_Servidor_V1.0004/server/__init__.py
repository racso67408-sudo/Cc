"""Paquete del servidor CC-Shops."""
