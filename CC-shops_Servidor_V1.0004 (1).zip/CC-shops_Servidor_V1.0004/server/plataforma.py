"""Gestión de la plataforma (superadmin): métricas, planes, suscripciones, tiendas, usuarios,
landing/SEO y soporte (tickets con chat). No accede a datos operativos de las tiendas
más allá de agregados (conteos, importes, almacenamiento)."""
from __future__ import annotations

import os
from datetime import date, datetime, timedelta

from . import config, db
from .db import all_rows, one
from .util import ApiError, iso_now, money, new_id, txt

# ---------------------------------------------------------------- métricas

def metricas(conn) -> dict:
    tiendas = all_rows(conn, "SELECT id, nombre, slug, estado, created_at FROM tiendas ORDER BY created_at")
    filas = []
    hoy = date.today()
    for t in tiendas:
        tid = t["id"]
        productos = one(conn, "SELECT COUNT(*) AS n FROM productos WHERE tienda_id=? AND activo=1", (tid,))["n"]
        pedidos = one(conn, "SELECT COUNT(*) AS n FROM pedidos WHERE tienda_id=? AND estado<>'cancelado'", (tid,))["n"]
        ventas = one(conn, "SELECT COALESCE(SUM(total),0) AS v FROM pedidos WHERE tienda_id=? AND estado<>'cancelado'", (tid,))["v"]
        clientes = one(conn, "SELECT COUNT(DISTINCT cliente_email) AS n FROM pedidos WHERE tienda_id=? AND estado<>'cancelado'", (tid,))["n"]
        clientes_dia = one(
            conn,
            "SELECT COUNT(*) AS n FROM (SELECT DISTINCT cliente_email, substr(created_at,1,10) AS d FROM pedidos WHERE tienda_id=? AND estado<>'cancelado')",
            (tid,),
        )["n"]
        dias = max(1, (hoy - datetime.fromisoformat(t["created_at"][:10]).date()).days + 1)
        bytes_img = one(conn, "SELECT COALESCE(SUM(LENGTH(imagen)),0) AS b FROM productos WHERE tienda_id=?", (tid,))["b"]
        filas.append({
            "id": tid, "nombre": t["nombre"], "slug": t["slug"], "estado": t["estado"],
            "productos": int(productos), "pedidos": int(pedidos), "ventas": money(ventas),
            "clientes": int(clientes), "clientes_medios_dia": round(clientes_dia / dias, 2),
            "almacenamiento_kb": round(float(bytes_img) / 1024, 1),
        })
    total_clientes = one(conn, "SELECT COUNT(*) AS n FROM usuarios WHERE rol='cliente'")["n"]
    emails_pedidos = one(conn, "SELECT COUNT(DISTINCT cliente_email) AS n FROM pedidos")["n"]
    return {
        "tiendas": len(tiendas),
        "tiendas_activas": sum(1 for t in tiendas if t["estado"] == "activa"),
        "productos": sum(f["productos"] for f in filas),
        "clientes_total": int(total_clientes) + int(emails_pedidos),
        "ventas_total": money(sum(f["ventas"] for f in filas)),
        "pedidos_total": sum(f["pedidos"] for f in filas),
        "almacenamiento_bd_mb": round(os.path.getsize(config.DB_PATH) / 1048576, 2) if os.path.exists(config.DB_PATH) else 0,
        "almacenamiento_imagenes_kb": round(sum(f["almacenamiento_kb"] for f in filas), 1),
        "por_tienda": filas,
    }

# ---------------------------------------------------------------- planes y suscripciones

def listar_planes(conn) -> list[dict]:
    return [dict(f) for f in all_rows(conn, "SELECT * FROM planes ORDER BY precio, nombre")]


def guardar_plan(conn, datos: dict, plan_id: str | None = None) -> dict:
    nombre = txt(datos.get("nombre"), 60)
    if len(nombre) < 2:
        raise ApiError("El nombre del plan es obligatorio", 400, "nombre")
    try:
        precio = money(float(datos.get("precio") or 0))
        max_prod = int(datos.get("max_productos") or 0)
        max_usr = int(datos.get("max_usuarios") or 0)
        max_mb = int(datos.get("max_storage_mb") or 0)
    except (TypeError, ValueError):
        raise ApiError("Precio y límites deben ser números", 400, "precio")
    if precio < 0 or max_prod < 1 or max_usr < 1 or max_mb < 1:
        raise ApiError("Precio no negativo y límites de al menos 1", 400, "precio")
    periodicidad = txt(datos.get("periodicidad") or "mensual", 20)
    activo = 1 if datos.get("activo", True) else 0
    descripcion = txt(datos.get("descripcion"), 240)
    if plan_id:
        if not one(conn, "SELECT id FROM planes WHERE id=?", (plan_id,)):
            raise ApiError("Plan no encontrado", 404)
        conn.execute(
            "UPDATE planes SET nombre=?, descripcion=?, precio=?, periodicidad=?, max_productos=?, max_usuarios=?, max_storage_mb=?, activo=? WHERE id=?",
            (nombre, descripcion, precio, periodicidad, max_prod, max_usr, max_mb, activo, plan_id),
        )
        return dict(one(conn, "SELECT * FROM planes WHERE id=?", (plan_id,)))
    pid = new_id("PLN")
    conn.execute(
        "INSERT INTO planes (id, nombre, descripcion, precio, periodicidad, max_productos, max_usuarios, max_storage_mb, activo, created_at) VALUES (?,?,?,?,?,?,?,?,?,?)",
        (pid, nombre, descripcion, precio, periodicidad, max_prod, max_usr, max_mb, activo, iso_now()),
    )
    return dict(one(conn, "SELECT * FROM planes WHERE id=?", (pid,)))


def listar_suscripciones(conn) -> list[dict]:
    return [dict(f) for f in all_rows(
        conn,
        "SELECT s.*, t.nombre AS tienda_nombre, p.nombre AS plan_nombre FROM suscripciones s "
        "JOIN tiendas t ON t.id=s.tienda_id JOIN planes p ON p.id=s.plan_id ORDER BY s.created_at DESC",
    )]


def asignar_suscripcion(conn, datos: dict, actor: str | None = None, suscripcion_id: str | None = None) -> dict:
    estado = txt(datos.get("estado") or "activa", 20)
    if estado not in ("activa", "pendiente", "vencida", "cancelada"):
        raise ApiError("Estado de suscripción no válido", 400, "estado")
    try:
        inicio = date.fromisoformat(txt(datos.get("fecha_inicio") or date.today().isoformat(), 10))
        fin = date.fromisoformat(txt(datos.get("fecha_fin") or (inicio + timedelta(days=30)).isoformat(), 10))
    except ValueError:
        raise ApiError("Las fechas no son válidas", 400, "fecha_inicio")
    if fin < inicio:
        raise ApiError("La fecha de fin es anterior a la de inicio", 400, "fecha_fin")
    plan_id = txt(datos.get("plan_id"), 40)
    if not one(conn, "SELECT id FROM planes WHERE id=?", (plan_id,)):
        raise ApiError("Plan no encontrado", 400, "plan_id")
    sello = iso_now()
    if suscripcion_id:
        sus = one(conn, "SELECT * FROM suscripciones WHERE id=?", (suscripcion_id,))
        if not sus:
            raise ApiError("Suscripción no encontrada", 404)
        tienda_id = sus["tienda_id"]
        conn.execute(
            "UPDATE suscripciones SET plan_id=?, estado=?, fecha_inicio=?, fecha_fin=?, updated_at=? WHERE id=?",
            (plan_id, estado, inicio.isoformat(), fin.isoformat(), sello, suscripcion_id),
        )
    else:
        tienda_id = txt(datos.get("tienda_id"), 40)
        if not one(conn, "SELECT id FROM tiendas WHERE id=?", (tienda_id,)):
            raise ApiError("Tienda no encontrada", 400, "tienda_id")
        suscripcion_id = new_id("SUS")
        conn.execute(
            "INSERT INTO suscripciones (id, tienda_id, plan_id, estado, fecha_inicio, fecha_fin, renovacion_auto, metodo_pago, created_at, updated_at) "
            "VALUES (?,?,?,?,?,?,1,'',?,?)",
            (suscripcion_id, tienda_id, plan_id, estado, inicio.isoformat(), fin.isoformat(), sello, sello),
        )
    if estado == "activa":
        conn.execute("UPDATE tiendas SET plan_id=? WHERE id=?", (plan_id, tienda_id))
    db.audit(conn, actor, "plataforma.suscripcion", "suscripcion", suscripcion_id, {"plan": plan_id, "estado": estado})
    return dict(one(conn, "SELECT * FROM suscripciones WHERE id=?", (suscripcion_id,)))

# ---------------------------------------------------------------- tiendas y usuarios

def listar_tiendas(conn) -> list[dict]:
    return [dict(f) for f in all_rows(
        conn,
        """SELECT t.*, u.nombre AS propietario_nombre, u.email AS propietario_email, p.nombre AS plan_nombre,
                  (SELECT COUNT(*) FROM productos pr WHERE pr.tienda_id=t.id AND pr.activo=1) AS productos
           FROM tiendas t LEFT JOIN usuarios u ON u.id=t.propietario_id LEFT JOIN planes p ON p.id=t.plan_id
           ORDER BY t.created_at DESC""",
    )]


def cambiar_estado_tienda(conn, tienda_id: str, estado: str, actor: str | None = None) -> dict:
    if estado not in ("activa", "suspendida"):
        raise ApiError("Estado no válido", 400, "estado")
    if not one(conn, "SELECT id FROM tiendas WHERE id=?", (tienda_id,)):
        raise ApiError("Tienda no encontrada", 404)
    conn.execute("UPDATE tiendas SET estado=?, updated_at=? WHERE id=?", (estado, iso_now(), tienda_id))
    db.audit(conn, actor, "plataforma.tienda_estado", "tienda", tienda_id, {"estado": estado})
    return {"id": tienda_id, "estado": estado}


def listar_usuarios(conn) -> list[dict]:
    return [dict(f) for f in all_rows(
        conn,
        """SELECT u.id, u.nombre, u.email, u.rol, u.activo, u.ultimo_acceso, u.created_at, t.nombre AS tienda_nombre
           FROM usuarios u LEFT JOIN tiendas t ON t.id=u.tienda_id ORDER BY u.created_at DESC LIMIT 500""",
    )]


def cambiar_activo_usuario(conn, usuario_id: str, activo: bool, actor: str | None = None) -> dict:
    fila = one(conn, "SELECT id, rol FROM usuarios WHERE id=?", (usuario_id,))
    if not fila:
        raise ApiError("Usuario no encontrado", 404)
    if fila["rol"] == "superadmin" and not activo:
        raise ApiError("No se puede desactivar un superadmin desde aquí", 409)
    conn.execute("UPDATE usuarios SET activo=?, session_version=session_version+1 WHERE id=?", (1 if activo else 0, usuario_id))
    db.audit(conn, actor, "plataforma.usuario_activo", "usuario", usuario_id, {"activo": activo})
    return {"id": usuario_id, "activo": activo}

# ---------------------------------------------------------------- landing y SEO

CLAVES_WEB = ("seo_titulo", "seo_descripcion", "landing_titulo", "landing_subtitulo")
VALORES_WEB = {
    "seo_titulo": "CC Shops · Tu tienda online y tu control de stock",
    "seo_descripcion": "CC Shops: tienda online por suscripción con backoffice, catálogo, pedidos, inventario y métricas. Elige el estilo clásico o tech.",
    "landing_titulo": "Vende online y controla tu stock desde el mismo sitio.",
    "landing_subtitulo": "Catálogo, pedidos, inventario con coste real y métricas de negocio en un único panel. Tu tienda, tu marca y tus datos.",
}


def landing_config(conn) -> dict:
    guardado = {f["clave"]: f["valor"] for f in all_rows(conn, "SELECT clave, valor FROM plataforma_config WHERE clave IN (?,?,?,?)", CLAVES_WEB)}
    return {k: guardado.get(k) or VALORES_WEB[k] for k in CLAVES_WEB}


def guardar_landing(conn, datos: dict, actor: str | None = None) -> dict:
    for clave in CLAVES_WEB:
        if clave in datos:
            valor = txt(datos.get(clave), 300 if clave.endswith("descripcion") or clave.endswith("subtitulo") else 120)
            if not valor:
                raise ApiError("Este texto no puede quedar vacío", 400, clave)
            conn.execute(
                "INSERT INTO plataforma_config (clave, valor, updated_at) VALUES (?,?,?) ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor, updated_at=excluded.updated_at",
                (clave, valor, iso_now()),
            )
    db.audit(conn, actor, "plataforma.landing", "plataforma", "landing", {"claves": sorted(k for k in datos if k in CLAVES_WEB)})
    return landing_config(conn)

def landing_html(conn) -> str:
    """Landing con los textos configurados por el superadmin (título, descripción y titular)."""
    import html as _html
    import re as _re

    cfg = landing_config(conn)
    texto = (config.STATIC_DIR / "landing.html").read_text(encoding="utf-8")
    texto = _re.sub(r"<title>.*?</title>", lambda m: f"<title>{_html.escape(cfg['seo_titulo'])}</title>", texto, count=1, flags=_re.S)
    texto = _re.sub(
        r'(<meta name="description" content=")[^"]*(")',
        lambda m: m.group(1) + _html.escape(cfg["seo_descripcion"], quote=True) + m.group(2),
        texto, count=1,
    )
    texto = _re.sub(r"<h1>.*?</h1>", lambda m: f"<h1>{_html.escape(cfg['landing_titulo'])}</h1>", texto, count=1, flags=_re.S)
    texto = _re.sub(r'<p class="lead">.*?</p>', lambda m: f'<p class="lead">{_html.escape(cfg["landing_subtitulo"])}</p>', texto, count=1, flags=_re.S)
    return texto
