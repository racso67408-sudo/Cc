"""Capa SQLite: conexión, esquema, ajustes, secuencias y auditoría."""
from __future__ import annotations

import json
import re
import sqlite3
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Any, Iterator

from . import config, pgadapter
from .util import biz_now, biz_today, iso_now, new_id, txt

SCHEMA_PATH = Path(__file__).with_name("schema.sql")


ERRORES_BD = (sqlite3.Error,) + pgadapter.ERRORES


def connect():
    if config.ES_POSTGRES:
        return pgadapter.PgConnection(config.DATABASE_URL)
    config.ensure_dirs()
    conn = sqlite3.connect(config.DB_PATH, timeout=20, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA busy_timeout=15000")
    return conn


@contextmanager
def session(write: bool = False) -> Iterator[sqlite3.Connection]:
    """Una conexión por petición. Las escrituras usan BEGIN IMMEDIATE para serializar el Kardex."""
    conn = connect()
    try:
        if write:
            conn.execute("BEGIN IMMEDIATE")
        yield conn
        if write:
            conn.execute("COMMIT")
    except Exception:
        if write:
            try:
                conn.execute("ROLLBACK")
            except ERRORES_BD:
                pass
        raise
    finally:
        conn.close()


def tabla_existe(conn, nombre: str) -> bool:
    if config.ES_POSTGRES:
        return one(conn, "SELECT 1 AS x FROM information_schema.tables WHERE table_schema=current_schema() AND table_name=?", (nombre,)) is not None
    return one(conn, "SELECT name FROM sqlite_master WHERE type='table' AND name=?", (nombre,)) is not None


def columnas(conn, nombre: str) -> list[str]:
    if config.ES_POSTGRES:
        return [r["column_name"] for r in all_rows(
            conn, "SELECT column_name FROM information_schema.columns WHERE table_schema=current_schema() AND table_name=? ORDER BY ordinal_position", (nombre,))]
    return [r["name"] for r in conn.execute(f"PRAGMA table_info({nombre})").fetchall()]


def sql_tabla(conn, nombre: str) -> str | None:
    """Texto CREATE de la tabla. Solo existe en SQLite: las migraciones de reconstrucción lo usan."""
    if config.ES_POSTGRES:
        return None
    fila = one(conn, "SELECT sql FROM sqlite_master WHERE type='table' AND name=?", (nombre,))
    return fila["sql"] if fila else None


def indices_tabla(conn, nombre: str) -> list[str]:
    if config.ES_POSTGRES:
        return []
    return [r["sql"] for r in all_rows(conn, "SELECT sql FROM sqlite_master WHERE type='index' AND tbl_name=? AND sql IS NOT NULL", (nombre,))]


def one(conn, sql: str, params: tuple | list = ()):
    return conn.execute(sql, tuple(params)).fetchone()


def all_rows(conn, sql: str, params: tuple | list = ()) -> list:
    return conn.execute(sql, tuple(params)).fetchall()


def execute(conn: sqlite3.Connection, sql: str, params: tuple | list = ()) -> sqlite3.Cursor:
    return conn.execute(sql, tuple(params))


def _asegurar_tienda_demo(conn) -> str:
    """Devuelve la tienda demo; si no existe, la crea y asigna los datos y usuarios sin tienda."""
    from .util import new_id, iso_now

    fila = one(conn, "SELECT id FROM tiendas ORDER BY created_at LIMIT 1")
    if fila:
        return str(fila["id"])
    tid = new_id("TND")
    conn.execute(
        "INSERT INTO tiendas (id, slug, nombre, estado, dominio_provisional, config, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?)",
        (tid, "demo", "CC Shops Demo", "activa", "demo.ccshops.com", "{}", iso_now(), iso_now()),
    )
    for tabla in ("categorias", "productos", "proveedores", "compras", "pedidos", "movimientos", "pedido_chat"):
        conn.execute(f"UPDATE {tabla} SET tienda_id=? WHERE tienda_id IS NULL", (tid,))
    conn.execute("UPDATE usuarios SET tienda_id=? WHERE tienda_id IS NULL AND rol<>'superadmin'", (tid,))
    conn.execute("UPDATE configuracion SET tienda_id=? WHERE tienda_id IS NULL", (tid,))
    return tid


def _migrar_estados_pedido(conn) -> None:
    """Quita la restricción fija de estados de la tabla de pedidos (ahora hay «preparado»)."""
    sql_actual = sql_tabla(conn, "pedidos")
    if not sql_actual or "CHECK (estado IN" not in sql_actual:
        return
    sql_nuevo = re.sub(r"CHECK \(estado IN \([^)]*\)\)", "", sql_actual, count=1)
    sql_nuevo = sql_nuevo.replace("CREATE TABLE IF NOT EXISTS pedidos (", "CREATE TABLE pedidos_nuevo (", 1)
    sql_nuevo = sql_nuevo.replace("CREATE TABLE pedidos (", "CREATE TABLE pedidos_nuevo (", 1)
    indices = indices_tabla(conn, "pedidos")
    conn.execute("PRAGMA foreign_keys=OFF")
    conn.execute("BEGIN")
    try:
        conn.execute(sql_nuevo)
        conn.execute("INSERT INTO pedidos_nuevo SELECT * FROM pedidos")
        conn.execute("DROP TABLE pedidos")
        conn.execute("ALTER TABLE pedidos_nuevo RENAME TO pedidos")
        for sql in indices:
            conn.execute(sql)
        conn.execute("COMMIT")
    except Exception:
        conn.execute("ROLLBACK")
        raise
    finally:
        conn.execute("PRAGMA foreign_keys=ON")


def _migrar_categorias(conn) -> None:
    """Añade subcategorías (padre_id) y quita la unicidad global del nombre de categoría."""
    cols = columnas(conn, "categorias")
    if not cols:
        return
    if "padre_id" not in cols:
        conn.execute("ALTER TABLE categorias ADD COLUMN padre_id TEXT REFERENCES categorias(id)")
    sql_actual = sql_tabla(conn, "categorias")
    if sql_actual and re.search(r"nombre\s+TEXT NOT NULL UNIQUE", sql_actual):
        sql_nuevo = re.sub(r"(nombre\s+TEXT NOT NULL) UNIQUE", r"\1", sql_actual, count=1)
        sql_nuevo = sql_nuevo.replace("CREATE TABLE categorias (", "CREATE TABLE categorias_nuevo (", 1)
        sql_nuevo = sql_nuevo.replace("CREATE TABLE IF NOT EXISTS categorias (", "CREATE TABLE categorias_nuevo (", 1)
        conn.execute("PRAGMA foreign_keys=OFF")
        conn.execute("BEGIN")
        try:
            conn.execute(sql_nuevo)
            conn.execute("INSERT INTO categorias_nuevo SELECT * FROM categorias")
            conn.execute("DROP TABLE categorias")
            conn.execute("ALTER TABLE categorias_nuevo RENAME TO categorias")
            conn.execute("COMMIT")
        except Exception:
            conn.execute("ROLLBACK")
            raise
        finally:
            conn.execute("PRAGMA foreign_keys=ON")
    conn.execute(
        "CREATE UNIQUE INDEX IF NOT EXISTS idx_categorias_nombre ON categorias(tienda_id, COALESCE(padre_id, ''), LOWER(nombre))"
    )


def _migrar_roles(conn) -> None:
    """Quita la restricción fija de roles de la tabla de usuarios y renombra los roles antiguos."""
    sql_actual = sql_tabla(conn, "usuarios")
    if sql_actual and "CHECK (rol IN" in sql_actual:
        columnas_actuales = columnas(conn, "usuarios")
        destino = ["id", "nombre", "email", "password_hash", "rol", "tienda_id", "activo", "session_version",
                   "ultimo_acceso", "created_at", "two_factor_secret", "two_factor_enabled", "recovery_codes"]
        comunes = [c for c in destino if c in columnas_actuales]
        conn.execute("PRAGMA foreign_keys=OFF")
        conn.execute("BEGIN")
        conn.execute(
            """CREATE TABLE usuarios_nuevo (
                id TEXT PRIMARY KEY,
                nombre TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                rol TEXT NOT NULL DEFAULT 'admin',
                tienda_id TEXT REFERENCES tiendas(id),
                activo INTEGER NOT NULL DEFAULT 1,
                session_version INTEGER NOT NULL DEFAULT 0,
                ultimo_acceso TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL DEFAULT '',
                two_factor_secret TEXT NOT NULL DEFAULT '',
                two_factor_enabled INTEGER NOT NULL DEFAULT 0,
                recovery_codes TEXT NOT NULL DEFAULT '[]'
            )"""
        )
        lista = ", ".join(comunes)
        conn.execute(f"INSERT INTO usuarios_nuevo ({lista}) SELECT {lista} FROM usuarios")
        conn.execute("DROP TABLE usuarios")
        conn.execute("ALTER TABLE usuarios_nuevo RENAME TO usuarios")
        conn.execute("COMMIT")
        conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("UPDATE usuarios SET rol='preparador' WHERE rol='operador'")
    conn.execute("UPDATE usuarios SET rol='admin' WHERE rol='propietario'")


def init_db(seed_demo: bool = True) -> None:
    config.ensure_dirs()
    conn = connect()
    try:
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.executescript(SCHEMA_PATH.read_text(encoding="utf-8"))
        from . import soporte as _soporte
        _soporte.migrar(conn)
        from . import clientes as _clientes
        _clientes.migrar(conn)
        # Migración: columna cliente_id en pedidos
        try:
            conn.execute("ALTER TABLE pedidos ADD COLUMN cliente_id TEXT REFERENCES usuarios(id)")
        except Exception:
            pass
        # Migración: tienda_id en entidades principales
        for tabla in ("usuarios", "categorias", "productos", "proveedores", "compras", "pedidos", "movimientos", "pedido_chat"):
            try:
                conn.execute(f"ALTER TABLE {tabla} ADD COLUMN tienda_id TEXT REFERENCES tiendas(id)")
            except Exception:
                pass
        # Migración: estado de pago (verificación de transferencias y cobro en contrareembolso)
        try:
            conn.execute("ALTER TABLE pedidos ADD COLUMN pago_estado TEXT NOT NULL DEFAULT 'no_aplica'")
        except Exception:
            pass
        # Migración: roles de equipo (admin, preparador, domiciliario) y límite de administradores por tienda
        _migrar_roles(conn)
        _migrar_estados_pedido(conn)
        _migrar_categorias(conn)
        try:
            conn.execute("ALTER TABLE tiendas ADD COLUMN max_admins INTEGER NOT NULL DEFAULT 3")
        except Exception:
            pass
        # Migración: variantes (un producto hijo por combinación de atributos)
        for col in ("padre_id TEXT REFERENCES productos(id)", "atributos TEXT NOT NULL DEFAULT '{}'"):
            try:
                conn.execute(f"ALTER TABLE productos ADD COLUMN {col}")
            except Exception:
                pass
        conn.execute("CREATE INDEX IF NOT EXISTS idx_productos_padre ON productos(padre_id)")
        # Migración: dominio propio por tienda (dominio_propio ya existía)
        for col in ("dominio_modo TEXT NOT NULL DEFAULT ''",
                    "dominio_estado TEXT NOT NULL DEFAULT 'sin_configurar'",
                    "dominio_add_on_activo INTEGER NOT NULL DEFAULT 0",
                    "dominio_verificado_at TEXT NOT NULL DEFAULT ''"):
            try:
                conn.execute(f"ALTER TABLE tiendas ADD COLUMN {col}")
            except Exception:
                pass
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_tiendas_dominio ON tiendas(dominio_propio) WHERE dominio_propio <> ''")
        # Migración: temas retirados (V2) pasan a Clásico
        conn.execute(
            "UPDATE configuracion SET valor='clasico' WHERE (clave LIKE '%:tema_tienda' OR clave LIKE '%:tema_backoffice' OR clave IN ('tema_tienda','tema_backoffice')) "
            "AND valor IN ('claro','claro-calido','oscuro','oscuro-azul','moderno','clasico-elegante')"
        )
        # Migración: packs y promociones sobre productos
        for col in ("es_pack INTEGER NOT NULL DEFAULT 0",
                    "promo_activa INTEGER NOT NULL DEFAULT 0",
                    "promo_precio REAL NOT NULL DEFAULT 0",
                    "promo_stock_inicial REAL NOT NULL DEFAULT 0",
                    "promo_stock_restante REAL NOT NULL DEFAULT 0",
                    "promo_fin TEXT NOT NULL DEFAULT ''"):
            try:
                conn.execute(f"ALTER TABLE productos ADD COLUMN {col}")
            except Exception:
                pass
        try:
            conn.execute("ALTER TABLE pedido_lineas ADD COLUMN promo INTEGER NOT NULL DEFAULT 0")
        except Exception:
            pass
        # Migración: forma de entrega y envío asignado por el administrador
        for col in ("tipo_entrega TEXT NOT NULL DEFAULT 'recogida'",
                    "envio_pendiente INTEGER NOT NULL DEFAULT 0",
                    "transportista TEXT NOT NULL DEFAULT ''",
                    "seguimiento TEXT NOT NULL DEFAULT ''",
                    "recogida_fecha TEXT NOT NULL DEFAULT ''",
                    "recogida_hora TEXT NOT NULL DEFAULT ''",
                    "envio_cobro TEXT NOT NULL DEFAULT ''",
                    "envio_pagado INTEGER NOT NULL DEFAULT 0",
                    "envio_cobrado INTEGER NOT NULL DEFAULT 0",
                    "pago_vence_at TEXT NOT NULL DEFAULT ''",
                    "pago_cancela_at TEXT NOT NULL DEFAULT ''"):
            try:
                conn.execute(f"ALTER TABLE pedidos ADD COLUMN {col}")
            except Exception:
                pass
        # Migración: 2FA en usuarios
        for col in ("two_factor_secret TEXT NOT NULL DEFAULT ''",
                    "two_factor_enabled INTEGER NOT NULL DEFAULT 0",
                    "recovery_codes TEXT NOT NULL DEFAULT '[]'"):
            try:
                conn.execute(f"ALTER TABLE usuarios ADD COLUMN {col}")
            except Exception:
                pass
        from . import seed

        seed.ensure_admin(conn)
        # Tienda demo antes de la siembra: todos los datos nacen con tienda_id.
        # La tienda demo existe en desarrollo y pruebas; en producción solo si se pide la siembra.
        if seed_demo or not config.IS_PROD:
            tienda_demo = _asegurar_tienda_demo(conn)
            if seed_demo and not one(conn, "SELECT COUNT(*) AS n FROM productos")["n"]:
                seed.seed_demo(conn, tienda_demo)
        # Multitienda: planes por defecto
        if not one(conn, "SELECT COUNT(*) AS n FROM planes")["n"]:
            from .util import new_id, iso_now
            for nombre, precio, prod, usr, storage in [("Básico", 19.0, 50, 2, 200), ("Pro", 49.0, 500, 10, 1000), ("Enterprise", 129.0, 5000, 50, 5000)]:
                conn.execute("INSERT INTO planes (id, nombre, descripcion, precio, periodicidad, max_productos, max_usuarios, max_storage_mb, activo, created_at) VALUES (?,?,?,?, 'mensual', ?, ?, ?, 1, ?)",
                    (new_id("PLN"), nombre, f"Plan {nombre}", precio, prod, usr, storage, iso_now()))
        # Ajustes por tienda: las claves antiguas (sin prefijo) pasan a la primera tienda.
        primera = one(conn, "SELECT id FROM tiendas ORDER BY created_at LIMIT 1")
        if primera:
            conn.execute(
                "UPDATE configuracion SET clave = ? || ':' || clave WHERE clave NOT LIKE '%:%'",
                (primera["id"],),
            )
        conn.commit()
    finally:
        conn.close()


def _clave_tienda(tienda_id: str, clave: str) -> str:
    """Los ajustes se guardan como «<tienda_id>:<clave>» para aislar cada tienda."""
    if not tienda_id:
        raise ValueError("Los ajustes requieren una tienda")
    return f"{tienda_id}:{clave}"


def settings_all(conn: sqlite3.Connection, tienda_id: str | None = None) -> dict[str, str]:
    datos = dict(config.TIENDA_DEFAULTS)
    if not tienda_id:
        return datos
    prefijo = f"{tienda_id}:"
    filas = all_rows(conn, "SELECT clave, valor FROM configuracion WHERE substr(clave, 1, ?) = ?", (len(prefijo), prefijo))
    datos.update({f["clave"][len(prefijo):]: f["valor"] for f in filas})
    return datos


def setting(conn: sqlite3.Connection, clave: str, defecto: str = "", tienda_id: str | None = None) -> str:
    if not tienda_id:
        return defecto
    fila = one(conn, "SELECT valor FROM configuracion WHERE clave=?", (_clave_tienda(tienda_id, clave),))
    return str(fila["valor"]) if fila else defecto


def save_settings(conn: sqlite3.Connection, datos: dict[str, Any], tienda_id: str) -> None:
    for clave, valor in datos.items():
        conn.execute(
            "INSERT INTO configuracion (clave, valor, tienda_id) VALUES (?, ?, ?) "
            "ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor",
            (_clave_tienda(tienda_id, clave), str(valor), tienda_id),
        )


def next_sequence(conn: sqlite3.Connection, nombre: str) -> int:
    fila = one(conn, "SELECT valor FROM secuencias WHERE nombre=?", (nombre,))
    if fila:
        valor = int(fila["valor"]) + 1
        conn.execute("UPDATE secuencias SET valor=? WHERE nombre=?", (valor, nombre))
    else:
        valor = 1
        conn.execute("INSERT INTO secuencias (nombre, valor) VALUES (?, ?)", (nombre, valor))
    return valor


def document_number(conn: sqlite3.Connection, prefijo: str, serie: str) -> str:
    year = biz_today().year
    n = next_sequence(conn, f"{serie}:{year}")
    return f"{prefijo}-{year}-{n:04d}"


def audit(
    conn: sqlite3.Connection,
    usuario_id: str | None,
    accion: str,
    entidad: str = "",
    entidad_id: str = "",
    detalle: dict | str | None = None,
    ip: str = "",
) -> None:
    if isinstance(detalle, dict):
        detalle_txt = json.dumps(detalle, ensure_ascii=False, default=str)[:2000]
    else:
        detalle_txt = txt(detalle, 2000)
    tienda_id = None
    if usuario_id:
        fila = one(conn, "SELECT tienda_id FROM usuarios WHERE id=?", (usuario_id,))
        tienda_id = fila["tienda_id"] if fila else None
    conn.execute(
        "INSERT INTO eventos (id, usuario_id, accion, entidad, entidad_id, detalle, ip, created_at, tienda_id) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (new_id("EVT"), usuario_id, accion, entidad, entidad_id, detalle_txt, ip, iso_now(), tienda_id),
    )


def backup(destino: Path) -> Path:
    """Copia consistente de SQLite usando la API de backup (con PostgreSQL usa pg_dump; ver deploy/backup.sh)."""
    if config.ES_POSTGRES:
        raise RuntimeError("Con PostgreSQL la copia se hace con pg_dump (deploy/backup.sh).")
    destino = Path(destino)
    destino.parent.mkdir(parents=True, exist_ok=True)
    origen = connect()
    copia = sqlite3.connect(destino)
    try:
        origen.backup(copia)
    finally:
        copia.close()
        origen.close()
    return destino


def db_stats() -> dict:
    conn = connect()
    try:
        filas = {}
        for tabla in ("productos", "pedidos", "movimientos", "compras"):
            filas[tabla] = one(conn, f"SELECT COUNT(*) AS n FROM {tabla}")["n"]
        filas["db"] = str(config.DB_PATH)
        filas["actualizado"] = iso_now()
        return filas
    finally:
        conn.close()
