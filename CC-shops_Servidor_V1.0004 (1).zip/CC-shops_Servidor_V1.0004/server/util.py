"""Utilidades comunes: fechas de negocio, importes, texto y validaciones."""
from __future__ import annotations

import re
import unicodedata
import uuid
from datetime import date, datetime, timedelta
from decimal import Decimal, ROUND_HALF_UP
from zoneinfo import ZoneInfo

MADRID = ZoneInfo("Europe/Madrid")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]{2,}$")
SKU_RE = re.compile(r"^[A-Z0-9][A-Z0-9._-]{1,31}$")


class ApiError(Exception):
    """Error de negocio con código HTTP y mensaje apto para el usuario."""

    def __init__(self, mensaje: str, status: int = 400, campo: str = ""):
        super().__init__(mensaje)
        self.mensaje = mensaje
        self.status = status
        self.campo = campo


def biz_now() -> datetime:
    return datetime.now(MADRID).replace(microsecond=0)


def biz_today() -> date:
    return biz_now().date()


def iso_now() -> str:
    return biz_now().isoformat(timespec="seconds")


def iso_at(dt: datetime) -> str:
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=MADRID)
    return dt.astimezone(MADRID).isoformat(timespec="seconds")


def parse_date(value: str, campo: str = "La fecha") -> date:
    try:
        return date.fromisoformat(str(value)[:10])
    except (TypeError, ValueError):
        raise ApiError(f"{campo} no es válida")


def parse_dt(value: str) -> datetime:
    try:
        dt = datetime.fromisoformat(str(value))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=MADRID)
        return dt.astimezone(MADRID)
    except (TypeError, ValueError):
        return biz_now()


def date_range(desde: str | None, hasta: str | None, dias: int = 30) -> tuple[date, date]:
    hoy = biz_today()
    if hasta:
        fin = parse_date(hasta, "La fecha final")
    else:
        fin = hoy
    if desde:
        ini = parse_date(desde, "La fecha inicial")
    else:
        ini = fin - timedelta(days=max(1, dias) - 1)
    if ini > fin:
        raise ApiError("La fecha inicial no puede ser posterior a la final")
    if (fin - ini).days > 730:
        raise ApiError("El rango no puede superar dos años")
    return ini, fin


def txt(value, maxlen: int = 500) -> str:
    if value is None:
        return ""
    return str(value).replace("\x00", "").strip()[:maxlen]


def num(value, campo: str, minimum: float | None = 0.0, maximum: float | None = 1e9) -> float:
    if value is None or value == "":
        raise ApiError(f"{campo} es obligatorio")
    try:
        limpio = str(value).strip().replace(" ", "")
        if "," in limpio and "." in limpio:
            limpio = limpio.replace(".", "").replace(",", ".")
        else:
            limpio = limpio.replace(",", ".")
        cifra = float(limpio)
    except (TypeError, ValueError):
        raise ApiError(f"{campo} debe ser un número")
    if cifra != cifra or cifra in (float("inf"), float("-inf")):
        raise ApiError(f"{campo} debe ser un número válido")
    if minimum is not None and cifra < minimum:
        raise ApiError(f"{campo} no puede ser menor que {minimum:g}")
    if maximum is not None and cifra > maximum:
        raise ApiError(f"{campo} no puede ser mayor que {maximum:g}")
    return cifra


def money(value) -> float:
    try:
        return float(Decimal(str(value)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))
    except Exception:
        return 0.0


def qty(value) -> float:
    try:
        return float(Decimal(str(value)).quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP))
    except Exception:
        return 0.0


def slugify(value: str) -> str:
    base = unicodedata.normalize("NFKD", str(value or "")).encode("ascii", "ignore").decode()
    base = re.sub(r"[^a-zA-Z0-9]+", "-", base).strip("-").lower()
    return base[:80] or "producto"


def new_id(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4().hex[:14]}"


def tiempo_relativo(iso: str) -> str:
    dt = parse_dt(iso)
    delta = biz_now() - dt
    minutos = int(delta.total_seconds() // 60)
    if minutos < 1:
        return "ahora mismo"
    if minutos < 60:
        return f"hace {minutos} min"
    horas = minutos // 60
    if horas < 24:
        return f"hace {horas} h"
    dias = horas // 24
    if dias == 1:
        return "ayer"
    if dias < 30:
        return f"hace {dias} días"
    return dt.strftime("%d/%m/%Y")
