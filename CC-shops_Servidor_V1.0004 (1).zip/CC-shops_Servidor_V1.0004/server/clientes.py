"""Clientes de cada tienda: cuenta automática tras la compra, activación de la contraseña
y la ficha de cliente que ve el administrador (pedidos, gasto, datos de contacto)."""
from __future__ import annotations

import hashlib
import secrets
from datetime import datetime, timedelta

from . import auth, config, correo, db
from .db import all_rows, one
from .util import ApiError, iso_now, money, new_id

DDL = """
CREATE TABLE IF NOT EXISTS tokens_cuenta (
    id          TEXT PRIMARY KEY,
    usuario_id  TEXT NOT NULL REFERENCES usuarios(id),
    tipo        TEXT NOT NULL,
    token_hash  TEXT NOT NULL UNIQUE,
    expira_at   TEXT NOT NULL,
    usado_at    TEXT NOT NULL DEFAULT '',
    created_at  TEXT NOT NULL
);
"""
DIAS_ACTIVACION = 7


def migrar(conn) -> None:
    conn.executescript(DDL)


def _hash(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def _nuevo_token(conn, usuario_id: str, tipo: str, dias: int) -> str:
    token = secrets.token_urlsafe(32)
    ahora = datetime.now().astimezone()
    conn.execute(
        "INSERT INTO tokens_cuenta (id, usuario_id, tipo, token_hash, expira_at, usado_at, created_at) VALUES (?,?,?,?,?,'',?)",
        (new_id("TOK"), usuario_id, tipo, _hash(token), (ahora + timedelta(days=dias)).isoformat(timespec="seconds"), iso_now()),
    )
    return token


def _enlace(tienda_slug: str, token: str) -> str:
    return f"{config.PUBLIC_URL}/?tienda={tienda_slug}#/cuenta/activar?token={token}"


def preparar_cuenta_compra(conn, tienda_id: str, pedido_id: str, nombre: str, email: str) -> dict | None:
    """Tras crear un pedido como invitado. Devuelve el aviso a enviar (o None si no hace falta)."""
    email = (email or "").strip().lower()
    if not email:
        return None
    tienda = one(conn, "SELECT slug, nombre FROM tiendas WHERE id=?", (tienda_id,))
    usuario = one(conn, "SELECT id, tienda_id, rol FROM usuarios WHERE email=?", (email,))
    if usuario:
        if usuario["rol"] == "cliente" and usuario["tienda_id"] == tienda_id:
            conn.execute("UPDATE pedidos SET cliente_id=? WHERE id=?", (usuario["id"], pedido_id))
        return None  # cuenta existente: el pedido aparece en su historial
    uid = new_id("USR")
    conn.execute(
        "INSERT INTO usuarios (id, nombre, email, password_hash, rol, tienda_id, activo, session_version, ultimo_acceso, created_at) "
        "VALUES (?,?,?,?,'cliente',?,1,0,'',?)",
        (uid, nombre[:120] or email, email, auth.hash_password(secrets.token_urlsafe(24)), tienda_id, iso_now()),
    )
    conn.execute("UPDATE pedidos SET cliente_id=? WHERE id=?", (uid, pedido_id))
    token = _nuevo_token(conn, uid, "activar", DIAS_ACTIVACION)
    db.audit(conn, None, "cliente.cuenta_creada", "usuario", uid, {"tienda": tienda_id, "pedido": pedido_id})
    return {
        "para": email,
        "asunto": f"Crea tu contraseña en {tienda['nombre']}",
        "cuerpo": (
            f"Hola {nombre or ''},\n\nHemos creado tu cuenta en {tienda['nombre']} para que sigas tu pedido "
            "y veas tu historial de compras.\n\n"
            f"Crea tu contraseña aquí (el enlace caduca en {DIAS_ACTIVACION} días):\n{_enlace(tienda['slug'], token)}\n\n"
            "Si no has comprado en esta tienda, ignora este mensaje."
        ),
    }


def enviar_aviso(aviso: dict | None) -> None:
    """Se llama fuera de la transacción: un fallo de correo no debe perder el pedido."""
    if not aviso:
        return
    try:
        correo.enviar(aviso["para"], aviso["asunto"], aviso["cuerpo"])
    except Exception:
        import traceback
        traceback.print_exc()


def reenviar_activacion(conn, tienda_id: str, email: str) -> dict | None:
    email = (email or "").strip().lower()
    usuario = one(conn, "SELECT id, nombre, email FROM usuarios WHERE email=? AND tienda_id=? AND rol='cliente'", (email, tienda_id))
    if not usuario:
        return None
    tienda = one(conn, "SELECT slug, nombre FROM tiendas WHERE id=?", (tienda_id,))
    token = _nuevo_token(conn, usuario["id"], "activar", DIAS_ACTIVACION)
    return {
        "para": email,
        "asunto": f"Crea tu contraseña en {tienda['nombre']}",
        "cuerpo": f"Crea tu contraseña aquí (caduca en {DIAS_ACTIVACION} días):\n{_enlace(tienda['slug'], token)}",
    }


def activar(conn, token: str, password: str) -> str:
    fila = one(conn, "SELECT * FROM tokens_cuenta WHERE token_hash=? AND tipo='activar'", (_hash(token or ""),))
    if not fila or fila["usado_at"]:
        raise ApiError("El enlace no es válido o ya se ha usado. Pide uno nuevo.", 400)
    if datetime.fromisoformat(fila["expira_at"]) < datetime.now().astimezone():
        raise ApiError("El enlace ha caducado. Pide uno nuevo.", 400)
    problema = auth.password_problem(password or "")
    if problema:
        raise ApiError(problema, 400, "password")
    usuario = one(conn, "SELECT email FROM usuarios WHERE id=?", (fila["usuario_id"],))
    conn.execute(
        "UPDATE usuarios SET password_hash=?, activo=1, session_version=session_version+1 WHERE id=?",
        (auth.hash_password(password), fila["usuario_id"]),
    )
    conn.execute("UPDATE tokens_cuenta SET usado_at=? WHERE id=?", (iso_now(), fila["id"]))
    db.audit(conn, None, "cliente.cuenta_activada", "usuario", fila["usuario_id"], {})
    return usuario["email"]


# ----------------------------------------------------------------- ficha de cliente (administrador)

def listar(conn, tienda_id: str) -> list[dict]:
    pedidos = all_rows(
        conn,
        """SELECT LOWER(cliente_email) AS email, MAX(cliente_nombre) AS nombre, MAX(cliente_telefono) AS telefono,
                  COUNT(*) AS pedidos, COALESCE(SUM(CASE WHEN estado<>'cancelado' THEN total END),0) AS gastado,
                  MAX(created_at) AS ultimo
           FROM pedidos WHERE tienda_id=? AND cliente_email<>'' GROUP BY LOWER(cliente_email)""",
        (tienda_id,),
    )
    cuentas = {c["email"]: c for c in all_rows(
        conn, "SELECT email, nombre, created_at, ultimo_acceso FROM usuarios WHERE tienda_id=? AND rol='cliente'", (tienda_id,))}
    items = {}
    for p in pedidos:
        items[p["email"]] = {
            "email": p["email"], "nombre": p["nombre"], "telefono": p["telefono"], "pedidos": int(p["pedidos"]),
            "gastado": money(p["gastado"]), "ultimo_pedido": p["ultimo"], "cuenta": p["email"] in cuentas,
        }
    for email, c in cuentas.items():
        if email not in items:
            items[email] = {"email": email, "nombre": c["nombre"], "telefono": "", "pedidos": 0, "gastado": 0.0,
                            "ultimo_pedido": "", "cuenta": True}
    out = sorted(items.values(), key=lambda x: x["ultimo_pedido"] or "", reverse=True)
    return out


def detalle(conn, tienda_id: str, email: str) -> dict:
    email = (email or "").strip().lower()
    pedidos = [dict(p) for p in all_rows(
        conn,
        "SELECT * FROM pedidos WHERE tienda_id=? AND LOWER(cliente_email)=? ORDER BY created_at DESC",
        (tienda_id, email),
    )]
    fila_cuenta = one(conn, "SELECT nombre, email, created_at, ultimo_acceso FROM usuarios WHERE tienda_id=? AND email=? AND rol='cliente'", (tienda_id, email))
    cuenta = dict(fila_cuenta) if fila_cuenta else None
    if not pedidos and not cuenta:
        raise ApiError("Cliente no encontrado", 404)
    ultimo = pedidos[0] if pedidos else None
    activos = [p for p in pedidos if p["estado"] != "cancelado"]
    return {
        "email": email,
        "nombre": (ultimo or {}).get("cliente_nombre") or (cuenta or {}).get("nombre", ""),
        "telefono": (ultimo or {}).get("cliente_telefono", ""),
        "nif": (ultimo or {}).get("nif", ""),
        "direccion": {
            "direccion": (ultimo or {}).get("direccion", ""), "ciudad": (ultimo or {}).get("ciudad", ""),
            "cp": (ultimo or {}).get("cp", ""), "provincia": (ultimo or {}).get("provincia", ""),
        },
        "cuenta": {"existe": bool(cuenta), "alta": (cuenta or {}).get("created_at", ""), "ultimo_acceso": (cuenta or {}).get("ultimo_acceso", "")},
        "resumen": {
            "pedidos": len(pedidos), "activos": len(activos),
            "gastado": money(sum(float(p["total"]) for p in activos)),
            "ticket_medio": money(sum(float(p["total"]) for p in activos) / len(activos)) if activos else 0.0,
        },
        "pedidos": [
            {"id": p["id"], "numero": p["numero"], "fecha": p["created_at"], "estado": p["estado"],
             "estado_label": p.get("estado_label") or p["estado"], "total": money(p["total"]),
             "pago_estado": p["pago_estado"], "tipo_entrega": p["tipo_entrega"]}
            for p in pedidos
        ],
    }
