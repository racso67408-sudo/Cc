"""Soporte al estilo CC: conversaciones (chat) y tickets (incidencia, mejora o feedback).

Lado tienda (rol admin de la tienda) y lado plataforma (superadmin). Cada consulta del lado
tienda filtra por tienda_id de la sesión. Los datos ocultos no se borran: solo cambian de
historial. Las fechas de mensajes usan microsegundos para ordenar bien mensajes seguidos.
"""
from __future__ import annotations

from datetime import datetime

from . import db
from .db import all_rows, one
from .util import ApiError, iso_now, new_id, txt

TIPOS = ("incidencia", "mejora", "feedback")
ESTADOS_TICKET = ("recibido", "en_proceso", "resuelto")
ESTADOS_CONV = ("abierta", "cerrada")
CATEGORIAS_DEFECTO = ("General", "Agenda", "Clientes", "Cobros", "Inventario", "Consentimientos", "Otros")
LIMITES = {"asunto": 160, "descripcion": 4000, "texto": 2000, "conv_asunto": 160}

DDL = """
CREATE TABLE IF NOT EXISTS tickets_categorias (
    id     TEXT PRIMARY KEY,
    nombre TEXT NOT NULL UNIQUE,
    activo INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS tickets (
    id                   TEXT PRIMARY KEY,
    tienda_id            TEXT NOT NULL REFERENCES tiendas(id),
    email_autor          TEXT NOT NULL DEFAULT '',
    tipo                 TEXT NOT NULL DEFAULT 'incidencia',
    categoria_id         TEXT REFERENCES tickets_categorias(id),
    asunto               TEXT NOT NULL,
    descripcion          TEXT NOT NULL DEFAULT '',
    estado               TEXT NOT NULL DEFAULT 'recibido',
    respuesta            TEXT NOT NULL DEFAULT '',
    sin_leer_tienda      INTEGER NOT NULL DEFAULT 0,
    sin_leer_plataforma  INTEGER NOT NULL DEFAULT 0,
    oculto_tienda        INTEGER NOT NULL DEFAULT 0,
    created_at           TEXT NOT NULL,
    updated_at           TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_tickets_tienda ON tickets(tienda_id, estado);
CREATE TABLE IF NOT EXISTS tickets_mensajes (
    id           TEXT PRIMARY KEY,
    ticket_id    TEXT NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
    autor_rol    TEXT NOT NULL,
    autor_email  TEXT NOT NULL DEFAULT '',
    texto        TEXT NOT NULL,
    created_at   TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_tickets_msg ON tickets_mensajes(ticket_id, created_at);
CREATE TABLE IF NOT EXISTS soporte_conversaciones (
    id            TEXT PRIMARY KEY,
    tienda_id     TEXT NOT NULL REFERENCES tiendas(id),
    asunto        TEXT NOT NULL,
    estado        TEXT NOT NULL DEFAULT 'abierta',
    oculta_tienda INTEGER NOT NULL DEFAULT 0,
    creado_por    TEXT NOT NULL DEFAULT '',
    created_at    TEXT NOT NULL,
    updated_at    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_conv_tienda ON soporte_conversaciones(tienda_id, updated_at);
CREATE TABLE IF NOT EXISTS soporte_mensajes (
    id              TEXT PRIMARY KEY,
    conversacion_id TEXT NOT NULL REFERENCES soporte_conversaciones(id) ON DELETE CASCADE,
    autor_rol       TEXT NOT NULL,
    autor_email     TEXT NOT NULL DEFAULT '',
    cuerpo          TEXT NOT NULL,
    created_at      TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_conv_msg ON soporte_mensajes(conversacion_id, created_at);
"""


def _ahora_us() -> str:
    return datetime.now().astimezone().isoformat(timespec="microseconds")


def _columnas(conn, tabla: str) -> set[str]:
    return set(db.columnas(conn, tabla))


def _tabla_existe(conn, tabla: str) -> bool:
    return db.tabla_existe(conn, tabla)


def migrar(conn) -> None:
    """Crea el modelo de soporte y traslada lo que existía en la versión anterior.

    Idempotente: las tablas antiguas se renombran (legacy_*) al migrar, así no se repite.
    """
    if _tabla_existe(conn, "soporte_mensajes") and "ticket_id" in _columnas(conn, "soporte_mensajes"):
        conn.execute("ALTER TABLE soporte_mensajes RENAME TO legacy_soporte_mensajes")
    if _tabla_existe(conn, "soporte_tickets") and "estado" in _columnas(conn, "soporte_tickets"):
        conn.execute("ALTER TABLE soporte_tickets RENAME TO legacy_soporte_tickets")
    if _tabla_existe(conn, "tickets") and "prioridad" in _columnas(conn, "tickets"):
        vacia = one(conn, "SELECT COUNT(*) AS n FROM tickets")["n"] == 0
        if vacia:
            conn.execute("DROP TABLE tickets")
        else:
            conn.execute("ALTER TABLE tickets RENAME TO legacy_tickets")
    if _tabla_existe(conn, "ticket_mensajes") and one(conn, "SELECT COUNT(*) AS n FROM ticket_mensajes")["n"] == 0:
        conn.execute("DROP TABLE ticket_mensajes")
    conn.executescript(DDL)
    for nombre in CATEGORIAS_DEFECTO:
        conn.execute("INSERT OR IGNORE INTO tickets_categorias (id, nombre, activo) VALUES (?,?,1)", (new_id("TCAT"), nombre))
    if _tabla_existe(conn, "legacy_soporte_tickets"):
        _trasladar_legacy(conn)


def _trasladar_legacy(conn) -> None:
    mapa = {"abierto": "recibido", "en_curso": "en_proceso", "resuelto": "resuelto", "cerrado": "resuelto"}
    general = one(conn, "SELECT id FROM tickets_categorias WHERE nombre='General'")["id"]
    for t in all_rows(conn, "SELECT * FROM legacy_soporte_tickets"):
        oculto = 1 if t["estado"] == "cerrado" else 0
        conn.execute(
            """INSERT OR IGNORE INTO tickets (id, tienda_id, email_autor, tipo, categoria_id, asunto, descripcion, estado,
               respuesta, sin_leer_tienda, sin_leer_plataforma, oculto_tienda, created_at, updated_at)
               VALUES (?,?,?,?,?,?,?,?,?,0,0,?,?,?)""",
            (t["id"], t["tienda_id"], "", "incidencia", general, t["asunto"], "", mapa.get(t["estado"], "recibido"),
             "", oculto, t["created_at"], t["updated_at"]),
        )
    if _tabla_existe(conn, "legacy_soporte_mensajes"):
        for m in all_rows(conn, "SELECT * FROM legacy_soporte_mensajes ORDER BY created_at, rowid"):
            autor = one(conn, "SELECT email FROM usuarios WHERE id=?", (m["autor_id"],))
            conn.execute(
                "INSERT OR IGNORE INTO tickets_mensajes (id, ticket_id, autor_rol, autor_email, texto, created_at) VALUES (?,?,?,?,?,?)",
                (m["id"], m["ticket_id"], "ccpro" if m["autor_tipo"] == "plataforma" else "centro",
                 autor["email"] if autor else "", m["texto"], m["created_at"]),
            )
    conn.execute("ALTER TABLE legacy_soporte_tickets RENAME TO legacy_soporte_tickets_migrado")


# ----------------------------------------------------------------- utilidades

def _limpio(valor, clave: str, obligatorio: bool = True) -> str:
    texto = txt(valor, LIMITES[clave])
    if obligatorio and not texto:
        raise ApiError("Este campo es obligatorio", 400, clave)
    return texto


def _conv_de_tienda(conn, conv_id: str, tienda_id: str | None) -> dict:
    fila = one(conn, "SELECT * FROM soporte_conversaciones WHERE id=?", (conv_id,))
    if not fila or (tienda_id is not None and fila["tienda_id"] != tienda_id):
        raise ApiError("Conversación no encontrada", 404)
    return dict(fila)


def _ticket_de_tienda(conn, ticket_id: str, tienda_id: str | None) -> dict:
    fila = one(conn, "SELECT * FROM tickets WHERE id=?", (ticket_id,))
    if not fila or (tienda_id is not None and fila["tienda_id"] != tienda_id):
        raise ApiError("Ticket no encontrado", 404)
    return dict(fila)


def _categoria_activa(conn, categoria_id: str) -> None:
    fila = one(conn, "SELECT activo FROM tickets_categorias WHERE id=?", (categoria_id,))
    if not fila or not int(fila["activo"]):
        raise ApiError("La categoría no existe o está desactivada", 400, "categoria_id")


def _ticket_con_hilo(conn, ticket: dict) -> dict:
    mensajes = [dict(m) for m in all_rows(
        conn, "SELECT * FROM tickets_mensajes WHERE ticket_id=? ORDER BY created_at, rowid", (ticket["id"],))]
    cat = one(conn, "SELECT nombre FROM tickets_categorias WHERE id=?", (ticket["categoria_id"],)) if ticket.get("categoria_id") else None
    return {**ticket, "categoria_nombre": cat["nombre"] if cat else "", "mensajes": mensajes}


# ----------------------------------------------------------------- categorías

def listar_categorias(conn, solo_activas: bool = True) -> list[dict]:
    sql = "SELECT * FROM tickets_categorias" + (" WHERE activo=1" if solo_activas else "") + " ORDER BY nombre"
    return [dict(f) for f in all_rows(conn, sql)]


def crear_categoria(conn, nombre: str, actor: str | None = None) -> dict:
    nombre = _limpio(nombre, "asunto")
    if one(conn, "SELECT id FROM tickets_categorias WHERE LOWER(nombre)=LOWER(?)", (nombre,)):
        raise ApiError("Ya existe una categoría con ese nombre", 409, "nombre")
    cid = new_id("TCAT")
    conn.execute("INSERT INTO tickets_categorias (id, nombre, activo) VALUES (?,?,1)", (cid, nombre))
    db.audit(conn, actor, "soporte.categoria_alta", "categoria", cid, {"nombre": nombre})
    return dict(one(conn, "SELECT * FROM tickets_categorias WHERE id=?", (cid,)))


def activar_categoria(conn, cid: str, activa: bool, actor: str | None = None) -> dict:
    if not one(conn, "SELECT id FROM tickets_categorias WHERE id=?", (cid,)):
        raise ApiError("Categoría no encontrada", 404)
    conn.execute("UPDATE tickets_categorias SET activo=? WHERE id=?", (1 if activa else 0, cid))
    db.audit(conn, actor, "soporte.categoria_activa", "categoria", cid, {"activa": activa})
    return dict(one(conn, "SELECT * FROM tickets_categorias WHERE id=?", (cid,)))


# ----------------------------------------------------------------- lado tienda: conversaciones

def tienda_listar_conversaciones(conn, tienda_id: str, historial: bool) -> list[dict]:
    cond = "(estado='cerrada' OR oculta_tienda=1)" if historial else "(estado='abierta' AND oculta_tienda=0)"
    return [dict(f) for f in all_rows(
        conn,
        f"""SELECT c.*, (SELECT COUNT(*) FROM soporte_mensajes m WHERE m.conversacion_id=c.id) AS mensajes
            FROM soporte_conversaciones c WHERE c.tienda_id=? AND {cond} ORDER BY c.updated_at DESC LIMIT 200""",
        (tienda_id,),
    )]


def tienda_crear_conversacion(conn, tienda_id: str, email: str, datos: dict) -> dict:
    asunto = _limpio(datos.get("asunto"), "conv_asunto")
    cuerpo = txt(datos.get("mensaje") or datos.get("cuerpo"), LIMITES["texto"])
    cid, sello = new_id("CONV"), iso_now()
    conn.execute(
        "INSERT INTO soporte_conversaciones (id, tienda_id, asunto, estado, oculta_tienda, creado_por, created_at, updated_at) VALUES (?,?,?, 'abierta', 0, ?,?,?)",
        (cid, tienda_id, asunto, email, sello, sello),
    )
    if cuerpo:
        conn.execute(
            "INSERT INTO soporte_mensajes (id, conversacion_id, autor_rol, autor_email, cuerpo, created_at) VALUES (?,?,'tienda',?,?,?)",
            (new_id("MSG"), cid, email, cuerpo, _ahora_us()),
        )
    return {"id": cid}


def tienda_ver_conversacion(conn, tienda_id: str, conv_id: str) -> dict:
    conv = _conv_de_tienda(conn, conv_id, tienda_id)
    mensajes = [dict(m) for m in all_rows(
        conn, "SELECT * FROM soporte_mensajes WHERE conversacion_id=? ORDER BY created_at, rowid", (conv_id,))]
    return {"conversacion": conv, "mensajes": mensajes}


def tienda_ocultar_conversacion(conn, tienda_id: str, conv_id: str, oculta: bool) -> dict:
    _conv_de_tienda(conn, conv_id, tienda_id)
    conn.execute("UPDATE soporte_conversaciones SET oculta_tienda=? WHERE id=?", (1 if oculta else 0, conv_id))
    return {"id": conv_id, "oculta": oculta}


def tienda_responder_conversacion(conn, tienda_id: str, conv_id: str, email: str, cuerpo: str) -> dict:
    conv = _conv_de_tienda(conn, conv_id, tienda_id)
    texto = _limpio(cuerpo, "texto")
    sello = iso_now()
    conn.execute(
        "INSERT INTO soporte_mensajes (id, conversacion_id, autor_rol, autor_email, cuerpo, created_at) VALUES (?,?,'tienda',?,?,?)",
        (new_id("MSG"), conv_id, email, texto, _ahora_us()),
    )
    # Si el equipo había cerrado la conversación y la tienda escribe, se reabre.
    nuevo = "abierta" if conv["estado"] == "cerrada" else conv["estado"]
    conn.execute("UPDATE soporte_conversaciones SET estado=?, oculta_tienda=0, updated_at=? WHERE id=?", (nuevo, sello, conv_id))
    return {"ok": True}


# ----------------------------------------------------------------- lado tienda: tickets

def tienda_listar_tickets(conn, tienda_id: str, historial: bool) -> list[dict]:
    cond = "(estado='resuelto' OR oculto_tienda=1)" if historial else "(estado<>'resuelto' AND oculto_tienda=0)"
    return [dict(f) for f in all_rows(
        conn,
        f"""SELECT t.*, c.nombre AS categoria_nombre,
              (SELECT COUNT(*) FROM tickets_mensajes m WHERE m.ticket_id=t.id) AS mensajes
            FROM tickets t LEFT JOIN tickets_categorias c ON c.id=t.categoria_id
            WHERE t.tienda_id=? AND {cond} ORDER BY t.updated_at DESC LIMIT 200""",
        (tienda_id,),
    )]


def tienda_crear_ticket(conn, tienda_id: str, email: str, datos: dict) -> dict:
    tipo = txt(datos.get("tipo") or "incidencia", 20)
    if tipo not in TIPOS:
        raise ApiError("Tipo de ticket no válido", 400, "tipo")
    categoria_id = txt(datos.get("categoria_id"), 40)
    if not categoria_id:
        raise ApiError("Elige una categoría", 400, "categoria_id")
    _categoria_activa(conn, categoria_id)
    asunto = _limpio(datos.get("asunto"), "asunto")
    descripcion = _limpio(datos.get("descripcion"), "descripcion")
    tid, sello = new_id("TKT"), iso_now()
    conn.execute(
        """INSERT INTO tickets (id, tienda_id, email_autor, tipo, categoria_id, asunto, descripcion, estado, respuesta,
           sin_leer_tienda, sin_leer_plataforma, oculto_tienda, created_at, updated_at)
           VALUES (?,?,?,?,?,?,?,'recibido','',0,1,0,?,?)""",
        (tid, tienda_id, email, tipo, categoria_id, asunto, descripcion, sello, sello),
    )
    conn.execute(
        "INSERT INTO tickets_mensajes (id, ticket_id, autor_rol, autor_email, texto, created_at) VALUES (?,?,'centro',?,?,?)",
        (new_id("TMSG"), tid, email, descripcion, _ahora_us()),
    )
    db.audit(conn, None, "soporte.ticket_alta", "ticket", tid, {"tipo": tipo, "tienda": tienda_id})
    return {"id": tid}


def tienda_ver_ticket(conn, tienda_id: str, ticket_id: str) -> dict:
    ticket = _ticket_de_tienda(conn, ticket_id, tienda_id)
    conn.execute("UPDATE tickets SET sin_leer_tienda=0 WHERE id=?", (ticket_id,))
    ticket["sin_leer_tienda"] = 0
    return _ticket_con_hilo(conn, ticket)


def tienda_ocultar_ticket(conn, tienda_id: str, ticket_id: str, oculto: bool) -> dict:
    _ticket_de_tienda(conn, ticket_id, tienda_id)
    conn.execute("UPDATE tickets SET oculto_tienda=? WHERE id=?", (1 if oculto else 0, ticket_id))
    return {"id": ticket_id, "oculto": oculto}


def tienda_responder_ticket(conn, tienda_id: str, ticket_id: str, email: str, texto: str) -> dict:
    ticket = _ticket_de_tienda(conn, ticket_id, tienda_id)
    cuerpo = _limpio(texto, "texto")
    sello = iso_now()
    conn.execute(
        "INSERT INTO tickets_mensajes (id, ticket_id, autor_rol, autor_email, texto, created_at) VALUES (?,?,'centro',?,?,?)",
        (new_id("TMSG"), ticket_id, email, cuerpo, _ahora_us()),
    )
    # Si estaba resuelto, la respuesta lo reabre y lo marca como pendiente para el equipo.
    nuevo = "en_proceso" if ticket["estado"] == "resuelto" else ticket["estado"]
    conn.execute(
        "UPDATE tickets SET estado=?, sin_leer_plataforma=1, oculto_tienda=0, updated_at=? WHERE id=?",
        (nuevo, sello, ticket_id),
    )
    return {"ok": True}


# ----------------------------------------------------------------- lado plataforma

def plataforma_listar_conversaciones(conn, historial: bool) -> list[dict]:
    cond = "(c.estado='cerrada' OR c.oculta_tienda=1)" if historial else "(c.estado='abierta' AND c.oculta_tienda=0)"
    return [dict(f) for f in all_rows(
        conn,
        f"""SELECT c.*, t.nombre AS tienda_nombre,
              (SELECT COUNT(*) FROM soporte_mensajes m WHERE m.conversacion_id=c.id) AS mensajes
            FROM soporte_conversaciones c JOIN tiendas t ON t.id=c.tienda_id
            WHERE {cond} ORDER BY c.updated_at DESC LIMIT 200""",
    )]


def plataforma_ver_conversacion(conn, conv_id: str) -> dict:
    return tienda_ver_conversacion(conn, None, conv_id)


def plataforma_responder_conversacion(conn, conv_id: str, email: str, cuerpo: str) -> dict:
    _conv_de_tienda(conn, conv_id, None)
    texto = _limpio(cuerpo, "texto")
    sello = iso_now()
    conn.execute(
        "INSERT INTO soporte_mensajes (id, conversacion_id, autor_rol, autor_email, cuerpo, created_at) VALUES (?,?,'plataforma',?,?,?)",
        (new_id("MSG"), conv_id, email, texto, _ahora_us()),
    )
    conn.execute("UPDATE soporte_conversaciones SET updated_at=? WHERE id=?", (sello, conv_id))
    return {"ok": True}


def plataforma_cambiar_estado_conversacion(conn, conv_id: str, estado: str, actor: str | None = None) -> dict:
    if estado not in ESTADOS_CONV:
        raise ApiError("Estado no válido", 400, "estado")
    _conv_de_tienda(conn, conv_id, None)
    conn.execute("UPDATE soporte_conversaciones SET estado=?, updated_at=? WHERE id=?", (estado, iso_now(), conv_id))
    db.audit(conn, actor, "soporte.conversacion_estado", "conversacion", conv_id, {"estado": estado})
    return {"id": conv_id, "estado": estado}


def plataforma_listar_tickets(conn, historial: bool, estado: str = "") -> list[dict]:
    cond = "(t.estado='resuelto' OR t.oculto_tienda=1)" if historial else "(t.estado<>'resuelto' AND t.oculto_tienda=0)"
    extra, params = "", []
    if estado in ESTADOS_TICKET:
        extra, params = " AND t.estado=?", [estado]
    return [dict(f) for f in all_rows(
        conn,
        f"""SELECT t.*, ti.nombre AS tienda_nombre, c.nombre AS categoria_nombre,
              (SELECT COUNT(*) FROM tickets_mensajes m WHERE m.ticket_id=t.id) AS mensajes
            FROM tickets t JOIN tiendas ti ON ti.id=t.tienda_id LEFT JOIN tickets_categorias c ON c.id=t.categoria_id
            WHERE {cond}{extra} ORDER BY t.updated_at DESC LIMIT 200""",
        params,
    )]


def plataforma_ver_ticket(conn, ticket_id: str) -> dict:
    ticket = _ticket_de_tienda(conn, ticket_id, None)
    conn.execute("UPDATE tickets SET sin_leer_plataforma=0 WHERE id=?", (ticket_id,))
    ticket["sin_leer_plataforma"] = 0
    return _ticket_con_hilo(conn, ticket)


def plataforma_responder_ticket(conn, ticket_id: str, email: str, texto: str) -> dict:
    _ticket_de_tienda(conn, ticket_id, None)
    cuerpo = _limpio(texto, "texto")
    sello = iso_now()
    conn.execute(
        "INSERT INTO tickets_mensajes (id, ticket_id, autor_rol, autor_email, texto, created_at) VALUES (?,?,'ccpro',?,?,?)",
        (new_id("TMSG"), ticket_id, email, cuerpo, _ahora_us()),
    )
    conn.execute(
        "UPDATE tickets SET respuesta=?, sin_leer_tienda=1, updated_at=? WHERE id=?",
        (cuerpo, sello, ticket_id),
    )
    return {"ok": True}


def plataforma_cambiar_estado_ticket(conn, ticket_id: str, estado: str, actor: str | None = None) -> dict:
    if estado not in ESTADOS_TICKET:
        raise ApiError("Estado no válido", 400, "estado")
    _ticket_de_tienda(conn, ticket_id, None)
    conn.execute("UPDATE tickets SET estado=?, updated_at=? WHERE id=?", (estado, iso_now(), ticket_id))
    db.audit(conn, actor, "soporte.ticket_estado", "ticket", ticket_id, {"estado": estado})
    return {"id": ticket_id, "estado": estado}


# ----------------------------------------------------------------- sondeo ligero

def version(conn, tienda_id: str | None, conv_id: str = "", ticket_id: str = "") -> dict:
    """Huella de las listas y del hilo abierto. El cliente solo vuelve a pedir datos si cambia."""
    filtro_c = "WHERE tienda_id=?" if tienda_id else ""
    filtro_t = "WHERE tienda_id=?" if tienda_id else ""
    params = (tienda_id,) if tienda_id else ()
    c = one(conn, f"SELECT COUNT(*) AS n, COALESCE(MAX(updated_at),'') AS u FROM soporte_conversaciones {filtro_c}", params)
    t = one(conn, f"SELECT COUNT(*) AS n, COALESCE(MAX(updated_at),'') AS u FROM tickets {filtro_t}", params)
    out = {"listas": f"{c['n']}|{c['u']}|{t['n']}|{t['u']}"}
    if conv_id:
        m = one(conn, "SELECT COUNT(*) AS n, COALESCE(MAX(created_at),'') AS u FROM soporte_mensajes WHERE conversacion_id=?", (conv_id,))
        out["hilo"] = f"{m['n']}|{m['u']}"
    if ticket_id:
        m = one(conn, "SELECT COUNT(*) AS n, COALESCE(MAX(created_at),'') AS u FROM tickets_mensajes WHERE ticket_id=?", (ticket_id,))
        out["hilo"] = f"{m['n']}|{m['u']}"
    return out
