"""Servidor HTTP: API JSON + estáticos de la tienda y del backoffice."""
from __future__ import annotations

import json
import mimetypes
import os
import sys
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

from . import api, config, db

MIME = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".mjs": "application/javascript; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".webmanifest": "application/manifest+json; charset=utf-8",
    ".svg": "image/svg+xml",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".webp": "image/webp",
    ".ico": "image/x-icon",
    ".txt": "text/plain; charset=utf-8",
    ".woff2": "font/woff2",
    ".pdf": "application/pdf",
}

CSP = (
    "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; "
    "script-src 'self'; font-src 'self'; connect-src 'self'; frame-ancestors 'none'; "
    "base-uri 'self'; form-action 'self'"
)


def es_tienda(headers: dict, query: dict) -> bool:
    """True si la petición identifica una tienda (subdominio, ?tienda= o cabecera). Si no, se muestra la landing."""
    from . import tenant

    with db.session() as conn:
        return tenant.resolve_tienda_id(conn, headers, query) is not None


class Handler(BaseHTTPRequestHandler):
    server_version = "CCShops/1.0"
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        # Silencio: solo se registran errores relevantes.
        pass

    # ------------------------------------------------------------------
    def _send(self, status: int, body: bytes, content_type: str, headers: dict | None = None) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "strict-origin-when-cross-origin")
        self.send_header("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        self.send_header("Content-Security-Policy", CSP)
        for clave, valor in (headers or {}).items():
            self.send_header(clave, valor)
        self.end_headers()
        if self.command != "HEAD" and body:
            try:
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError):
                pass

    def _json(self, status: int, payload, headers: dict | None = None) -> None:
        body = json.dumps(payload, ensure_ascii=False, default=str).encode("utf-8")
        extra = {"Cache-Control": "no-store"}
        extra.update(headers or {})
        self._send(status, body, "application/json; charset=utf-8", extra)

    def _read_body(self) -> dict:
        try:
            length = int(self.headers.get("Content-Length", "0") or 0)
        except ValueError:
            raise api.ApiError("Longitud de petición no válida", 400)
        if length < 0:
            raise api.ApiError("Longitud de petición no válida", 400)
        if length > config.MAX_BODY:
            raise api.ApiError("La petición es demasiado grande", 413)
        if length == 0:
            return {}
        raw = self.rfile.read(length)
        try:
            data = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            raise api.ApiError("El cuerpo de la petición no es JSON válido", 400)
        if not isinstance(data, dict):
            raise api.ApiError("El cuerpo debe ser un objeto JSON", 400)
        return data

    def _headers(self) -> dict:
        datos = {k.lower(): v for k, v in self.headers.items()}
        datos["x-cc-client-ip"] = self.client_address[0]
        return datos

    # ------------------------------------------------------------------
    def _static(self, path: str) -> None:
        if path in ("/", "/index.html"):
            from urllib.parse import parse_qs, urlsplit

            query = parse_qs(urlsplit(self.path).query)
            cabeceras = {k: v for k, v in self.headers.items()}
            archivo = config.STATIC_DIR / ("index.html" if es_tienda(cabeceras, query) else "landing.html")
            cache = "no-store"
        elif path in ("/admin", "/admin/", "/admin/index.html"):
            archivo = config.STATIC_DIR / "admin.html"
            cache = "no-store"
        elif path == "/favicon.svg":
            archivo = config.STATIC_DIR / "favicon.svg"
            cache = "public, max-age=86400"
        elif path.startswith("/static/"):
            relativo = unquote(path[len("/static/") :])
            archivo = (config.STATIC_DIR / relativo).resolve()
            try:
                archivo.relative_to(config.STATIC_DIR.resolve())
            except ValueError:
                self._send(403, b"No autorizado", "text/plain; charset=utf-8")
                return
            # Se revalidan en cada carga: tras una actualización no se sirve CSS o JS antiguo desde caché.
            cache = "no-cache"
        else:
            self._send(
                404,
                b"<h1>404</h1><p>La pagina que buscas no existe.</p>",
                "text/html; charset=utf-8",
                {"Cache-Control": "no-store"},
            )
            return
        if not archivo.is_file():
            self._send(404, b"Recurso no encontrado", "text/plain; charset=utf-8")
            return
        try:
            contenido = archivo.read_bytes()
            if archivo.name == "landing.html":
                from . import plataforma as _pl
                from .db import session as _session

                with _session() as _conn:
                    contenido = _pl.landing_html(_conn).encode("utf-8")
        except OSError:
            self._send(500, b"No se pudo leer el recurso", "text/plain; charset=utf-8")
            return
        tipo = MIME.get(archivo.suffix.lower()) or mimetypes.guess_type(str(archivo))[0] or "application/octet-stream"
        self._send(200, contenido, tipo, {"Cache-Control": cache})

    def _handle(self, method: str) -> None:
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        if path.startswith("/api/"):
            try:
                body = self._read_body() if method in {"POST", "PUT", "PATCH"} else {}
                query = parse_qs(parsed.query, keep_blank_values=True)
                respuesta = api.dispatch(method, path, query, body, self._headers())
                self._json(respuesta.status, respuesta.payload, respuesta.headers)
            except api.ApiError as exc:
                self._json(exc.status, {"error": exc.mensaje, **({"campo": exc.campo} if exc.campo else {})})
            except Exception:
                traceback.print_exc()
                self._json(500, {"error": "Ha ocurrido un error interno. Inténtalo de nuevo."})
            return
        if method in {"GET", "HEAD"}:
            self._static(path)
        else:
            self._send(405, b"Metodo no permitido", "text/plain; charset=utf-8", {"Allow": "GET, HEAD"})

    def do_GET(self):
        self._handle("GET")

    def do_HEAD(self):
        self._handle("HEAD")

    def do_POST(self):
        self._handle("POST")

    def do_PUT(self):
        self._handle("PUT")

    def do_DELETE(self):
        self._handle("DELETE")

    def do_OPTIONS(self):
        self._send(204, b"", "text/plain; charset=utf-8", {"Allow": "GET, HEAD, POST, PUT, DELETE, OPTIONS"})


class Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def main() -> None:
    if config.IS_PROD:
        faltan = [v for v in ("CC_SUPERADMIN_PASSWORD", "CC_ADMIN_PASSWORD") if not os.environ.get(v)]
        if faltan:
            raise SystemExit(f"[CC-Shops] Modo producción: define {', '.join(faltan)} antes de arrancar.")
        if not config.PUBLIC_URL.startswith("https://"):
            print("[CC-Shops] Aviso: CC_PUBLIC_URL no es https. Los enlaces de correo y el dominio propio necesitan HTTPS.", file=sys.stderr)
    config.ensure_dirs()
    db.init_db(seed_demo=config.SEED_DEMO)
    servidor = Server((config.HOST, config.PORT), Handler)
    print("")
    print("  CC-Shops · tienda y backoffice")
    print(f"  Tienda:     http://{config.HOST}:{config.PORT}/?tienda=<slug>")
    print(f"  Backoffice: http://{config.HOST}:{config.PORT}/admin")
    print(f"  Datos:      {config.DB_PATH}")
    print("  Ctrl+C para detener.")
    print("")
    try:
        servidor.serve_forever()
    except KeyboardInterrupt:
        print("\nCerrando CC-Shops…")
    finally:
        servidor.server_close()


if __name__ == "__main__":
    main()
