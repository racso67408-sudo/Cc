"""Proveedores y compras: borrador, recepción (entrada al Kardex) y anulación con salida."""
from __future__ import annotations

from typing import Any

from . import db, kardex
from .db import all_rows, document_number, one
from .util import ApiError, EMAIL_RE, biz_today, iso_now, money, new_id, num, parse_date, qty, txt


# ----------------------------------------------------------------------
# Proveedores


def listar_proveedores(conn, q: str = "", *, tienda_id: str | None) -> list[dict]:
    where = "p.tienda_id=?"
    params: list[Any] = [tienda_id]
    if q:
        where += " AND (p.nombre LIKE ? OR p.contacto LIKE ? OR p.email LIKE ?)"
        like = f"%{q}%"
        params += [like, like, like]
    filas = all_rows(
        conn,
        f"""SELECT p.*, (SELECT COUNT(*) FROM compras c WHERE c.proveedor_id=p.id) AS compras,
                   (SELECT COALESCE(SUM(c.total),0) FROM compras c WHERE c.proveedor_id=p.id AND c.estado='recibida') AS importe
            FROM proveedores p WHERE {where} ORDER BY p.activo DESC, p.nombre""",
        params,
    )
    return [dict(f) for f in filas]


def _datos_proveedor(data: dict, actual: dict | None = None) -> dict:
    actual = actual or {}
    nombre = txt(data.get("nombre", actual.get("nombre")), 120)
    if len(nombre) < 2:
        raise ApiError("El nombre del proveedor es obligatorio")
    email = txt(data.get("email", actual.get("email", "")), 160).lower()
    if email and not EMAIL_RE.match(email):
        raise ApiError("El email del proveedor no es válido")
    return {
        "nombre": nombre,
        "contacto": txt(data.get("contacto", actual.get("contacto", "")), 120),
        "email": email,
        "telefono": txt(data.get("telefono", actual.get("telefono", "")), 30),
        "notas": txt(data.get("notas", actual.get("notas", "")), 500),
        "activo": 1 if data.get("activo", actual.get("activo", 1)) in (1, True, "1", "true", "on") else 0,
    }


def crear_proveedor(conn, data: dict, tienda_id: str) -> dict:
    limpio = _datos_proveedor(data)
    pid = new_id("PRO")
    conn.execute(
        "INSERT INTO proveedores (id, tienda_id, nombre, contacto, email, telefono, notas, activo, created_at) VALUES (?,?,?,?,?,?,?,?,?)",
        (pid, tienda_id, limpio["nombre"], limpio["contacto"], limpio["email"], limpio["telefono"], limpio["notas"], limpio["activo"], iso_now()),
    )
    return dict(one(conn, "SELECT * FROM proveedores WHERE id=?", (pid,)))


def actualizar_proveedor(conn, proveedor_id: str, data: dict) -> dict:
    fila = one(conn, "SELECT * FROM proveedores WHERE id=?", (proveedor_id,))
    if not fila:
        raise ApiError("Proveedor no encontrado", 404)
    limpio = _datos_proveedor(data, dict(fila))
    conn.execute(
        "UPDATE proveedores SET nombre=?, contacto=?, email=?, telefono=?, notas=?, activo=? WHERE id=?",
        (limpio["nombre"], limpio["contacto"], limpio["email"], limpio["telefono"], limpio["notas"], limpio["activo"], proveedor_id),
    )
    return dict(one(conn, "SELECT * FROM proveedores WHERE id=?", (proveedor_id,)))


def borrar_proveedor(conn, proveedor_id: str) -> None:
    if not one(conn, "SELECT id FROM proveedores WHERE id=?", (proveedor_id,)):
        raise ApiError("Proveedor no encontrado", 404)
    if one(conn, "SELECT COUNT(*) AS n FROM compras WHERE proveedor_id=?", (proveedor_id,))["n"]:
        raise ApiError("No puedes borrar un proveedor con compras registradas", 409)
    conn.execute("DELETE FROM proveedores WHERE id=?", (proveedor_id,))


# ----------------------------------------------------------------------
# Compras


def _lineas_validas(conn, lineas, tienda_id: str | None) -> list[dict]:
    if not isinstance(lineas, list) or not lineas:
        raise ApiError("La compra necesita al menos una línea")
    if len(lineas) > 80:
        raise ApiError("La compra supera el máximo de 80 líneas")
    salida = []
    for item in lineas:
        if not isinstance(item, dict):
            raise ApiError("Hay una línea de compra no válida")
        pid = txt(item.get("producto_id"), 40)
        p = one(conn, "SELECT * FROM productos WHERE id=? AND tienda_id=?", (pid, tienda_id))
        if not p:
            raise ApiError("Uno de los productos de la compra no existe")
        cantidad = num(item.get("cantidad"), "La cantidad", 0.0001, 999999)
        coste = num(item.get("coste_unit", p["coste_medio"]), "El coste unitario", 0, 999999)
        total = money(cantidad * coste)
        salida.append(
            {
                "producto_id": pid,
                "nombre": p["nombre"],
                "sku": p["sku"],
                "cantidad": qty(cantidad),
                "coste_unit": money(coste),
                "iva": float(p["iva"]),
                "total": total,
            }
        )
    return salida


def _totales(lineas: list[dict]) -> dict:
    base = money(sum(l["total"] for l in lineas))
    iva = money(sum(l["total"] * l["iva"] / 100 for l in lineas))
    return {"base": base, "iva": iva, "total": money(base + iva)}


def crear_compra(conn, data: dict, usuario_id: str | None = None, *, recibir: bool = False, tienda_id: str | None = None) -> dict:
    proveedor_id = txt(data.get("proveedor_id"), 40)
    if proveedor_id and not one(conn, "SELECT id FROM proveedores WHERE id=? AND tienda_id=?", (proveedor_id, tienda_id)):
        raise ApiError("El proveedor no existe")
    fecha = parse_date(data.get("fecha") or biz_today().isoformat(), "La fecha de compra").isoformat()
    lineas = _lineas_validas(conn, data.get("lineas"), tienda_id)
    totales = _totales(lineas)
    numero = document_number(conn, "CMP", "compra")
    cid = new_id("CMP")
    sello = iso_now()
    conn.execute(
        """INSERT INTO compras (id, tienda_id, numero, proveedor_id, fecha, estado, base, iva, total, notas, creado_por, created_at)
           VALUES (?,?,?,?,?,'borrador',?,?,?,?,?,?)""",
        (
            cid,
            tienda_id,
            numero,
            proveedor_id or None,
            fecha,
            totales["base"],
            totales["iva"],
            totales["total"],
            txt(data.get("notas"), 500),
            usuario_id,
            sello,
        ),
    )
    for l in lineas:
        conn.execute(
            """INSERT INTO compra_lineas (id, compra_id, producto_id, nombre, sku, cantidad, coste_unit, iva, total)
               VALUES (?,?,?,?,?,?,?,?,?)""",
            (new_id("CLN"), cid, l["producto_id"], l["nombre"], l["sku"], l["cantidad"], l["coste_unit"], l["iva"], l["total"]),
        )
    db.audit(conn, usuario_id, "compra.creada", "compra", cid, {"numero": numero, "total": totales["total"]})
    if recibir:
        return recibir_compra(conn, cid, usuario_id)
    return detalle_compra(conn, cid)


def _compra(conn, compra_id: str) -> dict:
    fila = one(conn, "SELECT * FROM compras WHERE id=?", (compra_id,))
    if not fila:
        raise ApiError("Compra no encontrada", 404)
    return dict(fila)


def _lineas_compra(conn, compra_id: str) -> list[dict]:
    return [dict(f) for f in all_rows(conn, "SELECT * FROM compra_lineas WHERE compra_id=? ORDER BY rowid", (compra_id,))]


def detalle_compra(conn, compra_id: str) -> dict:
    compra = _compra(conn, compra_id)
    lineas = _lineas_compra(conn, compra_id)
    proveedor = None
    if compra["proveedor_id"]:
        fila = one(conn, "SELECT id, nombre, contacto, email, telefono FROM proveedores WHERE id=?", (compra["proveedor_id"],))
        proveedor = dict(fila) if fila else None
    compra["lineas"] = lineas
    compra["proveedor"] = proveedor
    compra["total"] = money(compra["total"])
    compra["base"] = money(compra["base"])
    compra["iva"] = money(compra["iva"])
    compra["unidades"] = qty(sum(float(l["cantidad"]) for l in lineas))
    return compra


def recibir_compra(conn, compra_id: str, usuario_id: str | None = None) -> dict:
    compra = _compra(conn, compra_id)
    if compra["estado"] != "borrador":
        raise ApiError("Solo se pueden recibir compras en borrador", 409)
    lineas = _lineas_compra(conn, compra_id)
    sello = iso_now()
    for l in lineas:
        kardex.entrada(
            conn,
            l["producto_id"],
            float(l["cantidad"]),
            float(l["coste_unit"]),
            tipo="entrada_compra",
            documento_tipo="compra",
            documento_id=compra_id,
            documento_numero=compra["numero"],
            motivo=f"Recepción de compra · {compra['numero']}",
            fecha=sello,
            usuario_id=usuario_id,
        )
    conn.execute("UPDATE compras SET estado='recibida', recibida_at=? WHERE id=?", (sello, compra_id))
    db.audit(conn, usuario_id, "compra.recibida", "compra", compra_id, {"numero": compra["numero"]})
    return detalle_compra(conn, compra_id)


def anular_compra(conn, compra_id: str, usuario_id: str | None = None) -> dict:
    compra = _compra(conn, compra_id)
    if compra["estado"] != "recibida":
        raise ApiError("Solo se pueden anular compras recibidas", 409)
    lineas = _lineas_compra(conn, compra_id)
    sello = iso_now()
    # Verificamos primero que hay stock de todas las líneas para no dejar una anulación a medias.
    for l in lineas:
        p = one(conn, "SELECT stock, nombre FROM productos WHERE id=?", (l["producto_id"],))
        if float(p["stock"]) + 0.000001 < float(l["cantidad"]):
            raise ApiError(
                f"No se puede anular: parte de «{l['nombre']}» ya se ha vendido. "
                "Regulariza la devolución con un ajuste.",
                409,
            )
    for l in lineas:
        kardex.salida(
            conn,
            l["producto_id"],
            float(l["cantidad"]),
            float(l["coste_unit"]),
            tipo="salida_compra_anulada",
            documento_tipo="compra",
            documento_id=compra_id,
            documento_numero=compra["numero"],
            motivo=f"Anulación de compra · {compra['numero']}",
            fecha=sello,
            usuario_id=usuario_id,
        )
    conn.execute("UPDATE compras SET estado='anulada', anulada_at=? WHERE id=?", (sello, compra_id))
    db.audit(conn, usuario_id, "compra.anulada", "compra", compra_id, {"numero": compra["numero"]})
    return detalle_compra(conn, compra_id)


def borrar_compra(conn, compra_id: str) -> None:
    compra = _compra(conn, compra_id)
    if compra["estado"] != "borrador":
        raise ApiError("Solo se pueden borrar compras en borrador", 409)
    conn.execute("DELETE FROM compras WHERE id=?", (compra_id,))


def listar_compras(conn, *, estado: str = "", q: str = "", pagina: int = 1, por_pagina: int = 20, tienda_id: str | None) -> dict:
    where = ["1=1"]
    params: list[Any] = []
    if estado in ("borrador", "recibida", "anulada"):
        where.append("c.estado=?")
        params.append(estado)
    where.append("c.tienda_id=?")
    params.append(tienda_id)
    if q:
        like = f"%{q}%"
        where.append("(c.numero LIKE ? OR pr.nombre LIKE ?)")
        params += [like, like]
    filtro = " AND ".join(where)
    total = one(
        conn,
        f"SELECT COUNT(*) AS n FROM compras c LEFT JOIN proveedores pr ON pr.id=c.proveedor_id WHERE {filtro}",
        params,
    )["n"]
    pagina = max(1, int(pagina))
    por_pagina = min(100, max(1, int(por_pagina)))
    filas = all_rows(
        conn,
        f"""SELECT c.*, pr.nombre AS proveedor_nombre,
                   (SELECT COUNT(*) FROM compra_lineas l WHERE l.compra_id=c.id) AS lineas,
                   (SELECT COALESCE(SUM(l.cantidad),0) FROM compra_lineas l WHERE l.compra_id=c.id) AS unidades
            FROM compras c LEFT JOIN proveedores pr ON pr.id=c.proveedor_id
            WHERE {filtro} ORDER BY c.fecha DESC, c.created_at DESC LIMIT ? OFFSET ?""",
        params + [por_pagina, (pagina - 1) * por_pagina],
    )
    items = []
    for f in filas:
        d = dict(f)
        d["total"] = money(d["total"])
        items.append(d)
    resumen = one(
        conn,
        """SELECT COUNT(*) AS total,
                  COALESCE(SUM(CASE WHEN estado='recibida' THEN total ELSE 0 END),0) AS importe,
                  SUM(CASE WHEN estado='borrador' THEN 1 ELSE 0 END) AS borradores
           FROM compras""",
    )
    return {
        "items": items,
        "total": int(total),
        "pagina": pagina,
        "paginas": max(1, (int(total) + por_pagina - 1) // por_pagina),
        "resumen": {
            "total": int(resumen["total"]),
            "importe": money(resumen["importe"]),
            "borradores": int(resumen["borradores"] or 0),
        },
    }
