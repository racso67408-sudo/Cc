"""Dominio propio de cada tienda.

Dos caminos, con el mismo resultado:
- propio: la tienda ya tiene su dominio y lo registra donde quiera.
- compra: CC Shops registra el dominio. El propietario paga el precio íntegro del dominio
  (no va incluido en la mensualidad).

En los dos casos el complemento mensual lo activa el superadmin tras verificar el pago.
El dominio solo se sirve cuando hay complemento activo y el DNS está verificado.

Estados (tiendas.dominio_estado):
  sin_configurar -> pendiente_dns (propio)
  sin_configurar -> pendiente_pago_dominio (compra) -> pendiente_registro -> pendiente_dns
  pendiente_dns -> dns_ok (al verificar el DNS)
  dns_ok + complemento activo = el dominio está activo y se sirve.
"""
from __future__ import annotations

import os
import re
import socket

from . import db
from .db import one
from .util import ApiError, iso_now, money

# Resolvedor de DNS inyectable (las pruebas lo sustituyen).
resolver = None

DOMINIOS_PLATAFORMA = ("ccshops.es", "localhost")
RE_DOMINIO = re.compile(r"^(?=.{4,253}$)(?!-)([a-z0-9-]{1,63}\.)+[a-z]{2,63}$")
RE_IP = re.compile(r"^\d{1,3}(\.\d{1,3}){3}$")

ESTADOS_TIENDA = {
    "sin_configurar": "Sin dominio propio",
    "pendiente_pago_dominio": "Pendiente de pago del dominio",
    "pendiente_registro": "Registrando el dominio",
    "pendiente_dns": "Pendiente de configurar el DNS",
    "dns_ok": "DNS verificado",
}


def normalizar(valor: str) -> str:
    """Deja solo el dominio: sin http, sin ruta, en minúsculas y sin «www.» delante."""
    v = (valor or "").strip().lower()
    v = re.sub(r"^https?://", "", v)
    v = v.split("/")[0].split("?")[0].split(":")[0].rstrip(".")
    if v.startswith("www."):
        v = v[4:]
    return v


def validar(dominio: str) -> str:
    if not dominio:
        raise ApiError("Escribe el dominio, por ejemplo midominio.com", 400, "dominio")
    if RE_IP.match(dominio) or not RE_DOMINIO.match(dominio):
        raise ApiError("El dominio no tiene un formato válido (por ejemplo midominio.com)", 400, "dominio")
    if any(dominio == p or dominio.endswith("." + p) for p in DOMINIOS_PLATAFORMA):
        raise ApiError("Ese dominio no se puede usar", 400, "dominio")
    return dominio


def _ajuste(conn, clave: str, defecto: str) -> str:
    fila = one(conn, "SELECT valor FROM plataforma_config WHERE clave=?", (clave,))
    return (fila["valor"] if fila and fila["valor"] != "" else defecto)


def configuracion(conn) -> dict:
    """Precios y datos de DNS que ve la tienda. Los fija el superadmin."""
    return {
        "mensual": money(float(_ajuste(conn, "dominio_mensual", "5"))),
        "compra_anual": money(float(_ajuste(conn, "dominio_compra_anual", "12"))),
        "dns_ip": _ajuste(conn, "dominio_dns_ip", os.environ.get("CC_DOMINIO_IP", "")),
        "dns_host": _ajuste(conn, "dominio_dns_host", os.environ.get("CC_DOMINIO_DESTINO", "tiendas.ccshops.es")),
        "iban": _ajuste(conn, "plataforma_iban", ""),
        "cartera": _ajuste(conn, "plataforma_cartera", ""),
    }


def guardar_configuracion(conn, datos: dict, actor: str | None = None) -> dict:
    for clave in ("dominio_mensual", "dominio_compra_anual"):
        if clave in datos:
            try:
                valor = money(float(datos[clave]))
            except (TypeError, ValueError):
                raise ApiError("El precio debe ser un número", 400, clave)
            if valor < 0:
                raise ApiError("El precio no puede ser negativo", 400, clave)
            _guardar(conn, clave, str(valor))
    for clave in ("dominio_dns_ip", "dominio_dns_host", "plataforma_iban", "plataforma_cartera"):
        if clave in datos:
            _guardar(conn, clave, str(datos[clave] or "").strip()[:200])
    if "dominio_dns_ip" in datos and datos["dominio_dns_ip"] and not RE_IP.match(str(datos["dominio_dns_ip"]).strip()):
        raise ApiError("La IP del servidor no es válida", 400, "dominio_dns_ip")
    db.audit(conn, actor, "plataforma.dominio_config", "plataforma", "dominios", {"claves": sorted(datos.keys())})
    return configuracion(conn)


def _guardar(conn, clave: str, valor: str) -> None:
    conn.execute(
        "INSERT INTO plataforma_config (clave, valor, updated_at) VALUES (?,?,?) ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor, updated_at=excluded.updated_at",
        (clave, valor, iso_now()),
    )


def _tienda(conn, tienda_id: str) -> dict:
    fila = one(conn, "SELECT * FROM tiendas WHERE id=?", (tienda_id,))
    if not fila:
        raise ApiError("Tienda no encontrada", 404)
    return dict(fila)


def estado_visible(t: dict) -> str:
    if not t.get("dominio_propio"):
        return "sin_configurar"
    if t.get("dominio_estado") == "dns_ok" and int(t.get("dominio_add_on_activo") or 0):
        return "activo"
    return t.get("dominio_estado") or "sin_configurar"


def texto_estado(estado: str) -> str:
    if estado == "activo":
        return "Activo"
    return ESTADOS_TIENDA.get(estado, "Sin dominio propio")


def vista(conn, tienda_id: str) -> dict:
    t = _tienda(conn, tienda_id)
    cfg = configuracion(conn)
    estado = estado_visible(t)
    return {
        "modo": t.get("dominio_modo") or "",
        "dominio": t.get("dominio_propio") or "",
        "estado": estado,
        "estado_texto": texto_estado(estado),
        "complemento_activo": bool(int(t.get("dominio_add_on_activo") or 0)),
        "nota": "El precio del dominio lo pagas tú íntegro, una vez al año. No está incluido en la mensualidad." if (t.get("dominio_modo") == "compra") else "",
        "precios": {"mensual": cfg["mensual"], "compra_anual": cfg["compra_anual"]},
        "dns": {"ip": cfg["dns_ip"], "host": cfg["dns_host"]},
        "pago": {"iban": cfg["iban"], "cartera": cfg["cartera"], "referencia": f"DOM-{t['slug'].upper()}"},
    }


def configurar(conn, tienda_id: str, modo: str, dominio_crudo: str, actor: str | None = None) -> dict:
    t = _tienda(conn, tienda_id)
    if t.get("dominio_propio") and t.get("dominio_estado") in ("pendiente_registro", "dns_ok") and t.get("dominio_modo") == "compra":
        raise ApiError("Tu dominio ya está registrado a tu nombre. Para cambiarlo, contacta con CC Shops.", 409)
    if modo not in ("propio", "compra"):
        raise ApiError("Elige cómo quieres el dominio", 400, "modo")
    dominio = validar(normalizar(dominio_crudo))
    if one(conn, "SELECT id FROM tiendas WHERE dominio_propio=? AND id<>?", (dominio, tienda_id)):
        raise ApiError("Ese dominio ya está en uso en otra tienda", 409, "dominio")
    estado = "pendiente_dns" if modo == "propio" else "pendiente_pago_dominio"
    conn.execute(
        "UPDATE tiendas SET dominio_modo=?, dominio_propio=?, dominio_estado=?, dominio_verificado_at='', dominio_add_on_activo=0, updated_at=? WHERE id=?",
        (modo, dominio, estado, iso_now(), tienda_id),
    )
    db.audit(conn, actor, "dominio.configurar", "tienda", tienda_id, {"modo": modo, "dominio": dominio})
    return vista(conn, tienda_id)


def cancelar(conn, tienda_id: str, actor: str | None = None) -> dict:
    """La tienda puede cancelar mientras no tenga un dominio comprado y registrado a su nombre."""
    t = _tienda(conn, tienda_id)
    if t.get("dominio_modo") == "compra" and t.get("dominio_estado") in ("pendiente_registro", "dns_ok"):
        raise ApiError("Tu dominio ya está registrado a tu nombre. Para cancelarlo, contacta con CC Shops.", 409)
    conn.execute(
        "UPDATE tiendas SET dominio_modo='', dominio_propio='', dominio_estado='sin_configurar', dominio_verificado_at='', dominio_add_on_activo=0, updated_at=? WHERE id=?",
        (iso_now(), tienda_id),
    )
    db.audit(conn, actor, "dominio.cancelar", "tienda", tienda_id, {"dominio": t.get("dominio_propio")})
    return vista(conn, tienda_id)


# ---------------------------------------------------------------- DNS

def _ips(host: str) -> set[str]:
    try:
        return {i[4][0] for i in socket.getaddrinfo(host, None, socket.AF_INET)}
    except OSError:
        return set()


def comprobar_dns(dominio: str, ip_servidor: str) -> bool:
    """El dominio o su «www» deben resolver a la IP del servidor de CC Shops."""
    resolver_actual = resolver or _ips
    if not ip_servidor:
        raise ApiError("La plataforma aún no tiene IP configurada para dominios. Avisa a CC Shops.", 503)
    return ip_servidor in resolver_actual(dominio) or ip_servidor in resolver_actual("www." + dominio)


def verificar(conn, tienda_id: str, actor: str | None = None) -> dict:
    t = _tienda(conn, tienda_id)
    if t.get("dominio_estado") not in ("pendiente_dns", "dns_ok") or not t.get("dominio_propio"):
        raise ApiError("Aún no se puede verificar el DNS de tu dominio", 409)
    cfg = configuracion(conn)
    if not comprobar_dns(t["dominio_propio"], cfg["dns_ip"]):
        raise ApiError("Todavía no vemos el dominio apuntando a CC Shops. Los cambios de DNS pueden tardar hasta 24 horas.", 409)
    conn.execute("UPDATE tiendas SET dominio_estado='dns_ok', dominio_verificado_at=?, updated_at=? WHERE id=?", (iso_now(), iso_now(), tienda_id))
    db.audit(conn, actor, "dominio.dns_ok", "tienda", tienda_id, {"dominio": t["dominio_propio"]})
    return vista(conn, tienda_id)


# ---------------------------------------------------------------- superadmin

def listado(conn) -> dict:
    filas = [dict(f) for f in conn.execute(
        "SELECT id, nombre, slug, dominio_modo, dominio_propio, dominio_estado, dominio_add_on_activo FROM tiendas WHERE dominio_propio<>'' OR dominio_modo<>'' ORDER BY nombre"
    ).fetchall()]
    for f in filas:
        f["estado_visible"] = estado_visible(f)
        f["complemento_activo"] = bool(int(f["dominio_add_on_activo"] or 0))
    return {"items": filas, "configuracion": configuracion(conn)}


def accion(conn, tienda_id: str, nombre: str, actor: str | None = None) -> dict:
    t = _tienda(conn, tienda_id)
    if not t.get("dominio_propio"):
        raise ApiError("La tienda no tiene dominio configurado", 409)
    if nombre == "pago_dominio_ok":
        if t.get("dominio_modo") != "compra" or t.get("dominio_estado") != "pendiente_pago_dominio":
            raise ApiError("No hay un pago de dominio pendiente", 409)
        conn.execute("UPDATE tiendas SET dominio_estado='pendiente_registro', updated_at=? WHERE id=?", (iso_now(), tienda_id))
    elif nombre == "registrado":
        if t.get("dominio_estado") != "pendiente_registro":
            raise ApiError("El dominio no está pendiente de registro", 409)
        conn.execute("UPDATE tiendas SET dominio_estado='pendiente_dns', updated_at=? WHERE id=?", (iso_now(), tienda_id))
    elif nombre in ("add_on_on", "add_on_off"):
        if nombre == "add_on_on" and t.get("dominio_estado") not in ("dns_ok",):
            raise ApiError("Primero el DNS del dominio debe estar verificado", 409)
        conn.execute("UPDATE tiendas SET dominio_add_on_activo=?, updated_at=? WHERE id=?", (1 if nombre == "add_on_on" else 0, iso_now(), tienda_id))
    else:
        raise ApiError("Acción no válida", 400, "accion")
    db.audit(conn, actor, f"dominio.{nombre}", "tienda", tienda_id, {"dominio": t["dominio_propio"]})
    return vista(conn, tienda_id)


def dominio_activo(conn, host: str) -> str | None:
    """Tienda que se sirve en ese dominio (solo con complemento activo, DNS verificado y tienda no suspendida)."""
    host = normalizar(host)
    if not host:
        return None
    fila = one(
        conn,
        """SELECT id FROM tiendas WHERE dominio_propio=? AND dominio_estado='dns_ok' AND dominio_add_on_activo=1
           AND estado<>'suspendida'""",
        (host,),
    )
    return str(fila["id"]) if fila else None
