"""Catálogo: categorías, productos, validación y vistas pública/backoffice."""
from __future__ import annotations

import json
import re
from datetime import datetime
from typing import Any

from . import config, db, kardex
from .db import all_rows, document_number, one
from .util import ApiError, EMAIL_RE, SKU_RE, iso_now, money, new_id, num, slugify, txt

IVAS = (0.0, 4.0, 10.0, 21.0)
UNIDADES = ("ud", "caja", "pack", "rollo", "kg", "l", "m")
IMAGE_RE = re.compile(r"^data:image/(jpeg|png|webp);base64,[A-Za-z0-9+/=\s]+$")


def promo_vigente(p: dict, ahora: datetime | None = None) -> bool:
    """Promoción activa: configurada, sin agotar, con stock disponible y dentro de la fecha de fin."""
    if not int(p.get("promo_activa") or 0) or not int(p.get("activo") or 0):
        return False
    if float(p.get("promo_stock_restante") or 0) <= 0 or float(p.get("stock") or 0) <= 0:
        return False
    fin = p.get("promo_fin") or ""
    if not fin:
        return False
    try:
        return datetime.fromisoformat(fin) > (ahora or datetime.now())
    except ValueError:
        return False


def _bool(value, defecto: bool = False) -> int:
    if value is None:
        return 1 if defecto else 0
    if isinstance(value, str):
        return 1 if value.strip().lower() in {"1", "true", "si", "sí", "on", "yes"} else 0
    return 1 if value else 0


def _imagen(value) -> str:
    if value is None:
        return ""
    texto = str(value).strip()
    if not texto:
        return ""
    if texto.startswith("/static/") and ".." not in texto and len(texto) <= 300:
        return texto
    if len(texto) > config.MAX_IMAGE_CHARS:
        raise ApiError("La imagen es demasiado grande (máximo ~330 KB tras comprimir)")
    if not IMAGE_RE.match(texto):
        raise ApiError("La imagen debe ser JPEG, PNG o WebP")
    return texto


def _especificaciones(value) -> str:
    if value in (None, ""):
        return "[]"
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except json.JSONDecodeError:
            raise ApiError("Las especificaciones no son válidas")
    if isinstance(value, dict):
        value = [{"clave": k, "valor": v} for k, v in value.items()]
    if not isinstance(value, list) or len(value) > 16:
        raise ApiError("Las especificaciones deben ser una lista de hasta 16 pares")
    limpias = []
    for item in value:
        if not isinstance(item, dict):
            continue
        clave = txt(item.get("clave"), 40)
        valor = txt(item.get("valor"), 120)
        if clave and valor:
            limpias.append({"clave": clave, "valor": valor})
    return json.dumps(limpias, ensure_ascii=False)


def _slug_unico(conn, nombre: str, tabla: str, actual: str = "") -> str:
    base = slugify(nombre)
    candidato = base
    n = 1
    while True:
        fila = one(conn, f"SELECT id FROM {tabla} WHERE slug=?", (candidato,))
        if not fila or fila["id"] == actual:
            return candidato
        n += 1
        candidato = f"{base}-{n}"


def _categoria(conn, categoria_id: str, tienda_id: str | None) -> dict | None:
    if not categoria_id:
        return None
    fila = one(conn, "SELECT * FROM categorias WHERE id=? AND tienda_id=?", (categoria_id, tienda_id))
    if not fila:
        raise ApiError("La categoría no existe")
    return dict(fila)


# ----------------------------------------------------------------------
# Variantes: cada variante es un producto hijo (padre_id) con su SKU, precio, stock y kardex.

ATRIBUTOS_MAX = 3


def atributos_de(valor) -> dict:
    if isinstance(valor, dict):
        return valor
    try:
        return json.loads(valor or "{}")
    except (TypeError, ValueError):
        return {}


def variantes_de(conn, padre_id: str, solo_activas: bool = False) -> list[dict]:
    sql = "SELECT * FROM productos WHERE padre_id=?" + (" AND activo=1" if solo_activas else "") + " ORDER BY created_at"
    out = []
    for f in all_rows(conn, sql, (padre_id,)):
        d = dict(f)
        d["atributos"] = atributos_de(d.get("atributos"))
        d["activo"] = bool(d["activo"])
        d["stock_estado"] = "agotado" if float(d["stock"]) <= 0 else ("ultimas" if float(d["stock"]) <= 5 else "disponible")
        d["promo_vigente"] = promo_vigente(d)
        d["precio_mostrado"] = float(d["promo_precio"]) if d["promo_vigente"] else float(d["precio"])
        out.append(d)
    return out


def _limpiar_atributos(atributos) -> dict:
    if not isinstance(atributos, dict) or not atributos:
        raise ApiError("Indica al menos un atributo (por ejemplo talla o color)", 400, "atributos")
    if len(atributos) > ATRIBUTOS_MAX:
        raise ApiError(f"Una variante admite como máximo {ATRIBUTOS_MAX} atributos", 400, "atributos")
    limpio = {}
    for clave, valor in atributos.items():
        k = txt(clave, 30)
        v = txt(valor, 40)
        if not k or not v:
            raise ApiError("Cada atributo necesita nombre y valor", 400, "atributos")
        limpio[k] = v
    return limpio


def crear_variante(conn, padre_id: str, data: dict, usuario_id: str | None, tienda_id: str | None) -> dict:
    padre = one(conn, "SELECT * FROM productos WHERE id=? AND tienda_id=?", (padre_id, tienda_id))
    if not padre:
        raise ApiError("Producto no encontrado", 404)
    if padre["padre_id"]:
        raise ApiError("Una variante no puede tener variantes", 400)
    if int(padre["es_pack"] or 0):
        raise ApiError("Un pack no admite variantes", 400)
    atributos = _limpiar_atributos(data.get("atributos"))
    existentes = variantes_de(conn, padre_id)
    if any(v["atributos"] == atributos for v in existentes):
        raise ApiError("Ya existe una variante con esa combinación", 409, "atributos")
    etiqueta = " · ".join(atributos.values())
    datos = {
        "nombre": f"{padre['nombre']} · {etiqueta}",
        "sku": data.get("sku") or "",
        "categoria_id": padre["categoria_id"] or "",
        "marca": padre["marca"],
        "precio": data.get("precio") if data.get("precio") not in (None, "") else padre["precio"],
        "iva": padre["iva"],
        "unidad": padre["unidad"],
        "stock_minimo": data.get("stock_minimo", 0),
        "stock_inicial": data.get("stock_inicial", 0),
        "coste": data.get("coste", 0),
        "descripcion_corta": padre["descripcion_corta"],
        "descripcion": padre["descripcion"],
        "imagen": padre["imagen"],
        "activo": data.get("activo", True),
    }
    creado = crear_producto(conn, datos, usuario_id, tienda_id)
    conn.execute("UPDATE productos SET padre_id=?, atributos=? WHERE id=?", (padre_id, json.dumps(atributos, ensure_ascii=False), creado["id"]))
    kardex.recalcular_padre(conn, creado["id"])
    db.audit(conn, usuario_id, "producto.variante_alta", "producto", padre_id, {"variante": creado["id"], "atributos": atributos})
    return _producto_admin(conn, creado["id"])


def actualizar_variante_activa(conn, variante_id: str, activa: bool, usuario_id: str | None, tienda_id: str | None) -> dict:
    v = one(conn, "SELECT * FROM productos WHERE id=? AND tienda_id=? AND padre_id IS NOT NULL", (variante_id, tienda_id))
    if not v:
        raise ApiError("Variante no encontrada", 404)
    conn.execute("UPDATE productos SET activo=?, updated_at=? WHERE id=?", (1 if activa else 0, iso_now(), variante_id))
    db.audit(conn, usuario_id, "producto.variante_activa", "producto", variante_id, {"activa": activa})
    return _producto_admin(conn, variante_id)


def _producto_admin(conn, producto_id: str, tienda_id: str | None = None) -> dict:
    fila = one(
        conn,
        """SELECT p.*, c.nombre AS categoria_nombre, c.slug AS categoria_slug
           FROM productos p LEFT JOIN categorias c ON c.id=p.categoria_id WHERE p.id=?""",
        (producto_id,),
    )
    if not fila:
        raise ApiError("Producto no encontrado", 404)
    return serializar_admin(conn, fila)


def serializar_admin(conn, fila) -> dict:
    d = dict(fila)
    d["subcategorias"] = subcategorias_de(conn, d["id"])
    d["atributos"] = atributos_de(d.get("atributos"))
    d["variantes"] = variantes_de(conn, d["id"]) if not d.get("padre_id") else []
    d["es_pack"] = bool(d.get("es_pack"))
    d["promo_activa"] = bool(d.get("promo_activa"))
    d["promo_vigente"] = promo_vigente(d)
    d["componentes"] = [
        dict(c) for c in all_rows(
            conn,
            """SELECT c.producto_id, c.cantidad, p.nombre, p.sku, p.stock FROM pack_componentes c
               JOIN productos p ON p.id=c.producto_id WHERE c.pack_id=? ORDER BY p.nombre""",
            (d["id"],),
        )
    ] if d["es_pack"] else []
    d["activo"] = bool(d["activo"])
    d["destacado"] = bool(d["destacado"])
    d["especificaciones"] = _load_specs(d.get("especificaciones"))
    d["bajo_minimo"] = float(d["stock"]) <= float(d["stock_minimo"])
    d["agotado"] = float(d["stock"]) <= 0
    precio = float(d["precio"])
    coste = float(d["coste_medio"])
    base = precio / (1 + float(d["iva"]) / 100) if d["iva"] else precio
    d["margen"] = money(base - coste)
    d["margen_pct"] = round((base - coste) / base * 100, 1) if base > 0 else 0.0
    d["precio_sin_iva"] = money(base)
    return d


def serializar_publico(fila) -> dict:
    d = dict(fila)
    d["stock"] = float(d["stock"])
    d["stock_minimo"] = float(d["stock_minimo"])
    d["especificaciones"] = _load_specs(d.get("especificaciones"))
    if d["stock"] <= 0:
        estado = "agotado"
    elif d["stock"] <= max(1.0, float(d["stock_minimo"])):
        estado = "ultimas"
    elif d["stock"] <= 5:
        estado = "ultimas"
    else:
        estado = "disponible"
    d["stock_estado"] = estado
    # No exponer el coste ni el valor del inventario en la tienda.
    for clave in ("coste_medio", "valor_stock", "activo"):
        d.pop(clave, None)
    d["destacado"] = bool(d.get("destacado"))
    d["es_pack"] = bool(d.get("es_pack"))
    if promo_vigente({**d, "activo": 1}):  # el listado público ya filtra los inactivos
        d["precio_original"] = float(d["precio"])
        d["precio"] = float(d["promo_precio"])
        d["promo"] = {"fin": d["promo_fin"], "stock": min(float(d["promo_stock_restante"]), float(d["stock"]))}
    else:
        d["promo"] = None
    for clave in ("promo_activa", "promo_precio", "promo_stock_inicial", "promo_stock_restante", "promo_fin"):
        d.pop(clave, None)
    return d


def _load_specs(value) -> list[dict]:
    try:
        datos = json.loads(value or "[]")
        if isinstance(datos, list):
            return [x for x in datos if isinstance(x, dict) and x.get("clave")]
    except Exception:
        pass
    return []


# ----------------------------------------------------------------------
# Categorías


def hay_promociones(conn, tienda_id: str | None) -> int:
    ahora = datetime.now().isoformat(timespec="minutes")
    return int(one(
        conn,
        """SELECT COUNT(*) AS n FROM productos WHERE tienda_id=? AND activo=1 AND promo_activa=1
           AND promo_stock_restante>0 AND stock>0 AND promo_fin>?""",
        (tienda_id, ahora),
    )["n"])


def listar_categorias(conn, publico: bool = False, *, tienda_id: str | None) -> list[dict]:
    """Categorías principales y subcategorías (padre_id). Cada una con su número de productos activos."""
    condicion = "WHERE c.tienda_id=?" + (" AND c.activo=1" if publico else "")
    filas = all_rows(
        conn,
        f"""SELECT c.*,
              (SELECT COUNT(*) FROM productos p WHERE p.tienda_id=c.tienda_id AND p.activo=1 AND p.categoria_id=c.id)
              + (SELECT COUNT(*) FROM producto_subcategorias ps JOIN productos p ON p.id=ps.producto_id
                 WHERE ps.categoria_id=c.id AND p.activo=1) AS productos
            FROM categorias c
            {condicion}
            ORDER BY c.orden, c.nombre""",
        (tienda_id,),
    )
    categorias = [dict(f) for f in filas]
    if publico:
        n = hay_promociones(conn, tienda_id)
        if n:
            categorias.append({
                "id": "promociones", "nombre": "Promociones", "slug": "promociones", "descripcion": "Ofertas por tiempo limitado",
                "icono": "tag", "orden": -1, "activo": 1, "padre_id": None, "productos": n, "virtual": True,
            })
    return categorias


def subcategorias_de(conn, producto_id: str) -> list[dict]:
    filas = all_rows(
        conn,
        """SELECT c.id, c.nombre, c.padre_id FROM producto_subcategorias ps
           JOIN categorias c ON c.id=ps.categoria_id WHERE ps.producto_id=? ORDER BY c.nombre""",
        (producto_id,),
    )
    return [dict(f) for f in filas]


def marcas(conn, tienda_id: str | None) -> list[str]:
    """Marcas ya usadas en la tienda: alimentan el desplegable del formulario de producto."""
    filas = all_rows(conn, "SELECT DISTINCT marca FROM productos WHERE tienda_id=? AND marca<>''", (tienda_id,))
    return sorted((f["marca"] for f in filas), key=str.casefold)


def _padre_valido(conn, padre_id: str, tienda_id: str) -> dict:
    padre = one(conn, "SELECT * FROM categorias WHERE id=? AND tienda_id=?", (padre_id, tienda_id))
    if not padre:
        raise ApiError("La categoría principal no existe", 400, "padre_id")
    if padre["padre_id"]:
        raise ApiError("Solo se admite un nivel de subcategorías", 400, "padre_id")
    return dict(padre)


def _nombre_libre(conn, nombre: str, tienda_id: str, padre_id: str | None, excepto: str = "") -> None:
    existe = one(
        conn,
        """SELECT id FROM categorias WHERE tienda_id=? AND COALESCE(padre_id,'')=COALESCE(?,'')
           AND LOWER(nombre)=LOWER(?) AND id<>?""",
        (tienda_id, padre_id, nombre, excepto),
    )
    if existe:
        raise ApiError("Ya existe una categoría o subcategoría con ese nombre en este nivel", 409, "nombre")


def crear_categoria(conn, data: dict, tienda_id: str) -> dict:
    nombre = txt(data.get("nombre"), 60)
    if not nombre:
        raise ApiError("El nombre de la categoría es obligatorio", 400, "nombre")
    padre_id = txt(data.get("padre_id"), 40) or None
    if padre_id:
        _padre_valido(conn, padre_id, tienda_id)
    _nombre_libre(conn, nombre, tienda_id, padre_id)
    cid = new_id("CAT")
    conn.execute(
        "INSERT INTO categorias (id, tienda_id, nombre, slug, descripcion, icono, orden, activo, padre_id) VALUES (?,?,?,?,?,?,?,?,?)",
        (
            cid,
            tienda_id,
            nombre,
            _slug_unico(conn, nombre, "categorias"),
            txt(data.get("descripcion"), 240),
            txt(data.get("icono"), 30),
            int(num(data.get("orden", 0), "El orden", 0, 999)),
            _bool(data.get("activo"), True),
            padre_id,
        ),
    )
    return dict(one(conn, "SELECT * FROM categorias WHERE id=?", (cid,)))


def actualizar_categoria(conn, categoria_id: str, data: dict) -> dict:
    actual = one(conn, "SELECT * FROM categorias WHERE id=?", (categoria_id,))
    if not actual:
        raise ApiError("Categoría no encontrada", 404)
    nombre = txt(data.get("nombre", actual["nombre"]), 60)
    if not nombre:
        raise ApiError("El nombre de la categoría es obligatorio", 400, "nombre")
    _nombre_libre(conn, nombre, actual["tienda_id"], actual["padre_id"], excepto=categoria_id)
    conn.execute(
        "UPDATE categorias SET nombre=?, slug=?, descripcion=?, icono=?, orden=?, activo=? WHERE id=?",
        (
            nombre,
            _slug_unico(conn, nombre, "categorias", categoria_id),
            txt(data.get("descripcion", actual["descripcion"]), 240),
            txt(data.get("icono", actual["icono"]), 30),
            int(num(data.get("orden", actual["orden"]), "El orden", 0, 999)),
            _bool(data.get("activo", actual["activo"]), True),
            categoria_id,
        ),
    )
    return dict(one(conn, "SELECT * FROM categorias WHERE id=?", (categoria_id,)))


def borrar_categoria(conn, categoria_id: str) -> None:
    if not one(conn, "SELECT id FROM categorias WHERE id=?", (categoria_id,)):
        raise ApiError("Categoría no encontrada", 404)
    if one(conn, "SELECT id FROM categorias WHERE padre_id=? LIMIT 1", (categoria_id,)):
        raise ApiError("Borra antes sus subcategorías", 409)
    n = one(conn, "SELECT COUNT(*) AS n FROM productos WHERE categoria_id=?", (categoria_id,))["n"]
    n += one(conn, "SELECT COUNT(*) AS n FROM producto_subcategorias WHERE categoria_id=?", (categoria_id,))["n"]
    if n:
        raise ApiError("No puedes borrar una categoría con productos. Reasígnalos primero.", 409)
    conn.execute("DELETE FROM categorias WHERE id=?", (categoria_id,))


# ----------------------------------------------------------------------
# Productos


def _validar_producto(conn, data: dict, actual: dict | None, tienda_id: str | None) -> dict:
    actual = actual or {}
    nombre = txt(data.get("nombre", actual.get("nombre")), 140)
    if not nombre:
        raise ApiError("El nombre del producto es obligatorio")
    sku = txt(data.get("sku", actual.get("sku")), 32).upper()
    if not sku:
        n = 1
        while True:
            candidato = f"INS-{n:04d}"
            if not one(conn, "SELECT id FROM productos WHERE sku=?", (candidato,)):
                sku = candidato
                break
            n += 1
    if not SKU_RE.match(sku):
        raise ApiError("El SKU debe tener entre 2 y 32 caracteres: letras, números, punto, guion o guion bajo")
    duplicado = one(conn, "SELECT id FROM productos WHERE sku=? AND id<>?", (sku, actual.get("id", "")))
    if duplicado:
        raise ApiError("Ya existe un producto con ese SKU", 409)

    categoria_id = txt(data.get("categoria_id", actual.get("categoria_id", "")), 40)
    if categoria_id:
        cat = _categoria(conn, categoria_id, tienda_id)
        if cat and cat.get("padre_id"):
            raise ApiError("Elige una categoría principal. Las subcategorías se añaden aparte.", 400, "categoria_id")
    subcategoria_ids = None
    if "subcategoria_ids" in data:
        bruto = data.get("subcategoria_ids") or []
        if isinstance(bruto, str):
            bruto = [x for x in bruto.split(",") if x]
        ids = list(dict.fromkeys(str(x).strip() for x in bruto if str(x).strip()))
        if len(ids) > 2:
            raise ApiError("Un producto puede tener como máximo 2 subcategorías", 400, "subcategoria_ids")
        for sid in ids:
            sub = one(conn, "SELECT padre_id, tienda_id FROM categorias WHERE id=?", (sid,))
            if not sub or sub["tienda_id"] != tienda_id:
                raise ApiError("Una subcategoría no existe", 400, "subcategoria_ids")
            if not sub["padre_id"] or sub["padre_id"] != categoria_id:
                raise ApiError("Las subcategorías deben pertenecer a la categoría principal del producto", 400, "subcategoria_ids")
        subcategoria_ids = ids

    iva = num(data.get("iva", actual.get("iva", 21)), "El IVA", 0, 21)
    if iva not in IVAS:
        raise ApiError("El IVA debe ser 0, 4, 10 o 21")
    unidad = txt(data.get("unidad", actual.get("unidad", "ud")), 10) or "ud"
    if unidad not in UNIDADES:
        unidad = "ud"

    return {
        "nombre": nombre,
        "sku": sku,
        "slug": _slug_unico(conn, nombre, "productos", actual.get("id", "")),
        "descripcion": txt(data.get("descripcion", actual.get("descripcion", "")), 4000),
        "descripcion_corta": txt(
            data.get("descripcion_corta", actual.get("descripcion_corta", "")), 300
        ),
        "especificaciones": _especificaciones(
            data.get("especificaciones", actual.get("especificaciones", "[]"))
        ),
        "categoria_id": categoria_id or None,
        "subcategoria_ids": subcategoria_ids,
        "marca": txt(data.get("marca", actual.get("marca", "")), 60),
        "unidad": unidad,
        "precio": money(num(data.get("precio", actual.get("precio", 0)), "El precio", 0, 999999)),
        "iva": iva,
        "stock_minimo": num(data.get("stock_minimo", actual.get("stock_minimo", 0)), "El stock mínimo", 0, 999999),
        "imagen": _imagen(data.get("imagen", actual.get("imagen", ""))),
        "activo": _bool(data.get("activo", actual.get("activo", True)), True),
        "destacado": _bool(data.get("destacado", actual.get("destacado", False))),
    }


def _guardar_subcategorias(conn, producto_id: str, ids: list[str] | None) -> None:
    if ids is None:  # no se han enviado: se conservan las actuales
        return
    conn.execute("DELETE FROM producto_subcategorias WHERE producto_id=?", (producto_id,))
    for sid in ids:
        conn.execute("INSERT INTO producto_subcategorias (producto_id, categoria_id) VALUES (?,?)", (producto_id, sid))


def _validar_componentes(conn, data: dict, pack_id: str | None, tienda_id: str | None) -> list[tuple[str, float]]:
    bruto = data.get("componentes")
    if not isinstance(bruto, list):
        raise ApiError("Indica los productos que forman el pack", 400, "componentes")
    if len(bruto) < 2:
        raise ApiError("Un pack se forma con 2 o más productos", 400, "componentes")
    if len(bruto) > 20:
        raise ApiError("Un pack admite como máximo 20 productos", 400, "componentes")
    vistos: list[tuple[str, float]] = []
    for linea in bruto:
        if not isinstance(linea, dict):
            raise ApiError("Hay un componente no válido", 400, "componentes")
        pid = txt(linea.get("producto_id"), 40)
        cantidad = num(linea.get("cantidad", 1), "La cantidad del componente", 0.0001, 9999)
        if not pid:
            raise ApiError("Hay un componente sin producto", 400, "componentes")
        if pid == pack_id:
            raise ApiError("Un pack no puede contenerse a sí mismo", 400, "componentes")
        if any(v[0] == pid for v in vistos):
            raise ApiError("Un producto aparece dos veces en el pack", 400, "componentes")
        fila = one(conn, "SELECT id, nombre, es_pack FROM productos WHERE id=? AND activo=1 AND tienda_id=?", (pid, tienda_id))
        if not fila:
            raise ApiError("Uno de los productos del pack no está disponible", 400, "componentes")
        if int(fila["es_pack"] or 0):
            raise ApiError("Un pack no puede incluir otros packs", 400, "componentes")
        vistos.append((pid, cantidad))
    return vistos


def _guardar_componentes(conn, pack_id: str, comps: list[tuple[str, float]]) -> None:
    conn.execute("DELETE FROM pack_componentes WHERE pack_id=?", (pack_id,))
    for pid, cantidad in comps:
        conn.execute("INSERT INTO pack_componentes (pack_id, producto_id, cantidad) VALUES (?,?,?)", (pack_id, pid, cantidad))
    kardex.recalcular_pack(conn, pack_id)


def _validar_promo(conn, data: dict, actual: dict, precio: float) -> dict | None:
    """Devuelve las columnas de promoción a guardar, o None si el formulario no toca la promoción."""
    if "promo_activa" not in data and "promo_precio" not in data and "promo_stock" not in data and "promo_fin" not in data:
        return None
    activa = _bool(data.get("promo_activa", actual.get("promo_activa", 0)))
    if not activa:
        return {"promo_activa": 0, "promo_precio": 0, "promo_stock_inicial": 0, "promo_stock_restante": 0, "promo_fin": ""}
    promo_precio = money(num(data.get("promo_precio", actual.get("promo_precio", 0)), "El precio de promoción", 0, 999999))
    if promo_precio <= 0 or promo_precio >= precio:
        raise ApiError("El precio de promoción debe ser mayor que 0 y menor que el precio normal", 400, "promo_precio")
    stock = num(data.get("promo_stock", actual.get("promo_stock_inicial", 0)), "El stock en promoción", 0.0001, 999999)
    fin_txt = txt(data.get("promo_fin", actual.get("promo_fin", "")), 19)
    try:
        fin = datetime.fromisoformat(fin_txt)
    except ValueError:
        raise ApiError("Indica hasta cuándo dura la promoción", 400, "promo_fin")
    if fin <= datetime.now():
        raise ApiError("La fecha de fin de la promoción ya ha pasado", 400, "promo_fin")
    return {
        "promo_activa": 1,
        "promo_precio": promo_precio,
        "promo_stock_inicial": stock,
        "promo_stock_restante": stock,
        "promo_fin": fin.isoformat(timespec="minutes"),
    }


def _limite_productos(conn, tienda_id: str | None) -> None:
    """El plan de la tienda limita el número de productos activos."""
    fila = one(
        conn,
        "SELECT p.max_productos, p.nombre FROM tiendas t JOIN planes p ON p.id=t.plan_id WHERE t.id=?",
        (tienda_id,),
    )
    if not fila:
        return
    actuales = one(conn, "SELECT COUNT(*) AS n FROM productos WHERE tienda_id=? AND activo=1", (tienda_id,))["n"]
    if actuales >= int(fila["max_productos"]):
        raise ApiError(f"Tu plan ({fila['nombre']}) permite hasta {fila['max_productos']} productos. Cambia de plan para añadir más.", 409)


def crear_producto(conn, data: dict, usuario_id: str | None = None, tienda_id: str | None = None) -> dict:
    _limite_productos(conn, tienda_id)
    es_pack = _bool(data.get("es_pack"), False)
    if es_pack:
        comps_pack = _validar_componentes(conn, data, None, tienda_id)
        data = {**data, "stock_inicial": 0, "coste": 0}
        if not txt(data.get("categoria_id"), 40) and comps_pack:
            primero = one(conn, "SELECT categoria_id FROM productos WHERE id=?", (comps_pack[0][0],))
            data["categoria_id"] = (primero["categoria_id"] if primero else "") or ""
    limpio = _validar_producto(conn, data, None, tienda_id)
    if es_pack and not limpio["descripcion"]:
        nombres = ", ".join(
            f"{one(conn, 'SELECT nombre FROM productos WHERE id=?', (pid,))['nombre']} × {float(q):g}" for pid, q in comps_pack
        )
        limpio["descripcion"] = f"Incluye: {nombres}."
    promo = _validar_promo(conn, data, {}, limpio["precio"])
    pid = new_id("PRD")
    sello = iso_now()
    stock_inicial = num(data.get("stock_inicial", 0), "El stock inicial", 0, 999999)
    coste = num(data.get("coste", 0), "El coste", 0, 999999)
    if stock_inicial > 0 and coste <= 0:
        raise ApiError("Indica el coste unitario para valorar el stock inicial")

    conn.execute(
        """INSERT INTO productos (id, tienda_id, sku, nombre, slug, descripcion, descripcion_corta, especificaciones,
            categoria_id, marca, unidad, precio, iva, stock, stock_minimo, coste_medio, valor_stock,
            imagen, activo, destacado, created_at, updated_at)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,0,?,?,0,?,?,?,?,?)""",
        (
            pid,
            tienda_id,
            limpio["sku"],
            limpio["nombre"],
            limpio["slug"],
            limpio["descripcion"],
            limpio["descripcion_corta"],
            limpio["especificaciones"],
            limpio["categoria_id"],
            limpio["marca"],
            limpio["unidad"],
            limpio["precio"],
            limpio["iva"],
            limpio["stock_minimo"],
            coste if stock_inicial <= 0 else 0,
            limpio["imagen"],
            limpio["activo"],
            limpio["destacado"],
            sello,
            sello,
        ),
    )
    _guardar_subcategorias(conn, pid, limpio["subcategoria_ids"])
    if es_pack:
        conn.execute("UPDATE productos SET es_pack=1 WHERE id=?", (pid,))
        _guardar_componentes(conn, pid, comps_pack)
    if promo:
        sets = ", ".join(f"{k}=?" for k in promo)
        conn.execute(f"UPDATE productos SET {sets} WHERE id=?", (*promo.values(), pid))
    if stock_inicial > 0 and not es_pack:
        kardex.entrada(
            conn,
            pid,
            stock_inicial,
            coste,
            tipo="entrada_ajuste",
            documento_tipo="ajuste",
            documento_numero=document_number(conn, "AJU", "ajuste"),
            motivo="Stock inicial del producto",
            usuario_id=usuario_id,
        )
    return _producto_admin(conn, pid)


def actualizar_producto(conn, producto_id: str, data: dict, usuario_id: str | None = None) -> dict:
    actual = one(conn, "SELECT * FROM productos WHERE id=?", (producto_id,))
    if not actual:
        raise ApiError("Producto no encontrado", 404)
    limpio = _validar_producto(conn, data, dict(actual), actual["tienda_id"])
    if limpio["subcategoria_ids"] is None and limpio["categoria_id"] != actual["categoria_id"]:
        limpio["subcategoria_ids"] = []  # cambió la categoría principal: las subcategorías anteriores ya no aplican
    conn.execute(
        """UPDATE productos SET sku=?, nombre=?, slug=?, descripcion=?, descripcion_corta=?,
            especificaciones=?, categoria_id=?, marca=?, unidad=?, precio=?, iva=?, stock_minimo=?,
            imagen=?, activo=?, destacado=?, updated_at=? WHERE id=?""",
        (
            limpio["sku"],
            limpio["nombre"],
            limpio["slug"],
            limpio["descripcion"],
            limpio["descripcion_corta"],
            limpio["especificaciones"],
            limpio["categoria_id"],
            limpio["marca"],
            limpio["unidad"],
            limpio["precio"],
            limpio["iva"],
            limpio["stock_minimo"],
            limpio["imagen"],
            limpio["activo"],
            limpio["destacado"],
            iso_now(),
            producto_id,
        ),
    )
    _guardar_subcategorias(conn, producto_id, limpio["subcategoria_ids"])
    if int(actual["es_pack"] or 0) and "componentes" in data:
        _guardar_componentes(conn, producto_id, _validar_componentes(conn, data, producto_id, actual["tienda_id"]))
    promo = _validar_promo(conn, data, dict(actual), limpio["precio"])
    if promo:
        sets = ", ".join(f"{k}=?" for k in promo)
        conn.execute(f"UPDATE productos SET {sets} WHERE id=?", (*promo.values(), producto_id))
    return _producto_admin(conn, producto_id)


def desactivar_producto(conn, producto_id: str) -> None:
    if not one(conn, "SELECT id FROM productos WHERE id=?", (producto_id,)):
        raise ApiError("Producto no encontrado", 404)
    conn.execute("UPDATE productos SET activo=0, updated_at=? WHERE id=?", (iso_now(), producto_id))


def listar_admin(conn, q: str = "", categoria: str = "", estado: str = "", pagina: int = 1, por_pagina: int = 25, tienda_id: str | None = None):
    where = ["p.padre_id IS NULL"]
    params: list[Any] = []
    where.append("p.tienda_id=?")
    params.append(tienda_id)
    if q:
        where.append("(p.nombre LIKE ? OR p.sku LIKE ? OR p.marca LIKE ?)")
        like = f"%{q}%"
        params += [like, like, like]
    if categoria:
        where.append("p.categoria_id=?")
        params.append(categoria)
    if estado == "activo":
        where.append("p.activo=1")
    elif estado == "inactivo":
        where.append("p.activo=0")
    elif estado == "bajo":
        where.append("p.activo=1 AND p.stock<=p.stock_minimo")
    elif estado == "agotado":
        where.append("p.activo=1 AND p.stock<=0")
    filtro = " AND ".join(where)
    total = one(conn, f"SELECT COUNT(*) AS n FROM productos p WHERE {filtro}", params)["n"]
    pagina = max(1, int(pagina))
    por_pagina = min(100, max(1, int(por_pagina)))
    filas = all_rows(
        conn,
        f"""SELECT p.*, c.nombre AS categoria_nombre, c.slug AS categoria_slug
            FROM productos p LEFT JOIN categorias c ON c.id=p.categoria_id
            WHERE {filtro} ORDER BY p.destacado DESC, p.nombre ASC LIMIT ? OFFSET ?""",
        params + [por_pagina, (pagina - 1) * por_pagina],
    )
    resumen = one(
        conn,
        """SELECT COUNT(*) AS referencias, COALESCE(SUM(stock),0) AS unidades,
                  COALESCE(SUM(valor_stock),0) AS valor,
                  SUM(CASE WHEN activo=1 AND stock<=stock_minimo THEN 1 ELSE 0 END) AS bajo
           FROM productos""",
    )
    return {
        "items": [serializar_admin(conn, f) for f in filas],
        "total": int(total),
        "pagina": pagina,
        "paginas": max(1, (int(total) + por_pagina - 1) // por_pagina),
        "resumen": {
            "referencias": int(resumen["referencias"]),
            "unidades": float(resumen["unidades"]),
            "valor": money(resumen["valor"]),
            "bajo": int(resumen["bajo"] or 0),
        },
    }


def ajustar_stock(conn, producto_id: str, data: dict, usuario_id: str | None = None) -> dict:
    """Ajuste por recuento físico (nuevo_stock) o por delta (cantidad). Siempre con motivo."""
    p = one(conn, "SELECT * FROM productos WHERE id=?", (producto_id,))
    if not p:
        raise ApiError("Producto no encontrado", 404)
    motivo = txt(data.get("motivo"), 240)
    if len(motivo) < 3:
        raise ApiError("El motivo del ajuste es obligatorio (mínimo 3 caracteres)")
    actual = float(p["stock"])
    if "nuevo_stock" in data and data.get("nuevo_stock") not in (None, ""):
        objetivo = num(data.get("nuevo_stock"), "El stock contado", 0, 999999)
        delta = round(objetivo - actual, 4)
    else:
        delta = num(data.get("cantidad"), "La cantidad", -999999, 999999)
    if abs(delta) < 0.0001:
        raise ApiError("El ajuste no cambia el stock")
    numero = document_number(conn, "AJU", "ajuste")
    if delta > 0:
        coste = data.get("coste")
        if coste in (None, ""):
            coste = float(p["coste_medio"])
        mov = kardex.entrada(
            conn,
            producto_id,
            delta,
            num(coste, "El coste unitario", 0, 999999),
            tipo="entrada_ajuste",
            documento_tipo="ajuste",
            documento_id=numero,
            documento_numero=numero,
            motivo=motivo,
            usuario_id=usuario_id,
        )
    else:
        mov = kardex.salida(
            conn,
            producto_id,
            abs(delta),
            tipo="salida_ajuste",
            documento_tipo="ajuste",
            documento_id=numero,
            documento_numero=numero,
            motivo=motivo,
            usuario_id=usuario_id,
        )
    return {"producto": _producto_admin(conn, producto_id), "movimiento": mov, "numero": numero}


def producto_por_slug(conn, slug: str, tienda_id: str | None) -> dict:
    fila = one(
        conn,
        """SELECT p.*, c.nombre AS categoria_nombre, c.slug AS categoria_slug
           FROM productos p LEFT JOIN categorias c ON c.id=p.categoria_id
           WHERE p.slug=? AND p.activo=1 AND p.tienda_id=?""",
        (slug, tienda_id),
    )
    if not fila:
        raise ApiError("Producto no encontrado", 404)
    datos = serializar_publico(fila)
    datos["atributos"] = {}
    datos["variantes"] = [
        {
            "id": v["id"], "nombre": v["nombre"], "sku": v["sku"], "atributos": v["atributos"],
            "precio": v["precio_mostrado"], "stock": float(v["stock"]), "stock_estado": v["stock_estado"],
            "imagen": v["imagen"], "unidad": v["unidad"],
        }
        for v in variantes_de(conn, fila["id"], solo_activas=True)
    ]
    datos["subcategorias"] = subcategorias_de(conn, fila["id"])
    datos["relacionados"] = relacionados(conn, fila["id"], fila["categoria_id"], tienda_id)
    return datos


def relacionados(conn, producto_id: str, categoria_id: str | None, tienda_id: str | None, limite: int = 4) -> list[dict]:
    if categoria_id:
        filas = all_rows(
            conn,
            """SELECT p.*, c.nombre AS categoria_nombre, c.slug AS categoria_slug
               FROM productos p LEFT JOIN categorias c ON c.id=p.categoria_id
               WHERE p.activo=1 AND p.tienda_id=? AND p.categoria_id=? AND p.id<>?
               ORDER BY p.destacado DESC, p.nombre LIMIT ?""",
            (tienda_id, categoria_id, producto_id, limite),
        )
    else:
        filas = []
    if len(filas) < limite:
        excluir = [producto_id] + [f["id"] for f in filas]
        marcas = ",".join("?" for _ in excluir)
        filas += all_rows(
            conn,
            f"""SELECT p.*, c.nombre AS categoria_nombre, c.slug AS categoria_slug
                FROM productos p LEFT JOIN categorias c ON c.id=p.categoria_id
                WHERE p.activo=1 AND p.tienda_id=? AND p.id NOT IN ({marcas})
                ORDER BY p.destacado DESC, p.nombre LIMIT ?""",
            [tienda_id] + excluir + [limite - len(filas)],
        )
    return [serializar_publico(f) for f in filas[:limite]]


def listar_publico(
    conn,
    *,
    q: str = "",
    categoria: str = "",
    orden: str = "relevancia",
    pagina: int = 1,
    por_pagina: int = 12,
    solo_disponibles: bool = False,
    tienda_id: str | None,
):
    where = ["p.activo=1", "p.padre_id IS NULL"]
    params: list[Any] = []
    where.append("p.tienda_id=?")
    params.append(tienda_id)
    if q:
        like = f"%{q}%"
        where.append("(p.nombre LIKE ? OR p.descripcion LIKE ? OR p.sku LIKE ? OR p.marca LIKE ?)")
        params += [like, like, like, like]
    if categoria == "promociones":
        where.append("p.promo_activa=1 AND p.promo_stock_restante>0 AND p.stock>0 AND p.promo_fin>?")
        params.append(datetime.now().isoformat(timespec="minutes"))
    elif categoria:
        where.append("c.slug=?")
        params.append(categoria)
    if solo_disponibles:
        where.append("p.stock>0")
    filtro = " AND ".join(where)
    ordenes = {
        "precio_asc": "p.precio ASC",
        "precio_desc": "p.precio DESC",
        "novedad": "p.created_at DESC",
        "nombre": "p.nombre ASC",
        "relevancia": "p.destacado DESC, p.stock>0 DESC, p.nombre ASC",
    }
    orden_sql = ordenes.get(orden, ordenes["relevancia"])
    total = one(
        conn,
        f"""SELECT COUNT(*) AS n FROM productos p
            LEFT JOIN categorias c ON c.id=p.categoria_id WHERE {filtro}""",
        params,
    )["n"]
    pagina = max(1, int(pagina))
    por_pagina = min(48, max(1, int(por_pagina)))
    filas = all_rows(
        conn,
        f"""SELECT p.*, c.nombre AS categoria_nombre, c.slug AS categoria_slug
            FROM productos p LEFT JOIN categorias c ON c.id=p.categoria_id
            WHERE {filtro} ORDER BY {orden_sql} LIMIT ? OFFSET ?""",
        params + [por_pagina, (pagina - 1) * por_pagina],
    )
    items = []
    for f in filas:
        d = serializar_publico(f)
        d["tiene_variantes"] = bool(one(conn, "SELECT id FROM productos WHERE padre_id=? AND activo=1 LIMIT 1", (f["id"],)))
        items.append(d)
    return {
        "items": items,
        "total": int(total),
        "pagina": pagina,
        "paginas": max(1, (int(total) + por_pagina - 1) // por_pagina),
        "por_pagina": por_pagina,
    }
