"""Resolución de la tienda (tenant).

Regla de seguridad (CC_ECOSYSTEM_STANDARD, sección 13):
- En el backoffice (/api/admin/*), la tienda es SIEMPRE la del usuario de la sesión.
  Cabeceras, parámetros y subdominios enviados por el cliente no tienen efecto ahí.
- En la tienda pública, la tienda se resuelve por subdominio, parámetro o cabecera,
  porque el catálogo público es, por definición, público de esa tienda.
- Un recurso solo se opera si pertenece a la tienda autorizada (`exigir`).
"""
from __future__ import annotations

from .db import one
from .util import ApiError

# Tablas con columna tienda_id que el backoffice puede operar por identificador.
TABLAS_TENANT = {"productos", "categorias", "proveedores", "compras", "pedidos"}


def tienda_de_sesion(user: dict | None) -> str:
    """Tienda autorizada para una operación de backoffice. Nunca viene del cliente."""
    tid = (user or {}).get("tienda_id")
    if not tid:
        raise ApiError("Tu usuario no está asociado a ninguna tienda", 403)
    return str(tid)


def exigir(conn, tabla: str, recurso_id: str, tienda_id: str) -> None:
    """Comprueba que el recurso existe y pertenece a la tienda. Si no, 404 (no revela existencia)."""
    if tabla not in TABLAS_TENANT:
        raise ValueError(f"Tabla no gestionada por tenant: {tabla}")
    fila = one(conn, f"SELECT tienda_id FROM {tabla} WHERE id=?", (recurso_id,))
    if not fila or fila["tienda_id"] != tienda_id:
        raise ApiError("No encontrado", 404)


def resolve_tienda_id(conn, headers: dict | None = None, query: dict | None = None) -> str | None:
    """Tienda pública: cabecera, parámetro o subdominio. Sin tienda identificada, devuelve None."""
    headers = headers or {}
    query = query or {}
    for clave in ("x-tienda", "x-tienda-id", "x-cc-tienda"):
        for k, v in headers.items():
            if k.lower() == clave:
                tid = _por_slug_o_id(conn, str(v))
                if tid:
                    return tid
    for clave in ("tienda", "tienda_id", "shop"):
        val = query.get(clave)
        if isinstance(val, (list, tuple)):
            val = val[0] if val else None
        if val:
            tid = _por_slug_o_id(conn, str(val))
            if tid:
                return tid
    host = ""
    for k, v in headers.items():
        if k.lower() == "host":
            host = str(v).split(":")[0]
            break
    if host:
        from .dominios import dominio_activo

        tid = dominio_activo(conn, host)  # dominio propio con complemento activo y DNS verificado
        if tid:
            return tid
    if host and "." in host:
        slug = host.split(".")[0]
        if slug and slug not in {"www", "api", "app"}:
            tid = _por_slug_o_id(conn, slug)
            if tid:
                return tid
    return None


def _por_slug_o_id(conn, valor: str) -> str | None:
    fila = one(conn, "SELECT id FROM tiendas WHERE (slug=? OR id=?) AND estado<>'suspendida'", (valor, valor))
    return str(fila["id"]) if fila else None


def tienda_actual(conn, headers=None, query=None) -> dict | None:
    tid = resolve_tienda_id(conn, headers, query)
    if not tid:
        return None
    fila = one(conn, "SELECT * FROM tiendas WHERE id=?", (tid,))
    return dict(fila) if fila else None
