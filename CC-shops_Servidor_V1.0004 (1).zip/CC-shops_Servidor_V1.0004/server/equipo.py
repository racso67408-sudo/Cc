"""Equipo de cada tienda: alta, cambio de rol y desactivación. Límite de administradores por tienda."""
from __future__ import annotations

import re

from . import auth, db
from .db import all_rows, one
from .roles import ROLES_EQUIPO, normalizar
from .util import ApiError, iso_now, new_id, txt

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def _max_admins(conn, tienda_id: str) -> int:
    fila = one(conn, "SELECT max_admins FROM tiendas WHERE id=?", (tienda_id,))
    return int(fila["max_admins"]) if fila and fila["max_admins"] is not None else 3


def _admins_activos(conn, tienda_id: str, excepto: str | None = None) -> int:
    filas = all_rows(conn, "SELECT id, rol FROM usuarios WHERE tienda_id=? AND activo=1", (tienda_id,))
    return sum(1 for f in filas if normalizar(f["rol"]) == "admin" and f["id"] != excepto)


def listar(conn, tienda_id: str) -> dict:
    filas = all_rows(
        conn,
        """SELECT id, nombre, email, rol, activo, ultimo_acceso FROM usuarios
           WHERE tienda_id=? AND rol<>'cliente' ORDER BY created_at""",
        (tienda_id,),
    )
    items = []
    for f in filas:
        d = dict(f)
        d["rol"] = normalizar(d["rol"])
        d["activo"] = bool(d["activo"])
        items.append(d)
    return {
        "items": items,
        "max_admins": _max_admins(conn, tienda_id),
        "admins_activos": _admins_activos(conn, tienda_id),
    }


def _validar_rol(rol: str) -> str:
    rol = normalizar(txt(rol, 20))
    if rol not in ROLES_EQUIPO:
        raise ApiError("El rol no es válido", 400, "rol")
    return rol


def crear(conn, tienda_id: str, datos: dict, actor_id: str | None = None) -> dict:
    nombre = txt(datos.get("nombre"), 120)
    if len(nombre) < 2:
        raise ApiError("El nombre es obligatorio", 400, "nombre")
    email = txt(datos.get("email"), 160).lower()
    if not EMAIL_RE.match(email):
        raise ApiError("El email no es válido", 400, "email")
    if one(conn, "SELECT id FROM usuarios WHERE email=?", (email,)):
        raise ApiError("Ya existe una cuenta con ese email", 409, "email")
    rol = _validar_rol(datos.get("rol"))
    password = str(datos.get("password") or "")
    problema = auth.password_problem(password)
    if problema:
        raise ApiError(problema, 400, "password")
    if rol == "admin" and _admins_activos(conn, tienda_id) >= _max_admins(conn, tienda_id):
        raise ApiError("La tienda ya tiene el máximo de administradores. Pide al superadmin que lo amplíe.", 409, "rol")
    uid = new_id("USR")
    sello = iso_now()
    conn.execute(
        "INSERT INTO usuarios (id, nombre, email, password_hash, rol, tienda_id, activo, session_version, ultimo_acceso, created_at) "
        "VALUES (?,?,?,?,?,?,1,0,'',?)",
        (uid, nombre, email, auth.hash_password(password), rol, tienda_id, sello),
    )
    db.audit(conn, actor_id, "equipo.alta", "usuario", uid, {"rol": rol})
    return {"id": uid, "nombre": nombre, "email": email, "rol": rol, "activo": True}


def actualizar(conn, tienda_id: str, uid: str, datos: dict, actor_id: str | None = None) -> dict:
    fila = one(conn, "SELECT * FROM usuarios WHERE id=? AND tienda_id=? AND rol<>'cliente'", (uid, tienda_id))
    if not fila:
        raise ApiError("Usuario no encontrado", 404)
    rol_actual = normalizar(fila["rol"])
    rol = _validar_rol(datos["rol"]) if "rol" in datos else rol_actual
    activo = bool(datos["activo"]) if "activo" in datos else bool(fila["activo"])
    nombre = txt(datos.get("nombre", fila["nombre"]), 120)
    if len(nombre) < 2:
        raise ApiError("El nombre es obligatorio", 400, "nombre")
    era_admin_activo = rol_actual == "admin" and bool(fila["activo"])
    sera_admin_activo = rol == "admin" and activo
    if era_admin_activo and not sera_admin_activo and _admins_activos(conn, tienda_id, excepto=uid) < 1:
        raise ApiError("Debe quedar al menos un administrador activo en la tienda", 409, "rol")
    if sera_admin_activo and not era_admin_activo and _admins_activos(conn, tienda_id) >= _max_admins(conn, tienda_id):
        raise ApiError("La tienda ya tiene el máximo de administradores. Pide al superadmin que lo amplíe.", 409, "rol")
    password_hash = fila["password_hash"]
    version = int(fila["session_version"])
    if datos.get("password"):
        problema = auth.password_problem(str(datos["password"]))
        if problema:
            raise ApiError(problema, 400, "password")
        password_hash = auth.hash_password(str(datos["password"]))
        version += 1
    conn.execute(
        "UPDATE usuarios SET nombre=?, rol=?, activo=?, password_hash=?, session_version=? WHERE id=?",
        (nombre, rol, 1 if activo else 0, password_hash, version, uid),
    )
    db.audit(conn, actor_id, "equipo.cambio", "usuario", uid, {"rol": rol, "activo": activo})
    return {"id": uid, "nombre": nombre, "email": fila["email"], "rol": rol, "activo": activo}


def fijar_limite(conn, tienda_id: str, maximo: int, actor_id: str | None = None) -> dict:
    try:
        valor = int(maximo)
    except (TypeError, ValueError):
        raise ApiError("El límite debe ser un número", 400, "max_admins")
    if valor < 1 or valor > 20:
        raise ApiError("El límite debe estar entre 1 y 20 administradores", 400, "max_admins")
    if not one(conn, "SELECT id FROM tiendas WHERE id=?", (tienda_id,)):
        raise ApiError("Tienda no encontrada", 404)
    if _admins_activos(conn, tienda_id) > valor:
        raise ApiError("La tienda tiene más administradores activos que el límite indicado", 409, "max_admins")
    conn.execute("UPDATE tiendas SET max_admins=? WHERE id=?", (valor, tienda_id))
    db.audit(conn, actor_id, "tienda.limite_admins", "tienda", tienda_id, {"max_admins": valor})
    return {"id": tienda_id, "max_admins": valor}
