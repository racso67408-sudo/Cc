"""Correo saliente de la plataforma.

La configuración la define el superadmin de CC Shops (tabla plataforma_config):
remitente, servidor SMTP, puerto, usuario, contraseña y TLS. Las variables de entorno
CC_SMTP_* y CC_CORREO_REMITENTE solo sirven de respaldo si no hay nada guardado.
Sin servidor configurado el envío se registra como «simulado» (desarrollo).
"""
from __future__ import annotations

import os
import re
import smtplib
import sys
from email.message import EmailMessage

from . import db
from .util import ApiError, iso_now

SIMULADOS: list[dict] = []  # memoria de los envíos simulados (pruebas y depuración)
CLAVES = ("correo_remitente", "smtp_host", "smtp_port", "smtp_usuario", "smtp_password", "smtp_tls")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def _leer_guardado() -> dict:
    with db.session() as conn:
        filas = conn.execute("SELECT clave, valor FROM plataforma_config").fetchall()
    return {f["clave"]: f["valor"] for f in filas}


def config_efectiva() -> dict:
    guardado = _leer_guardado()
    return {
        "correo_remitente": guardado.get("correo_remitente") or os.environ.get("CC_CORREO_REMITENTE", "CC Shops <no-reply@ccshops.es>"),
        "smtp_host": guardado.get("smtp_host") or os.environ.get("CC_SMTP_HOST", ""),
        "smtp_port": int(guardado.get("smtp_port") or os.environ.get("CC_SMTP_PORT", "587") or 587),
        "smtp_usuario": guardado.get("smtp_usuario") or os.environ.get("CC_SMTP_USER", ""),
        "smtp_password": guardado.get("smtp_password") or os.environ.get("CC_SMTP_PASSWORD", ""),
        "smtp_tls": (guardado.get("smtp_tls") or os.environ.get("CC_SMTP_TLS", "1")) == "1",
    }


def configuracion_publica() -> dict:
    cfg = config_efectiva()
    return {
        "correo_remitente": cfg["correo_remitente"],
        "smtp_host": cfg["smtp_host"],
        "smtp_port": cfg["smtp_port"],
        "smtp_usuario": cfg["smtp_usuario"],
        "smtp_password_configurada": bool(cfg["smtp_password"]),
        "smtp_tls": cfg["smtp_tls"],
        "configurado": bool(cfg["smtp_host"]),
    }


def guardar(conn, datos: dict, actor_id: str | None = None) -> dict:
    """Guarda la configuración. La contraseña solo cambia si se envía una nueva."""
    remitente = str(datos.get("correo_remitente") or "").strip()
    direccion = re.search(r"<([^>]+)>", remitente)
    solo = direccion.group(1) if direccion else remitente
    if not EMAIL_RE.match(solo):
        raise ApiError("El remitente debe ser una dirección de correo válida", 400, "correo_remitente")
    try:
        puerto = int(datos.get("smtp_port") or 587)
    except (TypeError, ValueError):
        raise ApiError("El puerto debe ser un número", 400, "smtp_port")
    if not 1 <= puerto <= 65535:
        raise ApiError("El puerto debe estar entre 1 y 65535", 400, "smtp_port")
    valores = {
        "correo_remitente": remitente,
        "smtp_host": str(datos.get("smtp_host") or "").strip()[:200],
        "smtp_port": str(puerto),
        "smtp_usuario": str(datos.get("smtp_usuario") or "").strip()[:200],
        "smtp_tls": "1" if str(datos.get("smtp_tls", "1")) in {"1", "true", "True"} else "0",
    }
    if datos.get("smtp_password"):
        valores["smtp_password"] = str(datos["smtp_password"])[:300]
    sello = iso_now()
    for clave, valor in valores.items():
        conn.execute(
            "INSERT INTO plataforma_config (clave, valor, updated_at) VALUES (?,?,?) "
            "ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor, updated_at=excluded.updated_at",
            (clave, valor, sello),
        )
    db.audit(conn, actor_id, "plataforma.correo_configurado", "plataforma", "correo", {"servidor": valores["smtp_host"], "remitente": solo})
    return configuracion_publica()


def enviar(destinatario: str, asunto: str, cuerpo: str, responder_a: str | None = None) -> str:
    """«enviado» o «simulado». Lanza excepción si el servidor falla (el mensaje de error es el real)."""
    cfg = config_efectiva()
    mensaje = EmailMessage()
    mensaje["From"] = cfg["correo_remitente"]
    mensaje["To"] = destinatario
    mensaje["Subject"] = asunto
    if responder_a:
        mensaje["Reply-To"] = responder_a
    mensaje.set_content(cuerpo)
    if not cfg["smtp_host"]:
        SIMULADOS.append({"to": destinatario, "subject": asunto, "reply_to": responder_a, "body": cuerpo})
        print(f"[CC-Shops] Correo simulado a {destinatario}: {asunto}", file=sys.stderr)
        return "simulado"
    with smtplib.SMTP(cfg["smtp_host"], cfg["smtp_port"], timeout=20) as smtp:
        if cfg["smtp_tls"]:
            smtp.starttls()
        if cfg["smtp_usuario"]:
            smtp.login(cfg["smtp_usuario"], cfg["smtp_password"])
        smtp.send_message(mensaje)
    return "enviado"
