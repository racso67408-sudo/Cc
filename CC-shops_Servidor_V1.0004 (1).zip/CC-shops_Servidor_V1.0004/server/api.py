"""Router JSON de CC-Shops."""
from __future__ import annotations

import json
import re
import traceback
from typing import Any

from . import auth, catalog, config, db, kardex, metrics, orders, purchases, ratelimit, tiendas
from .db import all_rows, one
from .util import (
    ApiError,
    EMAIL_RE,
    biz_today,
    iso_now,
    new_id,
    money,
    num,
    parse_date,
    txt,
)

PUBLIC_PRODUCTO_RE = re.compile(r"^/api/public/productos/([^/]+)$")
PUBLIC_PEDIDO_RE = re.compile(r"^/api/public/pedidos/([^/]+)$")
PRODUCTO_RE = re.compile(r"^/api/admin/productos/([^/]+)$")
PRODUCTO_KARDEX_RE = re.compile(r"^/api/admin/productos/([^/]+)/kardex$")
PRODUCTO_AJUSTE_RE = re.compile(r"^/api/admin/productos/([^/]+)/ajuste$")
PRODUCTO_VERIFICAR_RE = re.compile(r"^/api/admin/productos/([^/]+)/verificar$")
CATEGORIA_RE = re.compile(r"^/api/admin/categorias/([^/]+)$")
PROVEEDOR_RE = re.compile(r"^/api/admin/proveedores/([^/]+)$")
COMPRA_RE = re.compile(r"^/api/admin/compras/([^/]+)$")
COMPRA_ACCION_RE = re.compile(r"^/api/admin/compras/([^/]+)/(recibir|anular)$")
PEDIDO_RE = re.compile(r"^/api/admin/pedidos/([^/]+)$")
PEDIDO_ACCION_RE = re.compile(r"^/api/admin/pedidos/([^/]+)/(estado|cancelar)$")
PEDIDO_CHAT_RE = re.compile(r"^/api/admin/pedidos/([^/]+)/chat$")
PEDIDO_PAGO_RE = re.compile(r"^/api/admin/pedidos/([^/]+)/(verificar-pago|confirmar-cobro|verificar-envio)$")
PEDIDO_ENVIO_RE = re.compile(r"^/api/admin/pedidos/([^/]+)/envio$")
EQUIPO_RE = re.compile(r"^/api/admin/equipo/([^/]+)$")

# Recursos que el backoffice opera por identificador: se comprueba que pertenecen a la tienda.
_RECURSOS_ADMIN = [
    (PRODUCTO_RE, "productos"),
    (PRODUCTO_KARDEX_RE, "productos"),
    (PRODUCTO_AJUSTE_RE, "productos"),
    (PRODUCTO_VERIFICAR_RE, "productos"),
    (CATEGORIA_RE, "categorias"),
    (PROVEEDOR_RE, "proveedores"),
    (COMPRA_RE, "compras"),
    (COMPRA_ACCION_RE, "compras"),
    (PEDIDO_RE, "pedidos"),
    (PEDIDO_ACCION_RE, "pedidos"),
    (PEDIDO_CHAT_RE, "pedidos"),
    (PEDIDO_PAGO_RE, "pedidos"),
    (PEDIDO_ENVIO_RE, "pedidos"),
]


def _exigir_recurso_admin(path: str, tienda_id: str) -> None:
    from . import tenant
    for regex, tabla in _RECURSOS_ADMIN:
        m = regex.match(path)
        if m:
            with db.session() as conn:
                tenant.exigir(conn, tabla, m.group(1), tienda_id)
            return


class Response:
    def __init__(self, status: int = 200, payload: Any = None, headers: dict | None = None):
        self.status = status
        self.payload = payload
        self.headers = headers or {}


def _header(headers: dict, nombre: str, defecto: str = "") -> str:
    if not headers:
        return defecto
    for clave, valor in headers.items():
        if clave.lower() == nombre.lower():
            return str(valor)
    return defecto


def _q(query: dict | None, clave: str, defecto: str = "") -> str:
    if not query:
        return defecto
    valor = query.get(clave, defecto)
    if isinstance(valor, (list, tuple)):
        return str(valor[0]) if valor else defecto
    return str(valor) if valor is not None else defecto


def _ip(headers: dict) -> str:
    return _header(headers, "x-cc-client-ip") or "127.0.0.1"


def _csrf(method: str, headers: dict) -> None:
    if method not in {"POST", "PUT", "DELETE", "PATCH"}:
        return
    if _header(headers, "x-cc-request") != "1":
        raise ApiError("Petición no autorizada", 403)


def _usuario(headers: dict) -> dict:
    user = auth.current_user(headers)
    if not user:
        raise ApiError("Tu sesión ha caducado. Vuelve a iniciar sesión.", 401)
    return user


def permitidos_domiciliario(user: dict) -> bool:
    return user.get("rol") == "domiciliario"


def _solo_admin(user: dict) -> None:
    if user.get("rol") != "admin":
        raise ApiError("Solo el administrador puede realizar esta acción", 403)


def _body_lista(value, campo: str) -> list:
    if value is None:
        return []
    if not isinstance(value, list):
        raise ApiError(f"{campo} debe ser una lista")
    return value


_ultimo_mantenimiento = [0.0]


def _mantenimiento() -> None:
    """Cancela pedidos sin pago vencidos. Se ejecuta como mucho una vez por minuto."""
    import time as _time

    ahora = _time.time()
    if ahora - _ultimo_mantenimiento[0] < 60:
        return
    _ultimo_mantenimiento[0] = ahora
    try:
        with db.session(write=True) as conn:
            orders.procesar_vencimientos(conn)
    except Exception:
        traceback.print_exc()


def dispatch(method: str, path: str, query: dict | None, body: dict | None, headers: dict | None) -> Response:
    headers = headers or {}
    body = body if isinstance(body, dict) else {}
    _mantenimiento()
    try:
        _csrf(method, headers)
        path = path.rstrip("/") or "/"
        if path == "/api/health" and method == "GET":
            return Response(200, {"ok": True, "app": "CC-Shops", "hora": iso_now(), "db": db.db_stats()})
        if path.startswith("/api/public/"):
            return _public(method, path, query, body, headers)
        if path.startswith("/api/auth/"):
            return _auth(method, path, body, headers)
        if path.startswith("/api/admin/"):
            user = _usuario(headers)
            return _admin(method, path, query, body, headers, user)
        if path.startswith("/api/cliente/"):
            user = _usuario(headers)
            return _cliente(method, path, query, body, headers, user)
        if path.startswith("/api/superadmin/"):
            user = _usuario(headers)
            if user.get("rol") != "superadmin":
                raise ApiError("Acceso reservado al SuperAdmin", 403)
            return _superadmin(method, path, query, body, headers, user)
        raise ApiError("Ruta no encontrada", 404)
    except ApiError as exc:
        payload = {"error": exc.mensaje}
        if exc.campo:
            payload["campo"] = exc.campo
        return Response(exc.status, payload)
    except Exception:
        traceback.print_exc()
        return Response(500, {"error": "Ha ocurrido un error interno. Inténtalo de nuevo."})


# ----------------------------------------------------------------------
# Tienda pública


def _public(method: str, path: str, query: dict | None, body: dict, headers: dict) -> Response:
    from . import tenant
    if path not in ("/api/public/pagos-web/confirmacion", "/api/public/dominio-permitido"):  # no dependen de una tienda
        with db.session() as conn:
            if tenant.resolve_tienda_id(conn, headers, query) is None:
                raise ApiError("Tienda no encontrada", 404)

    if method == "GET" and path == "/api/public/config":
        with db.session() as conn:
            from . import tenant
            tid = tenant.resolve_tienda_id(conn, headers, query)
            ajustes = db.settings_all(conn, tid)
            email_tienda = tiendas.email_de_contacto(conn, tid) if tid else ""
            categorias = catalog.listar_categorias(conn, publico=True, tienda_id=tid)
            destacados = catalog.listar_publico(conn, orden="relevancia", por_pagina=4, tienda_id=tid)["items"]
            total = one(conn, "SELECT COUNT(*) AS n FROM productos WHERE activo=1 AND tienda_id=?", (tid,))["n"]
        return Response(
            200,
            {
                "tienda": {
                    "nombre": ajustes.get("tienda_nombre"),
                    "claim": ajustes.get("tienda_claim"),
                    "email": email_tienda,
                    "telefono": ajustes.get("tienda_telefono"),
                    "direccion": ajustes.get("tienda_direccion"),
                    "aviso_pago": ajustes.get("aviso_pago"),
                    "moneda": ajustes.get("moneda", "EUR"),
                    "tema": ajustes.get("tema_tienda", "clasico"),
                    "pago_iban": ajustes.get("pago_iban", ""),
                    "pago_web_activo": ajustes.get("pago_web_activo", "0") == "1",
                    "pago_plazo_horas": int(float(ajustes.get("pago_plazo_horas", "8") or 8)),
                    "aviso_plazo_pago": (ajustes.get("aviso_plazo_pago", "") or "").replace("{horas}", str(int(float(ajustes.get("pago_plazo_horas", "8") or 8)))),
                    "pago_cartera": ajustes.get("pago_cartera", ""),
                },
                "envio": {
                    "aviso": (ajustes.get("aviso_envio", "") or "").replace("{tienda}", ajustes.get("tienda_nombre", "")),
                    "recargo_contrareembolso": money(ajustes.get("recargo_contrareembolso", 0)),
                },
                "categorias": categorias,
                "destacados": destacados,
                "total_productos": int(total),
            },
        )

    if method == "GET" and path == "/api/public/categorias":
        with db.session() as conn:
            from . import tenant
            tid = tenant.resolve_tienda_id(conn, headers, query)
            return Response(200, {"items": catalog.listar_categorias(conn, publico=True, tienda_id=tid)})

    if method == "GET" and path == "/api/public/productos":
        solo = _q(query, "disponibles") in {"1", "true", "si"}
        with db.session() as conn:
            from . import tenant
            tid = tenant.resolve_tienda_id(conn, headers, query)
            datos = catalog.listar_publico(
                conn,
                q=txt(_q(query, "q"), 80),
                categoria=txt(_q(query, "categoria"), 80),
                orden=_q(query, "orden", "relevancia"),
                pagina=int(num(_q(query, "pagina", "1") or 1, "La página", 1, 10000)),
                por_pagina=int(num(_q(query, "por_pagina", "12") or 12, "El tamaño", 1, 48)),
                solo_disponibles=solo,
                tienda_id=tid,
            )
        return Response(200, datos)

    match = PUBLIC_PRODUCTO_RE.match(path)
    if match and method == "GET":
        with db.session() as conn:
            from . import tenant
            tid = tenant.resolve_tienda_id(conn, headers, query)
            return Response(200, catalog.producto_por_slug(conn, match.group(1), tid))

    if method == "GET" and path == "/api/public/dominio-permitido":
        from . import dominios as _dom

        with db.session() as conn:
            # El servidor HTTPS (Caddy) envía «domain»; se acepta también «dominio».
            if _dom.dominio_activo(conn, _q(query, "domain") or _q(query, "dominio")):
                return Response(200, {"ok": True})
        raise ApiError("Dominio no activo", 404)

    if method == "POST" and path == "/api/public/contacto":
        from . import correo as _correo
        from . import tiendas as _tiendas

        if body.get("website"):  # campo trampa: los robots lo rellenan
            return Response(200, {"ok": True})
        ip = _ip(headers)
        if not ratelimit.contacto_permitido(ip):
            raise ApiError("Has enviado demasiados mensajes. Inténtalo más tarde.", 429)
        nombre = txt(body.get("nombre"), 100)
        email = txt(body.get("email"), 160).lower()
        empresa = txt(body.get("empresa"), 100)
        mensaje = txt(body.get("mensaje"), 2000)
        if len(nombre) < 2:
            raise ApiError("Indica tu nombre", 400, "nombre")
        if not EMAIL_RE.match(email):
            raise ApiError("El email no es válido", 400, "email")
        if len(mensaje) < 10:
            raise ApiError("Cuéntanos un poco más en el mensaje", 400, "mensaje")
        with db.session(write=True) as conn:
            tid = tenant.resolve_tienda_id(conn, headers, query)
            if not tid:
                raise ApiError("Tienda no encontrada", 404)
            tienda = one(conn, "SELECT nombre FROM tiendas WHERE id=?", (tid,))
            destinatario = _tiendas.email_de_contacto(conn, tid)
            if not destinatario:
                raise ApiError("Esta tienda aún no puede recibir mensajes", 409)
            mid = new_id("MSG")
            conn.execute(
                "INSERT INTO mensajes_contacto (id, tienda_id, nombre, email, empresa, mensaje, destinatario, estado, created_at) "
                "VALUES (?,?,?,?,?,?,?,?,?)",
                (mid, tid, nombre, email, empresa, mensaje, destinatario, "pendiente", iso_now()),
            )
        cuerpo = (
            f"Nuevo mensaje desde la web de {tienda['nombre']}\n\n"
            f"Nombre: {nombre}\nEmail: {email}\nEmpresa: {empresa or '-'}\n\n{mensaje}\n\n"
            "Responde directamente a este correo para contestar al cliente."
        )
        try:
            estado = _correo.enviar(destinatario, f"[Web] Mensaje de {nombre} · {tienda['nombre']}", cuerpo, responder_a=email)
        except Exception:
            traceback.print_exc()
            estado = "error"
        with db.session(write=True) as conn:
            conn.execute("UPDATE mensajes_contacto SET estado=? WHERE id=?", (estado, mid))
        if estado == "error":
            raise ApiError("No hemos podido enviar el mensaje ahora mismo. Inténtalo más tarde.", 503)
        return Response(200, {"ok": True})

    if method == "POST" and path == "/api/public/pagos-web/confirmacion":
        # Confirmación de cobro desde la pasarela de la otra instancia. Firmada con CC_PAGOS_WEBHOOK_SECRET.
        import hashlib
        import hmac as _hmac
        import json as _json
        import os as _os

        secreto = _os.environ.get("CC_PAGOS_WEBHOOK_SECRET", "").strip()
        if not secreto:
            raise ApiError("Ruta no encontrada", 404)
        cuerpo = _json.dumps(body, sort_keys=True, separators=(",", ":")).encode("utf-8")
        firma_esperada = _hmac.new(secreto.encode("utf-8"), cuerpo, hashlib.sha256).hexdigest()
        if not _hmac.compare_digest(_header(headers, "x-cc-firma"), firma_esperada):
            raise ApiError("Firma no válida", 401)
        from . import orders as _orders

        with db.session(write=True) as conn:
            resultado = _orders.confirmar_pago_web(conn, txt(body.get("numero"), 40), txt(body.get("referencia"), 60))
        return Response(200, resultado)

    if method == "POST" and path == "/api/public/pedidos":
        ip = _ip(headers)
        if not ratelimit.pedido_permitido(ip):
            raise ApiError("Demasiados pedidos desde esta conexión. Inténtalo más tarde.", 429)
        user = auth.current_user(headers)
        with db.session(write=True) as conn:
            from . import tenant
            tid = tenant.resolve_tienda_id(conn, headers, query)
            if not tid:
                raise ApiError("Tienda no encontrada", 404)
            pedido = orders.crear_pedido(conn, body, ip=ip, usuario_id=(user["id"] if user else None), tienda_id=tid)
            aviso = None
            if not user:  # compra como invitado: se crea la cuenta del cliente
                from . import clientes as _clientes

                datos_cliente = body.get("cliente") or {}
                aviso = _clientes.preparar_cuenta_compra(conn, tid, pedido["id"], txt(datos_cliente.get("nombre"), 120), txt(datos_cliente.get("email"), 160))
        from . import clientes as _clientes
        _clientes.enviar_aviso(aviso)
        return Response(201, pedido)

    match = PUBLIC_PEDIDO_RE.match(path)
    if match and method == "GET":
        token = _q(query, "t")
        with db.session() as conn:
            return Response(200, orders.pedido_publico(conn, match.group(1), token))

    raise ApiError("Ruta no encontrada", 404)


# ----------------------------------------------------------------------
# Autenticación


def _auth(method: str, path: str, body: dict, headers: dict) -> Response:
    from . import clientes as _clientes

    if path == "/api/auth/activar" and method == "POST":
        with db.session(write=True) as conn:
            _clientes.activar(conn, txt(body.get("token"), 200), str(body.get("password") or ""))
        return Response(200, {"ok": True})
    if path == "/api/auth/reenviar-activacion" and method == "POST":
        from . import tenant

        aviso = None
        if ratelimit.contacto_permitido(_ip(headers)):
            with db.session(write=True) as conn:
                tid = tenant.resolve_tienda_id(conn, headers, {})
                if tid:
                    aviso = _clientes.reenviar_activacion(conn, tid, txt(body.get("email"), 160))
        _clientes.enviar_aviso(aviso)
        return Response(200, {"ok": True})  # siempre igual: no revela si el correo tiene cuenta

    if path == "/api/auth/me" and method == "GET":
        user = auth.current_user(headers)
        return Response(200, {"autenticado": bool(user), "usuario": user})

    if path == "/api/auth/register" and method == "POST":
        email = txt(body.get("email"), 160).lower()
        nombre = txt(body.get("nombre"), 120)
        password = str(body.get("password") or "")
        if len(nombre) < 2:
            raise ApiError("El nombre es obligatorio", 400, "nombre")
        if not EMAIL_RE.match(email):
            raise ApiError("El email no es válido", 400, "email")
        problema = auth.password_problem(password)
        if problema:
            raise ApiError(problema, 400, "password")
        with db.session(write=True) as conn:
            if one(conn, "SELECT id FROM usuarios WHERE email=?", (email,)):
                raise ApiError("Ya existe una cuenta con ese email", 409, "email")
            uid = new_id("USR")
            conn.execute(
                "INSERT INTO usuarios (id, nombre, email, password_hash, rol, activo, session_version, ultimo_acceso, created_at) VALUES (?,?,?,?, 'cliente', 1, 0, '', ?)",
                (uid, nombre, email, auth.hash_password(password), iso_now()),
            )
            db.audit(conn, uid, "auth.registro", "usuario", uid, {"email": email}, _ip(headers))
            sello = iso_now()
            conn.execute("UPDATE usuarios SET ultimo_acceso=? WHERE id=?", (sello, uid))
            user = {"id": uid, "nombre": nombre, "email": email, "rol": "cliente", "ultimo_acceso": sello}
            cookie = auth.session_cookie(uid, 0)
        return Response(201, {"usuario": user}, {"Set-Cookie": cookie})

    if path == "/api/auth/login" and method == "POST":
        ip = _ip(headers)
        if not ratelimit.login_permitido(ip):
            raise ApiError("Demasiados intentos. Espera unos minutos antes de volver a probar.", 429)
        email = txt(body.get("email"), 160).lower()
        password = str(body.get("password") or "")
        with db.session(write=True) as conn:
            fila = one(conn, "SELECT * FROM usuarios WHERE email=?", (email,))
            if not fila or not int(fila["activo"]) or not auth.verify_password(password, fila["password_hash"]):
                db.audit(conn, None, "auth.login_fallido", "usuario", "", {"email": email}, ip)
                raise ApiError("Email o contraseña incorrectos", 401)
            sello = iso_now()
            conn.execute("UPDATE usuarios SET ultimo_acceso=? WHERE id=?", (sello, fila["id"]))
            db.audit(conn, fila["id"], "auth.login", "usuario", fila["id"], {}, ip)
            user = {
                "id": fila["id"],
                "nombre": fila["nombre"],
                "email": fila["email"],
                "rol": fila["rol"],
                "ultimo_acceso": sello,
            }
            cookie = auth.session_cookie(fila["id"], int(fila["session_version"]))
        return Response(200, {"usuario": user}, {"Set-Cookie": cookie})

    if path == "/api/auth/registrar-tienda" and method == "POST":
        ip = _ip(headers)
        if not ratelimit.registro_tienda_permitido(ip):
            raise ApiError("Demasiados intentos. Inténtalo más tarde.", 429)
        from . import tiendas

        with db.session(write=True) as conn:
            resultado = tiendas.registrar_tienda(conn, body, ip)
        cookie = auth.session_cookie(resultado["usuario"]["id"], 0)
        return Response(201, resultado, {"Set-Cookie": cookie})

    if path == "/api/auth/logout" and method == "POST":
        user = auth.current_user(headers)
        if user:
            with db.session(write=True) as conn:
                db.audit(conn, user["id"], "auth.logout", "usuario", user["id"], {}, _ip(headers))
        return Response(200, {"ok": True}, {"Set-Cookie": auth.clear_cookie()})

    if path == "/api/auth/password" and method == "POST":
        user = _usuario(headers)
        actual = str(body.get("actual") or "")
        nueva = str(body.get("nueva") or "")
        problema = auth.password_problem(nueva)
        if problema:
            raise ApiError(problema, 400, "nueva")
        with db.session(write=True) as conn:
            fila = one(conn, "SELECT * FROM usuarios WHERE id=?", (user["id"],))
            if not fila or not auth.verify_password(actual, fila["password_hash"]):
                raise ApiError("La contraseña actual no es correcta", 400, "actual")
            if auth.verify_password(nueva, fila["password_hash"]):
                raise ApiError("La nueva contraseña debe ser distinta de la actual", 400, "nueva")
            version = int(fila["session_version"]) + 1
            conn.execute(
                "UPDATE usuarios SET password_hash=?, session_version=? WHERE id=?",
                (auth.hash_password(nueva), version, user["id"]),
            )
            db.audit(conn, user["id"], "auth.password", "usuario", user["id"], {}, _ip(headers))
            cookie = auth.session_cookie(user["id"], version)
        return Response(200, {"ok": True}, {"Set-Cookie": cookie})

    raise ApiError("Ruta no encontrada", 404)


# ----------------------------------------------------------------------
# Backoffice


def _admin(method: str, path: str, query: dict | None, body: dict, headers: dict, user: dict) -> Response:
    from . import roles, tenant
    tid_admin = tenant.tienda_de_sesion(user)
    roles.autorizar(user.get("rol", ""), method, path)
    with db.session() as _c:
        fila_estado = one(_c, "SELECT estado FROM tiendas WHERE id=?", (tid_admin,))
    if fila_estado and fila_estado["estado"] == "suspendida":
        raise ApiError("Esta tienda está suspendida. Contacta con CC Shops.", 403)
    _exigir_recurso_admin(path, tid_admin)

    if method == "GET" and path == "/api/admin/dashboard":
        dias = int(num(_q(query, "dias", "14") or 14, "Los días", 7, 90))
        with db.session() as conn:
            return Response(200, metrics.dashboard(conn, dias, tid=tid_admin))

    if method == "GET" and path == "/api/admin/metricas":
        with db.session() as conn:
            return Response(
                200,
                metrics.metricas(
                    conn,
                    desde=_q(query, "desde") or None,
                    hasta=_q(query, "hasta") or None,
                    dias=int(num(_q(query, "dias", "30") or 30, "Los días", 1, 730)),
                    tid=tid_admin,
                ),
            )

    if method == "GET" and path == "/api/admin/inventario":
        with db.session() as conn:
            resumen = metrics.inventario(conn, tid_admin)
            bajo = kardex.bajo_minimo(conn, 30, tienda_id=tid_admin)
            ultimos = kardex.ultimos(conn, 10, tienda_id=tid_admin)
            categorias = catalog.listar_categorias(conn, publico=False, tienda_id=tid_admin)
        return Response(
            200,
            {"resumen": resumen, "bajo_stock": bajo, "ultimos": ultimos, "categorias": categorias},
        )

    if method == "GET" and path == "/api/admin/movimientos":
        with db.session() as conn:
            items, total = kardex.listar_global(
                conn,
                tienda_id=tid_admin,
                producto_id=_q(query, "producto_id"),
                tipo=_q(query, "tipo"),
                desde=_q(query, "desde"),
                hasta=_q(query, "hasta"),
                pagina=int(num(_q(query, "pagina", "1") or 1, "La página", 1, 10000)),
                por_pagina=int(num(_q(query, "por_pagina", "50") or 50, "El tamaño", 1, 200)),
            )
        for item in items:
            item["tipo_label"] = kardex.etiqueta(item["tipo"])
        return Response(200, {"items": items, "total": total})

    if path == "/api/admin/dominio" and method == "GET":
        from . import dominios as _dom

        with db.session() as conn:
            return Response(200, _dom.vista(conn, tid_admin))
    if path in ("/api/admin/dominio/configurar", "/api/admin/dominio/verificar", "/api/admin/dominio/cancelar") and method == "POST":
        from . import dominios as _dom

        with db.session(write=True) as conn:
            if path.endswith("configurar"):
                return Response(200, _dom.configurar(conn, tid_admin, txt(body.get("modo"), 20), txt(body.get("dominio"), 200), user["id"]))
            if path.endswith("verificar"):
                return Response(200, _dom.verificar(conn, tid_admin, user["id"]))
            return Response(200, _dom.cancelar(conn, tid_admin, user["id"]))

    if path.startswith("/api/admin/soporte"):
        return _soporte_tienda(method, path, query, body, user, tid_admin)

    match = re.match(r"^/api/admin/productos/([^/]+)/variantes$", path)
    if match and method == "POST":
        from . import catalog as _cat

        with db.session(write=True) as conn:
            return Response(201, {"producto": _cat.crear_variante(conn, match.group(1), body, user["id"], tid_admin)})
    match = re.match(r"^/api/admin/productos/([^/]+)/variantes/([^/]+)$", path)
    if match and method == "PUT":
        from . import catalog as _cat

        with db.session(write=True) as conn:
            return Response(200, {"producto": _cat.actualizar_variante_activa(conn, match.group(2), bool(body.get("activa")), user["id"], tid_admin)})

    if method == "GET" and path == "/api/admin/clientes":
        from . import clientes as _clientes

        with db.session() as conn:
            return Response(200, {"items": _clientes.listar(conn, tid_admin)})
    match = re.match(r"^/api/admin/clientes/(.+)$", path)
    if match and method == "GET":
        from urllib.parse import unquote
        from . import clientes as _clientes

        with db.session() as conn:
            return Response(200, _clientes.detalle(conn, tid_admin, unquote(match.group(1))))

    if method == "GET" and path == "/api/admin/marcas":
        with db.session() as conn:
            return Response(200, {"items": catalog.marcas(conn, tid_admin)})

    if method == "GET" and path == "/api/admin/ruta":
        with db.session() as conn:
            from . import orders as _orders

            return Response(200, _orders.listar_ruta(conn, tid_admin))

    if path == "/api/admin/equipo":
        from . import equipo as _equipo

        if method == "GET":
            with db.session() as conn:
                return Response(200, _equipo.listar(conn, tid_admin))
        if method == "POST":
            with db.session(write=True) as conn:
                nuevo = _equipo.crear(conn, tid_admin, body, user["id"])
            return Response(201, {"usuario": nuevo})

    match = EQUIPO_RE.match(path)
    if match and method == "PUT":
        from . import equipo as _equipo

        with db.session(write=True) as conn:
            actualizado = _equipo.actualizar(conn, tid_admin, match.group(1), body, user["id"])
        return Response(200, {"usuario": actualizado})

    if method == "GET" and path == "/api/admin/pagos":
        with db.session() as conn:
            from . import orders as _orders

            return Response(200, _orders.listar_pagos(conn, tid_admin))

    if method == "GET" and path == "/api/admin/notificaciones":
        with db.session() as conn:
            from . import orders as _orders

            return Response(200, _orders.listar_notificaciones(conn, tid_admin))

    if method == "POST" and path == "/api/admin/notificaciones/leidas":
        with db.session(write=True) as conn:
            from . import orders as _orders

            _orders.marcar_notificaciones_leidas(conn, tid_admin)
        return Response(200, {"ok": True})

    match = PEDIDO_ENVIO_RE.match(path)
    if match and method == "POST":
        from . import orders as _orders

        with db.session(write=True) as conn:
            pedido = _orders.asignar_envio(
                conn, match.group(1), body.get("importe"), body.get("transportista", ""), body.get("seguimiento", ""), user["id"],
                cobro=body.get("cobro", ""),
            )
        return Response(200, {"pedido": pedido})

    match = PEDIDO_PAGO_RE.match(path)
    if match and method == "POST":
        pid, accion = match.group(1), match.group(2)
        from . import orders as _orders

        if accion in {"verificar-pago", "verificar-envio"}:
            _solo_admin(user)
            with db.session(write=True) as conn:
                fn = _orders.verificar_pago if accion == "verificar-pago" else _orders.verificar_envio
                pedido = fn(conn, pid, user["id"])
        else:
            with db.session(write=True) as conn:
                if permitidos_domiciliario(user) and not _orders.pedido_visible_domiciliario(conn, pid):
                    raise ApiError("Este pedido no está en tu hoja de ruta", 403)
                pedido = _orders.confirmar_cobro(conn, pid, user["id"])
        return Response(200, {"pedido": pedido})

    if method == "GET" and path == "/api/admin/eventos":
        limite = int(num(_q(query, "limite", "100") or 100, "El límite", 1, 500))
        with db.session() as conn:
            filas = all_rows(
                conn,
                """SELECT e.*, u.nombre AS usuario FROM eventos e LEFT JOIN usuarios u ON u.id=e.usuario_id
                   WHERE e.tienda_id=? ORDER BY e.created_at DESC, e.rowid DESC LIMIT ?""",
                (tid_admin, limite),
            )
        return Response(200, {"items": [dict(f) for f in filas]})

    # ---------------------------- Productos ----------------------------
    if path == "/api/admin/productos":
        if method == "GET":
            with db.session() as conn:
                from . import tenant
                tid = tid_admin
                datos = catalog.listar_admin(
                    conn,
                    q=txt(_q(query, "q"), 80),
                    categoria=_q(query, "categoria"),
                    estado=_q(query, "estado"),
                    pagina=int(num(_q(query, "pagina", "1") or 1, "La página", 1, 10000)),
                    por_pagina=int(num(_q(query, "por_pagina", "25") or 25, "El tamaño", 1, 500)),
                    tienda_id=tid,
                )
            return Response(200, datos)
        if method == "POST":
            with db.session(write=True) as conn:
                from . import tenant
                tid = tid_admin
                producto = catalog.crear_producto(conn, body, user["id"], tid)
                db.audit(conn, user["id"], "producto.creado", "producto", producto["id"], {"sku": producto["sku"]})
            return Response(201, {"producto": producto})

    match = PRODUCTO_RE.match(path)
    if match:
        pid = match.group(1)
        if method == "GET":
            with db.session() as conn:
                from . import tenant
                tid = tid_admin
                return Response(200, {"producto": catalog._producto_admin(conn, pid, tid)})
        if method == "PUT":
            with db.session(write=True) as conn:
                producto = catalog.actualizar_producto(conn, pid, body, user["id"])
                db.audit(conn, user["id"], "producto.actualizado", "producto", pid, {"sku": producto["sku"]})
            return Response(200, {"producto": producto})
        if method == "DELETE":
            with db.session(write=True) as conn:
                catalog.desactivar_producto(conn, pid)
                db.audit(conn, user["id"], "producto.desactivado", "producto", pid, {})
            return Response(200, {"ok": True})

    match = PRODUCTO_KARDEX_RE.match(path)
    if match and method == "GET":
        pid = match.group(1)
        with db.session() as conn:
            producto = catalog._producto_admin(conn, pid)
            resumen = kardex.resumen(conn, pid)
            movimientos = kardex.listar(
                conn,
                pid,
                desde=_q(query, "desde"),
                hasta=_q(query, "hasta"),
                limite=int(num(_q(query, "limite", "1000") or 1000, "El límite", 1, 5000)),
            )
            verificacion = kardex.verificar(conn, pid)
        for mov in movimientos:
            mov["tipo_label"] = kardex.etiqueta(mov["tipo"])
        return Response(
            200,
            {
                "producto": producto,
                "resumen": resumen,
                "movimientos": movimientos,
                "verificacion": verificacion,
            },
        )

    match = PRODUCTO_AJUSTE_RE.match(path)
    if match and method == "POST":
        with db.session(write=True) as conn:
            resultado = catalog.ajustar_stock(conn, match.group(1), body, user["id"])
            db.audit(
                conn,
                user["id"],
                "producto.ajuste",
                "producto",
                match.group(1),
                {"numero": resultado["numero"], "motivo": body.get("motivo")},
            )
        return Response(200, resultado)

    match = PRODUCTO_VERIFICAR_RE.match(path)
    if match and method == "GET":
        with db.session() as conn:
            return Response(200, kardex.verificar(conn, match.group(1)))

    # ---------------------------- Categorías ----------------------------
    if path == "/api/admin/categorias":
        if method == "GET":
            with db.session() as conn:
                return Response(200, {"items": catalog.listar_categorias(conn, tienda_id=tid_admin)})
        if method == "POST":
            with db.session(write=True) as conn:
                categoria = catalog.crear_categoria(conn, body, tid_admin)
                db.audit(conn, user["id"], "categoria.creada", "categoria", categoria["id"], {})
            return Response(201, {"categoria": categoria})

    match = CATEGORIA_RE.match(path)
    if match:
        cid = match.group(1)
        if method == "PUT":
            with db.session(write=True) as conn:
                categoria = catalog.actualizar_categoria(conn, cid, body)
                db.audit(conn, user["id"], "categoria.actualizada", "categoria", cid, {})
            return Response(200, {"categoria": categoria})
        if method == "DELETE":
            with db.session(write=True) as conn:
                catalog.borrar_categoria(conn, cid)
                db.audit(conn, user["id"], "categoria.borrada", "categoria", cid, {})
            return Response(200, {"ok": True})

    # ---------------------------- Proveedores ----------------------------
    if path == "/api/admin/proveedores":
        if method == "GET":
            with db.session() as conn:
                return Response(200, {"items": purchases.listar_proveedores(conn, q=txt(_q(query, "q"), 80), tienda_id=tid_admin)})
        if method == "POST":
            with db.session(write=True) as conn:
                proveedor = purchases.crear_proveedor(conn, body, tid_admin)
                db.audit(conn, user["id"], "proveedor.creado", "proveedor", proveedor["id"], {})
            return Response(201, {"proveedor": proveedor})

    match = PROVEEDOR_RE.match(path)
    if match:
        prid = match.group(1)
        if method == "PUT":
            with db.session(write=True) as conn:
                proveedor = purchases.actualizar_proveedor(conn, prid, body)
                db.audit(conn, user["id"], "proveedor.actualizado", "proveedor", prid, {})
            return Response(200, {"proveedor": proveedor})
        if method == "DELETE":
            with db.session(write=True) as conn:
                purchases.borrar_proveedor(conn, prid)
                db.audit(conn, user["id"], "proveedor.borrado", "proveedor", prid, {})
            return Response(200, {"ok": True})

    # ---------------------------- Compras ----------------------------
    if path == "/api/admin/compras":
        if method == "GET":
            with db.session() as conn:
                return Response(
                    200,
                    purchases.listar_compras(
                        conn,
                        tienda_id=tid_admin,
                        estado=_q(query, "estado"),
                        q=txt(_q(query, "q"), 80),
                        pagina=int(num(_q(query, "pagina", "1") or 1, "La página", 1, 10000)),
                        por_pagina=int(num(_q(query, "por_pagina", "20") or 20, "El tamaño", 1, 100)),
                    ),
                )
        if method == "POST":
            with db.session(write=True) as conn:
                compra = purchases.crear_compra(
                    conn, body, user["id"], recibir=bool(body.get("recibir")), tienda_id=tid_admin
                )
                db.audit(conn, user["id"], "compra.creada", "compra", compra["id"], {"numero": compra["numero"]})
            return Response(201, {"compra": compra})

    match = COMPRA_RE.match(path)
    if match:
        cid = match.group(1)
        if method == "GET":
            with db.session() as conn:
                return Response(200, {"compra": purchases.detalle_compra(conn, cid)})
        if method == "DELETE":
            with db.session(write=True) as conn:
                purchases.borrar_compra(conn, cid)
                db.audit(conn, user["id"], "compra.borrada", "compra", cid, {})
            return Response(200, {"ok": True})

    match = COMPRA_ACCION_RE.match(path)
    if match and method == "POST":
        cid, accion = match.group(1), match.group(2)
        with db.session(write=True) as conn:
            if accion == "recibir":
                compra = purchases.recibir_compra(conn, cid, user["id"])
                db.audit(conn, user["id"], "compra.recibida", "compra", cid, {"numero": compra["numero"]})
            else:
                compra = purchases.anular_compra(conn, cid, user["id"])
                db.audit(conn, user["id"], "compra.anulada", "compra", cid, {"numero": compra["numero"]})
        return Response(200, {"compra": compra})

    # ---------------------------- Pedidos ----------------------------
    if path == "/api/admin/pedidos" and method == "GET":
        with db.session() as conn:
            return Response(
                200,
                orders.listar_admin(
                    conn,
                    tienda_id=tid_admin,
                    estado=_q(query, "estado"),
                    q=txt(_q(query, "q"), 80),
                    desde=_q(query, "desde"),
                    hasta=_q(query, "hasta"),
                    pagina=int(num(_q(query, "pagina", "1") or 1, "La página", 1, 10000)),
                    por_pagina=int(num(_q(query, "por_pagina", "20") or 20, "El tamaño", 1, 100)),
                ),
            )

    match = PEDIDO_RE.match(path)
    if match and method == "GET":
        with db.session() as conn:
            if permitidos_domiciliario(user) and not orders.pedido_visible_domiciliario(conn, match.group(1)):
                raise ApiError("Este pedido no está en tu hoja de ruta", 403)
            return Response(200, {"pedido": orders.pedido_admin(conn, match.group(1))})

    match = PEDIDO_ACCION_RE.match(path)
    if match and method == "POST":
        pid, accion = match.group(1), match.group(2)
        from . import roles as _roles

        if accion == "estado":
            permitidos = _roles.estados_permitidos(user.get("rol", ""))
            if permitidos is not None and body.get("estado") not in permitidos:
                raise ApiError("Tu rol no puede pasar el pedido a ese estado", 403)
        with db.session(write=True) as conn:
            if permitidos_domiciliario(user) and not orders.pedido_visible_domiciliario(conn, pid):
                raise ApiError("Este pedido no está en tu hoja de ruta", 403)
            if accion == "estado":
                pedido = orders.cambiar_estado(
                    conn,
                    pid,
                    body.get("estado"),
                    nota=txt(body.get("nota"), 240),
                    usuario_id=user["id"],
                )
            else:
                pedido = orders.cancelar_pedido(
                    conn, pid, nota=txt(body.get("motivo") or body.get("nota"), 240), usuario_id=user["id"]
                )
        return Response(200, {"pedido": pedido})

    # ---------------------------- Ajustes y auditoría ----------------------------
    if path == "/api/admin/ajustes":
        if method == "GET":
            with db.session() as conn:
                ajustes = db.settings_all(conn, tid_admin)
                from . import tiendas as _tiendas

                ajustes["tienda_email"] = _tiendas.email_de_contacto(conn, tid_admin)
                stats = {
                    "productos": one(conn, "SELECT COUNT(*) AS n FROM productos WHERE activo=1 AND tienda_id=?", (tid_admin,))["n"],
                    "pedidos": one(conn, "SELECT COUNT(*) AS n FROM pedidos WHERE tienda_id=?", (tid_admin,))["n"],
                    "movimientos": one(conn, "SELECT COUNT(*) AS n FROM movimientos WHERE tienda_id=?", (tid_admin,))["n"],
                    "eventos": one(conn, "SELECT COUNT(*) AS n FROM eventos WHERE tienda_id=?", (tid_admin,))["n"],
                }
                fila_tienda = one(conn, "SELECT slug FROM tiendas WHERE id=?", (tid_admin,))
            return Response(
                200,
                {
                    "ajustes": ajustes,
                    "stats": stats,
                    "db": str(config.DB_PATH),
                    "public_url": config.PUBLIC_URL,
                    "usuario": user,
                    "tienda_slug": fila_tienda["slug"] if fila_tienda else "",
                },
            )
        if method == "PUT":
            _solo_admin(user)
            permitidos = {
                "tienda_nombre",
                "tienda_claim",

                "tienda_telefono",
                "tienda_direccion",
                "aviso_envio",
                "aviso_plazo_pago",
                "pago_plazo_horas",
                "pago_gracia_admin_horas",
                "recargo_contrareembolso",
                "aviso_pago",
                "tema_backoffice",
                "tema_tienda",
                "pago_iban",
                "pago_cartera",
                "pago_web_activo",
                "pago_web_cuenta",
            }
            cambios: dict[str, str] = {}
            with db.session() as _c:
                ajustes_actuales = db.settings_all(_c, tid_admin)
            for clave in permitidos:
                if clave not in body:
                    continue
                valor = body.get(clave)
                if clave == "pago_web_activo":
                    activo = "1" if str(valor).lower() in {"1", "true", "on", "si", "sí"} else "0"
                    if activo == "1" and not txt(body.get("pago_web_cuenta", ajustes_actuales.get("pago_web_cuenta", "")), 80):
                        raise ApiError("Para activar el pago con tarjeta, indica primero la cuenta conectada", 400, "pago_web_cuenta")
                    cambios[clave] = activo
                elif clave == "pago_web_cuenta":
                    cambios[clave] = txt(valor, 80)
                elif clave in {"tema_backoffice", "tema_tienda"}:
                    tema = txt(valor, 20)
                    if tema not in config.TEMAS:
                        raise ApiError("Tema no válido", 400, clave)
                    cambios[clave] = tema
                elif clave in {"pago_plazo_horas", "pago_gracia_admin_horas"}:
                    limite = (1, 72) if clave == "pago_plazo_horas" else (1, 168)
                    try:
                        horas = int(float(valor))
                    except (TypeError, ValueError):
                        raise ApiError("Indica un número de horas válido", 400, clave)
                    if not limite[0] <= horas <= limite[1]:
                        raise ApiError(f"Las horas deben estar entre {limite[0]} y {limite[1]}", 400, clave)
                    cambios[clave] = str(horas)
                elif clave == "recargo_contrareembolso":
                    cambios[clave] = str(round(num(valor, "El importe", 0, 9999), 2))
                else:
                    maxlen = 400 if clave == "tienda_direccion" else 300
                    cambios[clave] = txt(valor, maxlen)
            if not cambios:
                raise ApiError("No hay cambios que guardar")
            with db.session(write=True) as conn:
                db.save_settings(conn, cambios, tid_admin)
                db.audit(conn, user["id"], "ajustes.actualizados", "configuracion", "", cambios, _ip(headers))
            return Response(200, {"ok": True, "ajustes": cambios})

    import re as _re
    m = _re.match(r"^/api/admin/pedidos/([^/]+)/chat$", path)
    if m:
        pedido_id = m.group(1)
        if method == "GET":
            with db.session() as conn:
                return Response(200, {"items": orders.listar_chat(conn, pedido_id)})
        if method == "POST":
            with db.session(write=True) as conn:
                msg = orders.enviar_mensaje(conn, pedido_id, user, body.get("mensaje", ""))
            return Response(201, {"mensaje": msg})

    raise ApiError("Ruta no encontrada", 404)


def _cliente(method: str, path: str, query: dict | None, body: dict, headers: dict, user: dict) -> Response:
    if user.get("rol") not in {"cliente", "admin", "preparador", "domiciliario"}:
        raise ApiError("Acceso no autorizado", 403)
    from . import tenant
    if method == "GET" and path == "/api/cliente/pedidos":
        with db.session() as conn:
            tid = tenant.resolve_tienda_id(conn, headers, query)
            return Response(200, orders.listar_por_cliente(conn, user["id"], user.get("email", ""), tid))
    import re
    m = re.match(r"^/api/cliente/pedidos/([^/]+)$", path)
    if m and method == "GET":
        with db.session() as conn:
            tid = tenant.resolve_tienda_id(conn, headers, query)
            if orders._row_pedido(conn, m.group(1)).get("tienda_id") != tid or tid is None:
                raise ApiError("Pedido no encontrado", 404)
            return Response(200, orders.pedido_cliente(conn, m.group(1), user))
    m = re.match(r"^/api/cliente/pedidos/([^/]+)/chat$", path)
    if m:
        numero = m.group(1)
        with db.session() as conn:
            pedido = orders._row_pedido(conn, numero)
            tid = tenant.resolve_tienda_id(conn, headers, query)
        if tid is None or pedido.get("tienda_id") != tid:
            raise ApiError("Pedido no encontrado", 404)
        # ownership check
        if pedido.get("cliente_id") and pedido["cliente_id"] != user["id"] and pedido["cliente_email"].lower() != (user.get("email") or "").lower():
            raise ApiError("No tienes acceso a este pedido", 403)
        if not pedido.get("cliente_id") and pedido["cliente_email"].lower() != (user.get("email") or "").lower():
            raise ApiError("No tienes acceso a este pedido", 403)
        if method == "GET":
            with db.session() as conn:
                return Response(200, {"items": orders.listar_chat(conn, pedido["id"])})
        if method == "POST":
            with db.session(write=True) as conn:
                msg = orders.enviar_mensaje(conn, pedido["id"], user, body.get("mensaje", ""))
            return Response(201, {"mensaje": msg})
    raise ApiError("Ruta no encontrada", 404)


def _superadmin(method: str, path: str, query: dict | None, body: dict, headers: dict, user: dict) -> Response:
    from . import correo as _correo

    if path == "/api/superadmin/correo" and method == "GET":
        return Response(200, _correo.configuracion_publica())
    if path == "/api/superadmin/correo" and method == "PUT":
        with db.session(write=True) as conn:
            return Response(200, _correo.guardar(conn, body, user["id"]))
    if path == "/api/superadmin/correo/prueba" and method == "POST":
        try:
            estado = _correo.enviar(
                user["email"], "Prueba de correo de CC Shops",
                "Si recibes este mensaje, el correo de la plataforma está bien configurado.",
            )
        except Exception as exc:
            traceback.print_exc()
            raise ApiError(f"No se ha podido enviar: {exc}", 502)
        return Response(200, {"ok": True, "estado": estado, "destino": user["email"]})

    match = re.match(r"^/api/superadmin/tiendas/([^/]+)/limite-admins$", path)
    if match and method == "PUT":
        from . import equipo as _equipo

        with db.session(write=True) as conn:
            return Response(200, _equipo.fijar_limite(conn, match.group(1), body.get("max_admins"), user["id"]))

    from . import plataforma as _pl

    if path == "/api/superadmin/dominios" and method == "GET":
        from . import dominios as _dom

        with db.session() as conn:
            return Response(200, _dom.listado(conn))
    if path == "/api/superadmin/dominios/config" and method == "PUT":
        from . import dominios as _dom

        with db.session(write=True) as conn:
            return Response(200, _dom.guardar_configuracion(conn, body, user["id"]))
    match = re.match(r"^/api/superadmin/dominios/([^/]+)/accion$", path)
    if match and method == "POST":
        from . import dominios as _dom

        with db.session(write=True) as conn:
            return Response(200, _dom.accion(conn, match.group(1), txt(body.get("accion"), 30), user["id"]))

    if path == "/api/superadmin/metricas" and method == "GET":
        with db.session() as conn:
            return Response(200, _pl.metricas(conn))
    if path == "/api/superadmin/planes":
        with db.session(write=method in {"POST", "PUT"}) as conn:
            if method == "GET":
                return Response(200, {"items": _pl.listar_planes(conn)})
            if method == "POST":
                return Response(201, {"plan": _pl.guardar_plan(conn, body)})
    match = re.match(r"^/api/superadmin/planes/([^/]+)$", path)
    if match and method == "PUT":
        with db.session(write=True) as conn:
            return Response(200, {"plan": _pl.guardar_plan(conn, body, match.group(1))})
    if path == "/api/superadmin/suscripciones":
        with db.session(write=method == "POST") as conn:
            if method == "GET":
                return Response(200, {"items": _pl.listar_suscripciones(conn)})
            if method == "POST":
                return Response(201, {"suscripcion": _pl.asignar_suscripcion(conn, body, user["id"])})
    match = re.match(r"^/api/superadmin/suscripciones/([^/]+)$", path)
    if match and method == "PUT":
        with db.session(write=True) as conn:
            return Response(200, {"suscripcion": _pl.asignar_suscripcion(conn, body, user["id"], match.group(1))})
    if path == "/api/superadmin/tiendas" and method == "GET":
        with db.session() as conn:
            return Response(200, {"items": _pl.listar_tiendas(conn)})
    match = re.match(r"^/api/superadmin/tiendas/([^/]+)/estado$", path)
    if match and method == "PUT":
        with db.session(write=True) as conn:
            return Response(200, _pl.cambiar_estado_tienda(conn, match.group(1), txt(body.get("estado"), 20), user["id"]))
    if path == "/api/superadmin/usuarios" and method == "GET":
        with db.session() as conn:
            return Response(200, {"items": _pl.listar_usuarios(conn)})
    match = re.match(r"^/api/superadmin/usuarios/([^/]+)$", path)
    if match and method == "PUT":
        with db.session(write=True) as conn:
            return Response(200, _pl.cambiar_activo_usuario(conn, match.group(1), bool(body.get("activo")), user["id"]))
    if path == "/api/superadmin/landing":
        with db.session(write=method == "PUT") as conn:
            if method == "GET":
                return Response(200, _pl.landing_config(conn))
            if method == "PUT":
                return Response(200, _pl.guardar_landing(conn, body, user["id"]))
    if path.startswith("/api/superadmin/soporte"):
        return _soporte_plataforma(method, path, query, body, user)
    raise ApiError("Ruta no encontrada", 404)


def _soporte_tienda(method, path, query, body, user, tid) -> Response:
    from . import soporte as _s

    sub = path[len("/api/admin/soporte"):]
    with db.session(write=method in {"POST", "PUT"}) as conn:
        if sub == "/estado" and method == "GET":
            return Response(200, _s.version(conn, tid, txt(_q(query, "conv"), 40), txt(_q(query, "ticket"), 40)))
        if sub == "/categorias" and method == "GET":
            return Response(200, {"items": _s.listar_categorias(conn, solo_activas=True)})
        if sub == "/conversaciones":
            if method == "GET":
                return Response(200, {"items": _s.tienda_listar_conversaciones(conn, tid, _q(query, "historial") == "1")})
            if method == "POST":
                return Response(201, _s.tienda_crear_conversacion(conn, tid, user["email"], body))
        m = re.match(r"^/api/admin/soporte/conversaciones/([^/]+)$", path)
        if m and method == "GET":
            return Response(200, _s.tienda_ver_conversacion(conn, tid, m.group(1)))
        if m and method == "PUT":
            return Response(200, _s.tienda_ocultar_conversacion(conn, tid, m.group(1), bool(body.get("oculta"))))
        m = re.match(r"^/api/admin/soporte/conversaciones/([^/]+)/mensajes$", path)
        if m and method == "POST":
            return Response(200, _s.tienda_responder_conversacion(conn, tid, m.group(1), user["email"], body.get("cuerpo")))
        if sub == "/tickets":
            if method == "GET":
                return Response(200, {"items": _s.tienda_listar_tickets(conn, tid, _q(query, "historial") == "1")})
            if method == "POST":
                return Response(201, _s.tienda_crear_ticket(conn, tid, user["email"], body))
        m = re.match(r"^/api/admin/soporte/tickets/([^/]+)$", path)
        if m and method == "GET":
            return Response(200, _s.tienda_ver_ticket(conn, tid, m.group(1)))
        if m and method == "PUT":
            return Response(200, _s.tienda_ocultar_ticket(conn, tid, m.group(1), bool(body.get("oculto"))))
        m = re.match(r"^/api/admin/soporte/tickets/([^/]+)/mensajes$", path)
        if m and method == "POST":
            return Response(200, _s.tienda_responder_ticket(conn, tid, m.group(1), user["email"], body.get("texto")))
    raise ApiError("Ruta no encontrada", 404)


def _soporte_plataforma(method, path, query, body, user) -> Response:
    from . import soporte as _s

    sub = path[len("/api/superadmin/soporte"):]
    with db.session(write=method in {"POST", "PUT"}) as conn:
        if sub == "/estado" and method == "GET":
            return Response(200, _s.version(conn, None, txt(_q(query, "conv"), 40), txt(_q(query, "ticket"), 40)))
        if sub == "/categorias":
            if method == "GET":
                return Response(200, {"items": _s.listar_categorias(conn, solo_activas=_q(query, "todas") != "1")})
            if method == "POST":
                return Response(201, {"categoria": _s.crear_categoria(conn, body.get("nombre"), user["id"])})
        m = re.match(r"^/api/superadmin/soporte/categorias/([^/]+)$", path)
        if m and method == "PUT":
            return Response(200, {"categoria": _s.activar_categoria(conn, m.group(1), bool(body.get("activa")), user["id"])})
        if sub == "/conversaciones" and method == "GET":
            return Response(200, {"items": _s.plataforma_listar_conversaciones(conn, _q(query, "historial") == "1")})
        m = re.match(r"^/api/superadmin/soporte/conversaciones/([^/]+)$", path)
        if m and method == "GET":
            return Response(200, _s.plataforma_ver_conversacion(conn, m.group(1)))
        if m and method == "PUT":
            return Response(200, _s.plataforma_cambiar_estado_conversacion(conn, m.group(1), txt(body.get("estado"), 20), user["id"]))
        m = re.match(r"^/api/superadmin/soporte/conversaciones/([^/]+)/mensajes$", path)
        if m and method == "POST":
            return Response(200, _s.plataforma_responder_conversacion(conn, m.group(1), user["email"], body.get("cuerpo")))
        if sub == "/tickets" and method == "GET":
            return Response(200, {"items": _s.plataforma_listar_tickets(conn, _q(query, "historial") == "1", txt(_q(query, "estado"), 20))})
        m = re.match(r"^/api/superadmin/soporte/tickets/([^/]+)$", path)
        if m and method == "GET":
            return Response(200, _s.plataforma_ver_ticket(conn, m.group(1)))
        if m and method == "PUT":
            return Response(200, _s.plataforma_cambiar_estado_ticket(conn, m.group(1), txt(body.get("estado"), 20), user["id"]))
        m = re.match(r"^/api/superadmin/soporte/tickets/([^/]+)/mensajes$", path)
        if m and method == "POST":
            return Response(200, _s.plataforma_responder_ticket(conn, m.group(1), user["email"], body.get("texto")))
    raise ApiError("Ruta no encontrada", 404)
