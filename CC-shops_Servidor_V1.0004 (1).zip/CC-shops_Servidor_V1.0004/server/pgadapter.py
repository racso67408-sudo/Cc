"""Adaptador PostgreSQL con la misma forma que la conexión SQLite que usa la aplicación.

La aplicación escribe SQL en dialecto SQLite (signos «?», «rowid», «INSERT OR IGNORE»…).
Este módulo traduce esas sentencias a PostgreSQL y devuelve filas como diccionarios, de modo
que el resto del código no cambia. Las transacciones las abre db.session() con BEGIN/COMMIT,
igual que con SQLite; la conexión funciona en modo autocommit para que un error controlado
no deje la transacción abortada.
"""
from __future__ import annotations

import re
from decimal import Decimal

try:  # el driver solo es necesario si se usa PostgreSQL
    import psycopg
    from psycopg.rows import tuple_row as _tuple_row
except ImportError:  # pragma: no cover
    psycopg = None

ERRORES = (psycopg.Error,) if psycopg else ()

_RE_COMENTARIO = re.compile(r"--[^\n]*")
_RE_OR_IGNORE = re.compile(r"^\s*INSERT\s+OR\s+IGNORE\s+INTO", re.IGNORECASE)
_RE_ROWID = re.compile(r"\browid\b")
_RE_LIKE = re.compile(r"\bLIKE\b", re.IGNORECASE)
_RE_CREATE = re.compile(r"(CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?\w+\s*\()", re.IGNORECASE)
_RE_PRAGMA = re.compile(r"^\s*PRAGMA\b", re.IGNORECASE)
_RE_PRAGMA_TABLE = re.compile(r"^\s*PRAGMA\s+table_info\((\w+)\)", re.IGNORECASE)


def traducir(sql: str, con_parametros: bool) -> str:
    """Traduce una sentencia SQLite a PostgreSQL."""
    texto = sql
    if con_parametros:
        texto = texto.replace("%", "%%").replace("?", "%s")
    if _RE_OR_IGNORE.search(texto):
        texto = _RE_OR_IGNORE.sub("INSERT INTO", texto).rstrip().rstrip(";") + " ON CONFLICT DO NOTHING"
    # Las escrituras se serializan (como BEGIN IMMEDIATE en SQLite) con un bloqueo consultivo
    # que se libera al confirmar: así el stock no se vende dos veces.
    texto = re.sub(r"\bBEGIN\s+IMMEDIATE\b", "BEGIN; SELECT pg_advisory_xact_lock(424242)", texto, flags=re.IGNORECASE)
    texto = _RE_ROWID.sub("seq", texto)
    texto = _RE_LIKE.sub("ILIKE", texto)
    # Columna de orden de inserción en cada tabla nueva (equivale al rowid de SQLite).
    texto = _RE_CREATE.sub(lambda m: m.group(1) + "seq BIGSERIAL, ", texto) if "CREATE TABLE" in texto.upper() else texto
    return texto


def sentencias(script: str) -> list[str]:
    """Separa un guion SQL en sentencias, quitando comentarios."""
    limpio = _RE_COMENTARIO.sub("", script)
    return [s.strip() for s in limpio.split(";") if s.strip()]


_RE_ADD_CONSTRAINT = re.compile(r"ALTER\s+TABLE\s+(\w+)\s+ADD\s+CONSTRAINT\s+(\w+)", re.IGNORECASE)
_RE_TABLA = re.compile(r"CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(\w+)", re.IGNORECASE)
_RE_COLUMNA_REF = re.compile(
    r"^(\s*)(\w+)(\s+.*?)\s+REFERENCES\s+(\w+)\s*\(\s*(\w+)\s*\)(.*?)(,?)\s*$", re.IGNORECASE)


def ordenar_ddl(lista: list[str]) -> list[str]:
    """Adapta el DDL de SQLite a PostgreSQL.

    SQLite admite claves foráneas hacia tablas creadas después y ciclos entre tablas
    (usuarios <-> tiendas); PostgreSQL no. Por eso las tablas se crean primero sin claves
    foráneas y después se añaden con ALTER TABLE. Los índices y el resto van al final.
    """
    tablas, otras, fks = [], [], []
    for sent in lista:
        m = _RE_TABLA.search(sent)
        if not m:
            otras.append(sent)
            continue
        nombre = m.group(1)
        lineas = []
        for linea in sent.split("\n"):
            r = _RE_COLUMNA_REF.match(linea)
            if r:
                indent, col, tipo, ref_tabla, ref_col, resto, coma = r.groups()
                # DEFERRABLE: la comprobación se hace al confirmar, así los ciclos y la carga de datos funcionan.
                fks.append(
                    f"ALTER TABLE {nombre} ADD CONSTRAINT fk_{nombre}_{col} FOREIGN KEY ({col}) "
                    f"REFERENCES {ref_tabla}({ref_col}){resto.rstrip()} DEFERRABLE INITIALLY DEFERRED"
                )
                lineas.append(f"{indent}{col}{tipo}{coma}")
            else:
                lineas.append(linea)
        tablas.append("\n".join(lineas))
    return tablas + fks + otras


def _convertir(valor):
    return float(valor) if isinstance(valor, Decimal) else valor


class _Cursor:
    """Cursor sencillo: filas como diccionarios con los nombres de columna originales."""

    def __init__(self, filas: list[dict] | None = None, cursor=None):
        self._filas = filas
        self._cursor = cursor
        self._pos = 0

    def _rows(self):
        if self._filas is None:
            cols = [d.name for d in self._cursor.description] if self._cursor.description else []
            self._filas = [dict(zip(cols, (_convertir(v) for v in r))) for r in self._cursor.fetchall()]
        return self._filas

    def fetchone(self):
        filas = self._rows()
        if self._pos < len(filas):
            self._pos += 1
            return filas[self._pos - 1]
        return None

    def fetchall(self):
        filas = self._rows()
        resto = filas[self._pos:]
        self._pos = len(filas)
        return resto

    def __iter__(self):
        return iter(self.fetchall())


class PgConnection:
    """Conexión con la misma interfaz que se usa con sqlite3 en la aplicación."""

    es_postgres = True

    def __init__(self, url: str):
        if psycopg is None:
            raise RuntimeError("Para usar PostgreSQL instala el driver: pip install \"psycopg[binary]\"")
        self.raw = psycopg.connect(url, autocommit=True, row_factory=_tuple_row)

    def execute(self, sql: str, params=()) -> _Cursor:
        params = tuple(params) if params is not None else ()
        if _RE_PRAGMA.match(sql):
            return self._pragma(sql)
        texto = traducir(sql, bool(params))
        cur = self.raw.cursor()
        cur.execute(texto, params if params else None)
        return _Cursor(cursor=cur)

    def _pragma(self, sql: str) -> _Cursor:
        m = _RE_PRAGMA_TABLE.match(sql)
        if m:
            cur = self.raw.cursor()
            cur.execute(
                """SELECT column_name FROM information_schema.columns
                   WHERE table_schema=current_schema() AND table_name=%s ORDER BY ordinal_position""",
                (m.group(1),),
            )
            return _Cursor([{"name": r[0]} for r in cur.fetchall()])
        return _Cursor([])  # foreign_keys, busy_timeout, journal_mode… no aplican a PostgreSQL

    def executescript(self, script: str) -> None:
        for sentencia in ordenar_ddl(sentencias(script)):
            m = _RE_ADD_CONSTRAINT.match(sentencia)
            if m:  # arranque repetible: la clave foránea ya existe si la base estaba creada
                if self.execute("SELECT 1 AS x FROM pg_constraint WHERE conname=?", (m.group(2),)).fetchone():
                    continue
            self.execute(sentencia)

    def commit(self) -> None:
        pass  # autocommit

    def close(self) -> None:
        self.raw.close()
