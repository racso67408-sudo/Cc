"""Datos iniciales y demostración realista de CC-Shops."""
from __future__ import annotations

import json
import os
from datetime import timedelta

from . import auth, db, kardex, orders
from .db import one
from .util import biz_now, iso_at, iso_now, money, new_id, qty, slugify

ADMIN_EMAIL = "admin@ccshops.es"

CATEGORIAS = [
    ("Pestañas", "pestanas", "Pestañas clásicas, tecnológicas y efecto volumen para extensiones.", "layers", 10),
    ("Adhesivos", "adhesivos", "Adhesivos de diferentes tiempos de secado y viscosidad.", "droplet", 20),
    ("Limpieza y primer", "limpieza", "Shampoo, primer y limpiadores para preparar la pestaña natural.", "spray", 30),
    ("Accesorios", "accesorios", "Anillos, cinta transpore, parches y herramientas.", "box", 40),
    ("Cuidado", "cuidado", "Tratamientos, selladores y productos de mantenimiento.", "shield", 50),
    ("Consumibles", "consumibles", "Microcepillos, pads, guantes y material desechable.", "tag", 60),
]

PROVEEDORES = [
    ("Limpezas Delta S.L.", "Marta Ruiz", "marta@limpiezasdelta.es", "+34 931 220 441", "Químicos y limpieza profesional. Entrega los martes."),
    ("Distribuciones Nova", "Jordi Puig", "jordi@distnova.es", "+34 935 771 208", "Desechables, higiene y guantes."),
    ("EcoPack Ibérica", "Laura Soto", "laura@ecopack.es", "+34 961 440 903", "Empaque sostenible y papel."),
]

# nombre, sku, categoría, precio con IVA, IVA, coste, stock inicial, mínimo, unidad, marca, imagen, destacado
PRODUCTOS = [
    ("Pestañas clásicas 0.15 C (bandeja 16 líneas)", "PES-001", "pestanas", 14.90, 21, 5.20, 40, 10, "bandeja", "LashPro", "bayetas.svg", 1),
    ("Pestañas tecnológicas 0.07 D (bandeja)", "PES-002", "pestanas", 16.50, 21, 6.10, 32, 8, "bandeja", "LashPro", "bayetas.svg", 1),
    ("Pestañas volumen 0.05 C (bandeja)", "PES-003", "pestanas", 17.90, 21, 6.80, 28, 8, "bandeja", "LashPro", "bayetas.svg", 0),
    ("Adhesivo de pestañas 5 ml (secado rápido)", "ADH-001", "adhesivos", 24.90, 21, 9.40, 25, 6, "ud", "Bond", "gel.svg", 1),
    ("Adhesivo sensible 5 ml (baja irritación)", "ADH-002", "adhesivos", 26.50, 21, 10.20, 18, 5, "ud", "Bond", "gel.svg", 0),
    ("Primer desengrasante 15 ml", "LIM-001", "limpieza", 9.90, 21, 3.60, 30, 8, "ud", "Clean", "jabon.svg", 1),
    ("Shampoo para pestañas 50 ml", "LIM-002", "limpieza", 12.40, 21, 4.80, 22, 6, "ud", "Clean", "jabon.svg", 0),
    ("Limpiador de pestañas (espuma) 30 ml", "LIM-003", "limpieza", 8.50, 21, 3.10, 35, 10, "ud", "Clean", "jabon.svg", 0),
    ("Anillo para adhesivo (pack 10)", "ACC-001", "accesorios", 6.90, 21, 2.40, 50, 12, "pack", "Tools", "etiquetas.svg", 1),
    ("Cinta transpore micropore (rollo)", "ACC-002", "accesorios", 4.50, 21, 1.60, 60, 15, "rollo", "Tools", "cinta.svg", 0),
    ("Parches de colágeno (pack 10)", "ACC-003", "accesorios", 5.60, 21, 2.10, 45, 12, "pack", "Tools", "toallitas.svg", 1),
    ("Pinzas curvas de precisión", "ACC-004", "accesorios", 19.90, 21, 7.80, 15, 4, "ud", "Tools", "cutter.svg", 0),
    ("Sellador de pestañas 10 ml", "CUI-001", "cuidado", 11.90, 21, 4.20, 20, 5, "ud", "Care", "ambientador.svg", 0),
    ("Tratamiento nutritivo para pestañas", "CUI-002", "cuidado", 13.50, 21, 5.10, 16, 4, "ud", "Care", "ambientador.svg", 0),
    ("Microcepillos (pack 100)", "CON-001", "consumibles", 4.90, 21, 1.70, 80, 20, "pack", "Consum", "multiusos.svg", 0),
    ("Pads de algodón (pack 100)", "CON-002", "consumibles", 3.90, 21, 1.40, 90, 24, "pack", "Consum", "papel.svg", 0),
    ("Guantes de nitrilo (caja 100)", "CON-003", "consumibles", 11.90, 21, 5.20, 30, 8, "caja", "Consum", "guantes.svg", 1),
    ("Máscara protectora desechable", "CON-004", "consumibles", 2.90, 21, 1.00, 40, 10, "ud", "Consum", "mascarillas.svg", 0),
    ("Lámpara LED para curado", "ACC-005", "accesorios", 49.90, 21, 22.00, 8, 2, "ud", "Tools", "film.svg", 0),
    ("Espejo de mano con luz", "ACC-006", "accesorios", 15.90, 21, 6.20, 12, 3, "ud", "Tools", "cajas.svg", 0),
]

DESCRIPCIONES = {
    "LIM-001": ("Fórmula concentrada de alto rendimiento para superficies lavables. Rinde hasta 15 litros de producto listo para usar.", "Diluye 1:20 en agua. Apta para suelos, paredes y mobiliario. No utilizar sobre mármol pulido."),
    "LIM-002": ("Desengrasante de potencia industrial para cocinas, talleres y zonas de alto tránsito. Baja espuma y aroma neutro.", "Dilución recomendada 1:10 para suciedad intensa. Enjuagar con agua limpia."),
    "LIM-003": ("Gel hidroalcohólico con aloe vera. Protege y suaviza mientras elimina bacterias y virus.", "Aplicar una pequeña cantidad y frotar hasta que se seque. Uso externo."),
    "LIM-004": ("Ambientador de larga duración con aceites esenciales de lavanda. Neutraliza olores sin enmascararlos.", "Pulverizar a 30 cm de la superficie. No rociar sobre personas ni alimentos."),
    "LIM-005": ("Pack de 10 bayetas de microfibra de 30x30 cm. Absorben hasta 7 veces su peso y no dejan marcas.", "Lavar a 40 °C sin suavizante. Se pueden usar en seco o húmedas."),
    "HIG-001": ("Jabón líquido con pH neutro y glicerina, apto para uso frecuente. Dispensador de 1 litro.", "Aplicar sobre las manos húmedas, frotar 20 segundos y aclarar."),
    "HIG-002": ("Papel secamanos de dos capas, extra suave y de alta absorción. Pack de 6 rollos de 200 servicios.", "Compatible con dispensadores universales. Producto de un solo uso."),
    "HIG-003": ("Toallitas desinfectantes de amplio espectro para superficies de contacto. Pack de 100 unidades.", "Limpiar la superficie y dejar actuar 30 segundos. No reutilizar."),
    "DES-001": ("Guantes de nitrilo sin polvo, 100 % libres de látex. Talla M, caja de 100 unidades.", "Uso profesional. Desechar tras cada uso. No aptos para contacto con alimentos grasos."),
    "DES-002": ("Mascarillas quirúrgicas de tres capas con filtro bacteriano. Caja de 50 unidades.", "Colocar cubriendo nariz y boca. Producto de un solo uso."),
    "DES-003": ("Vasos de 200 ml fabricados con PLA compostable. Pack de 50 unidades.", "Aptos para bebidas frías y templadas. No aptos para microondas."),
    "DES-004": ("Cubiertos de madera de abedul FSC: 50 tenedores, 50 cuchillos y 50 cucharas.", "Producto compostable. Almacenar en lugar seco."),
    "EMP-001": ("Film transparente profesional de 30 cm de ancho y 300 m de largo. Alta transparencia y adherencia.", "Apto para contacto alimentario. Conservar en lugar fresco."),
    "EMP-002": ("Bolsas de papel kraft con asa, 25x35 cm, 100 unidades. Ideales para tienda y take away.", "Papel kraft 80 g/m². Reciclables y compostables."),
    "EMP-003": ("Bolsas de basura industriales de 120 litros, galga 60. Rollo de 25 unidades.", "Para residuos no peligrosos. No sobrecargar."),
    "EMP-004": ("Cajas de cartón ondulado de doble canal, 40x30x30 cm. Pack de 10 unidades.", "Montaje sin cinta. Resistencia hasta 20 kg."),
    "SEG-001": ("Cinta de señalización de PVC de 50 mm x 33 m, color amarillo y negro.", "Uso temporal en zonas de paso y obras."),
    "SEG-002": ("Cúter con hoja retráctil y bloqueo de seguridad. Cuerpo ergonómico antideslizante.", "Sustituir la hoja cuando pierda filo. Mantener fuera del alcance de menores."),
    "PAP-001": ("Etiquetas blancas mate de 70x36 mm, 500 unidades en hoja A4. Adhesivo permanente.", "Compatibles con impresoras láser e inyección de tinta."),
    "PAP-002": ("Cuaderno A4 con 100 hojas cuadriculadas y cubierta resistente. Ideal para recuentos e inventario.", "Papel 90 g/m². Encuadernación cosida."),
}

ESPECIFICACIONES = {
    "LIM-001": [("Formato", "750 ml"), ("Rendimiento", "Hasta 15 L diluido"), ("Aroma", "Fresco"), ("PH", "7,5")],
    "LIM-002": [("Formato", "5 litros"), ("Dilución", "1:10"), ("Uso", "Suelos y superficies"), ("Aroma", "Neutro")],
    "LIM-003": [("Formato", "500 ml"), ("Alcohol", "70 %"), ("Con aloe", "Sí"), ("Uso", "Manos")],
    "LIM-004": [("Formato", "400 ml"), ("Aroma", "Lavanda"), ("Duración", "Hasta 8 h"), ("Uso", "Ambientes")],
    "LIM-005": [("Unidades", "10"), ("Medida", "30x30 cm"), ("Composición", "80 % poliéster / 20 % poliamida"), ("Lavable", "Sí, 40 °C")],
    "HIG-001": [("Formato", "1 litro"), ("PH", "Neutro"), ("Uso", "Manos"), ("Dispensador", "Incluido")],
    "HIG-002": [("Rollos", "6"), ("Capas", "2"), ("Servicios", "200 por rollo"), ("Certificado", "FSC")],
    "HIG-003": [("Unidades", "100"), ("Formato", "20x20 cm"), ("Activo", "Alcohol 70 %"), ("Uso", "Superficies")],
    "DES-001": [("Talla", "M"), ("Material", "Nitrilo"), ("Unidades", "100"), ("Sin polvo", "Sí")],
    "DES-002": [("Unidades", "50"), ("Capas", "3"), ("Filtro", "BFE ≥ 95 %"), ("Uso", "Un solo uso")],
    "DES-003": [("Capacidad", "200 ml"), ("Unidades", "50"), ("Material", "PLA compostable"), ("Apto", "Bebidas frías")],
    "DES-004": [("Unidades", "150"), ("Material", "Madera de abedul"), ("Certificado", "FSC"), ("Compostable", "Sí")],
    "EMP-001": [("Ancho", "30 cm"), ("Largo", "300 m"), ("Grosor", "10 micras"), ("Apto alimentos", "Sí")],
    "EMP-002": [("Medidas", "25x35 cm"), ("Unidades", "100"), ("Papel", "Kraft 80 g/m²"), ("Asa", "Sí")],
    "EMP-003": [("Capacidad", "120 L"), ("Rollo", "25 uds"), ("Galga", "60"), ("Color", "Negro")],
    "EMP-004": [("Medidas", "40x30x30 cm"), ("Unidades", "10"), ("Cartón", "Doble canal"), ("Carga máx.", "20 kg")],
    "SEG-001": [("Ancho", "50 mm"), ("Largo", "33 m"), ("Color", "Amarillo / negro"), ("Material", "PVC")],
    "SEG-002": [("Hoja", "Retráctil"), ("Bloqueo", "Sí"), ("Cuerpo", "ABS"), ("Hojas de repuesto", "2")],
    "PAP-001": [("Medidas", "70x36 mm"), ("Unidades", "500"), ("Adhesivo", "Permanente"), ("Hojas", "A4")],
    "PAP-002": [("Formato", "A4"), ("Hojas", "100"), ("Cuadrícula", "5 mm"), ("Papel", "90 g/m²")],
}


def _password_inicial(variable: str, etiqueta: str) -> str:
    """Contraseña de una cuenta inicial: la del entorno, o una aleatoria mostrada una sola vez."""
    import secrets
    import sys

    valor = os.environ.get(variable, "").strip()
    if valor:
        return valor
    generada = secrets.token_urlsafe(12) + "Aa1!"
    print(f"[CC-Shops] Contraseña inicial generada para {etiqueta}: {generada}", file=sys.stderr)
    print(f"[CC-Shops] Para fijarla, define {variable} antes de crear la base. No se volverá a mostrar.", file=sys.stderr)
    return generada


def ensure_admin(conn) -> None:
    if one(conn, "SELECT COUNT(*) AS n FROM usuarios")["n"]:
        return
    sello = iso_now()
    conn.execute(
        "INSERT INTO usuarios (id, nombre, email, password_hash, rol, activo, session_version, ultimo_acceso, created_at) "
        "VALUES (?,?,?,?,'superadmin',1,0,'',?)",
        (new_id("USR"), "Super Admin", "superadmin@ccshops.com", auth.hash_password(_password_inicial("CC_SUPERADMIN_PASSWORD", "superadmin")), sello),
    )
    conn.execute(
        "INSERT INTO usuarios (id, nombre, email, password_hash, rol, activo, session_version, ultimo_acceso, created_at) "
        "VALUES (?,?,?,?,'admin',1,0,'',?)",
        (new_id("USR"), "Clara Campos", ADMIN_EMAIL, auth.hash_password(_password_inicial("CC_ADMIN_PASSWORD", "administrador de la tienda")), sello),
    )
    conn.execute(
        "INSERT INTO usuarios (id, nombre, email, password_hash, rol, activo, session_version, ultimo_acceso, created_at) "
        "VALUES (?,?,?,?,'preparador',1,0,'',?)",
        (new_id("USR"), "Equipo de tienda", "equipo@ccshops.es", auth.hash_password(_password_inicial("CC_OPERADOR_PASSWORD", "preparación")), sello),
    )


def _fecha(dias_atras: int, hora: int = 10, minuto: int = 15) -> str:
    base = biz_now() - timedelta(days=dias_atras)
    return iso_at(base.replace(hour=hora, minute=minuto, second=0))


def seed_demo(conn, tienda_id: str) -> None:
    if one(conn, "SELECT COUNT(*) AS n FROM productos")["n"]:
        return
    cat_ids: dict[str, str] = {}
    for nombre, slug, descripcion, icono, orden in CATEGORIAS:
        cid = new_id("CAT")
        conn.execute(
            "INSERT INTO categorias (id, tienda_id, nombre, slug, descripcion, icono, orden, activo) VALUES (?,?,?,?,?,?,?,1)",
            (cid, tienda_id, nombre, slug, descripcion, icono, orden),
        )
        cat_ids[slug] = cid

    prov_ids: list[str] = []
    for nombre, contacto, email, telefono, notas in PROVEEDORES:
        pid = new_id("PRO")
        conn.execute(
            "INSERT INTO proveedores (id, tienda_id, nombre, contacto, email, telefono, notas, activo, created_at) "
            "VALUES (?,?,?,?,?,?,?,1,?)",
            (pid, tienda_id, nombre, contacto, email, telefono, notas, _fecha(60)),
        )
        prov_ids.append(pid)

    productos: dict[str, dict] = {}
    for i, (nombre, sku, cat, precio, iva, coste, stock, minimo, unidad, marca, imagen, destacado) in enumerate(PRODUCTOS):
        pid = new_id("PRD")
        corta, larga = DESCRIPCIONES.get(sku, ("", ""))
        specs = json.dumps(
            [{"clave": k, "valor": v} for k, v in ESPECIFICACIONES.get(sku, [])], ensure_ascii=False
        )
        sello = _fecha(55 - (i % 10), 9, i)
        conn.execute(
            """INSERT INTO productos (id, tienda_id, sku, nombre, slug, descripcion, descripcion_corta, especificaciones,
                categoria_id, marca, unidad, precio, iva, stock, stock_minimo, coste_medio, valor_stock,
                imagen, activo, destacado, created_at, updated_at)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,0,?,?,0,?,1,?,?,?)""",
            (
                pid,
                tienda_id,
                sku,
                nombre,
                slugify(nombre),
                larga,
                corta,
                specs,
                cat_ids[cat],
                marca,
                unidad,
                precio,
                iva,
                minimo,
                coste,
                f"/static/img/products/{imagen}",
                destacado,
                sello,
                sello,
            ),
        )
        if stock > 0:
            kardex.entrada(
                conn,
                pid,
                stock,
                coste,
                tipo="entrada_ajuste",
                documento_tipo="inicial",
                documento_numero="Stock inicial",
                motivo="Carga inicial de inventario",
                fecha=_fecha(54 - (i % 10), 9, 20 + i),
            )
        productos[sku] = {"id": pid, "nombre": nombre, "precio": precio, "iva": iva, "coste": coste}

    # Compras y pedidos se ejecutan en orden cronológico para que el saldo del Kardex
    # sea siempre el saldo real en cada fecha (no se puede insertar una compra "pasada"
    # después de una venta posterior).
    compras = [
        {
            "proveedor_id": prov_ids[0],
            "fecha": _fecha(20, 11),
            "lineas": [("LIM-001", 24, 2.10), ("LIM-002", 12, 8.25), ("LIM-003", 48, 1.55)],
            "notas": "Reposición de línea de limpieza.",
        },
        {
            "proveedor_id": prov_ids[1],
            "fecha": _fecha(9, 16),
            "lineas": [("ADH-001", 12, 9.00), ("PES-001", 20, 5.00), ("CON-003", 15, 5.00)],
            "notas": "Pedido mensual de desechables.",
        },
    ]

    pedidos = [
        {"dias": 40, "estado": "entregado", "metodo": "transferencia", "items": [("PES-001", 3), ("ADH-001", 1), ("ACC-003", 2)], "nombre": "Marta Sanz", "email": "marta.sanz@example.com", "direccion": "Carrer de la Riera, 18", "ciudad": "Terrassa", "cp": "08221"},
        {"dias": 35, "estado": "entregado", "metodo": "bizum", "items": [("PES-002", 2), ("LIM-002", 1), ("ACC-001", 3)], "nombre": "Oficinas Bellvitge", "email": "compras@bellvitge.example.com", "direccion": "Av. Europa, 44", "ciudad": "L'Hospitalet", "cp": "08907"},
        {"dias": 28, "estado": "entregado", "metodo": "transferencia", "items": [("PES-003", 4), ("ADH-002", 1), ("LIM-003", 2)], "nombre": "Clínica Dental Sonrisa", "email": "admin@sonrisa.example.com", "direccion": "Calle Mayor, 12", "ciudad": "Sabadell", "cp": "08201"},
        {"dias": 24, "estado": "entregado", "metodo": "contrareembolso", "items": [("ACC-001", 5), ("ACC-002", 2), ("CON-001", 3)], "nombre": "Restaurante La Plaza", "email": "hola@laplaza.example.com", "direccion": "Plaza Nova, 3", "ciudad": "Rubí", "cp": "08191"},
        {"dias": 18, "estado": "entregado", "metodo": "bizum", "items": [("LIM-001", 2), ("LIM-002", 1), ("CON-003", 1)], "nombre": "Peluquería Estilo", "email": "estilo@example.com", "direccion": "Carrer Sant Joan, 9", "ciudad": "Sant Cugat", "cp": "08172"},
        {"dias": 12, "estado": "entregado", "metodo": "transferencia", "items": [("PES-001", 3), ("ADH-001", 1)], "nombre": "Catering Aurora", "email": "pedidos@aurora.example.com", "direccion": "Calle Indústria, 71", "ciudad": "Barcelona", "cp": "08025"},
        {"dias": 7, "estado": "enviado", "metodo": "bizum", "items": [("PES-002", 2), ("LIM-001", 1)], "nombre": "Gimnasio FitNord", "email": "compras@fitnord.example.com", "direccion": "Av. del Vallès, 120", "ciudad": "Terrassa", "cp": "08224"},
        {"dias": 3, "estado": "pagado", "metodo": "transferencia", "items": [("ACC-004", 1), ("ACC-005", 1)], "nombre": "Taller Mecànic Grau", "email": "taller@grau.example.com", "direccion": "Carrer del Ferro, 5", "ciudad": "Sabadell", "cp": "08202"},
        {"dias": 1, "estado": "pendiente", "metodo": "contrareembolso", "items": [("ACC-006", 1), ("ACC-003", 2)], "nombre": "Floristeria Vall", "email": "flor@vall.example.com", "direccion": "Carrer de la Pau, 22", "ciudad": "Terrassa", "cp": "08222"},
        {"dias": 0, "estado": "pendiente", "metodo": "bizum", "items": [("CON-002", 3), ("CON-004", 2), ("LIM-002", 1)], "nombre": "Coworking Nexo", "email": "hola@nexo.example.com", "direccion": "Carrer Tecnologia, 8", "ciudad": "Barcelona", "cp": "08018"},
        {"dias": 0, "estado": "pagado", "metodo": "transferencia", "items": [("CON-003", 1), ("PES-001", 1)], "nombre": "Centre Benestar Alba", "email": "alba@example.com", "direccion": "Carrer del Sol, 14", "ciudad": "Terrassa", "cp": "08223"},
    ]
    for i, pedido in enumerate(pedidos):
        pedido["fecha"] = _fecha(pedido["dias"], 10 + (i % 7), 5 + i)

    operaciones = [(c["fecha"], 0, "compra", c) for c in compras]
    operaciones += [(p["fecha"], 1, "pedido", p) for p in pedidos]
    operaciones.sort(key=lambda x: (x[0], x[1]))

    for fecha, _, tipo, op in operaciones:
        if tipo == "compra":
            numero = db.document_number(conn, "CMP", "compra")
            cid = new_id("CMP")
            base = money(sum(c * cost for _, c, cost in op["lineas"]))
            iva_total = money(sum(c * cost * (21 / 100) for _, c, cost in op["lineas"]))
            conn.execute(
                """INSERT INTO compras (id, tienda_id, numero, proveedor_id, fecha, estado, base, iva, total, notas,
                    recibida_at, creado_por, created_at) VALUES (?,?,?,?,?,'recibida',?,?,?,?,?,NULL,?)""",
                (cid, tienda_id, numero, op["proveedor_id"], fecha[:10], base, iva_total, money(base + iva_total), op["notas"], fecha, fecha),
            )
            for sku, cantidad, coste in op["lineas"]:
                p = productos[sku]
                conn.execute(
                    """INSERT INTO compra_lineas (id, compra_id, producto_id, nombre, sku, cantidad, coste_unit, iva, total)
                       VALUES (?,?,?,?,?,?,?,?,?)""",
                    (new_id("CLN"), cid, p["id"], p["nombre"], sku, cantidad, coste, 21, money(cantidad * coste)),
                )
                kardex.entrada(
                    conn,
                    p["id"],
                    cantidad,
                    coste,
                    tipo="entrada_compra",
                    documento_tipo="compra",
                    documento_id=cid,
                    documento_numero=numero,
                    motivo=f"Recepción de compra · {numero}",
                    fecha=fecha,
                )
        else:
            creado = orders.crear_pedido(
                conn,
                {
                    "cliente": {
                        "nombre": op["nombre"],
                        "email": op["email"],
                        "telefono": "+34 600 000 000",
                        "direccion": op["direccion"],
                        "ciudad": op["ciudad"],
                        "cp": op["cp"],
                        "provincia": "Barcelona",
                    },
                    "items": [{"producto_id": productos[sku]["id"], "cantidad": cant} for sku, cant in op["items"]],
                    "metodo_pago": op["metodo"],
                    "notas": "",
                },
                fecha=fecha,
                tienda_id=tienda_id,
            )
            _avanzar_estado(conn, creado["id"], op["estado"], fecha)

    # Pedidos ya avanzados: el pago está verificado o cobrado, y sus avisos leídos.
    conn.execute(
        "UPDATE pedidos SET pago_estado='verificado' WHERE tienda_id=? AND estado<>'pendiente' AND estado<>'cancelado' AND pago_estado='pendiente_verificacion'",
        (tienda_id,),
    )
    conn.execute(
        "UPDATE pedidos SET pago_estado='cobrado' WHERE tienda_id=? AND estado='entregado' AND pago_estado='pendiente_cobro'",
        (tienda_id,),
    )
    conn.execute(
        "UPDATE pedidos SET envio_pendiente=0 WHERE tienda_id=? AND estado<>'pendiente'",
        (tienda_id,),
    )
    conn.execute("UPDATE notificaciones SET leida=1 WHERE tienda_id=?", (tienda_id,))
    db.audit(conn, None, "demo.inicializada", "sistema", "", {"productos": len(productos), "pedidos": len(pedidos)})


def _avanzar_estado(conn, pedido_id: str, estado_final: str, fecha: str) -> None:
    if estado_final == "pendiente":
        return
    ruta = {
        "pagado": ["pagado"],
        "preparando": ["pagado", "preparando"],
        "preparado": ["pagado", "preparando", "preparado"],
        "enviado": ["pagado", "preparando", "preparado", "enviado"],
        "entregado": ["pagado", "preparando", "preparado", "enviado", "entregado"],
    }.get(estado_final, [])
    from .util import parse_dt, iso_at as _iso

    base = parse_dt(fecha)
    notas = {
        "pagado": "Pago confirmado",
        "preparando": "Pedido en preparación",
        "preparado": "Pedido preparado",
        "enviado": "Pedido entregado a la agencia",
        "entregado": "Entrega confirmada",
    }
    for n, estado in enumerate(ruta, start=1):
        sello = _iso(base + timedelta(minutes=25 * n))
        conn.execute(
            "INSERT INTO pedido_eventos (id, pedido_id, estado, nota, usuario_id, created_at) VALUES (?,?,?,?,NULL,?)",
            (new_id("PEV"), pedido_id, estado, notas[estado], sello),
        )
    conn.execute(
        "UPDATE pedidos SET estado=?, updated_at=? WHERE id=?",
        (estado_final, _iso(base + timedelta(minutes=25 * len(ruta))), pedido_id),
    )
