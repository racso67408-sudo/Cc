"""Límites sencillos en memoria para login y pedidos públicos."""
from __future__ import annotations

import threading
import time
from collections import defaultdict, deque

_lock = threading.Lock()
_intentos: dict[str, deque[float]] = defaultdict(deque)
_pedidos: dict[str, deque[float]] = defaultdict(deque)
_registros: dict[str, deque[float]] = defaultdict(deque)
_contactos: dict[str, deque[float]] = defaultdict(deque)


def _hit(store: dict[str, deque[float]], key: str, limit: int, seconds: int) -> bool:
    ahora = time.time()
    with _lock:
        cola = store[key]
        while cola and ahora - cola[0] > seconds:
            cola.popleft()
        if len(cola) >= limit:
            return False
        cola.append(ahora)
        return True


def login_permitido(ip: str) -> bool:
    return _hit(_intentos, ip or "?", 8, 600)


def pedido_permitido(ip: str) -> bool:
    return _hit(_pedidos, ip or "?", 20, 3600)


def contacto_permitido(ip: str) -> bool:
    return _hit(_contactos, ip or "?", 5, 3600)


def registro_tienda_permitido(ip: str) -> bool:
    return _hit(_registros, ip or "?", 5, 3600)


def reset_all() -> None:
    with _lock:
        _intentos.clear()
        _pedidos.clear()
        _registros.clear()
        _contactos.clear()
