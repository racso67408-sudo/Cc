"""Roles del equipo de cada tienda y qué puede hacer cada uno.

- admin: todas las funciones de la tienda. Máximo max_admins administradores por tienda.
- preparador: prepara pedidos (en preparación y preparado) y consulta pedidos, productos e inventario.
- domiciliario: ve solo su hoja de ruta (pedidos preparados con el pago listo) y registra las entregas.
- cliente: cuenta de comprador en la tienda pública.
"""
from __future__ import annotations

import re

from .util import ApiError

ROLES_EQUIPO = ("admin", "preparador", "domiciliario")
# Valores antiguos que siguen aceptándose en sesiones y datos.
ROLES_ANTIGUOS = {"propietario": "admin", "operador": "preparador"}
ROLES_NOMBRE = {"admin": "Administrador", "preparador": "Preparación", "domiciliario": "Domiciliario"}

ESTADOS_PREPARADOR = {"preparando", "preparado"}
ESTADOS_DOMICILIARIO = {"enviado", "entregado"}

_LECTURA_PREPARADOR = [
    r"^/api/admin/dashboard$",
    r"^/api/admin/pedidos$",
    r"^/api/admin/pedidos/[^/]+$",
    r"^/api/admin/pedidos/[^/]+/chat$",
    r"^/api/admin/productos$",
    r"^/api/admin/productos/[^/]+$",
    r"^/api/admin/productos/[^/]+/kardex$",
    r"^/api/admin/categorias$",
    r"^/api/admin/marcas$",
    r"^/api/admin/inventario$",
    r"^/api/admin/movimientos$",
]
_PREPARADOR_ESCRITURA = [
    r"^/api/admin/pedidos/[^/]+/estado$",
    r"^/api/admin/pedidos/[^/]+/chat$",
]
_DOMICILIARIO = [
    r"^/api/admin/ruta$",
    r"^/api/admin/pedidos/[^/]+$",
    r"^/api/admin/pedidos/[^/]+/estado$",
    r"^/api/admin/pedidos/[^/]+/confirmar-cobro$",
]


def normalizar(rol: str) -> str:
    return ROLES_ANTIGUOS.get(rol, rol)


def _coincide(patrones: list[str], ruta: str) -> bool:
    return any(re.match(p, ruta) for p in patrones)


def autorizar(rol: str, metodo: str, ruta: str) -> None:
    """Lanza 403 si el rol no puede usar esa ruta. Las comprobaciones de estado y pedido van en la API."""
    rol = normalizar(rol)
    if rol == "admin":
        return
    if rol == "preparador":
        if metodo == "GET" and _coincide(_LECTURA_PREPARADOR, ruta):
            return
        if metodo == "POST" and _coincide(_PREPARADOR_ESCRITURA, ruta):
            return
    if rol == "domiciliario":
        if metodo == "GET" and _coincide([_DOMICILIARIO[0], _DOMICILIARIO[1]], ruta):
            return
        if metodo == "POST" and _coincide(_DOMICILIARIO[2:], ruta):
            return
    raise ApiError("Tu rol no permite esta acción", 403)


def estados_permitidos(rol: str) -> set[str] | None:
    """None = sin restricción (admin). Conjunto de estados a los que puede pasar el rol."""
    rol = normalizar(rol)
    if rol == "preparador":
        return ESTADOS_PREPARADOR
    if rol == "domiciliario":
        return ESTADOS_DOMICILIARIO
    return None


def pago_listo_para_ruta(pedido: dict) -> bool:
    """El domiciliario solo sale con pedidos cuyo pago está verificado (o es contrareembolso)."""
    if pedido.get("envio_cobro") == "anticipado" and not int(pedido.get("envio_pagado") or 0):
        return False
    return pedido.get("pago_estado") in {"verificado", "cobrado", "pendiente_cobro"}
