"""Pedidos de la tienda: creación, estados, cancelación con devolución al Kardex y consulta pública."""
from __future__ import annotations

import hmac
import re
import secrets
from typing import Any

from . import db, kardex
from .catalog import promo_vigente
from .db import all_rows, document_number, one, setting
from .util import (
    ApiError,
    EMAIL_RE,
    iso_now,
    money,
    new_id,
    num,
    qty,
    txt,
)

METODOS = {
    "transferencia": "Transferencia bancaria",
    "cartera_digital": "Cartera digital",
    "contrareembolso": "Contrareembolso",
    "tarjeta_web": "Tarjeta (pago online)",
}
# Valores antiguos que se aceptan y se guardan con su nombre actual.
METODOS_ALIAS = {"bizum": "cartera_digital"}
# Métodos que se verifican por el administrador antes de preparar el pedido.
METODOS_VERIFICACION = {"transferencia", "cartera_digital"}
# Forma de entrega. Los envíos no tienen coste en el pedido: el administrador lo asigna después.
TIPOS_ENTREGA = {
    "recogida": "Recogida en tienda",
    "envio_propio": "Envío propio",
    "envio_transportista": "Envío por transportista (Correos, DHL…)",
}
TIPOS_CON_ENVIO = {"envio_propio", "envio_transportista"}
# Cómo se paga el envío: en la entrega (a cargo del destinatario) o por adelantado por otros medios.
ENVIO_COBROS = {
    "entrega": "Se cobra al recibir el pedido",
    "anticipado": "Pagado por adelantado",
}

# Pedidos que se pagan antes de prepararlos: tienen un plazo para pagar y, después, otro del administrador.
METODOS_CON_PLAZO = {"transferencia", "cartera_digital", "tarjeta_web"}

# Pago online: solo disponible si la tienda lo tiene activado (ajuste pago_web_activo).
# El cobro lo realiza la pasarela configurada en la otra instancia y lo confirma mediante
# confirmar_pago_web(). Mientras no se confirme, el pedido queda pendiente de pago.
PAGO_ESTADOS = {
    "no_aplica": "No aplica",
    "pendiente_pago_web": "Pendiente de pago online",
    "pendiente_verificacion": "Pendiente de verificar",
    "verificado": "Verificado",
    "pendiente_cobro": "Pendiente de cobro",
    "cobrado": "Cobrado",
}
ESTADOS = {
    "pendiente": "Pendiente",
    "pagado": "Pagado",
    "preparando": "En preparación",
    "preparado": "Preparado",
    "enviado": "Enviado",
    "entregado": "Entregado",
    "cancelado": "Cancelado",
}
TRANSICIONES = {
    "pendiente": {"pagado", "preparando", "cancelado"},
    "pagado": {"preparando", "preparado", "cancelado"},
    "preparando": {"preparado", "cancelado"},
    "preparado": {"enviado", "entregado", "cancelado"},  # entregado solo en recogida
    "enviado": {"entregado", "cancelado"},
    "entregado": set(),
    "cancelado": set(),
}
IVA_ENVIO = 21.0


def _cliente(data: dict, exigir_direccion: bool = True) -> dict:
    nombre = txt(data.get("nombre"), 120)
    email = txt(data.get("email"), 160).lower()
    direccion = txt(data.get("direccion"), 200)
    ciudad = txt(data.get("ciudad"), 80)
    cp = txt(data.get("cp"), 12)
    if len(nombre) < 2:
        raise ApiError("El nombre y los apellidos son obligatorios", 400, "nombre")
    if not EMAIL_RE.match(email):
        raise ApiError("El email no es válido", 400, "email")
    if exigir_direccion:
        if len(direccion) < 5:
            raise ApiError("La dirección de envío es obligatoria", 400, "direccion")
        if len(ciudad) < 2:
            raise ApiError("La ciudad es obligatoria", 400, "ciudad")
        if not cp:
            raise ApiError("El código postal es obligatorio", 400, "cp")
    return {
        "cliente_nombre": nombre,
        "cliente_email": email,
        "cliente_telefono": txt(data.get("telefono"), 30),
        "empresa": txt(data.get("empresa"), 120),
        "nif": txt(data.get("nif"), 20),
        "direccion": direccion,
        "ciudad": ciudad,
        "cp": cp,
        "provincia": txt(data.get("provincia"), 80),
        "pais": txt(data.get("pais"), 60) or "España",
    }


def _componentes_linea(conn, producto_id: str, cantidad: float) -> list[tuple[str, float, float]]:
    """Productos que salen del inventario por esta línea: el propio producto, o los componentes de un pack."""
    comps = all_rows(
        conn,
        "SELECT c.producto_id, c.cantidad, p.coste_medio FROM pack_componentes c JOIN productos p ON p.id=c.producto_id WHERE c.pack_id=?",
        (producto_id,),
    )
    if not comps:
        return [(producto_id, cantidad, None)]
    return [(c["producto_id"], float(c["cantidad"]) * cantidad, float(c["coste_medio"])) for c in comps]


def _descontar_linea(conn, linea: dict, pedido_id: str, numero: str, sello: str) -> None:
    for pid, cantidad, _ in _componentes_linea(conn, linea["producto_id"], linea["cantidad"]):
        kardex.salida(
            conn, pid, cantidad, tipo="salida_venta", documento_tipo="pedido", documento_id=pedido_id,
            documento_numero=numero, motivo="Venta online", fecha=sello,
        )


def _devolver_linea(conn, linea: dict, pedido: dict, sello: str, usuario_id: str | None) -> None:
    for pid, cantidad, coste in _componentes_linea(conn, linea["producto_id"], float(linea["cantidad"])):
        kardex.entrada(
            conn, pid, cantidad, coste, tipo="entrada_devolucion", documento_tipo="pedido", documento_id=pedido["id"],
            documento_numero=pedido["numero"], motivo=f"Cancelación de {pedido['numero']}", fecha=sello, usuario_id=usuario_id,
        )
    if int(linea.get("promo") or 0):
        conn.execute(
            """UPDATE productos SET promo_stock_restante = CASE WHEN promo_stock_restante + ? < promo_stock_inicial
               THEN promo_stock_restante + ? ELSE promo_stock_inicial END WHERE id=?""",
            (float(linea["cantidad"]), float(linea["cantidad"]), linea["producto_id"]),
        )


def _lineas(conn, items, tienda_id: str | None) -> list[dict]:
    if not isinstance(items, list) or not items:
        raise ApiError("Tu carrito está vacío")
    if len(items) > 40:
        raise ApiError("El pedido supera el máximo de 40 referencias")
    agrupados: dict[str, float] = {}
    for item in items:
        if not isinstance(item, dict):
            raise ApiError("Hay una línea del carrito no válida")
        pid = txt(item.get("producto_id") or item.get("id"), 40)
        cantidad = num(item.get("cantidad"), "La cantidad", 0.0001, 9999)
        if not pid:
            raise ApiError("Hay una línea del carrito sin producto")
        agrupados[pid] = qty(agrupados.get(pid, 0) + cantidad)
    if len(agrupados) > 40:
        raise ApiError("El pedido supera el máximo de 40 referencias")

    lineas = []
    for pid, cantidad in agrupados.items():
        p = one(conn, "SELECT * FROM productos WHERE id=? AND activo=1 AND tienda_id=?", (pid, tienda_id))
        if not p:
            raise ApiError("Uno de los productos ya no está disponible", 409)
        if one(conn, "SELECT id FROM productos WHERE padre_id=? LIMIT 1", (pid,)):
            raise ApiError(f"Elige una variante de «{p['nombre']}» (talla, color…) antes de añadirlo", 409)
        if float(p["stock"]) + 0.000001 < cantidad:
            raise ApiError(
                f"No hay stock suficiente de «{p['nombre']}». Disponible: {float(p['stock']):g} {p['unidad']}",
                409,
            )
        precio = float(p["precio"])
        en_promo = 0
        if promo_vigente(dict(p)):
            restante = float(p["promo_stock_restante"])
            if cantidad > restante + 0.000001:
                raise ApiError(
                    f"Solo quedan {restante:g} unidades de «{p['nombre']}» en promoción. Ajusta la cantidad.",
                    409,
                )
            precio = float(p["promo_precio"])
            en_promo = 1
        iva = float(p["iva"])
        total = money(precio * cantidad)
        lineas.append(
            {
                "producto_id": pid,
                "nombre": p["nombre"],
                "sku": p["sku"],
                "cantidad": cantidad,
                "promo": en_promo,
                "precio_unit": precio,
                "iva": iva,
                "total": total,
                "coste_unit": float(p["coste_medio"]),
            }
        )
    return lineas


def _totales(conn, lineas: list[dict], metodo_pago: str, tienda_id: str | None = None) -> dict:
    # El total no incluye el envío: el administrador lo asigna después (envio, envio_pendiente).
    productos = money(sum(l["total"] for l in lineas))
    base = money(sum(l["total"] / (1 + l["iva"] / 100) if l["iva"] else l["total"] for l in lineas))
    recargo = 0.0
    if metodo_pago == "contrareembolso":
        # settings_all incluye los valores por defecto (setting solo lee lo guardado).
        recargo = money(db.settings_all(conn, tienda_id).get("recargo_contrareembolso", "0") or 0)
    total = money(productos + recargo)
    return {
        "base": money(base + recargo),
        "iva": money(total - base - recargo),
        "envio": 0.0,
        "total": total,
        "productos": productos,
        "recargo": recargo,
    }


def _fecha_hora_recogida(data: dict) -> tuple[str, str]:
    """Fecha (YYYY-MM-DD, no anterior a hoy) y hora aproximada (HH:MM) para recoger el pedido."""
    from datetime import date as _date

    from .util import biz_today

    fecha_txt = txt(data.get("recogida_fecha"), 10)
    hora_txt = txt(data.get("recogida_hora"), 5)
    try:
        fecha = _date.fromisoformat(fecha_txt)
    except ValueError:
        raise ApiError("Indica la fecha aproximada de recogida", 400, "recogida_fecha")
    if fecha < biz_today():
        raise ApiError("La fecha de recogida no puede ser anterior a hoy", 400, "recogida_fecha")
    if not re.fullmatch(r"([01]\d|2[0-3]):[0-5]\d", hora_txt):
        raise ApiError("Indica la hora aproximada de recogida (HH:MM)", 400, "recogida_hora")
    return fecha.isoformat(), hora_txt


def _plazos_pago(conn, tienda_id: str | None, creado) -> tuple[str, str]:
    """Plazo para que el cliente pague y momento de la cancelación automática (plazo + gracia del administrador)."""
    from datetime import timedelta

    ajustes = db.settings_all(conn, tienda_id)
    horas = int(float(ajustes.get("pago_plazo_horas", "8") or 8))
    gracia = int(float(ajustes.get("pago_gracia_admin_horas", "24") or 24))
    vence = creado + timedelta(hours=horas)
    cancela = vence + timedelta(hours=gracia)
    return vence.isoformat(timespec="seconds"), cancela.isoformat(timespec="seconds")


def crear_pedido(conn, data: dict, *, ip: str = "", fecha: str | None = None, usuario_id: str | None = None, tienda_id: str | None = None) -> dict:
    tipo_entrega = txt(data.get("tipo_entrega"), 40) or "envio_transportista"
    if tipo_entrega not in TIPOS_ENTREGA:
        raise ApiError("La forma de entrega no es válida", 400, "tipo_entrega")
    cliente = _cliente(data.get("cliente") or data, exigir_direccion=tipo_entrega != "recogida")
    recogida_fecha = recogida_hora = ""
    if tipo_entrega == "recogida":
        cliente["direccion"] = cliente["direccion"] or "Recogida en tienda"
        recogida_fecha, recogida_hora = _fecha_hora_recogida(data)
    metodo = txt(data.get("metodo_pago"), 24).lower() or "transferencia"
    metodo = METODOS_ALIAS.get(metodo, metodo)
    if metodo not in METODOS:
        raise ApiError("Método de pago no válido")
    lineas = _lineas(conn, data.get("items"), tienda_id)
    totales = _totales(conn, lineas, metodo, tienda_id)
    envio_pendiente = 1 if tipo_entrega in TIPOS_CON_ENVIO else 0
    sello = fecha or iso_now()
    numero = document_number(conn, "PED", "pedido")
    pedido_id = new_id("PED")
    token = secrets.token_urlsafe(24)
    if metodo == "tarjeta_web" and setting(conn, "pago_web_activo", "0", tienda_id) != "1":
        raise ApiError("El pago con tarjeta no está disponible en esta tienda", 400, "metodo_pago")
    if metodo == "tarjeta_web":
        pago_inicial = "pendiente_pago_web"
    else:
        pago_inicial = "pendiente_verificacion" if metodo in METODOS_VERIFICACION else "pendiente_cobro"
    conn.execute(
        """INSERT INTO pedidos (id, tienda_id, numero, token, cliente_nombre, cliente_email, cliente_telefono,
            empresa, nif, direccion, ciudad, cp, provincia, pais, metodo_pago, estado, base, iva,
            envio, total, notas, stock_descontado, stock_devuelto, cliente_id, created_at, updated_at, pago_estado,
            tipo_entrega, envio_pendiente, recogida_fecha, recogida_hora)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'pendiente',?,?,?,?,?,1,0,?,?,?,?,?,?,?,?)""",
        (
            pedido_id,
            tienda_id,
            numero,
            token,
            cliente["cliente_nombre"],
            cliente["cliente_email"],
            cliente["cliente_telefono"],
            cliente["empresa"],
            cliente["nif"],
            cliente["direccion"],
            cliente["ciudad"],
            cliente["cp"],
            cliente["provincia"],
            cliente["pais"],
            metodo,
            totales["base"],
            totales["iva"],
            totales["envio"],
            totales["total"],
            txt(data.get("notas"), 500),
            usuario_id,
            sello,
            sello,
            pago_inicial,
            tipo_entrega,
            envio_pendiente,
            recogida_fecha,
            recogida_hora,
        ),
    )
    if metodo in METODOS_CON_PLAZO and fecha is None:
        # Solo pedidos en vivo: los importados (fecha indicada) no caducan automáticamente.
        from datetime import datetime as _dt

        vence, cancela = _plazos_pago(conn, tienda_id, _dt.now().astimezone())
        conn.execute("UPDATE pedidos SET pago_vence_at=?, pago_cancela_at=? WHERE id=?", (vence, cancela, pedido_id))
    for linea in lineas:
        conn.execute(
            """INSERT INTO pedido_lineas (id, pedido_id, producto_id, nombre, sku, cantidad, precio_unit,
                iva, total, coste_unit, promo) VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            (
                new_id("LIN"),
                pedido_id,
                linea["producto_id"],
                linea["nombre"],
                linea["sku"],
                linea["cantidad"],
                linea["precio_unit"],
                linea["iva"],
                linea["total"],
                linea["coste_unit"],
                linea.get("promo", 0),
            ),
        )
        _descontar_linea(conn, linea, pedido_id, numero, sello)
        if linea.get("promo"):
            conn.execute(
                """UPDATE productos SET promo_stock_restante = CASE WHEN promo_stock_restante - ? > 0
                   THEN promo_stock_restante - ? ELSE 0 END WHERE id=?""",
                (linea["cantidad"], linea["cantidad"], linea["producto_id"]),
            )
    conn.execute(
        "INSERT INTO pedido_eventos (id, pedido_id, estado, nota, usuario_id, created_at) VALUES (?,?,?,?,?,?)",
        (new_id("PEV"), pedido_id, "pendiente", "Pedido recibido en la tienda", None, sello),
    )
    db.audit(
        conn,
        None,
        "pedido.creado",
        "pedido",
        pedido_id,
        {"numero": numero, "total": totales["total"], "lineas": len(lineas)},
        ip,
    )
    if envio_pendiente and tienda_id:
        crear_notificacion(
            conn, tienda_id, "envio_pendiente", pedido_id,
            f"Pedido {numero} · asigna el coste de envío ({TIPOS_ENTREGA[tipo_entrega].lower()})",
        )
    if metodo in METODOS_VERIFICACION and tienda_id:
        crear_notificacion(
            conn,
            tienda_id,
            "pago_pendiente",
            pedido_id,
            f"Pedido {numero} · {totales['total']:.2f} € · pendiente de verificar el pago ({METODOS[metodo].lower()}) · {cliente['cliente_nombre']}",
        )
    return {
        "id": pedido_id,
        "numero": numero,
        "token": token,
        "total": totales["total"],
        "estado": "pendiente",
        "envio": totales["envio"],
        "metodo_pago": metodo,
        "pago_estado": pago_inicial,
        "tipo_entrega": tipo_entrega,
        "envio_pendiente": bool(envio_pendiente),
        "recogida_fecha": recogida_fecha,
        "recogida_hora": recogida_hora,
    }


def _row_pedido(conn, numero: str) -> dict:
    fila = one(conn, "SELECT * FROM pedidos WHERE numero=?", (numero,))
    if not fila:
        raise ApiError("Pedido no encontrado", 404)
    return dict(fila)


def _lineas_pedido(conn, pedido_id: str) -> list[dict]:
    filas = all_rows(conn, "SELECT * FROM pedido_lineas WHERE pedido_id=? ORDER BY rowid", (pedido_id,))
    return [dict(f) for f in filas]


def _eventos(conn, pedido_id: str) -> list[dict]:
    filas = all_rows(
        conn,
        """SELECT e.*, u.nombre AS usuario FROM pedido_eventos e
           LEFT JOIN usuarios u ON u.id=e.usuario_id
           WHERE e.pedido_id=? ORDER BY e.created_at ASC, e.rowid ASC""",
        (pedido_id,),
    )
    return [dict(f) for f in filas]


def _serializar(pedido: dict, lineas: list[dict], eventos: list[dict], *, publico: bool) -> dict:
    d = {k: v for k, v in pedido.items() if k != "token"}
    d["total"] = money(d["total"])
    d["base"] = money(d["base"])
    d["iva"] = money(d["iva"])
    d["envio"] = money(d["envio"])
    d["estado_label"] = ESTADOS.get(d["estado"], d["estado"])
    d["metodo_pago_label"] = METODOS.get(d["metodo_pago"], d["metodo_pago"])
    d["pago_estado_label"] = PAGO_ESTADOS.get(d.get("pago_estado") or "", "")
    d["pago_estado_label"] = "Cancelado: sin pago" if d.get("pago_estado") == "cancelado_sin_pago" else d["pago_estado_label"]
    d["pago_vence_at"] = d.get("pago_vence_at") or ""
    d["pago_cancela_at"] = d.get("pago_cancela_at") or ""
    d["pago_vencido"] = _pago_vencido(d)
    d["tipo_entrega_label"] = TIPOS_ENTREGA.get(d.get("tipo_entrega") or "", "")
    d["recogida_fecha"] = d.get("recogida_fecha") or ""
    d["envio_cobro"] = d.get("envio_cobro") or ""
    d["envio_cobro_label"] = ENVIO_COBROS.get(d["envio_cobro"], "")
    d["envio_pagado"] = bool(d.get("envio_pagado"))
    d["envio_cobrado"] = bool(d.get("envio_cobrado"))
    d["recogida_hora"] = d.get("recogida_hora") or ""
    d["envio_pendiente"] = bool(d.get("envio_pendiente"))
    d["envio"] = money(d.get("envio") or 0)
    cobro = _cobro_en_entrega(d)
    d["a_cobrar"] = cobro["importe"] if cobro["pendiente"] and not d["envio_pendiente"] else None
    d["lineas"] = []
    for l in lineas:
        item = {
            "id": l["id"],
            "producto_id": l["producto_id"],
            "nombre": l["nombre"],
            "sku": l["sku"],
            "cantidad": float(l["cantidad"]),
            "precio_unit": money(l["precio_unit"]),
            "iva": float(l["iva"]),
            "total": money(l["total"]),
        }
        if not publico:
            item["coste_unit"] = money(l["coste_unit"])
        d["lineas"].append(item)
    d["eventos"] = [
        {
            "estado": e["estado"],
            "estado_label": ESTADOS.get(e["estado"], e["estado"]),
            "nota": e["nota"],
            "created_at": e["created_at"],
            "usuario": e.get("usuario") or "",
        }
        for e in eventos
    ]
    d["unidades"] = qty(sum(float(l["cantidad"]) for l in lineas))
    if publico:
        for clave in ("stock_descontado", "stock_devuelto", "cliente_telefono", "nif"):
            d.pop(clave, None)
    return d


def pedido_publico(conn, numero: str, token: str) -> dict:
    pedido = _row_pedido(conn, numero)
    if not token or not hmac.compare_digest(str(token), str(pedido["token"])):
        raise ApiError("Enlace de pedido no válido", 403)
    return _serializar(pedido, _lineas_pedido(conn, pedido["id"]), _eventos(conn, pedido["id"]), publico=True)


def pedido_admin(conn, pedido_id: str) -> dict:
    fila = one(conn, "SELECT * FROM pedidos WHERE id=?", (pedido_id,))
    if not fila:
        raise ApiError("Pedido no encontrado", 404)
    pedido = dict(fila)
    d = _serializar(pedido, _lineas_pedido(conn, pedido_id), _eventos(conn, pedido_id), publico=False)
    d["cliente"] = {
        "nombre": pedido["cliente_nombre"],
        "email": pedido["cliente_email"],
        "telefono": pedido["cliente_telefono"],
        "empresa": pedido["empresa"],
        "nif": pedido["nif"],
        "direccion": pedido["direccion"],
        "ciudad": pedido["ciudad"],
        "cp": pedido["cp"],
        "provincia": pedido["provincia"],
        "pais": pedido["pais"],
    }
    return d


def listar_admin(
    conn,
    *,
    estado: str = "",
    q: str = "",
    desde: str = "",
    hasta: str = "",
    pagina: int = 1,
    por_pagina: int = 20,
    tienda_id: str | None,
) -> dict:
    where = ["1=1"]
    params: list[Any] = []
    where.append("p.tienda_id=?")
    params.append(tienda_id)
    if estado == "por_preparar":
        # Pedidos que hay que preparar: aún no enviados (incluye los pendientes de pago, con aviso).
        where.append("p.estado IN ('pendiente','pagado','preparando')")
    elif estado and estado in ESTADOS:
        where.append("p.estado=?")
        params.append(estado)
    if q:
        like = f"%{q}%"
        where.append("(p.numero LIKE ? OR p.cliente_nombre LIKE ? OR p.cliente_email LIKE ? OR p.empresa LIKE ?)")
        params += [like, like, like, like]
    if desde:
        where.append("substr(p.created_at,1,10)>=?")
        params.append(desde[:10])
    if hasta:
        where.append("substr(p.created_at,1,10)<=?")
        params.append(hasta[:10])
    filtro = " AND ".join(where)
    total = one(conn, f"SELECT COUNT(*) AS n FROM pedidos p WHERE {filtro}", params)["n"]
    pagina = max(1, int(pagina))
    por_pagina = min(100, max(1, int(por_pagina)))
    filas = all_rows(
        conn,
        f"""SELECT p.*, (SELECT COUNT(*) FROM pedido_lineas l WHERE l.pedido_id=p.id) AS referencias,
                   (SELECT COALESCE(SUM(l.cantidad),0) FROM pedido_lineas l WHERE l.pedido_id=p.id) AS unidades
            FROM pedidos p WHERE {filtro}
            ORDER BY p.created_at DESC, p.rowid DESC LIMIT ? OFFSET ?""",
        params + [por_pagina, (pagina - 1) * por_pagina],
    )
    items = []
    for f in filas:
        d = dict(f)
        d["total"] = money(d["total"])
        d["estado_label"] = ESTADOS.get(d["estado"], d["estado"])
        d["metodo_pago_label"] = METODOS.get(d["metodo_pago"], d["metodo_pago"])
        d.pop("token", None)
        items.append(d)
    conteos = {k: 0 for k in ESTADOS}
    for f in all_rows(conn, "SELECT estado, COUNT(*) AS n FROM pedidos GROUP BY estado"):
        conteos[f["estado"]] = int(f["n"])
    resumen = one(
        conn,
        """SELECT COUNT(*) AS pedidos,
                  COALESCE(SUM(CASE WHEN estado IN ('pagado','preparando','enviado','entregado') THEN total ELSE 0 END),0) AS ventas,
                  COALESCE(SUM(CASE WHEN estado='pendiente' THEN total ELSE 0 END),0) AS pendiente
           FROM pedidos""",
    )
    return {
        "items": items,
        "total": int(total),
        "pagina": pagina,
        "paginas": max(1, (int(total) + por_pagina - 1) // por_pagina),
        "conteos": conteos,
        "resumen": {
            "pedidos": int(resumen["pedidos"]),
            "ventas": money(resumen["ventas"]),
            "pendiente": money(resumen["pendiente"]),
        },
    }


def _cambiar(conn, pedido: dict, nuevo: str, nota: str, usuario_id: str | None) -> None:
    sello = iso_now()
    conn.execute("UPDATE pedidos SET estado=?, updated_at=? WHERE id=?", (nuevo, sello, pedido["id"]))
    conn.execute(
        "INSERT INTO pedido_eventos (id, pedido_id, estado, nota, usuario_id, created_at) VALUES (?,?,?,?,?,?)",
        (new_id("PEV"), pedido["id"], nuevo, txt(nota, 240), usuario_id, sello),
    )


def cambiar_estado(conn, pedido_id: str, nuevo: str, *, nota: str = "", usuario_id: str | None = None) -> dict:
    pedido = one(conn, "SELECT * FROM pedidos WHERE id=?", (pedido_id,))
    if not pedido:
        raise ApiError("Pedido no encontrado", 404)
    pedido = dict(pedido)
    nuevo = txt(nuevo, 24).lower()
    if nuevo not in ESTADOS:
        raise ApiError("Estado no válido")
    if nuevo == pedido["estado"]:
        return pedido_admin(conn, pedido_id)
    if nuevo not in TRANSICIONES.get(pedido["estado"], set()):
        raise ApiError(f"No se puede pasar de «{ESTADOS[pedido['estado']]}» a «{ESTADOS[nuevo]}»", 409)
    if nuevo == "enviado" and pedido.get("envio_pendiente"):
        raise ApiError("Asigna primero el coste de envío del pedido", 409)
    if nuevo == "entregado" and pedido["estado"] == "preparado" and pedido.get("tipo_entrega") in TIPOS_CON_ENVIO:
        raise ApiError("Pasa primero el pedido a «Enviado» antes de registrar la entrega", 409)
    if nuevo == "entregado" and _cobro_en_entrega(pedido)["pendiente"]:
        raise ApiError("Usa «Entregado y cobrado» para registrar el cobro en la entrega", 409)
    if nuevo == "entregado" and pedido.get("envio_cobro") == "anticipado" and not int(pedido.get("envio_pagado") or 0):
        raise ApiError("El envío debe estar pagado antes de entregar el pedido", 409)
    if nuevo == "cancelado":
        return cancelar_pedido(conn, pedido_id, nota=nota, usuario_id=usuario_id)
    _cambiar(conn, pedido, nuevo, nota, usuario_id)
    db.audit(conn, usuario_id, "pedido.estado", "pedido", pedido_id, {"de": pedido["estado"], "a": nuevo})
    return pedido_admin(conn, pedido_id)


def cancelar_pedido(conn, pedido_id: str, *, nota: str = "", usuario_id: str | None = None) -> dict:
    fila = one(conn, "SELECT * FROM pedidos WHERE id=?", (pedido_id,))
    if not fila:
        raise ApiError("Pedido no encontrado", 404)
    pedido = dict(fila)
    if pedido["estado"] == "cancelado":
        raise ApiError("El pedido ya está cancelado", 409)
    if pedido["estado"] == "entregado":
        raise ApiError("Un pedido entregado no se cancela: registra una entrada por devolución", 409)
    if not int(pedido["stock_descontado"]) or int(pedido["stock_devuelto"]):
        raise ApiError("El stock de este pedido ya se había devuelto", 409)
    sello = iso_now()
    lineas = _lineas_pedido(conn, pedido_id)
    for linea in lineas:
        _devolver_linea(conn, linea, pedido, sello, usuario_id)
    conn.execute(
        "UPDATE pedidos SET estado='cancelado', stock_devuelto=1, updated_at=? WHERE id=?",
        (sello, pedido_id),
    )
    conn.execute(
        "INSERT INTO pedido_eventos (id, pedido_id, estado, nota, usuario_id, created_at) VALUES (?,?,?,?,?,?)",
        (
            new_id("PEV"),
            pedido_id,
            "cancelado",
            txt(nota, 240) or "Pedido cancelado. Stock devuelto al inventario.",
            usuario_id,
            sello,
        ),
    )
    db.audit(
        conn,
        usuario_id,
        "pedido.cancelado",
        "pedido",
        pedido_id,
        {"numero": pedido["numero"], "nota": nota},
    )
    return pedido_admin(conn, pedido_id)


def listar_por_cliente(conn, usuario_id: str, email: str, tienda_id: str | None) -> dict:
    where = ["p.cliente_id=?"]
    params = [usuario_id]
    if email:
        where.append("OR p.cliente_email=?")
        params.append(email)
    filtro = " AND (".join(where) + ")" if len(where) > 1 else where[0]
    # simpler: cliente_id OR email
    filtro = "(p.cliente_id=? OR p.cliente_email=?)"
    params = [usuario_id, email or ""]
    filtro = f"({filtro}) AND p.tienda_id=?"
    params.append(tienda_id)
    total = one(conn, f"SELECT COUNT(*) AS n FROM pedidos p WHERE {filtro}", params)["n"]
    filas = all_rows(conn, f"""SELECT p.*, (SELECT COUNT(*) FROM pedido_lineas l WHERE l.pedido_id=p.id) AS referencias,
               (SELECT COALESCE(SUM(l.cantidad),0) FROM pedido_lineas l WHERE l.pedido_id=p.id) AS unidades
        FROM pedidos p WHERE {filtro} ORDER BY p.created_at DESC LIMIT 50""", params)
    items = []
    for f in filas:
        d = dict(f)
        d["total"] = money(d["total"])
        d["estado_label"] = ESTADOS.get(d["estado"], d["estado"])
        d["metodo_pago_label"] = METODOS.get(d["metodo_pago"], d["metodo_pago"])
        d.pop("token", None)
        items.append(d)
    return {"items": items, "total": int(total)}

def pedido_cliente(conn, numero: str, usuario: dict) -> dict:
    pedido = _row_pedido(conn, numero)
    if pedido.get("cliente_id") and pedido["cliente_id"] != usuario["id"] and pedido["cliente_email"].lower() != (usuario.get("email") or "").lower():
        raise ApiError("No tienes acceso a este pedido", 403)
    if not pedido.get("cliente_id") and pedido["cliente_email"].lower() != (usuario.get("email") or "").lower():
        raise ApiError("No tienes acceso a este pedido", 403)
    return _serializar(pedido, _lineas_pedido(conn, pedido["id"]), _eventos(conn, pedido["id"]), publico=True)


def ultimos(conn, limite: int = 6, *, tienda_id: str | None) -> list[dict]:
    filas = all_rows(
        conn,
        """SELECT p.*, (SELECT COUNT(*) FROM pedido_lineas l WHERE l.pedido_id=p.id) AS referencias
           FROM pedidos p WHERE p.tienda_id=? ORDER BY p.created_at DESC, p.rowid DESC LIMIT ?""",
        (tienda_id, limite),
    )
    out = []
    for f in filas:
        d = dict(f)
        d["total"] = money(d["total"])
        d["estado_label"] = ESTADOS.get(d["estado"], d["estado"])
        d.pop("token", None)
        out.append(d)
    return out



# ----------------------------------------------------------------------
# Pagos pendientes: verificación de transferencias y carteras, cobro en contrareembolso

def _pedido_con_pago(conn, pedido_id: str) -> dict:
    fila = one(conn, "SELECT * FROM pedidos WHERE id=?", (pedido_id,))
    if not fila:
        raise ApiError("Pedido no encontrado", 404)
    return dict(fila)


def verificar_pago(conn, pedido_id: str, usuario_id: str | None = None) -> dict:
    pedido = _pedido_con_pago(conn, pedido_id)
    if pedido.get("pago_estado") != "pendiente_verificacion":
        raise ApiError("Este pedido no tiene un pago pendiente de verificar", 409)
    if pedido["estado"] == "cancelado":
        raise ApiError("No se puede verificar el pago de un pedido cancelado", 409)
    sello = iso_now()
    conn.execute("UPDATE pedidos SET pago_estado='verificado', updated_at=? WHERE id=?", (sello, pedido_id))
    if pedido["estado"] == "pendiente":
        _cambiar(conn, pedido, "pagado", "Pago verificado por la tienda", usuario_id)
    else:
        conn.execute(
            "INSERT INTO pedido_eventos (id, pedido_id, estado, nota, usuario_id, created_at) VALUES (?,?,?,?,?,?)",
            (new_id("PEV"), pedido_id, pedido["estado"], "Pago verificado por la tienda", usuario_id, sello),
        )
    conn.execute("UPDATE notificaciones SET leida=1 WHERE tienda_id=? AND referencia=?", (pedido["tienda_id"], pedido_id))
    db.audit(conn, usuario_id, "pedido.pago_verificado", "pedido", pedido_id, {"numero": pedido["numero"]})
    return pedido_admin(conn, pedido_id)


def confirmar_pago_web(conn, numero: str, referencia: str) -> dict:
    """Confirma un pago online recibido desde la pasarela. Idempotente por pedido."""
    pedido = dict(one(conn, "SELECT * FROM pedidos WHERE numero=?", (numero,)) or {})
    if not pedido:
        raise ApiError("Pedido no encontrado", 404)
    if pedido.get("pago_estado") == "verificado":
        return {"numero": numero, "ya_confirmado": True}
    if pedido.get("pago_estado") != "pendiente_pago_web":
        raise ApiError("Este pedido no espera un pago online", 409)
    if pedido["estado"] == "cancelado":
        raise ApiError("No se puede confirmar el pago de un pedido cancelado", 409)
    sello = iso_now()
    conn.execute("UPDATE pedidos SET pago_estado='verificado', updated_at=? WHERE id=?", (sello, pedido["id"]))
    if pedido["estado"] == "pendiente":
        _cambiar(conn, pedido, "pagado", f"Pago online confirmado (ref. {txt(referencia, 60)})", None)
    db.audit(conn, None, "pedido.pago_web_confirmado", "pedido", pedido["id"], {"numero": numero, "referencia": txt(referencia, 60)})
    return {"numero": numero, "ya_confirmado": False}


def verificar_envio(conn, pedido_id: str, usuario_id: str | None = None) -> dict:
    pedido = _pedido_con_pago(conn, pedido_id)
    if pedido.get("envio_cobro") != "anticipado" or int(pedido.get("envio_pendiente") or 0):
        raise ApiError("Este envío no está pendiente de pago por adelantado", 409)
    if int(pedido.get("envio_pagado") or 0):
        raise ApiError("El pago del envío ya está verificado", 409)
    if pedido["estado"] == "cancelado":
        raise ApiError("No se puede verificar el envío de un pedido cancelado", 409)
    sello = iso_now()
    conn.execute("UPDATE pedidos SET envio_pagado=1, updated_at=? WHERE id=?", (sello, pedido_id))
    conn.execute(
        "INSERT INTO pedido_eventos (id, pedido_id, estado, nota, usuario_id, created_at) VALUES (?,?,?,?,?,?)",
        (new_id("PEV"), pedido_id, pedido["estado"], f"Pago del envío verificado ({money(pedido['envio'])} €)", usuario_id, sello),
    )
    conn.execute(
        "UPDATE notificaciones SET leida=1 WHERE tienda_id=? AND referencia=? AND tipo='envio_pago_pendiente'",
        (pedido["tienda_id"], pedido_id),
    )
    db.audit(conn, usuario_id, "pedido.envio_pagado", "pedido", pedido_id, {"numero": pedido["numero"]})
    return pedido_admin(conn, pedido_id)


def confirmar_cobro(conn, pedido_id: str, usuario_id: str | None = None) -> dict:
    """Contrareembolso: el repartidor confirma la entrega y el cobro."""
    pedido = _pedido_con_pago(conn, pedido_id)
    cobro = _cobro_en_entrega(pedido)
    if not cobro["pendiente"]:
        raise ApiError("No hay importes pendientes de cobro en la entrega", 409)
    if pedido["estado"] != "enviado":
        raise ApiError("Solo se puede confirmar el cobro cuando el pedido está enviado", 409)
    if pedido.get("envio_pendiente"):
        raise ApiError("Asigna primero el coste de envío del pedido", 409)
    sello = iso_now()
    if cobro["producto"]:
        conn.execute("UPDATE pedidos SET pago_estado='cobrado', updated_at=? WHERE id=?", (sello, pedido_id))
    if cobro["envio"]:
        conn.execute("UPDATE pedidos SET envio_cobrado=1, updated_at=? WHERE id=?", (sello, pedido_id))
    _cambiar(conn, pedido, "entregado", "Entrega y cobro confirmados por el repartidor", usuario_id)
    db.audit(conn, usuario_id, "pedido.cobro_confirmado", "pedido", pedido_id, {"numero": pedido["numero"]})
    return pedido_admin(conn, pedido_id)


def asignar_envio(conn, pedido_id: str, importe: float, transportista: str = "", seguimiento: str = "", usuario_id: str | None = None, cobro: str = "") -> dict:
    """Asigna el coste de envío de un pedido con envío. Se puede corregir mientras no esté enviado."""
    pedido = _pedido_con_pago(conn, pedido_id)
    if pedido.get("tipo_entrega") not in TIPOS_CON_ENVIO:
        raise ApiError("Este pedido no requiere envío (recogida en tienda)", 409)
    if pedido["estado"] in {"enviado", "entregado", "cancelado"}:
        raise ApiError("El coste de envío ya no se puede cambiar en este estado", 409)
    try:
        coste = float(importe)
    except (TypeError, ValueError):
        raise ApiError("Indica un importe de envío válido", 400, "importe")
    if coste < 0 or coste > 9999:
        raise ApiError("El importe de envío debe estar entre 0 y 9999 €", 400, "importe")
    coste = money(coste)
    # Envío propio: siempre se cobra en la entrega. Transportista: lo elige el administrador.
    if pedido.get("tipo_entrega") == "envio_propio":
        cobro = "entrega"
    elif cobro not in ENVIO_COBROS:
        raise ApiError("Indica cómo se paga el envío: en la entrega o por adelantado", 400, "cobro")
    if int(pedido.get("envio_pagado") or 0) or int(pedido.get("envio_cobrado") or 0):
        if cobro != pedido.get("envio_cobro"):
            raise ApiError("El envío ya está pagado: no se puede cambiar su forma de cobro", 409)
    tr = txt(transportista, 60)
    seg = txt(seguimiento, 80)
    sello = iso_now()
    conn.execute(
        "UPDATE pedidos SET envio=?, envio_pendiente=0, envio_cobro=?, transportista=?, seguimiento=?, updated_at=? WHERE id=?",
        (coste, cobro, tr, seg, sello, pedido_id),
    )
    detalle = f"Envío asignado: {coste:.2f} € · {ENVIO_COBROS[cobro].lower()}" + (f" · {tr}" if tr else "") + (f" · seguimiento {seg}" if seg else "")
    conn.execute(
        "INSERT INTO pedido_eventos (id, pedido_id, estado, nota, usuario_id, created_at) VALUES (?,?,?,?,?,?)",
        (new_id("PEV"), pedido_id, pedido["estado"], detalle, usuario_id, sello),
    )
    conn.execute(
        "UPDATE notificaciones SET leida=1 WHERE tienda_id=? AND referencia=? AND tipo='envio_pendiente'",
        (pedido["tienda_id"], pedido_id),
    )
    if cobro == "anticipado" and coste > 0:
        crear_notificacion(
            conn, pedido["tienda_id"], "envio_pago_pendiente", pedido_id,
            f"Pedido {pedido['numero']} · envío de {coste:.2f} € pendiente de pago por adelantado",
        )
    db.audit(conn, usuario_id, "pedido.envio_asignado", "pedido", pedido_id, {"numero": pedido["numero"], "importe": coste})
    return pedido_admin(conn, pedido_id)


def _cobro_en_entrega(pedido: dict) -> dict:
    """Qué debe cobrar el repartidor al entregar: producto (contrareembolso) y/o envío (cobro en entrega)."""
    cobra_producto = pedido.get("pago_estado") == "pendiente_cobro"
    cobra_envio = (
        pedido.get("envio_cobro") == "entrega"
        and not int(pedido.get("envio_cobrado") or 0)
        and not int(pedido.get("envio_pendiente") or 0)
        and pedido.get("tipo_entrega") in TIPOS_CON_ENVIO
    )
    if not (cobra_producto or cobra_envio):
        return {"pendiente": False, "importe": 0.0, "producto": False, "envio": False, "importe_pendiente_envio": False}
    total = money(pedido["total"]) if cobra_producto else 0.0
    envio = money(pedido.get("envio") or 0) if cobra_envio else 0.0
    return {
        "pendiente": True,
        "importe": money(total + envio),
        "producto": cobra_producto,
        "envio": cobra_envio,
        "importe_pendiente_envio": False,
    }


def procesar_vencimientos(conn, ahora=None) -> int:
    """Cancela los pedidos sin pago cuyo plazo (cliente + gracia del administrador) ha pasado. Devuelve cuántos."""
    from datetime import datetime as _dt

    from .util import parse_dt

    ahora = ahora or _dt.now().astimezone()
    candidatos = all_rows(
        conn,
        """SELECT id, numero, tienda_id, pago_cancela_at FROM pedidos
           WHERE pago_estado IN ('pendiente_verificacion','pendiente_pago_web') AND estado<>'cancelado'
           AND pago_cancela_at<>''""",
    )
    canceladas = 0
    for c in candidatos:
        if parse_dt(c["pago_cancela_at"]) > ahora:
            continue
        cancelar_pedido(conn, c["id"], nota="Cancelado automáticamente: no se recibió el pago en el plazo. Stock devuelto.", usuario_id=None)
        conn.execute("UPDATE pedidos SET pago_estado='cancelado_sin_pago' WHERE id=?", (c["id"],))
        crear_notificacion(
            conn, c["tienda_id"], "pedido_cancelado_sin_pago", c["id"],
            f"Pedido {c['numero']} cancelado automáticamente por falta de pago. El stock se ha devuelto.",
        )
        db.audit(conn, None, "pedido.cancelado_sin_pago", "pedido", c["id"], {"numero": c["numero"]})
        canceladas += 1
    return canceladas


def pedido_visible_domiciliario(conn, pedido_id: str) -> bool:
    from .roles import pago_listo_para_ruta

    p = _pedido_con_pago(conn, pedido_id)
    return (
        p["estado"] in ("preparado", "enviado")
        and p.get("tipo_entrega") in TIPOS_CON_ENVIO
        and pago_listo_para_ruta(p)
    )


def listar_ruta(conn, tienda_id: str) -> dict:
    """Hoja de ruta: pedidos preparados (o en reparto) con envío y pago listo para salir."""
    from .roles import pago_listo_para_ruta

    filas = all_rows(
        conn,
        """SELECT * FROM pedidos WHERE tienda_id=? AND estado IN ('preparado','enviado')
           AND tipo_entrega IN ('envio_propio','envio_transportista') ORDER BY created_at""",
        (tienda_id,),
    )
    items = []
    for f in filas:
        p = dict(f)
        if not pago_listo_para_ruta(p):
            continue
        d = _resumen_pago(p)
        cobro = _cobro_en_entrega(p)
        d.update({
            "cliente_telefono": p.get("cliente_telefono") or "",
            "direccion": p["direccion"], "ciudad": p["ciudad"], "cp": p["cp"], "provincia": p["provincia"],
            "notas": p.get("notas") or "",
            "importe_cobrar": cobro["importe"] if cobro["pendiente"] else 0.0,
            "cobro_pendiente": cobro["pendiente"],
            "envio_ya_pagado": p.get("envio_cobro") == "anticipado" and bool(p.get("envio_pagado")),
        })
        items.append(d)
    return {"items": items}


def _pago_vencido(pedido: dict) -> bool:
    from datetime import datetime as _dt

    from .util import parse_dt

    if pedido.get("pago_estado") not in ("pendiente_verificacion", "pendiente_pago_web") or not pedido.get("pago_vence_at"):
        return False
    return parse_dt(pedido["pago_vence_at"]) <= _dt.now().astimezone()


def _resumen_pago(fila) -> dict:
    d = dict(fila)
    d["pago_vencido"] = _pago_vencido(d)
    d["total"] = money(d["total"])
    d["envio"] = money(d.get("envio") or 0)
    d["envio_pendiente"] = bool(d.get("envio_pendiente"))
    cobro = _cobro_en_entrega(d)
    d["a_cobrar"] = cobro["importe"] if cobro["pendiente"] else None
    d["estado_label"] = ESTADOS.get(d["estado"], d["estado"])
    d["metodo_pago_label"] = METODOS.get(d["metodo_pago"], d["metodo_pago"])
    d["pago_estado_label"] = PAGO_ESTADOS.get(d.get("pago_estado") or "", "")
    d.pop("token", None)
    return d


def listar_pagos(conn, tienda_id: str) -> dict:
    """Pedidos pendientes de verificar (transferencia y cartera) y de cobro (contrareembolso)."""
    por_verificar = all_rows(
        conn,
        """SELECT * FROM pedidos WHERE tienda_id=? AND pago_estado='pendiente_verificacion'
           AND estado<>'cancelado' ORDER BY created_at""",
        (tienda_id,),
    )
    envios_anticipados = all_rows(
        conn,
        """SELECT * FROM pedidos WHERE tienda_id=? AND envio_cobro='anticipado' AND envio_pagado=0
           AND envio_pendiente=0 AND estado<>'cancelado' ORDER BY created_at""",
        (tienda_id,),
    )
    en_entrega = all_rows(
        conn,
        """SELECT * FROM pedidos WHERE tienda_id=? AND estado<>'cancelado' AND (
             pago_estado='pendiente_cobro'
             OR (envio_cobro='entrega' AND envio_cobrado=0 AND envio_pendiente=0 AND tipo_entrega IN ('envio_propio','envio_transportista'))
           ) ORDER BY created_at""",
        (tienda_id,),
    )
    return {
        "por_verificar": [_resumen_pago(f) for f in por_verificar],
        "envios_por_verificar": [_resumen_pago(f) for f in envios_anticipados],
        "contrareembolso": [_resumen_pago(f) for f in en_entrega],
    }


# ----------------------------------------------------------------------
# Notificaciones del backoffice

def crear_notificacion(conn, tienda_id: str, tipo: str, referencia: str, texto: str) -> None:
    conn.execute(
        "INSERT INTO notificaciones (id, tienda_id, tipo, referencia, texto, leida, created_at) VALUES (?,?,?,?,?,0,?)",
        (new_id("NOT"), tienda_id, tipo, referencia, txt(texto, 240), iso_now()),
    )


def listar_notificaciones(conn, tienda_id: str, limite: int = 30) -> dict:
    filas = all_rows(
        conn,
        "SELECT * FROM notificaciones WHERE tienda_id=? ORDER BY created_at DESC, rowid DESC LIMIT ?",
        (tienda_id, limite),
    )
    no_leidas = one(conn, "SELECT COUNT(*) AS n FROM notificaciones WHERE tienda_id=? AND leida=0", (tienda_id,))["n"]
    return {"items": [dict(f) for f in filas], "no_leidas": int(no_leidas)}


def marcar_notificaciones_leidas(conn, tienda_id: str) -> None:
    conn.execute("UPDATE notificaciones SET leida=1 WHERE tienda_id=? AND leida=0", (tienda_id,))

# ----------------------------------------------------------------------
# Chat interno del pedido (cliente <-> administrador)
def listar_chat(conn, pedido_id: str) -> list[dict]:
    filas = all_rows(
        conn,
        """SELECT c.*, u.nombre AS usuario_nombre FROM pedido_chat c
           LEFT JOIN usuarios u ON u.id=c.usuario_id
           WHERE c.pedido_id=? ORDER BY c.created_at ASC, c.rowid ASC""",
        (pedido_id,),
    )
    out = []
    for f in filas:
        d = dict(f)
        d["autor"] = d.get("autor_nombre") or d.get("usuario_nombre") or ("Administrador" if d["autor_rol"] != "cliente" else "Cliente")
        out.append(d)
    return out


def enviar_mensaje(conn, pedido_id: str, usuario: dict, mensaje: str) -> dict:
    texto = txt(mensaje, 1000)
    if len(texto) < 1:
        raise ApiError("El mensaje no puede estar vacío")
    pid = new_id("CHT")
    sello = iso_now()
    rol = usuario.get("rol", "cliente")
    autor_rol = "cliente" if rol == "cliente" else "admin"
    conn.execute(
        "INSERT INTO pedido_chat (id, pedido_id, usuario_id, autor_rol, autor_nombre, mensaje, created_at) VALUES (?,?,?,?,?,?,?)",
        (pid, pedido_id, usuario.get("id"), autor_rol, usuario.get("nombre", ""), texto, sello),
    )
    db.audit(conn, usuario.get("id"), "pedido.chat", "pedido", pedido_id, {"mensaje": texto[:120]})
    return {"id": pid, "pedido_id": pedido_id, "autor_rol": autor_rol, "autor_nombre": usuario.get("nombre", ""), "mensaje": texto, "created_at": sello}
