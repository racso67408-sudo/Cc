"""Genera las ilustraciones SVG del catálogo de demostración (sin dependencias)."""
from __future__ import annotations

from html import escape
from pathlib import Path

OUT = Path(__file__).resolve().parent.parent / "static" / "img" / "products"

PALETAS = {
    "limpieza": ("#e2eee7", "#f8fbf8", "#1d5b45", "#79a891"),
    "higiene": ("#e0edf6", "#f8fbfd", "#2c5c88", "#86aecb"),
    "desechables": ("#eae6f4", "#fbf9fd", "#63548c", "#b0a4cf"),
    "empaque": ("#f5e7d8", "#fdf8f2", "#b9672f", "#dda678"),
    "seguridad": ("#f4edda", "#fdfbf4", "#8a6a1e", "#d2b76b"),
    "papeleria": ("#f6e4df", "#fdf8f6", "#a94f3e", "#dda093"),
}


def base(tipo: str, etiqueta: str, titulo: str) -> tuple[str, str, str, str, str]:
    bg1, bg2, acento, suave = PALETAS[tipo]
    cabecera = f'''<defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="{bg1}"/><stop offset="0.72" stop-color="{bg2}"/>
    </linearGradient>
    <linearGradient id="body" x1="0" y1="0" x2="1" y2="0.3">
      <stop offset="0" stop-color="{acento}"/><stop offset="0.55" stop-color="{suave}"/><stop offset="1" stop-color="{acento}"/>
    </linearGradient>
    <linearGradient id="paper" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#fffef9"/><stop offset="1" stop-color="#f5efe3"/>
    </linearGradient>
    <pattern id="grid" width="32" height="32" patternUnits="userSpaceOnUse">
      <path d="M32 0H0V32" fill="none" stroke="{acento}" stroke-opacity="0.055" stroke-width="1"/>
    </pattern>
    <filter id="sh" x="-30%" y="-30%" width="160%" height="160%">
      <feDropShadow dx="0" dy="16" stdDeviation="18" flood-color="{acento}" flood-opacity="0.22"/>
    </filter>
    <filter id="soft" x="-30%" y="-30%" width="160%" height="160%">
      <feDropShadow dx="0" dy="5" stdDeviation="5" flood-color="{acento}" flood-opacity="0.18"/>
    </filter>
  </defs>
  <rect width="640" height="640" fill="url(#bg)"/>
  <circle cx="548" cy="96" r="188" fill="#ffffff" opacity="0.34"/>
  <circle cx="76" cy="574" r="150" fill="{acento}" opacity="0.055"/>
  <rect width="640" height="640" fill="url(#grid)"/>
  <ellipse cx="320" cy="524" rx="150" ry="24" fill="{acento}" opacity="0.16"/>
  <text x="46" y="58" font-family="Arial, Helvetica, sans-serif" font-size="11" font-weight="700"
        letter-spacing="3" fill="{acento}" opacity="0.65">CC · SHOPS</text>
  <text x="594" y="600" text-anchor="end" font-family="Arial, Helvetica, sans-serif" font-size="10"
        font-weight="700" letter-spacing="2.2" fill="{acento}" opacity="0.55">{escape(etiqueta)}</text>'''
    return bg1, bg2, acento, suave, cabecera


def texto(x, y, contenido, size=15, color="#ffffff", weight="700", anchor="middle", spacing="1.4"):
    return (
        f'<text x="{x}" y="{y}" text-anchor="{anchor}" font-family="Arial, Helvetica, sans-serif" '
        f'font-size="{size}" font-weight="{weight}" letter-spacing="{spacing}" fill="{color}">{escape(contenido)}</text>'
    )


def bottle(tipo, etiqueta, etiqueta_envase, sub, etiqueta_tipo="limpieza"):
    bg1, bg2, acento, suave, cab = base(etiqueta_tipo, etiqueta, etiqueta_envase)
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640" role="img" aria-label="{escape(etiqueta_envase)}">
  {cab}
  <g filter="url(#sh)">
    <rect x="252" y="238" width="152" height="262" rx="30" fill="url(#body)"/>
    <rect x="252" y="238" width="152" height="262" rx="30" fill="none" stroke="#ffffff" stroke-opacity="0.25"/>
    <rect x="292" y="196" width="72" height="52" rx="7" fill="{acento}" opacity="0.85"/>
    <rect x="284" y="170" width="88" height="30" rx="8" fill="{acento}"/>
    <rect x="292" y="176" width="72" height="5" rx="2.5" fill="#ffffff" opacity="0.22"/>
    <rect x="270" y="296" width="116" height="132" rx="12" fill="url(#paper)" filter="url(#soft)"/>
    <rect x="270" y="296" width="116" height="9" rx="4" fill="{suave}"/>
    {texto(328, 336, envase.split()[0], 14, acento)}
    {texto(328, 360, "PROFESIONAL", 7.2, "#7c847c", "700", spacing="1.1")}
    <rect x="288" y="378" width="80" height="2" fill="{acento}" opacity="0.22"/>
    {texto(328, 397, sub, 10, acento, "700")}
    <path d="M294 407h68M304 414h48" stroke="{acento}" stroke-opacity="0.18" stroke-width="2"/>
  </g>
</svg>'''


def spray(tipo, etiqueta, etiqueta_envase, sub):
    bg1, bg2, acento, suave, cab = base("limpieza", etiqueta, etiqueta_envase)
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640" role="img" aria-label="{escape(etiqueta_envase)}">
  {cab}
  <g filter="url(#sh)">
    <rect x="258" y="246" width="146" height="254" rx="28" fill="url(#body)"/>
    <rect x="292" y="210" width="78" height="42" rx="6" fill="{acento}" opacity="0.9"/>
    <rect x="286" y="178" width="90" height="34" rx="8" fill="{acento}"/>
    <path d="M258 200 L204 200 Q188 200 188 216 L188 222 Q188 234 200 234 L258 234 L258 206 Z" fill="{acento}"/>
    <path d="M188 212 L172 212" stroke="{acento}" stroke-width="7" stroke-linecap="round"/>
    <rect x="276" y="300" width="112" height="138" rx="12" fill="url(#paper)" filter="url(#soft)"/>
    <rect x="276" y="300" width="112" height="9" rx="4" fill="{suave}"/>
    {texto(332, 340, etiqueta_envase.split()[0], 13, acento)}
    {texto(332, 362, "SPRAY", 8.5, "#7c847c", "700", spacing="1.3")}
    <rect x="294" y="382" width="76" height="2" fill="{acento}" opacity="0.22"/>
    {texto(332, 402, sub, 10, acento, "700")}
    <path d="M300 414h64M310 421h44" stroke="{acento}" stroke-opacity="0.18" stroke-width="2"/>
  </g>
</svg>'''


def pump(tipo, etiqueta, etiqueta_envase, sub):
    bg1, bg2, acento, suave, cab = base(tipo, etiqueta, etiqueta_envase)
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640" role="img" aria-label="{escape(etiqueta_envase)}">
  {cab}
  <g filter="url(#sh)">
    <rect x="250" y="248" width="160" height="252" rx="28" fill="url(#body)"/>
    <rect x="296" y="212" width="68" height="44" rx="5" fill="{acento}" opacity="0.9"/>
    <rect x="282" y="194" width="96" height="24" rx="8" fill="{acento}"/>
    <path d="M362 200 L410 200" stroke="{acento}" stroke-width="12" stroke-linecap="round"/>
    <rect x="320" y="238" width="20" height="22" fill="{acento}"/>
    <rect x="274" y="300" width="112" height="130" rx="12" fill="url(#paper)" filter="url(#soft)"/>
    <rect x="274" y="300" width="112" height="9" rx="4" fill="{suave}"/>
    {texto(330, 338, etiqueta_envase.split()[0], 13, acento)}
    {texto(330, 360, "HIDRATANTE", 7.3, "#7c847c", "700", spacing="1.1")}
    <rect x="292" y="380" width="76" height="2" fill="{acento}" opacity="0.22"/>
    {texto(330, 400, sub, 10, acento, "700")}
    <path d="M288 440h84" stroke="{acento}" stroke-opacity="0.2" stroke-width="2"/>
  </g>
</svg>'''


def jerry(tipo, etiqueta, etiqueta_envase, sub):
    bg1, bg2, acento, suave, cab = base("limpieza", etiqueta, etiqueta_envase)
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640" role="img" aria-label="{escape(etiqueta_envase)}">
  {cab}
  <g filter="url(#sh)">
    <rect x="208" y="228" width="224" height="272" rx="22" fill="url(#body)"/>
    <path d="M208 260 L208 228 L250 228 M432 260 L432 228 L390 228" fill="none" stroke="{acento}" stroke-width="8" stroke-linejoin="round"/>
    <rect x="286" y="192" width="68" height="42" rx="5" fill="{acento}"/>
    <rect x="274" y="182" width="92" height="16" rx="5" fill="{acento}"/>
    <path d="M238 228 Q238 196 270 196 L274 196" fill="none" stroke="{acento}" stroke-width="9" stroke-linecap="round"/>
    <rect x="246" y="306" width="148" height="124" rx="10" fill="url(#paper)" filter="url(#soft)"/>
    <rect x="246" y="306" width="148" height="10" rx="4" fill="{suave}"/>
    {texto(320, 346, etiqueta_envase.split()[0], 14, acento)}
    {texto(320, 368, "CONCENTRADO", 7.2, "#7c847c", "700", spacing="1.1")}
    {texto(320, 394, sub, 20, acento)}
    <rect x="270" y="408" width="100" height="2" fill="{acento}" opacity="0.22"/>
    <path d="M274 456h92M286 465h68" stroke="{acento}" stroke-opacity="0.18" stroke-width="3"/>
  </g>
</svg>'''


def caja(etiqueta_tipo, etiqueta, envase, sub, tipo_caja="guantes"):
    bg1, bg2, acento, suave, cab = base(etiqueta_tipo, etiqueta, envase)
    extra = ""
    if tipo_caja == "mascarillas":
        extra = f'''<g filter="url(#soft)">
          <rect x="264" y="214" width="112" height="57" rx="20" fill="#f7f7f2" stroke="{acento}" stroke-opacity="0.35"/>
          <path d="M260 232h-14M380 232h14" stroke="{acento}" stroke-width="4" stroke-linecap="round"/>
          <path d="M282 232h76M300 246h40" stroke="{acento}" stroke-opacity="0.22" stroke-width="3"/>
        </g>'''
    elif tipo_caja == "cajas":
        extra = f'''<path d="M236 206 L320 172 L404 206 L404 236 L320 270 L236 236 Z" fill="url(#paper)" stroke="{acento}" stroke-opacity="0.25"/>'''
    else:
        extra = f'''<g filter="url(#soft)" fill="#f8f7f2" stroke="{acento}" stroke-opacity="0.3">
          <path d="M266 220 q10 -26 34 -26 q22 0 22 24 l0 26 l-56 0Z"/>
          <path d="M300 236 l0 22 M292 244 l0 16 M308 244 l0 16" stroke-width="2"/>
        </g>'''
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640" role="img" aria-label="{escape(envase)}">
  {cab}
  {extra}
  <g filter="url(#sh)">
    <path d="M196 260 L320 212 L444 260 L444 476 L320 524 L196 476 Z" fill="url(#body)"/>
    <path d="M196 260 L320 308 L444 260" fill="none" stroke="#ffffff" stroke-opacity="0.35" stroke-width="2"/>
    <path d="M320 308 L320 524" stroke="#ffffff" stroke-opacity="0.22" stroke-width="2"/>
    <path d="M320 212 L320 260" stroke="{acento}" stroke-opacity="0.2" stroke-width="2"/>
    <rect x="236" y="338" width="168" height="112" rx="10" fill="url(#paper)" filter="url(#soft)"/>
    <rect x="236" y="338" width="168" height="9" rx="4" fill="{suave}"/>
    {texto(320, 376, envase.split()[0], 15, acento)}
    {texto(320, 399, sub, 7.5, "#7c847c", "700", spacing="1.1")}
    <rect x="264" y="416" width="112" height="2" fill="{acento}" opacity="0.2"/>
    {texto(320, 436, "PRO", 9, acento, "800")}
  </g>
</svg>'''


def rollo(etiqueta_tipo, etiqueta, envase, sub, transparente=False, basura=False):
    bg1, bg2, acento, suave, cab = base(etiqueta_tipo, etiqueta, envase)
    cuerpo = "#f4f5ee" if transparente else ("#3b423d" if basura else "url(#body)")
    cuerpo_borde = "#d5d8ce" if transparente else acento
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640" role="img" aria-label="{escape(envase)}">
  {cab}
  <g filter="url(#sh)">
    <path d="M204 268 L204 438 A116 42 0 0 0 436 438 L436 268" fill="{cuerpo}" stroke="{cuerpo_borde}" stroke-opacity="0.35"/>
    <ellipse cx="320" cy="268" rx="116" ry="42" fill="{suave if not basura else '#525a54'}"/>
    <ellipse cx="320" cy="268" rx="58" ry="20" fill="{bg2}"/>
    <ellipse cx="320" cy="268" rx="58" ry="20" fill="none" stroke="{acento}" stroke-opacity="0.25" stroke-width="3"/>
    <path d="M436 300 L500 348 L500 454 L456 432 L436 390 Z" fill="#fffef9" opacity="0.92" stroke="{acento}" stroke-opacity="0.15"/>
    <rect x="252" y="330" width="136" height="86" rx="9" fill="url(#paper)" filter="url(#soft)" opacity="{0.55 if transparente else 1}"/>
    <rect x="252" y="330" width="136" height="8" rx="4" fill="{suave}"/>
    {texto(320, 362, envase.split()[0], 13, acento)}
    {texto(320, 382, sub, 9, "#7c847c", "700", spacing="1.1")}
    <path d="M278 400h84" stroke="{acento}" stroke-opacity="0.2" stroke-width="2"/>
  </g>
</svg>'''


def bolsa(etiqueta_tipo, etiqueta, envase, sub):
    bg1, bg2, acento, suave, cab = base("empaque", etiqueta, envase)
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640" role="img" aria-label="{escape(envase)}">
  {cab}
  <g filter="url(#sh)">
    <path d="M226 248 L414 248 L438 494 L202 494 Z" fill="url(#body)"/>
    <path d="M226 248 L414 248 L406 278 L234 278 Z" fill="{acento}" opacity="0.28"/>
    <path d="M258 248 Q258 198 292 198 M382 248 Q382 198 348 198" fill="none" stroke="{acento}" stroke-width="9" stroke-linecap="round" opacity="0.8"/>
    <rect x="258" y="326" width="124" height="118" rx="9" fill="url(#paper)" filter="url(#soft)"/>
    <rect x="258" y="326" width="124" height="9" rx="4" fill="{suave}"/>
    {texto(320, 360, envase.split()[0], 13, acento)}
    {texto(320, 382, "KRAFT", 8, "#7c847c", "700", spacing="1.2")}
    <path d="M282 402h76" stroke="{acento}" stroke-opacity="0.2" stroke-width="2"/>
    {texto(320, 424, sub, 9, acento, "700")}
  </g>
</svg>'''


def vasos(etiqueta_tipo, etiqueta, envase, sub, cubiertos=False):
    bg1, bg2, acento, suave, cab = base("desechables", etiqueta, envase)
    if cubiertos:
        dibujo = f'''<g filter="url(#sh)">
          <rect x="206" y="330" width="228" height="150" rx="18" fill="url(#body)"/>
          <rect x="206" y="330" width="228" height="16" fill="{acento}" opacity="0.3"/>
          <g stroke="#c99a62" stroke-width="9" stroke-linecap="round">
            <path d="M244 300 l0 100 M238 300 l0 26 M250 300 l0 26"/>
            <path d="M320 300 l0 100 M320 274 l0 26"/>
            <path d="M396 300 l0 100 M396 300 q-14 8 -14 28 q0 20 14 22 M396 300 q14 8 14 28 q0 20 -14 22"/>
          </g>
          <rect x="236" y="394" width="168" height="52" rx="7" fill="url(#paper)"/>
          {texto(320, 418, envase.split()[0], 12, acento)}
          {texto(320, 435, sub, 8, "#7c847c", "700")}
        </g>'''
    else:
        dibujo = f'''<g filter="url(#sh)">
          <path d="M232 262 L408 262 L386 486 L254 486 Z" fill="url(#body)"/>
          <path d="M254 300 L386 300 L382 348 L258 348 Z" fill="{suave}" opacity="0.55"/>
          <path d="M244 392 L396 392 L392 440 L248 440 Z" fill="{acento}" opacity="0.24"/>
          <ellipse cx="320" cy="262" rx="88" ry="20" fill="{suave}"/>
          <ellipse cx="320" cy="262" rx="68" ry="14" fill="{bg2}"/>
          <rect x="264" y="358" width="112" height="70" rx="8" fill="url(#paper)" opacity="0.95"/>
          {texto(320, 384, envase.split()[0], 12, acento)}
          {texto(320, 402, sub, 8, "#7c847c", "700")}
          <path d="M292 416h56" stroke="{acento}" stroke-opacity="0.2" stroke-width="2"/>
        </g>'''
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640" role="img" aria-label="{escape(envase)}">
  {cab}
  {dibujo}
</svg>'''


def bayetas(etiqueta_tipo, etiqueta, envase, sub):
    bg1, bg2, acento, suave, cab = base("limpieza", etiqueta, envase)
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640" role="img" aria-label="{escape(envase)}">
  {cab}
  <g filter="url(#sh)">
    <rect x="198" y="300" width="244" height="176" rx="24" fill="{acento}" opacity="0.30" transform="rotate(-7 320 388)"/>
    <rect x="206" y="288" width="238" height="170" rx="24" fill="{suave}" opacity="0.75" transform="rotate(-3 320 372)"/>
    <rect x="214" y="276" width="230" height="164" rx="22" fill="url(#body)" transform="rotate(2 320 358)"/>
    <path d="M226 322 q28 -18 56 0 t56 0 t56 0 t46 0" fill="none" stroke="#ffffff" stroke-opacity="0.28" stroke-width="5"/>
    <rect x="260" y="330" width="132" height="70" rx="9" fill="url(#paper)" filter="url(#soft)" transform="rotate(2 320 358)"/>
    {texto(326, 362, envase.split()[0], 13, acento)}
    {texto(326, 383, sub, 8.5, "#7c847c", "700")}
    <path d="M250 390 q22 14 44 0 t44 0 t44 0" fill="none" stroke="#ffffff" stroke-opacity="0.22" stroke-width="4"/>
  </g>
</svg>'''


def toallitas(etiqueta_tipo, etiqueta, envase, sub):
    bg1, bg2, acento, suave, cab = base("higiene", etiqueta, envase)
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640" role="img" aria-label="{escape(envase)}">
  {cab}
  <g filter="url(#sh)">
    <rect x="196" y="266" width="248" height="212" rx="24" fill="url(#body)"/>
    <rect x="196" y="266" width="248" height="34" rx="17" fill="{suave}" opacity="0.6"/>
    <ellipse cx="320" cy="300" rx="62" ry="16" fill="{bg2}" opacity="0.9"/>
    <path d="M288 300 q32 -34 64 0 q-32 30 -64 0" fill="#fffef9" opacity="0.9"/>
    <rect x="222" y="350" width="196" height="90" rx="11" fill="url(#paper)" filter="url(#soft)"/>
    <rect x="222" y="350" width="196" height="9" rx="4" fill="{suave}"/>
    {texto(320, 383, envase.split()[0], 14, acento)}
    {texto(320, 404, sub, 8, "#7c847c", "700")}
    <path d="M254 420h132" stroke="{acento}" stroke-opacity="0.2" stroke-width="2"/>
    <path d="M444 340 q32 8 32 40" fill="none" stroke="{acento}" stroke-opacity="0.35" stroke-width="4"/>
  </g>
</svg>'''


def cinta(etiqueta_tipo, etiqueta, envase, sub):
    bg1, bg2, acento, suave, cab = base("seguridad", etiqueta, envase)
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640" role="img" aria-label="{escape(envase)}">
  {cab}
  <g filter="url(#sh)">
    <path d="M188 350 L500 270 L520 350 L208 430 Z" fill="url(#body)"/>
    <g stroke="#222b25" stroke-opacity="0.45" stroke-width="10">
      <path d="M230 356 L258 292"/><path d="M286 342 L314 278"/><path d="M342 328 L370 264"/><path d="M398 314 L426 250"/><path d="M454 300 L482 236"/>
    </g>
    <circle cx="470" cy="354" r="96" fill="{acento}"/>
    <circle cx="470" cy="354" r="58" fill="{bg2}"/>
    <circle cx="470" cy="354" r="58" fill="none" stroke="{acento}" stroke-opacity="0.3" stroke-width="6"/>
    <circle cx="470" cy="354" r="16" fill="{acento}" opacity="0.3"/>
    <rect x="202" y="392" width="164" height="56" rx="9" fill="url(#paper)" filter="url(#soft)" transform="rotate(-14 284 420)"/>
    {texto(284, 416, envase.split()[0], 12, acento, anchor="middle")}
    {texto(284, 432, sub, 8, "#7c847c", "700")}
  </g>
</svg>'''


def cutter(etiqueta_tipo, etiqueta, envase, sub):
    bg1, bg2, acento, suave, cab = base("seguridad", etiqueta, envase)
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640" role="img" aria-label="{escape(envase)}">
  {cab}
  <g filter="url(#sh)" transform="rotate(-18 320 340)">
    <rect x="206" y="300" width="270" height="86" rx="28" fill="url(#body)"/>
    <rect x="206" y="300" width="270" height="86" rx="28" fill="none" stroke="#ffffff" stroke-opacity="0.2"/>
    <rect x="250" y="322" width="118" height="42" rx="9" fill="{acento}" opacity="0.75"/>
    <path d="M476 326 L566 342 L566 366 L476 356 Z" fill="#d9ded8" stroke="{acento}" stroke-opacity="0.35" stroke-width="2"/>
    <path d="M260 332 l64 0" stroke="#ffffff" stroke-opacity="0.5" stroke-width="4" stroke-linecap="round"/>
    <circle cx="246" cy="343" r="12" fill="{bg2}" opacity="0.8"/>
  </g>
  <rect x="220" y="470" width="200" height="54" rx="9" fill="url(#paper)" filter="url(#soft)"/>
  {texto(320, 495, envase.split()[0], 12, acento)}
  {texto(320, 512, sub, 8, "#7c847c", "700")}
</svg>'''


def etiquetas(etiqueta_tipo, etiqueta, envase, sub):
    bg1, bg2, acento, suave, cab = base("papeleria", etiqueta, envase)
    filas = []
    for fila in range(3):
        for col in range(2):
            x = 238 + col * 88
            y = 286 + fila * 62
            filas.append(f'<rect x="{x}" y="{y}" width="76" height="48" rx="6" fill="#f7f3e9" stroke="{acento}" stroke-opacity="0.22"/>')
            filas.append(f'<path d="M{x+10} {y+16} h40 M{x+10} {y+28} h28 M{x+10} {y+38} h48" stroke="{acento}" stroke-opacity="0.18" stroke-width="2"/>')
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640" role="img" aria-label="{escape(envase)}">
  {cab}
  <g filter="url(#sh)">
    <rect x="214" y="262" width="212" height="238" rx="15" fill="url(#body)" transform="rotate(-4 320 380)"/>
    <rect x="224" y="270" width="212" height="238" rx="15" fill="url(#paper)" transform="rotate(-2 330 388)"/>
    {''.join(filas)}
    <rect x="244" y="470" width="124" height="3" fill="{acento}" opacity="0.2"/>
    {texto(306, 490, envase.split()[0], 10, acento)}
  </g>
</svg>'''


def cuaderno(etiqueta_tipo, etiqueta, envase, sub):
    bg1, bg2, acento, suave, cab = base("papeleria", etiqueta, envase)
    anillas = "".join(f'<circle cx="248" cy="{290 + i*26}" r="6" fill="none" stroke="{acento}" stroke-width="3" opacity="0.6"/>' for i in range(9))
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640" role="img" aria-label="{escape(envase)}">
  {cab}
  <g filter="url(#sh)">
    <rect x="240" y="238" width="226" height="286" rx="14" fill="url(#body)" transform="rotate(3 350 380)"/>
    <rect x="232" y="246" width="218" height="286" rx="12" fill="url(#paper)" transform="rotate(-2 340 390)"/>
    <rect x="232" y="246" width="218" height="286" rx="12" fill="none" stroke="{acento}" stroke-opacity="0.18"/>
    {anillas}
    <rect x="286" y="316" width="134" height="120" rx="8" fill="{acento}" opacity="0.1"/>
    {texto(353, 360, envase.split()[0], 14, acento)}
    {texto(353, 384, "INVENTARIO", 8.5, "#7c847c", "700", spacing="1.1")}
    <path d="M310 405h86" stroke="{acento}" stroke-opacity="0.2" stroke-width="2"/>
    {texto(353, 520, "A4", 11, acento, "800")}
  </g>
</svg>'''


ARCHIVOS = {
    "multiusos.svg": lambda: spray("limpieza", "MULTIUSOS", "LIMPIADOR MULTIUSOS", "750 ML"),
    "detergente.svg": lambda: jerry("limpieza", "DETERGENTE", "DETERGENTE 5 L", "5 L"),
    "gel.svg": lambda: pump("limpieza", "GEL", "GEL HIDROALCOHÓLICO", "500 ML"),
    "ambientador.svg": lambda: spray("limpieza", "LAVANDA", "AMBIENTADOR LAVANDA", "400 ML"),
    "bayetas.svg": lambda: bayetas("limpieza", "MICROFIBRA", "BAYETAS MICROFIBRA", "PACK 10"),
    "jabon.svg": lambda: pump("higiene", "JABÓN", "JABÓN DE MANOS", "1 L"),
    "papel.svg": lambda: rollo("higiene", "SECAMANOS", "PAPEL SECAMANOS", "6 ROLLOS"),
    "toallitas.svg": lambda: toallitas("higiene", "DESINFECTA", "TOALLITAS 100 UDS", "PACK 100"),
    "guantes.svg": lambda: caja("desechables", "NITRILO", "GUANTES NITRILO", "TALLA M · 100 UDS", "guantes"),
    "mascarillas.svg": lambda: caja("desechables", "QUIRÚRGICA", "MASCARILLAS 50 UDS", "3 CAPAS · BFE 95%", "mascarillas"),
    "vasos.svg": lambda: vasos("desechables", "COMPOSTABLE", "VASOS 200 ML", "50 UDS"),
    "cubiertos.svg": lambda: vasos("desechables", "MADERA", "CUBIERTOS MADERA", "PACK 50", cubiertos=True),
    "film.svg": lambda: rollo("empaque", "FILM", "FILM TRANSPARENTE", "30 CM · 300 M", transparente=True),
    "bolsas-kraft.svg": lambda: bolsa("empaque", "KRAFT", "BOLSAS KRAFT", "100 UDS"),
    "bolsas-basura.svg": lambda: rollo("empaque", "INDUSTRIAL", "BOLSAS 120 L", "25 UDS", basura=True),
    "cajas.svg": lambda: caja("empaque", "CARTÓN", "CAJAS 40x30x30", "PACK 10", "cajas"),
    "cinta.svg": lambda: cinta("seguridad", "SEÑALIZA", "CINTA SEÑALIZACIÓN", "50 MM · 33 M"),
    "cutter.svg": lambda: cutter("seguridad", "SAFEPRO", "CÚTER SEGURIDAD", "HOJA RETRÁCTIL"),
    "etiquetas.svg": lambda: etiquetas("papeleria", "ADHESIVAS", "ETIQUETAS 70x36", "500 UDS"),
    "cuaderno.svg": lambda: cuaderno("papeleria", "INVENTARIO", "CUADERNO A4", "100 HOJAS"),
}


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    for nombre, fabrica in ARCHIVOS.items():
        (OUT / nombre).write_text(fabrica(), encoding="utf-8")
    print(f"{len(ARCHIVOS)} ilustraciones generadas en {OUT}")


if __name__ == "__main__":
    main()
