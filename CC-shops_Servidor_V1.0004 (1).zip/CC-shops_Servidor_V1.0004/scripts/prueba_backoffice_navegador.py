"""Prueba del backoffice en un navegador real (opcional, requiere Playwright y el servidor en marcha).

Uso:
  CC_ADMIN_PASSWORD=... python3 app.py          # en otra terminal
  python3 scripts/prueba_backoffice_navegador.py --email admin@ccshops.es --password '...'

Comprueba: login, crear y editar producto, crear categoría, guardar tema de tienda,
abrir pedido, nueva compra, inventario, métricas y movimientos (kardex).
Crea datos de prueba («Lampara UI Test», «Categoria UI Test») en la tienda indicada.
"""
import argparse
import sys

from playwright.sync_api import sync_playwright


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--url", default="http://127.0.0.1:8123")
    parser.add_argument("--email", required=True)
    parser.add_argument("--password", required=True)
    args = parser.parse_args()
    base = args.url.rstrip("/")
    resultados = []

    def paso(nombre, ok, detalle=""):
        resultados.append(ok)
        print(("OK    " if ok else "FALLO "), nombre, detalle)

    with sync_playwright() as p:
        navegador = p.chromium.launch()
        ctx = navegador.new_context(viewport={"width": 1440, "height": 900})
        page = ctx.new_page()
        errores = []
        page.on("pageerror", lambda e: errores.append(str(e)))
        page.goto(f"{base}/admin", wait_until="networkidle")
        page.fill("#lg-email", args.email)
        page.fill("#lg-pass", args.password)
        page.click("button[type=submit]")
        page.wait_for_timeout(1500)
        paso("login", page.locator(".admin-content").count() > 0)

        page.goto(f"{base}/admin#/productos", wait_until="networkidle")
        page.wait_for_timeout(900)
        page.click("#new-product-btn")
        page.wait_for_timeout(600)
        page.fill("input[name=nombre]", "Lampara UI Test")
        page.fill("input[name=precio]", "19.9")
        page.fill("input[name=coste]", "7")
        page.fill("input[name=stock_inicial]", "5")
        page.fill("input[name=stock_minimo]", "1")
        errores.clear()
        page.click("#save-product-btn")
        page.wait_for_timeout(1500)
        paso("crear producto", page.get_by_text("Lampara UI Test").count() > 0 and not errores, str(errores))

        page.reload(wait_until="networkidle")
        page.wait_for_timeout(900)
        page.locator("tr", has_text="Lampara UI Test").locator("[data-edit]").first.click()
        page.wait_for_timeout(700)
        page.fill("input[name=precio]", "24.5")
        errores.clear()
        page.click("#save-product-btn")
        page.wait_for_timeout(1500)
        page.goto(f"{base}/admin#/productos", wait_until="networkidle")
        page.wait_for_timeout(1000)
        fila = page.locator("tr", has_text="Lampara UI Test").inner_text()
        paso("editar precio (24,5 €)", "24,50" in fila and not errores, fila.replace("\n", " ")[:120])

        for ruta, nombre in [("#/pedidos", "pedidos"), ("#/compras/nueva", "nueva compra"),
                             ("#/inventario", "inventario"), ("#/metricas", "métricas"),
                             ("#/movimientos", "kardex/movimientos")]:
            errores.clear()
            page.goto(f"{base}/admin{ruta}", wait_until="networkidle")
            page.wait_for_timeout(1000)
            paso(nombre, page.locator(".admin-content").inner_text().strip() != "" and not errores, str(errores))

        navegador.close()
    total = sum(resultados)
    print(f"\nRESUMEN: {total} de {len(resultados)} correctas")
    return 0 if total == len(resultados) else 1


if __name__ == "__main__":
    sys.exit(main())
