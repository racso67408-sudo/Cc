"""Copia los datos de una base SQLite de CC-Shops a PostgreSQL.

Uso (desde la carpeta del proyecto):
    CC_DATABASE_URL=postgresql://usuario:clave@servidor:5432/ccshops \
    python3 scripts/migrar_a_postgres.py --origen data/cc_shops.db [--sin-confirmar]

Crea el esquema en PostgreSQL, vacía sus tablas y copia todas las filas de SQLite en una
sola transacción (las claves foráneas se comprueban al confirmar). Después compara el número
de filas de cada tabla. Si algo no cuadra, la transacción se revierte y no queda nada copiado.
"""
from __future__ import annotations

import argparse
import sqlite3
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from server import config  # noqa: E402

if not config.ES_POSTGRES:
    raise SystemExit("Define CC_DATABASE_URL=postgresql://... para la base de destino.")

from server import db, pgadapter  # noqa: E402


def tablas_sqlite(origen: sqlite3.Connection) -> list[str]:
    filas = origen.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").fetchall()
    return [f[0] for f in filas]


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--origen", required=True, help="Ruta del archivo SQLite de origen")
    ap.add_argument("--sin-confirmar", action="store_true", help="No pedir confirmación antes de vaciar el destino")
    args = ap.parse_args()

    origen_path = Path(args.origen)
    if not origen_path.exists():
        raise SystemExit(f"No existe el archivo de origen: {origen_path}")
    origen = sqlite3.connect(origen_path)
    origen.row_factory = sqlite3.Row
    tablas = tablas_sqlite(origen)

    # 1) Esquema en PostgreSQL (sin datos de demostración ni cuentas iniciales)
    db.init_db(seed_demo=False)
    destino = pgadapter.PgConnection(config.DATABASE_URL)
    existentes = [r["table_name"] for r in destino.execute(
        "SELECT table_name FROM information_schema.tables WHERE table_schema=current_schema()").fetchall()]
    if not args.sin_confirmar:
        resp = input(f"Se vaciarán {len(existentes)} tablas del destino y se copiarán {len(tablas)} tablas de {origen_path}. ¿Continuar? [escribe SI] ")
        if resp.strip() != "SI":
            raise SystemExit("Cancelado.")

    # 2) Copia en una transacción
    destino.execute("BEGIN")
    try:
        if existentes:
            destino.execute("TRUNCATE " + ", ".join(existentes) + " CASCADE")
        copiadas = {}
        for tabla in tablas:
            cols_sqlite = [c[1] for c in origen.execute(f"PRAGMA table_info({tabla})").fetchall()]
            cols_pg = set(db.columnas(destino, tabla))
            cols = [c for c in cols_sqlite if c in cols_pg]
            if not cols:
                continue
            filas = origen.execute(f"SELECT {', '.join(cols)} FROM {tabla} ORDER BY rowid").fetchall()
            if filas:
                marcas = ", ".join(["?"] * len(cols))
                sql = f"INSERT INTO {tabla} ({', '.join(cols)}) VALUES ({marcas})"
                for fila in filas:
                    destino.execute(sql, tuple(fila))
            copiadas[tabla] = len(filas)
        destino.execute("COMMIT")
    except Exception:
        destino.execute("ROLLBACK")
        raise

    # 3) Verificación: filas por tabla
    errores = []
    for tabla, n in copiadas.items():
        m = db.one(destino, f"SELECT COUNT(*) AS n FROM {tabla}")["n"]
        if m != n:
            errores.append(f"{tabla}: origen {n}, destino {m}")
    total = sum(copiadas.values())
    print(f"Tablas copiadas: {len(copiadas)} · filas: {total}")
    if errores:
        raise SystemExit("Diferencias: " + "; ".join(errores))
    print("Verificación correcta: el número de filas coincide en todas las tablas.")


if __name__ == "__main__":
    main()
