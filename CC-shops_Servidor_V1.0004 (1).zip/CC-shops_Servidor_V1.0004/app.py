"""CC-Shops · tienda online con backoffice e inventario Kardex.

Arranque:  python3 app.py
"""
from server.httpd import main

if __name__ == "__main__":
    main()
